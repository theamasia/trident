#!/usr/bin/env bash
set -euo pipefail

# ═══════════════════════════════════════════════════════════════════
#  ████████╗██████╗ ██╗██████╗ ███████╗███╗   ██╗████████╗
#  ╚══██╔══╝██╔══██╗██║██╔══██╗██╔════╝████╗  ██║╚══██╔══╝
#     ██║   ██████╔╝██║██║  ██║█████╗  ██╔██╗ ██║   ██║   
#     ██║   ██╔══██╗██║██║  ██║██╔══╝  ██║╚██╗██║   ██║   
#     ██║   ██║  ██║██║██████╔╝███████╗██║ ╚████║   ██║   
#     ╚═╝   ╚═╝  ╚═╝╚═╝╚═════╝ ╚══════╝╚═╝  ╚═══╝   ╚═╝   
#  VOICE PROCESSING MODULE — SETUP SCRIPT
#  Target: Ubuntu 24.04 LTS
# ═══════════════════════════════════════════════════════════════════

CYAN='\033[0;36m'
GREEN='\033[0;32m'
AMBER='\033[0;33m'
RED='\033[0;31m'
BOLD='\033[1m'
NC='\033[0m'

log_step() {
    echo -e "${CYAN}${BOLD}[ TRIDENT ]${NC} ${GREEN}>>>${NC} $1"
}

log_warn() {
    echo -e "${CYAN}${BOLD}[ TRIDENT ]${NC} ${AMBER}>>>${NC} $1"
}

log_error() {
    echo -e "${CYAN}${BOLD}[ TRIDENT ]${NC} ${RED}>>>${NC} $1"
}

log_done() {
    echo -e "${CYAN}${BOLD}[ TRIDENT ]${NC} ${GREEN}[✓]${NC} $1"
}

echo ""
echo -e "${CYAN}${BOLD}"
echo "  ╔══════════════════════════════════════════════════════╗"
echo "  ║   TRIDENT — VOICE PROCESSING MODULE INSTALLER       ║"
echo "  ║   Faster-Whisper STT + Piper TTS                    ║"
echo "  ║   Target: Ubuntu 24.04 LTS                          ║"
echo "  ╚══════════════════════════════════════════════════════╝"
echo -e "${NC}"

# ═══════════════════════════════════════════════════
# 1. Install system dependencies
# ═══════════════════════════════════════════════════
log_step "INSTALLING SYSTEM DEPENDENCIES..."
apt-get update -qq
apt-get install -y ffmpeg python3-pip python3-venv curl
log_done "System dependencies installed"

# ═══════════════════════════════════════════════════
# 2. Create Python venv for voice services
# ═══════════════════════════════════════════════════
log_step "CREATING PYTHON VIRTUAL ENVIRONMENT..."
mkdir -p /opt/trident-voice
python3 -m venv /opt/trident-voice/venv
source /opt/trident-voice/venv/bin/activate
log_done "Virtual environment created at /opt/trident-voice/venv"

# ═══════════════════════════════════════════════════
# 3. Install faster-whisper (local STT — no OpenAI API needed)
# ═══════════════════════════════════════════════════
log_step "INSTALLING FASTER-WHISPER (SPEECH-TO-TEXT ENGINE)..."
pip install faster-whisper
log_done "Faster-Whisper installed"

# ═══════════════════════════════════════════════════
# 4. Install piper-tts (local TTS)
# ═══════════════════════════════════════════════════
log_step "INSTALLING PIPER TTS (TEXT-TO-SPEECH ENGINE)..."
pip install piper-tts
log_done "Piper TTS installed"

# ═══════════════════════════════════════════════════
# 5. Download Piper voice models
# ═══════════════════════════════════════════════════
log_step "DOWNLOADING VOICE MODELS..."
mkdir -p /opt/trident-voice/voices
cd /opt/trident-voice/voices

log_step "  Downloading en_US-lessac-medium (~60MB)..."
curl -fsSL "https://huggingface.co/rhasspy/piper-voices/resolve/main/en/en_US/lessac/medium/en_US-lessac-medium.onnx" -o en_US-lessac-medium.onnx
curl -fsSL "https://huggingface.co/rhasspy/piper-voices/resolve/main/en/en_US/lessac/medium/en_US-lessac-medium.onnx.json" -o en_US-lessac-medium.onnx.json

log_step "  Downloading en_US-amy-medium (~60MB)..."
curl -fsSL "https://huggingface.co/rhasspy/piper-voices/resolve/main/en/en_US/amy/medium/en_US-amy-medium.onnx" -o en_US-amy-medium.onnx
curl -fsSL "https://huggingface.co/rhasspy/piper-voices/resolve/main/en/en_US/amy/medium/en_US-amy-medium.onnx.json" -o en_US-amy-medium.onnx.json

log_done "Voice models downloaded"

# ═══════════════════════════════════════════════════
# 6. Download Whisper tiny model (fastest, ~75MB)
# ═══════════════════════════════════════════════════
log_step "DOWNLOADING WHISPER TINY MODEL (~75MB)..."
mkdir -p /opt/trident-voice/whisper-models
python3 -c "
from faster_whisper import WhisperModel
model = WhisperModel('tiny', device='cpu', download_root='/opt/trident-voice/whisper-models')
print('Whisper tiny model downloaded')
"
log_done "Whisper tiny model cached"

# ═══════════════════════════════════════════════════
# 7. Create voice processing Python service script
# ═══════════════════════════════════════════════════
log_step "WRITING VOICE PROCESSING SERVICE..."

cat > /opt/trident-voice/voice_service.py << 'PYEOF'
#!/usr/bin/env python3
"""
TRIDENT Voice Processing Service
Exposes HTTP endpoints for STT and TTS
Runs on port 5001 (internal only, not exposed via Nginx)
"""
import os
import sys
import tempfile
import subprocess
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs
import json

WHISPER_MODEL_PATH = "/opt/trident-voice/whisper-models"
VOICES_PATH = "/opt/trident-voice/voices"
PORT = 5001

# Load Whisper model at startup
from faster_whisper import WhisperModel
print("Loading Whisper model...")
whisper_model = WhisperModel("tiny", device="cpu", download_root=WHISPER_MODEL_PATH)
print("Whisper model loaded.")

AVAILABLE_VOICES = {
    "lessac": os.path.join(VOICES_PATH, "en_US-lessac-medium.onnx"),
    "amy": os.path.join(VOICES_PATH, "en_US-amy-medium.onnx"),
}

class VoiceHandler(BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        pass  # Suppress default logging

    def do_POST(self):
        if self.path == "/stt":
            self._handle_stt()
        elif self.path.startswith("/tts"):
            self._handle_tts()
        else:
            self.send_response(404)
            self.end_headers()

    def _handle_stt(self):
        """Receive audio file, return transcript"""
        try:
            content_length = int(self.headers.get('Content-Length', 0))
            audio_data = self.rfile.read(content_length)

            with tempfile.NamedTemporaryFile(suffix='.webm', delete=False) as f:
                f.write(audio_data)
                tmp_path = f.name

            # Convert to wav for whisper
            wav_path = tmp_path + ".wav"
            subprocess.run([
                "ffmpeg", "-y", "-i", tmp_path, "-ar", "16000", "-ac", "1", wav_path
            ], capture_output=True, check=True)

            segments, info = whisper_model.transcribe(wav_path, beam_size=5)
            transcript = " ".join([seg.text for seg in segments]).strip()

            os.unlink(tmp_path)
            os.unlink(wav_path)

            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(json.dumps({"transcript": transcript}).encode())

        except Exception as e:
            self.send_response(500)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(json.dumps({"error": str(e)}).encode())

    def _handle_tts(self):
        """Receive text, return WAV audio"""
        try:
            content_length = int(self.headers.get('Content-Length', 0))
            body = json.loads(self.rfile.read(content_length))
            text = body.get("text", "")
            voice = body.get("voice", "lessac")

            voice_model = AVAILABLE_VOICES.get(voice, AVAILABLE_VOICES["lessac"])

            with tempfile.NamedTemporaryFile(suffix='.wav', delete=False) as f:
                out_path = f.name

            # Run piper
            proc = subprocess.run([
                "/opt/trident-voice/venv/bin/piper",
                "--model", voice_model,
                "--output_file", out_path
            ], input=text.encode(), capture_output=True)

            with open(out_path, 'rb') as f:
                audio_data = f.read()
            os.unlink(out_path)

            self.send_response(200)
            self.send_header("Content-Type", "audio/wav")
            self.send_header("Content-Length", str(len(audio_data)))
            self.end_headers()
            self.wfile.write(audio_data)

        except Exception as e:
            self.send_response(500)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(json.dumps({"error": str(e)}).encode())

if __name__ == "__main__":
    server = HTTPServer(("127.0.0.1", PORT), VoiceHandler)
    print(f"TRIDENT Voice Service running on port {PORT}")
    server.serve_forever()
PYEOF

chmod +x /opt/trident-voice/voice_service.py
log_done "Voice service script written"

# ═══════════════════════════════════════════════════
# 8. Create systemd service
# ═══════════════════════════════════════════════════
log_step "CONFIGURING SYSTEMD SERVICE..."

cat > /etc/systemd/system/trident-voice.service << 'EOF'
[Unit]
Description=TRIDENT Voice Processing Service
After=network.target trident.service

[Service]
Type=simple
User=trident
WorkingDirectory=/opt/trident-voice
ExecStart=/opt/trident-voice/venv/bin/python3 /opt/trident-voice/voice_service.py
Restart=always
RestartSec=10
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
EOF

# Create trident user if it doesn't exist
if ! id -u trident &>/dev/null; then
    log_warn "Creating 'trident' system user..."
    useradd --system --no-create-home --shell /bin/false trident
fi

chown -R trident:trident /opt/trident-voice
systemctl daemon-reload
systemctl enable trident-voice
systemctl start trident-voice

log_done "Systemd service enabled and started"

# ═══════════════════════════════════════════════════
# COMPLETE
# ═══════════════════════════════════════════════════
echo ""
echo -e "${CYAN}${BOLD}  ╔══════════════════════════════════════════════════════╗${NC}"
echo -e "${CYAN}${BOLD}  ║   ${GREEN}VOICE PROCESSING MODULE — ONLINE${CYAN}                  ║${NC}"
echo -e "${CYAN}${BOLD}  ╚══════════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "${GREEN}  Service running on port 5001 (internal only)${NC}"
echo ""
echo -e "${AMBER}  Test STT:${NC}"
echo -e "    curl -X POST http://localhost:5001/stt --data-binary @test.webm"
echo ""
echo -e "${AMBER}  Test TTS:${NC}"
echo -e "    curl -X POST http://localhost:5001/tts \\"
echo -e "      -H 'Content-Type: application/json' \\"
echo -e "      -d '{\"text\":\"TRIDENT system online\",\"voice\":\"lessac\"}' \\"
echo -e "      --output test.wav"
echo ""
echo -e "${CYAN}  Status: ${NC}systemctl status trident-voice"
echo -e "${CYAN}  Logs:   ${NC}journalctl -u trident-voice -f"
echo ""
