import { useState, useEffect } from "react";
import {
  Users,
  Shield,
  Trash2,
  ToggleLeft,
  ToggleRight,
  ChevronDown,
  ChevronUp,
  Activity,
  Server,
  Cpu,
  HardDrive,
  RefreshCw,
  MessageSquare,
  Image,
  FileText,
  Terminal,
} from "lucide-react";
import { useAuth, getAuthHeaders } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import type { SafeUser } from "@shared/schema";

const API_BASE = "__PORT_5000__".startsWith("__") ? "" : "__PORT_5000__";

// ═══════════════════════════════════════════════════
// HELPERS
// ═══════════════════════════════════════════════════
function formatBytes(bytes: number): string {
  if (!bytes) return "0 B";
  const gb = bytes / (1024 * 1024 * 1024);
  if (gb >= 1) return `${gb.toFixed(2)} GB`;
  const mb = bytes / (1024 * 1024);
  if (mb >= 1) return `${mb.toFixed(1)} MB`;
  const kb = bytes / 1024;
  return `${kb.toFixed(0)} KB`;
}

function formatUptime(seconds: number): string {
  const d = Math.floor(seconds / 86400);
  const h = Math.floor((seconds % 86400) / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const parts: string[] = [];
  if (d > 0) parts.push(`${d}d`);
  if (h > 0) parts.push(`${h}h`);
  parts.push(`${m}m`);
  return parts.join(" ");
}

// ═══════════════════════════════════════════════════
// TYPES
// ═══════════════════════════════════════════════════
interface SystemStats {
  users: { total: number; active: number; admins: number };
  conversations: { total: number; totalMessages: number };
  images: { total: number; totalSize: number };
  files: { total: number; totalSize: number };
  system: {
    uptime: number;
    nodeVersion: string;
    platform: string;
    memoryUsed: number;
    memoryTotal: number;
  };
}

interface UserStats {
  conversations: number;
  messages: number;
  images: number;
  files: number;
  storageBytes: number;
}

interface ServiceStatus {
  name: string;
  endpoint: string;
  status: "online" | "offline" | "checking";
  lastChecked: string;
}

// ═══════════════════════════════════════════════════
// PERSONNEL TAB (tab 1)
// ═══════════════════════════════════════════════════
function PersonnelTab() {
  const { user: currentUser } = useAuth();
  const { toast } = useToast();
  const [users, setUsers] = useState<SafeUser[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [deleteConfirm, setDeleteConfirm] = useState<number | null>(null);
  const [expandedUser, setExpandedUser] = useState<number | null>(null);
  const [userStats, setUserStats] = useState<Record<number, UserStats>>({});
  const [loadingStats, setLoadingStats] = useState<number | null>(null);

  const fetchUsers = async () => {
    try {
      const res = await fetch(`${API_BASE}/api/admin/users`, {
        headers: getAuthHeaders(),
      });
      if (!res.ok) throw new Error("FAILED TO LOAD");
      const data = await res.json();
      setUsers(data.users);
    } catch {
      toast({
        title: ">> ERROR",
        description: "FAILED TO LOAD PERSONNEL DATABASE",
        variant: "destructive",
        className: "border-[#ff2244] bg-trident-surface text-[#ff2244]",
      });
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  const fetchUserStats = async (userId: number) => {
    if (userStats[userId]) return;
    setLoadingStats(userId);
    try {
      const res = await fetch(`${API_BASE}/api/admin/user-stats/${userId}`, {
        headers: getAuthHeaders(),
      });
      if (!res.ok) throw new Error("FAILED");
      const stats = await res.json();
      setUserStats((prev) => ({ ...prev, [userId]: stats }));
    } catch {
      // silently fail
    } finally {
      setLoadingStats(null);
    }
  };

  const toggleExpand = (userId: number) => {
    if (expandedUser === userId) {
      setExpandedUser(null);
    } else {
      setExpandedUser(userId);
      fetchUserStats(userId);
    }
  };

  const handleRoleChange = async (userId: number, newRole: string) => {
    try {
      const res = await fetch(`${API_BASE}/api/admin/users/${userId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json", ...getAuthHeaders() },
        body: JSON.stringify({ role: newRole }),
      });
      if (!res.ok) throw new Error("FAILED");
      await fetchUsers();
      toast({
        title: ">> ROLE UPDATED",
        description: "CLEARANCE LEVEL MODIFIED",
        className: "terminal-text border-trident-border bg-trident-surface",
      });
    } catch {
      toast({
        title: ">> ERROR",
        description: "ROLE UPDATE FAILED",
        variant: "destructive",
        className: "border-[#ff2244] bg-trident-surface text-[#ff2244]",
      });
    }
  };

  const handleToggleActive = async (userId: number, currentlyActive: boolean) => {
    try {
      const res = await fetch(`${API_BASE}/api/admin/users/${userId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json", ...getAuthHeaders() },
        body: JSON.stringify({ is_active: !currentlyActive }),
      });
      if (!res.ok) throw new Error("FAILED");
      await fetchUsers();
      toast({
        title: currentlyActive ? ">> USER DEACTIVATED" : ">> USER ACTIVATED",
        description: "STATUS UPDATED",
        className: "terminal-text border-trident-border bg-trident-surface",
      });
    } catch {
      toast({
        title: ">> ERROR",
        description: "STATUS UPDATE FAILED",
        variant: "destructive",
        className: "border-[#ff2244] bg-trident-surface text-[#ff2244]",
      });
    }
  };

  const handleDelete = async (userId: number) => {
    try {
      const res = await fetch(`${API_BASE}/api/admin/users/${userId}`, {
        method: "DELETE",
        headers: getAuthHeaders(),
      });
      if (!res.ok) throw new Error("FAILED");
      setDeleteConfirm(null);
      await fetchUsers();
      toast({
        title: ">> USER ELIMINATED",
        description: "RECORD PURGED FROM DATABASE",
        className: "terminal-text border-trident-border bg-trident-surface",
      });
    } catch {
      toast({
        title: ">> ERROR",
        description: "DELETION FAILED",
        variant: "destructive",
        className: "border-[#ff2244] bg-trident-surface text-[#ff2244]",
      });
    }
  };

  const roleBadgeStyle: Record<string, string> = {
    admin: "text-trident-amber border-trident-amber/40 bg-trident-amber/10",
    power_user: "text-trident-cyan border-trident-cyan/40 bg-trident-cyan/10",
    user: "text-[#00ff41] border-[#00ff41]/40 bg-[#00ff41]/10",
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="flex items-center gap-2">
          {[0, 1, 2].map((i) => (
            <span
              key={i}
              className="inline-block w-2 h-2 rounded-full bg-trident-cyan pulse-dot"
              style={{ animationDelay: `${i * 0.3}s` }}
            />
          ))}
          <span className="text-xs font-mono uppercase tracking-widest text-trident-text/40 ml-2">
            LOADING PERSONNEL RECORDS...
          </span>
        </div>
      </div>
    );
  }

  return (
    <div className="overflow-x-auto">
      <table className="w-full" data-testid="table-users">
        <thead>
          <tr className="border-b border-trident-border">
            {["", "ID", "USERNAME", "EMAIL", "ROLE", "STATUS", "LAST LOGIN", "ACTIONS"].map(
              (header) => (
                <th
                  key={header || "expand"}
                  className="px-3 py-3 text-left text-[10px] font-mono uppercase tracking-widest text-trident-cyan/70"
                >
                  {header}
                </th>
              )
            )}
          </tr>
        </thead>
        <tbody>
          {users.map((u) => (
            <>
              <tr
                key={u.id}
                className="border-b border-trident-border/30 hover:bg-trident-cyan/5 transition-colors cursor-pointer"
                onClick={() => toggleExpand(u.id)}
                data-testid={`row-user-${u.id}`}
              >
                <td className="px-3 py-3 text-trident-text/30">
                  {expandedUser === u.id ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
                </td>
                <td className="px-3 py-3 font-mono text-xs text-trident-text/40">
                  {String(u.id).padStart(3, "0")}
                </td>
                <td className="px-3 py-3 font-mono text-xs uppercase text-trident-cyan">
                  {u.username}
                  {u.id === currentUser?.id && (
                    <span className="ml-2 text-[9px] text-trident-amber">[YOU]</span>
                  )}
                </td>
                <td className="px-3 py-3 font-mono text-xs text-trident-text/60" style={{ textTransform: "none" }}>
                  {u.email}
                </td>
                <td className="px-3 py-3" onClick={(e) => e.stopPropagation()}>
                  <div className="relative inline-block">
                    <select
                      value={u.role}
                      onChange={(e) => handleRoleChange(u.id, e.target.value)}
                      disabled={u.id === currentUser?.id}
                      className={`appearance-none cursor-pointer px-2 py-0.5 text-[10px] font-mono uppercase tracking-widest border pr-6 bg-transparent ${
                        roleBadgeStyle[u.role] || roleBadgeStyle.user
                      } ${u.id === currentUser?.id ? "opacity-50 cursor-not-allowed" : ""}`}
                      data-testid={`select-role-${u.id}`}
                    >
                      <option value="admin" className="bg-trident-surface text-trident-text">ADMIN</option>
                      <option value="power_user" className="bg-trident-surface text-trident-text">POWER USER</option>
                      <option value="user" className="bg-trident-surface text-trident-text">USER</option>
                    </select>
                    <ChevronDown className="w-3 h-3 absolute right-1 top-1/2 -translate-y-1/2 pointer-events-none text-current opacity-50" />
                  </div>
                </td>
                <td className="px-3 py-3" onClick={(e) => e.stopPropagation()}>
                  <button
                    onClick={() => handleToggleActive(u.id, u.is_active)}
                    disabled={u.id === currentUser?.id}
                    className={`flex items-center gap-1.5 text-[10px] font-mono uppercase tracking-widest transition-colors ${
                      u.id === currentUser?.id ? "opacity-50 cursor-not-allowed" : "cursor-pointer hover:opacity-80"
                    }`}
                    data-testid={`toggle-active-${u.id}`}
                  >
                    {u.is_active ? (
                      <>
                        <ToggleRight className="w-4 h-4 text-[#00ff41]" />
                        <span className="text-[#00ff41]">ACTIVE</span>
                      </>
                    ) : (
                      <>
                        <ToggleLeft className="w-4 h-4 text-trident-red" />
                        <span className="text-trident-red">INACTIVE</span>
                      </>
                    )}
                  </button>
                </td>
                <td className="px-3 py-3 font-mono text-[10px] text-trident-text/30">
                  {u.last_login
                    ? new Date(u.last_login).toLocaleString("en-US", {
                        month: "short",
                        day: "2-digit",
                        hour: "2-digit",
                        minute: "2-digit",
                      })
                    : "NEVER"}
                </td>
                <td className="px-3 py-3" onClick={(e) => e.stopPropagation()}>
                  {u.id !== currentUser?.id && (
                    <>
                      {deleteConfirm === u.id ? (
                        <div className="flex items-center gap-2">
                          <span className="text-[10px] font-mono text-trident-red">CONFIRM?</span>
                          <button
                            onClick={() => handleDelete(u.id)}
                            className="text-[10px] font-mono uppercase text-trident-red hover:text-white bg-trident-red/20 px-2 py-0.5 border border-trident-red/40"
                            data-testid={`confirm-delete-${u.id}`}
                          >
                            YES
                          </button>
                          <button
                            onClick={() => setDeleteConfirm(null)}
                            className="text-[10px] font-mono uppercase text-trident-text/40 hover:text-trident-text px-2 py-0.5 border border-trident-border"
                          >
                            NO
                          </button>
                        </div>
                      ) : (
                        <button
                          onClick={() => setDeleteConfirm(u.id)}
                          className="text-trident-red/40 hover:text-trident-red transition-colors"
                          data-testid={`button-delete-${u.id}`}
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </>
                  )}
                </td>
              </tr>
              {/* Expanded stats row */}
              {expandedUser === u.id && (
                <tr key={`stats-${u.id}`} className="border-b border-trident-border/20">
                  <td colSpan={8} className="px-6 py-3" style={{ backgroundColor: "#050a0e" }}>
                    {loadingStats === u.id ? (
                      <span className="text-[10px] font-mono text-trident-text/30">LOADING USAGE DATA...</span>
                    ) : userStats[u.id] ? (
                      <div className="flex items-center gap-6 text-[10px] font-mono uppercase tracking-widest">
                        <span className="text-trident-text/40">
                          <MessageSquare className="w-3 h-3 inline mr-1 text-trident-cyan/50" />
                          {userStats[u.id].conversations} CONVERSATIONS
                        </span>
                        <span className="text-trident-text/40">
                          {userStats[u.id].messages} MESSAGES
                        </span>
                        <span className="text-trident-text/40">
                          <Image className="w-3 h-3 inline mr-1 text-trident-cyan/50" />
                          {userStats[u.id].images} IMAGES
                        </span>
                        <span className="text-trident-text/40">
                          <FileText className="w-3 h-3 inline mr-1 text-trident-cyan/50" />
                          {userStats[u.id].files} FILES
                        </span>
                        <span className="text-trident-text/40">
                          <HardDrive className="w-3 h-3 inline mr-1 text-trident-cyan/50" />
                          {formatBytes(userStats[u.id].storageBytes)} STORAGE
                        </span>
                      </div>
                    ) : (
                      <span className="text-[10px] font-mono text-trident-text/30">NO DATA</span>
                    )}
                  </td>
                </tr>
              )}
            </>
          ))}
        </tbody>
      </table>
      {users.length === 0 && (
        <div className="text-center py-12 font-mono text-xs text-trident-text/30 uppercase">
          NO PERSONNEL RECORDS FOUND
        </div>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════
// SYSTEM STATUS TAB (tab 2)
// ═══════════════════════════════════════════════════
function SystemStatusTab() {
  const [stats, setStats] = useState<SystemStats | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [services, setServices] = useState<ServiceStatus[]>([
    { name: "TRIDENT APP", endpoint: "", status: "online", lastChecked: new Date().toISOString() },
    { name: "OLLAMA", endpoint: "/api/ollama/status", status: "checking", lastChecked: "" },
    { name: "VOICE SERVICE", endpoint: "/api/voice/status", status: "checking", lastChecked: "" },
    { name: "IMAGE GEN", endpoint: "/api/imagegen/status", status: "checking", lastChecked: "" },
  ]);

  const fetchStats = async () => {
    try {
      const res = await fetch(`${API_BASE}/api/admin/stats`, {
        headers: getAuthHeaders(),
      });
      if (!res.ok) throw new Error("FAILED");
      const data = await res.json();
      setStats(data);
    } catch {
      // silent
    } finally {
      setIsLoading(false);
    }
  };

  const checkService = async (service: ServiceStatus, index: number) => {
    if (!service.endpoint) return; // Trident is always online
    try {
      const res = await fetch(`${API_BASE}${service.endpoint}`, {
        headers: getAuthHeaders(),
      });
      const now = new Date().toISOString();
      let isOnline = false;
      if (res.ok) {
        try {
          const data = await res.json();
          isOnline = data.online === true;
        } catch {
          isOnline = true; // if no JSON, assume online if 200
        }
      }
      setServices((prev) => {
        const updated = [...prev];
        updated[index] = { ...service, status: isOnline ? "online" : "offline", lastChecked: now };
        return updated;
      });
    } catch {
      setServices((prev) => {
        const updated = [...prev];
        updated[index] = { ...service, status: "offline", lastChecked: new Date().toISOString() };
        return updated;
      });
    }
  };

  const checkAllServices = () => {
    services.forEach((s, i) => checkService(s, i));
  };

  useEffect(() => {
    fetchStats();
    checkAllServices();
    const interval = setInterval(checkAllServices, 10000);
    return () => clearInterval(interval);
  }, []);

  const handleRefresh = () => {
    setIsLoading(true);
    fetchStats();
    checkAllServices();
  };

  if (isLoading || !stats) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="flex items-center gap-2">
          {[0, 1, 2].map((i) => (
            <span
              key={i}
              className="inline-block w-2 h-2 rounded-full bg-trident-cyan pulse-dot"
              style={{ animationDelay: `${i * 0.3}s` }}
            />
          ))}
          <span className="text-xs font-mono uppercase tracking-widest text-trident-text/40 ml-2">
            LOADING SYSTEM STATUS...
          </span>
        </div>
      </div>
    );
  }

  const memPercent = stats.system.memoryTotal > 0
    ? Math.round((stats.system.memoryUsed / stats.system.memoryTotal) * 100)
    : 0;

  return (
    <div className="space-y-4">
      {/* Quick actions */}
      <div className="flex justify-end">
        <button
          onClick={handleRefresh}
          className="flex items-center gap-1.5 px-3 py-1.5 text-[10px] font-mono uppercase tracking-widest border border-trident-border text-trident-text/50 hover:text-trident-cyan hover:border-trident-cyan/30 transition-colors"
          data-testid="button-refresh-stats"
        >
          <RefreshCw className="w-3 h-3" />
          REFRESH ALL
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Platform metrics */}
        <div className="trident-panel p-4 space-y-4">
          <h3 className="font-display text-xs tracking-[0.12em] text-trident-amber border-b border-trident-border pb-2 flex items-center gap-2">
            <Activity className="w-3.5 h-3.5" />
            PLATFORM METRICS
          </h3>

          <div className="grid grid-cols-2 gap-3">
            <StatBlock label="TOTAL USERS" value={stats.users.total} icon={<Users className="w-3 h-3" />} />
            <StatBlock label="ACTIVE USERS" value={stats.users.active} icon={<Shield className="w-3 h-3" />} accent="green" />
            <StatBlock label="ADMINS" value={stats.users.admins} icon={<Shield className="w-3 h-3" />} accent="amber" />
            <StatBlock label="CONVERSATIONS" value={stats.conversations.total} icon={<MessageSquare className="w-3 h-3" />} />
            <StatBlock label="TOTAL MESSAGES" value={stats.conversations.totalMessages} icon={<MessageSquare className="w-3 h-3" />} />
            <StatBlock label="IMAGES GENERATED" value={stats.images.total} icon={<Image className="w-3 h-3" />} />
            <StatBlock label="FILES UPLOADED" value={stats.files.total} icon={<FileText className="w-3 h-3" />} />
            <StatBlock label="FILE STORAGE" value={formatBytes(stats.files.totalSize)} icon={<HardDrive className="w-3 h-3" />} />
          </div>
        </div>

        {/* System info */}
        <div className="trident-panel p-4 space-y-4">
          <h3 className="font-display text-xs tracking-[0.12em] text-trident-amber border-b border-trident-border pb-2 flex items-center gap-2">
            <Server className="w-3.5 h-3.5" />
            SYSTEM INFO
          </h3>

          <div className="space-y-3">
            <div className="flex justify-between text-[10px] font-mono uppercase tracking-widest">
              <span className="text-trident-text/40">UPTIME</span>
              <span className="text-trident-cyan">{formatUptime(stats.system.uptime)}</span>
            </div>
            <div className="flex justify-between text-[10px] font-mono uppercase tracking-widest">
              <span className="text-trident-text/40">NODE VERSION</span>
              <span className="text-trident-cyan">{stats.system.nodeVersion}</span>
            </div>
            <div className="flex justify-between text-[10px] font-mono uppercase tracking-widest">
              <span className="text-trident-text/40">PLATFORM</span>
              <span className="text-trident-cyan">{stats.system.platform}</span>
            </div>

            {/* Memory bar */}
            <div className="space-y-1">
              <div className="flex justify-between text-[10px] font-mono uppercase tracking-widest">
                <span className="text-trident-text/40">MEMORY</span>
                <span className="text-trident-cyan">
                  {formatBytes(stats.system.memoryUsed)} / {formatBytes(stats.system.memoryTotal)} ({memPercent}%)
                </span>
              </div>
              <div className="h-2 bg-[#050a0e] border border-trident-border overflow-hidden">
                <div
                  className="h-full transition-all duration-500"
                  style={{
                    width: `${memPercent}%`,
                    backgroundColor: memPercent > 80 ? "#ff2244" : memPercent > 60 ? "#ff6b00" : "#00f0ff",
                    boxShadow: `0 0 6px ${memPercent > 80 ? "#ff2244" : memPercent > 60 ? "#ff6b00" : "#00f0ff"}40`,
                  }}
                />
              </div>
            </div>
          </div>
        </div>

        {/* Service status */}
        <div className="trident-panel p-4 space-y-4">
          <h3 className="font-display text-xs tracking-[0.12em] text-trident-amber border-b border-trident-border pb-2 flex items-center gap-2">
            <Cpu className="w-3.5 h-3.5" />
            SERVICE STATUS
          </h3>

          <div className="space-y-2">
            {services.map((s) => (
              <div
                key={s.name}
                className="flex items-center justify-between px-3 py-2 border border-trident-border/30"
                style={{ backgroundColor: "#050a0e" }}
                data-testid={`service-${s.name.toLowerCase().replace(/\s/g, "-")}`}
              >
                <div className="flex items-center gap-2">
                  <span
                    className={`inline-block w-2 h-2 rounded-full ${
                      s.status === "online"
                        ? "bg-[#00ff41] shadow-[0_0_4px_#00ff41]"
                        : s.status === "offline"
                        ? "bg-[#ff2244] shadow-[0_0_4px_#ff2244]"
                        : "bg-trident-amber animate-pulse"
                    }`}
                  />
                  <span className="text-[10px] font-mono uppercase tracking-widest text-trident-text/70">
                    {s.name}
                  </span>
                </div>
                <div className="flex items-center gap-3">
                  <span
                    className={`text-[10px] font-mono uppercase tracking-widest font-bold ${
                      s.status === "online"
                        ? "text-[#00ff41] text-glow-green"
                        : s.status === "offline"
                        ? "text-[#ff2244]"
                        : "text-trident-amber"
                    }`}
                  >
                    {s.status === "checking" ? "CHECKING..." : s.status.toUpperCase()}
                  </span>
                  {s.lastChecked && (
                    <span className="text-[8px] font-mono text-trident-text/20">
                      {new Date(s.lastChecked).toLocaleTimeString("en-US", { hour12: false, hour: "2-digit", minute: "2-digit", second: "2-digit" })}
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Server logs hint */}
        <div className="trident-panel p-4 space-y-4">
          <h3 className="font-display text-xs tracking-[0.12em] text-trident-amber border-b border-trident-border pb-2 flex items-center gap-2">
            <Terminal className="w-3.5 h-3.5" />
            SERVER LOGS
          </h3>
          <div className="px-3 py-3 border border-trident-border/30 font-mono text-xs" style={{ backgroundColor: "#050a0e" }}>
            <p className="text-trident-text/40 text-[10px] uppercase tracking-widest mb-2">
              TO VIEW LIVE SERVER LOGS:
            </p>
            <code className="text-[#00ff41] text-[11px]" style={{ textTransform: "none" }}>
              ssh root@server && journalctl -u trident -f
            </code>
          </div>
        </div>
      </div>
    </div>
  );
}

function StatBlock({
  label,
  value,
  icon,
  accent = "cyan",
}: {
  label: string;
  value: number | string;
  icon: React.ReactNode;
  accent?: "cyan" | "green" | "amber";
}) {
  const colorMap = {
    cyan: "text-trident-cyan",
    green: "text-[#00ff41]",
    amber: "text-trident-amber",
  };
  return (
    <div className="px-3 py-2 border border-trident-border/30" style={{ backgroundColor: "#050a0e" }}>
      <div className="flex items-center gap-1.5 mb-1">
        <span className="text-trident-text/30">{icon}</span>
        <span className="text-[8px] font-mono uppercase tracking-widest text-trident-text/30">{label}</span>
      </div>
      <span className={`font-mono text-sm ${colorMap[accent]}`}>
        {typeof value === "number" ? value.toLocaleString() : value}
      </span>
    </div>
  );
}

// ═══════════════════════════════════════════════════
// MAIN ADMIN PAGE — TABBED
// ═══════════════════════════════════════════════════
export default function AdminUsersPage() {
  const [activeTab, setActiveTab] = useState<"personnel" | "system">("personnel");

  return (
    <div className="h-full flex flex-col">
      <div className="trident-panel p-4 mb-4">
        <div className="flex items-center justify-between">
          <h1 className="font-display text-sm tracking-[0.15em] text-trident-amber text-glow-amber flex items-center gap-2">
            <Shield className="w-4 h-4" />
            COMMAND CENTER
          </h1>

          {/* Tabs */}
          <div className="flex items-center border border-trident-border">
            <button
              onClick={() => setActiveTab("personnel")}
              className={`px-4 py-1.5 text-[10px] font-mono uppercase tracking-widest transition-colors flex items-center gap-1.5 border-r border-trident-border ${
                activeTab === "personnel"
                  ? "bg-trident-cyan/10 text-trident-cyan"
                  : "text-trident-text/40 hover:text-trident-cyan"
              }`}
              data-testid="tab-personnel"
            >
              <Users className="w-3 h-3" />
              PERSONNEL DATABASE
            </button>
            <button
              onClick={() => setActiveTab("system")}
              className={`px-4 py-1.5 text-[10px] font-mono uppercase tracking-widest transition-colors flex items-center gap-1.5 ${
                activeTab === "system"
                  ? "bg-trident-cyan/10 text-trident-cyan"
                  : "text-trident-text/40 hover:text-trident-cyan"
              }`}
              data-testid="tab-system"
            >
              <Activity className="w-3 h-3" />
              SYSTEM STATUS
            </button>
          </div>
        </div>
      </div>

      <div className="trident-panel flex-1 overflow-auto">
        {activeTab === "personnel" ? <PersonnelTab /> : <SystemStatusTab />}
      </div>
    </div>
  );
}
