import { useState } from "react";
import { Settings, Save, AlertTriangle, Key, Plus, Trash2, Copy, Check, Loader2 } from "lucide-react";
import { useAuth, getAuthHeaders } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";

const API_BASE = "__PORT_5000__".startsWith("__") ? "" : "__PORT_5000__";

export default function DashboardSettings() {
  const { user, setUser } = useAuth();
  const { toast } = useToast();
  
  const [username, setUsername] = useState(user?.username || "");
  const [email, setEmail] = useState(user?.email || "");
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmNewPassword, setConfirmNewPassword] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      const data: any = {};
      if (username !== user?.username) data.username = username;
      if (email !== user?.email) data.email = email;
      
      if (Object.keys(data).length === 0) {
        toast({
          title: ">> INFO",
          description: "NO CHANGES DETECTED",
          className: "border-trident-border bg-trident-surface text-trident-cyan",
        });
        setIsSubmitting(false);
        return;
      }

      const res = await fetch("/api/auth/settings", {
        method: "PATCH",
        headers: { "Content-Type": "application/json", ...getAuthHeaders() },
        body: JSON.stringify(data),
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || "FAILED");
      }
      const result = await res.json();
      setUser(result.user);
      toast({
        title: ">> PROFILE UPDATED",
        description: "SETTINGS SAVED SUCCESSFULLY",
        className: "terminal-text border-trident-border bg-trident-surface",
      });
    } catch (err: any) {
      toast({
        title: ">> ERROR",
        description: err.message || "UPDATE FAILED",
        variant: "destructive",
        className: "border-[#ff2244] bg-trident-surface text-[#ff2244]",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (newPassword !== confirmNewPassword) {
      toast({
        title: ">> ERROR",
        description: "PASSWORDS DO NOT MATCH",
        variant: "destructive",
        className: "border-[#ff2244] bg-trident-surface text-[#ff2244]",
      });
      return;
    }
    setIsSubmitting(true);
    try {
      const res = await fetch("/api/auth/settings", {
        method: "PATCH",
        headers: { "Content-Type": "application/json", ...getAuthHeaders() },
        body: JSON.stringify({
          current_password: currentPassword,
          new_password: newPassword,
        }),
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || "FAILED");
      }
      setCurrentPassword("");
      setNewPassword("");
      setConfirmNewPassword("");
      toast({
        title: ">> PASSWORD UPDATED",
        description: "SECURITY CREDENTIALS MODIFIED",
        className: "terminal-text border-trident-border bg-trident-surface",
      });
    } catch (err: any) {
      toast({
        title: ">> ERROR",
        description: err.message || "PASSWORD UPDATE FAILED",
        variant: "destructive",
        className: "border-[#ff2244] bg-trident-surface text-[#ff2244]",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="h-full flex flex-col">
      <div className="trident-panel p-4 mb-4">
        <h1 className="font-display text-sm tracking-[0.15em] text-trident-amber text-glow-amber flex items-center gap-2">
          <Settings className="w-4 h-4" />
          USER SETTINGS
        </h1>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Profile Settings */}
        <form onSubmit={handleSaveProfile} className="trident-panel p-5 space-y-4">
          <h2 className="font-display text-xs tracking-[0.12em] text-trident-cyan border-b border-trident-border pb-2">
            PROFILE DATA
          </h2>

          <div className="space-y-1">
            <label className="block text-[10px] font-mono uppercase tracking-widest text-trident-cyan/70">
              USERNAME
            </label>
            <input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="trident-input w-full px-3 py-2 text-sm"
              data-testid="input-settings-username"
            />
          </div>

          <div className="space-y-1">
            <label className="block text-[10px] font-mono uppercase tracking-widest text-trident-cyan/70">
              EMAIL
            </label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="trident-input w-full px-3 py-2 text-sm"
              data-testid="input-settings-email"
            />
          </div>

          <div className="flex items-center gap-2 pt-1 text-[10px] font-mono text-trident-text/40">
            <span>ROLE: <span className="text-trident-amber">{user?.role?.toUpperCase()}</span></span>
            <span className="text-trident-border">|</span>
            <span>ID: <span className="text-trident-cyan">{user?.id}</span></span>
          </div>

          <button
            type="submit"
            disabled={isSubmitting}
            className="trident-btn trident-btn-primary px-6 py-2 text-xs flex items-center gap-2 disabled:opacity-50"
            data-testid="button-save-profile"
          >
            <Save className="w-3.5 h-3.5" />
            SAVE PROFILE
          </button>
        </form>

        {/* Password Change */}
        <form onSubmit={handleChangePassword} className="trident-panel p-5 space-y-4">
          <h2 className="font-display text-xs tracking-[0.12em] text-trident-cyan border-b border-trident-border pb-2 flex items-center gap-2">
            <AlertTriangle className="w-3.5 h-3.5 text-trident-amber" />
            SECURITY CREDENTIALS
          </h2>

          <div className="space-y-1">
            <label className="block text-[10px] font-mono uppercase tracking-widest text-trident-cyan/70">
              CURRENT PASSWORD
            </label>
            <input
              type="password"
              value={currentPassword}
              onChange={(e) => setCurrentPassword(e.target.value)}
              className="trident-input w-full px-3 py-2 text-sm"
              style={{ textTransform: "none" }}
              data-testid="input-current-password"
            />
          </div>

          <div className="space-y-1">
            <label className="block text-[10px] font-mono uppercase tracking-widest text-trident-cyan/70">
              NEW PASSWORD
            </label>
            <input
              type="password"
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
              className="trident-input w-full px-3 py-2 text-sm"
              style={{ textTransform: "none" }}
              data-testid="input-new-password"
            />
          </div>

          <div className="space-y-1">
            <label className="block text-[10px] font-mono uppercase tracking-widest text-trident-cyan/70">
              CONFIRM NEW PASSWORD
            </label>
            <input
              type="password"
              value={confirmNewPassword}
              onChange={(e) => setConfirmNewPassword(e.target.value)}
              className="trident-input w-full px-3 py-2 text-sm"
              style={{ textTransform: "none" }}
              data-testid="input-confirm-new-password"
            />
          </div>

          <button
            type="submit"
            disabled={isSubmitting}
            className="trident-btn trident-btn-secondary px-6 py-2 text-xs flex items-center gap-2 disabled:opacity-50"
            data-testid="button-change-password"
          >
            <Save className="w-3.5 h-3.5" />
            UPDATE PASSWORD
          </button>
        </form>
      </div>

      {/* API Keys Section */}
      <div className="mt-4">
        <ApiKeysSection />
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════
// API KEYS SECTION
// ═══════════════════════════════════════════════════
interface ApiKeyInfo {
  id: number;
  name: string;
  key_prefix: string;
  created_at: string;
  last_used: string | null;
}

function ApiKeysSection() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [showDialog, setShowDialog] = useState(false);
  const [keyName, setKeyName] = useState("");
  const [generatedKey, setGeneratedKey] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  const { data, isLoading } = useQuery({
    queryKey: ["/api/keys"],
    queryFn: async () => {
      const res = await fetch(`${API_BASE}/api/keys`, { headers: getAuthHeaders() });
      if (!res.ok) throw new Error("FAILED");
      return res.json() as Promise<{ keys: ApiKeyInfo[] }>;
    },
    staleTime: 0,
  });

  const createMutation = useMutation({
    mutationFn: async (name: string) => {
      const res = await fetch(`${API_BASE}/api/keys`, {
        method: "POST",
        headers: { "Content-Type": "application/json", ...getAuthHeaders() },
        body: JSON.stringify({ name }),
      });
      if (!res.ok) throw new Error("GENERATION FAILED");
      return res.json() as Promise<{ key: string; prefix: string; name: string }>;
    },
    onSuccess: (result) => {
      setGeneratedKey(result.key);
      setKeyName("");
      queryClient.invalidateQueries({ queryKey: ["/api/keys"] });
    },
    onError: () => {
      toast({
        title: ">> ERROR",
        description: "KEY GENERATION FAILED",
        variant: "destructive",
        className: "border-[#ff2244] bg-trident-surface text-[#ff2244]",
      });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (keyId: number) => {
      const res = await fetch(`${API_BASE}/api/keys/${keyId}`, {
        method: "DELETE",
        headers: getAuthHeaders(),
      });
      if (!res.ok) throw new Error("FAILED");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/keys"] });
      toast({
        title: ">> KEY REVOKED",
        description: "API KEY DEACTIVATED",
        className: "terminal-text border-trident-border bg-trident-surface",
      });
    },
  });

  const handleCopyKey = () => {
    if (generatedKey) {
      navigator.clipboard.writeText(generatedKey);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleCreate = () => {
    if (!keyName.trim()) return;
    createMutation.mutate(keyName.trim());
  };

  const keys = data?.keys ?? [];

  return (
    <div className="trident-panel p-5 space-y-4">
      <h2 className="font-display text-xs tracking-[0.12em] text-trident-cyan border-b border-trident-border pb-2 flex items-center gap-2">
        <Key className="w-3.5 h-3.5 text-trident-amber" />
        API KEYS
      </h2>

      {isLoading ? (
        <div className="flex items-center gap-2">
          <Loader2 className="w-3 h-3 animate-spin text-trident-cyan" />
          <span className="text-[10px] font-mono uppercase tracking-widest text-trident-text/40">LOADING KEYS...</span>
        </div>
      ) : keys.length === 0 ? (
        <p className="text-[10px] font-mono uppercase tracking-widest text-trident-text/30">
          NO API KEYS GENERATED
        </p>
      ) : (
        <div className="space-y-2">
          {keys.map((k) => (
            <div
              key={k.id}
              className="flex items-center justify-between px-3 py-2 border border-trident-border/30"
              style={{ backgroundColor: "#050a0e" }}
              data-testid={`api-key-${k.id}`}
            >
              <div className="flex items-center gap-4">
                <span className="font-mono text-xs text-trident-cyan" style={{ textTransform: "none" }}>
                  {k.key_prefix}
                </span>
                <span className="font-mono text-[10px] uppercase tracking-widest text-trident-text/50">
                  {k.name}
                </span>
              </div>
              <div className="flex items-center gap-3">
                <span className="text-[8px] font-mono text-trident-text/25">
                  {new Date(k.created_at).toLocaleDateString("en-US", { month: "short", day: "2-digit" })}
                </span>
                {k.last_used && (
                  <span className="text-[8px] font-mono text-trident-text/25">
                    LAST: {new Date(k.last_used).toLocaleDateString("en-US", { month: "short", day: "2-digit" })}
                  </span>
                )}
                <button
                  onClick={() => deleteMutation.mutate(k.id)}
                  className="text-trident-red/40 hover:text-trident-red transition-colors"
                  data-testid={`button-delete-key-${k.id}`}
                >
                  <Trash2 className="w-3 h-3" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Generate new key dialog */}
      {showDialog ? (
        <div className="border border-trident-cyan/30 p-4 space-y-3" style={{ backgroundColor: "#050a0e" }}>
          {generatedKey ? (
            <div className="space-y-3">
              <p className="text-[10px] font-mono uppercase tracking-widest text-trident-amber">
                <AlertTriangle className="w-3 h-3 inline mr-1" />
                THIS KEY WILL NOT BE SHOWN AGAIN
              </p>
              <div className="flex items-center gap-2">
                <code
                  className="flex-1 font-mono text-[11px] text-[#00ff41] px-3 py-2 border border-trident-border bg-[#0a1628] break-all"
                  style={{ textTransform: "none" }}
                  data-testid="text-generated-key"
                >
                  {">> KEY GENERATED: "}{generatedKey}
                </code>
                <button
                  onClick={handleCopyKey}
                  className="p-2 border border-trident-border text-trident-text/40 hover:text-trident-cyan hover:border-trident-cyan/30 transition-colors flex-shrink-0"
                  data-testid="button-copy-key"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-[#00ff41]" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
              </div>
              <button
                onClick={() => { setShowDialog(false); setGeneratedKey(null); }}
                className="text-[10px] font-mono uppercase tracking-widest text-trident-text/40 hover:text-trident-cyan"
              >
                CLOSE
              </button>
            </div>
          ) : (
            <div className="space-y-3">
              <label className="block text-[10px] font-mono uppercase tracking-widest text-trident-cyan/70">
                KEY NAME
              </label>
              <input
                type="text"
                value={keyName}
                onChange={(e) => setKeyName(e.target.value)}
                placeholder="e.g. MY-SCRIPT, CI-PIPELINE"
                className="trident-input w-full px-3 py-2 text-sm"
                onKeyDown={(e) => e.key === "Enter" && handleCreate()}
                data-testid="input-key-name"
              />
              <div className="flex items-center gap-2">
                <button
                  onClick={handleCreate}
                  disabled={createMutation.isPending || !keyName.trim()}
                  className="trident-btn trident-btn-primary px-4 py-1.5 text-xs flex items-center gap-2 disabled:opacity-50"
                  data-testid="button-confirm-generate"
                >
                  {createMutation.isPending ? <Loader2 className="w-3 h-3 animate-spin" /> : <Key className="w-3 h-3" />}
                  GENERATE
                </button>
                <button
                  onClick={() => { setShowDialog(false); setKeyName(""); }}
                  className="text-[10px] font-mono uppercase tracking-widest text-trident-text/40 hover:text-trident-text px-3 py-1.5 border border-trident-border"
                >
                  CANCEL
                </button>
              </div>
            </div>
          )}
        </div>
      ) : (
        <button
          onClick={() => setShowDialog(true)}
          className="trident-btn trident-btn-primary px-4 py-2 text-xs flex items-center gap-2"
          data-testid="button-generate-key"
        >
          <Plus className="w-3.5 h-3.5" />
          GENERATE NEW KEY
        </button>
      )}
    </div>
  );
}
