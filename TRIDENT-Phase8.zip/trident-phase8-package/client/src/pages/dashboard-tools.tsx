import { useState, useEffect } from "react";
import {
  Wrench,
  Server,
  HardDrive,
  Network,
  Activity,
  Plus,
  Play,
  Trash2,
  Pencil,
  ChevronDown,
  ChevronRight,
  Check,
  X,
  Clock,
  AlertTriangle,
  Zap,
  Loader2,
  Terminal,
  Settings,
  Power,
  PowerOff,
} from "lucide-react";
import { useAuth, getAuthHeaders } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import type { ToolConfig, ScheduledTask, TaskRun } from "@shared/schema";

const API_BASE = "__PORT_5000__".startsWith("__") ? "" : "__PORT_5000__";

// ═══════════════════════════════════════════════════
// TOOL DEFINITIONS
// ═══════════════════════════════════════════════════

const TOOL_DEFS = {
  proxmox: {
    label: "PROXMOX HYPERVISOR",
    icon: Server,
    requiresConfig: true,
    description: "Virtual machine management and monitoring",
    actions: [
      { value: "get_nodes", label: "Get Nodes" },
      { value: "get_vms", label: "Get VMs" },
      { value: "get_vm_status", label: "Get VM Status" },
      { value: "start_vm", label: "Start VM" },
      { value: "stop_vm", label: "Stop VM" },
      { value: "get_storage", label: "Get Storage" },
    ],
  },
  truenas: {
    label: "TRUENAS STORAGE",
    icon: HardDrive,
    requiresConfig: true,
    description: "ZFS pool, dataset, disk and alert management",
    actions: [
      { value: "get_pools", label: "Get Pools" },
      { value: "get_datasets", label: "Get Datasets" },
      { value: "get_alerts", label: "Get Alerts" },
      { value: "get_system_info", label: "Get System Info" },
      { value: "get_disks", label: "Get Disks" },
      { value: "dismiss_alert", label: "Dismiss Alert" },
    ],
  },
  network: {
    label: "NETWORK TOOLS",
    icon: Network,
    requiresConfig: false,
    description: "Ping, DNS, port check, traceroute",
    actions: [
      { value: "ping", label: "Ping" },
      { value: "dns_lookup", label: "DNS Lookup" },
      { value: "port_check", label: "Port Check" },
      { value: "get_local_hosts", label: "Get Local Hosts" },
      { value: "traceroute", label: "Traceroute" },
    ],
  },
  system: {
    label: "SYSTEM METRICS",
    icon: Activity,
    requiresConfig: false,
    description: "TRIDENT server stats — always available",
    actions: [
      { value: "get_metrics", label: "Get Metrics" },
      { value: "get_services", label: "Get Services" },
      { value: "get_disk_usage", label: "Get Disk Usage" },
      { value: "run_command", label: "Run Command" },
    ],
  },
} as const;

type ToolName = keyof typeof TOOL_DEFS;

const CRON_PRESETS = [
  { label: "5M", value: "*/5 * * * *" },
  { label: "15M", value: "*/15 * * * *" },
  { label: "30M", value: "*/30 * * * *" },
  { label: "1H", value: "0 * * * *" },
  { label: "6H", value: "0 */6 * * *" },
  { label: "24H", value: "0 0 * * *" },
];

// ═══════════════════════════════════════════════════
// MAIN COMPONENT
// ═══════════════════════════════════════════════════

export default function DashboardTools() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch configs
  const { data: configsData, isLoading: loadingConfigs } = useQuery<{ configs: ToolConfig[] }>({
    queryKey: ["/api/tools/configs"],
    queryFn: async () => {
      const res = await fetch(`${API_BASE}/api/tools/configs`, { headers: getAuthHeaders() });
      if (!res.ok) throw new Error("Failed to fetch configs");
      return res.json();
    },
    staleTime: 0,
  });

  // Fetch tasks
  const { data: tasksData, isLoading: loadingTasks } = useQuery<{ tasks: ScheduledTask[] }>({
    queryKey: ["/api/tasks"],
    queryFn: async () => {
      const res = await fetch(`${API_BASE}/api/tasks`, { headers: getAuthHeaders() });
      if (!res.ok) throw new Error("Failed to fetch tasks");
      return res.json();
    },
    staleTime: 0,
  });

  // Fetch recent runs
  const { data: runsData } = useQuery<{ runs: TaskRun[] }>({
    queryKey: ["/api/tasks/runs/recent"],
    queryFn: async () => {
      const res = await fetch(`${API_BASE}/api/tasks/runs/recent`, { headers: getAuthHeaders() });
      if (!res.ok) throw new Error("Failed to fetch runs");
      return res.json();
    },
    staleTime: 0,
  });

  const configs = configsData?.configs || [];
  const tasks = tasksData?.tasks || [];
  const recentRuns = runsData?.runs || [];

  const getConfig = (name: string) => configs.find((c) => c.tool_name === name);

  return (
    <div className="space-y-6 max-w-6xl mx-auto" data-testid="page-tools">
      {/* Page header */}
      <div className="flex items-center gap-3">
        <Wrench className="w-5 h-5 text-trident-cyan" />
        <h1
          className="font-display text-sm tracking-[0.15em] text-trident-cyan text-glow-cyan uppercase"
          data-testid="text-page-title"
        >
          AGENT TOOLS
        </h1>
      </div>

      {/* Section 1: Connected Integrations */}
      <section>
        <h2 className="font-display text-[10px] tracking-[0.15em] text-trident-amber text-glow-amber uppercase mb-3">
          CONNECTED INTEGRATIONS
        </h2>
        <div className="space-y-2">
          {(Object.keys(TOOL_DEFS) as ToolName[]).map((toolName) => (
            <ToolCard
              key={toolName}
              toolName={toolName}
              config={getConfig(toolName)}
              onRefresh={() => queryClient.invalidateQueries({ queryKey: ["/api/tools/configs"] })}
            />
          ))}
        </div>
      </section>

      {/* Section 2: Scheduled Monitors */}
      <section>
        <ScheduledMonitors
          tasks={tasks}
          loading={loadingTasks}
          onRefresh={() => {
            queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
            queryClient.invalidateQueries({ queryKey: ["/api/tasks/runs/recent"] });
          }}
        />
      </section>

      {/* Section 3: Quick Execute */}
      <section>
        <QuickExecute />
      </section>

      {/* Section 4: Task Run History */}
      <section>
        <RunHistory runs={recentRuns} tasks={tasks} />
      </section>
    </div>
  );
}

// ═══════════════════════════════════════════════════
// TOOL CARD
// ═══════════════════════════════════════════════════

function ToolCard({
  toolName,
  config,
  onRefresh,
}: {
  toolName: ToolName;
  config: ToolConfig | undefined;
  onRefresh: () => void;
}) {
  const def = TOOL_DEFS[toolName];
  const Icon = def.icon;
  const { toast } = useToast();
  const [expanded, setExpanded] = useState(false);
  const [testing, setTesting] = useState(false);
  const [testResult, setTestResult] = useState<string | null>(null);

  // Form state
  const [formData, setFormData] = useState<Record<string, any>>({});

  useEffect(() => {
    if (config) {
      try {
        setFormData(JSON.parse(config.config));
      } catch {
        setFormData({});
      }
    }
  }, [config]);

  const isConfigured = !!config;
  const isBuiltin = !def.requiresConfig;

  const handleSaveAndTest = async () => {
    setTesting(true);
    setTestResult(null);
    try {
      // Save config
      const res = await fetch(`${API_BASE}/api/tools/configs`, {
        method: "POST",
        headers: { "Content-Type": "application/json", ...getAuthHeaders() },
        body: JSON.stringify({ tool_name: toolName, config: formData, is_enabled: true }),
      });
      if (!res.ok) throw new Error("Failed to save config");

      // Test connection
      const testAction = toolName === "proxmox" ? "get_nodes" : "get_system_info";
      const testRes = await fetch(`${API_BASE}/api/tools/execute`, {
        method: "POST",
        headers: { "Content-Type": "application/json", ...getAuthHeaders() },
        body: JSON.stringify({ tool_name: toolName, action: testAction, params: {} }),
      });
      const result = await testRes.json();

      if (result.success) {
        const count = Array.isArray(result.data) ? result.data.length : "OK";
        setTestResult(`✓ CONNECTED — ${count}`);
        toast({ title: "CONNECTED", description: `${def.label} link established` });
      } else {
        setTestResult(`✗ CONNECTION FAILED: ${result.error || "Unknown error"}`);
      }

      onRefresh();
    } catch (err: any) {
      setTestResult(`✗ CONNECTION FAILED: ${err.message}`);
    } finally {
      setTesting(false);
    }
  };

  const handleTest = async () => {
    if (!isConfigured) return;
    setTesting(true);
    setTestResult(null);
    try {
      const testAction = toolName === "proxmox" ? "get_nodes" : toolName === "truenas" ? "get_system_info" : "get_metrics";
      const res = await fetch(`${API_BASE}/api/tools/execute`, {
        method: "POST",
        headers: { "Content-Type": "application/json", ...getAuthHeaders() },
        body: JSON.stringify({ tool_name: toolName, action: testAction, params: {} }),
      });
      const result = await res.json();
      if (result.success) {
        setTestResult("✓ CONNECTED");
      } else {
        setTestResult(`✗ ${result.error || "FAILED"}`);
      }
    } catch (err: any) {
      setTestResult(`✗ ${err.message}`);
    } finally {
      setTesting(false);
    }
  };

  const handleDelete = async () => {
    try {
      await fetch(`${API_BASE}/api/tools/configs/${toolName}`, {
        method: "DELETE",
        headers: getAuthHeaders(),
      });
      onRefresh();
      setExpanded(false);
      toast({ title: "REMOVED", description: `${def.label} config purged` });
    } catch {
      toast({ title: "ERROR", description: "Failed to delete config", variant: "destructive" });
    }
  };

  return (
    <div
      className="border border-trident-border bg-[#0a1628]/80"
      data-testid={`card-tool-${toolName}`}
    >
      {/* Card header */}
      <div className="flex items-center justify-between px-4 py-3">
        <div className="flex items-center gap-3">
          <Icon className="w-4 h-4 text-trident-cyan" />
          <span className="font-display text-[10px] tracking-[0.15em] text-trident-text uppercase">
            {def.label}
          </span>
        </div>
        <div className="flex items-center gap-2">
          {/* Status badge */}
          {isBuiltin ? (
            <span className="px-2 py-0.5 text-[8px] font-mono uppercase tracking-widest text-[#00ff41] border border-[#00ff41]/30 bg-[#00ff41]/5">
              ● BUILT-IN
            </span>
          ) : isConfigured ? (
            <span className="px-2 py-0.5 text-[8px] font-mono uppercase tracking-widest text-[#00ff41] border border-[#00ff41]/30 bg-[#00ff41]/5">
              ● CONFIGURED
            </span>
          ) : (
            <span className="px-2 py-0.5 text-[8px] font-mono uppercase tracking-widest text-trident-text/30 border border-trident-border">
              ○ NOT CONFIGURED
            </span>
          )}

          {/* Action buttons */}
          {isConfigured && !isBuiltin && (
            <button
              onClick={handleTest}
              disabled={testing}
              className="px-2 py-0.5 text-[8px] font-mono uppercase tracking-widest text-trident-cyan border border-trident-cyan/30 hover:bg-trident-cyan/10 transition-all"
              data-testid={`button-test-${toolName}`}
            >
              {testing ? <Loader2 className="w-3 h-3 animate-spin" /> : "TEST"}
            </button>
          )}

          {def.requiresConfig && (
            <button
              onClick={() => setExpanded(!expanded)}
              className="px-2 py-0.5 text-[8px] font-mono uppercase tracking-widest text-trident-amber border border-trident-amber/30 hover:bg-trident-amber/10 transition-all"
              data-testid={`button-configure-${toolName}`}
            >
              {expanded ? "CLOSE" : "CONFIGURE"}
            </button>
          )}
        </div>
      </div>

      {/* Description */}
      <div className="px-4 pb-2">
        <p className="font-mono text-[9px] text-trident-text/40 uppercase tracking-widest">
          {isBuiltin ? "No config required — " : ""}
          {def.description}
        </p>
        {testResult && (
          <p
            className={`font-mono text-[9px] mt-1 ${
              testResult.startsWith("✓") ? "text-[#00ff41]" : "text-trident-red"
            }`}
          >
            {testResult}
          </p>
        )}
      </div>

      {/* Expanded config form */}
      {expanded && def.requiresConfig && (
        <div className="border-t border-trident-border px-4 py-3 space-y-3 bg-[#050a0e]/50">
          {toolName === "proxmox" && (
            <>
              <FormField label="HOST IP" value={formData.host || ""} onChange={(v) => setFormData({ ...formData, host: v })} placeholder="192.168.1.100" />
              <FormField label="PORT" value={formData.port || "8006"} onChange={(v) => setFormData({ ...formData, port: parseInt(v) || 8006 })} placeholder="8006" />
              <FormField label="TOKEN ID" value={formData.token_id || ""} onChange={(v) => setFormData({ ...formData, token_id: v })} placeholder="user@pam!token-name" />
              <FormField label="TOKEN SECRET" value={formData.token_secret || ""} onChange={(v) => setFormData({ ...formData, token_secret: v })} placeholder="xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx" type="password" />
              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={formData.verify_ssl || false}
                  onChange={(e) => setFormData({ ...formData, verify_ssl: e.target.checked })}
                  className="accent-trident-cyan"
                  data-testid="checkbox-verify-ssl-proxmox"
                />
                <label className="font-mono text-[9px] uppercase tracking-widest text-trident-text/50">VERIFY SSL</label>
              </div>
            </>
          )}
          {toolName === "truenas" && (
            <>
              <FormField label="HOST" value={formData.host || ""} onChange={(v) => setFormData({ ...formData, host: v })} placeholder="192.168.1.200" />
              <FormField label="API KEY" value={formData.api_key || ""} onChange={(v) => setFormData({ ...formData, api_key: v })} placeholder="1-xxxxx..." type="password" />
              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={formData.verify_ssl || false}
                  onChange={(e) => setFormData({ ...formData, verify_ssl: e.target.checked })}
                  className="accent-trident-cyan"
                  data-testid="checkbox-verify-ssl-truenas"
                />
                <label className="font-mono text-[9px] uppercase tracking-widest text-trident-text/50">VERIFY SSL</label>
              </div>
            </>
          )}

          <div className="flex items-center gap-2 pt-1">
            <button
              onClick={handleSaveAndTest}
              disabled={testing}
              className="flex items-center gap-1.5 px-3 py-2 text-[9px] font-display uppercase tracking-widest border border-trident-cyan text-trident-cyan hover:bg-trident-cyan/10 transition-all"
              data-testid={`button-save-test-${toolName}`}
            >
              {testing ? <Loader2 className="w-3 h-3 animate-spin" /> : <Check className="w-3 h-3" />}
              SAVE & TEST
            </button>
            {isConfigured && (
              <button
                onClick={handleDelete}
                className="flex items-center gap-1.5 px-3 py-2 text-[9px] font-mono uppercase tracking-widest border border-trident-red/30 text-trident-red/70 hover:bg-trident-red/10 transition-all"
                data-testid={`button-delete-${toolName}`}
              >
                <Trash2 className="w-3 h-3" />
                REMOVE
              </button>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════
// FORM FIELD HELPER
// ═══════════════════════════════════════════════════

function FormField({
  label,
  value,
  onChange,
  placeholder,
  type = "text",
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  type?: string;
}) {
  return (
    <div>
      <label className="block font-mono text-[8px] uppercase tracking-widest text-trident-text/40 mb-1">
        {label}
      </label>
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="w-full font-mono text-xs bg-[#050a0e] border border-trident-border text-trident-text px-2 py-1.5 focus:border-trident-cyan focus:outline-none placeholder:text-trident-text/15"
        data-testid={`input-${label.toLowerCase().replace(/\s/g, "-")}`}
      />
    </div>
  );
}

// ═══════════════════════════════════════════════════
// SCHEDULED MONITORS
// ═══════════════════════════════════════════════════

function ScheduledMonitors({
  tasks,
  loading,
  onRefresh,
}: {
  tasks: ScheduledTask[];
  loading: boolean;
  onRefresh: () => void;
}) {
  const { toast } = useToast();
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);

  // Form state
  const [taskName, setTaskName] = useState("");
  const [taskDesc, setTaskDesc] = useState("");
  const [taskTool, setTaskTool] = useState<ToolName>("system");
  const [taskAction, setTaskAction] = useState("");
  const [taskParams, setTaskParams] = useState("{}");
  const [taskCron, setTaskCron] = useState("*/5 * * * *");
  const [alertField, setAlertField] = useState("");
  const [alertOp, setAlertOp] = useState(">");
  const [alertValue, setAlertValue] = useState("");
  const [alertMessage, setAlertMessage] = useState("");

  const resetForm = () => {
    setTaskName("");
    setTaskDesc("");
    setTaskTool("system");
    setTaskAction("");
    setTaskParams("{}");
    setTaskCron("*/5 * * * *");
    setAlertField("");
    setAlertOp(">");
    setAlertValue("");
    setAlertMessage("");
    setEditingId(null);
    setShowForm(false);
  };

  const handleSave = async () => {
    if (!taskName || !taskAction) {
      toast({ title: "ERROR", description: "Name and action required", variant: "destructive" });
      return;
    }

    const alertCondition = alertField
      ? { field: alertField, operator: alertOp, value: alertValue, message: alertMessage }
      : null;

    try {
      if (editingId) {
        await fetch(`${API_BASE}/api/tasks/${editingId}`, {
          method: "PATCH",
          headers: { "Content-Type": "application/json", ...getAuthHeaders() },
          body: JSON.stringify({
            name: taskName,
            description: taskDesc,
            tool_name: taskTool,
            tool_action: taskAction,
            tool_params: taskParams,
            schedule_cron: taskCron,
            alert_condition: alertCondition,
          }),
        });
        toast({ title: "UPDATED", description: "Task schedule modified" });
      } else {
        await fetch(`${API_BASE}/api/tasks`, {
          method: "POST",
          headers: { "Content-Type": "application/json", ...getAuthHeaders() },
          body: JSON.stringify({
            name: taskName,
            description: taskDesc,
            tool_name: taskTool,
            tool_action: taskAction,
            tool_params: taskParams,
            schedule_cron: taskCron,
            alert_condition: alertCondition,
          }),
        });
        toast({ title: "CREATED", description: "Monitoring task scheduled" });
      }

      resetForm();
      onRefresh();
    } catch {
      toast({ title: "ERROR", description: "Failed to save task", variant: "destructive" });
    }
  };

  const handleEdit = (task: ScheduledTask) => {
    setTaskName(task.name);
    setTaskDesc(task.description);
    setTaskTool(task.tool_name as ToolName);
    setTaskAction(task.tool_action);
    setTaskParams(task.tool_params);
    setTaskCron(task.schedule_cron);
    if (task.alert_condition) {
      try {
        const ac = JSON.parse(task.alert_condition);
        setAlertField(ac.field || "");
        setAlertOp(ac.operator || ">");
        setAlertValue(ac.value || "");
        setAlertMessage(ac.message || "");
      } catch { /* */ }
    }
    setEditingId(task.id);
    setShowForm(true);
  };

  const handleRunNow = async (taskId: number) => {
    try {
      await fetch(`${API_BASE}/api/tasks/${taskId}/run`, {
        method: "POST",
        headers: { "Content-Type": "application/json", ...getAuthHeaders() },
      });
      toast({ title: "EXECUTED", description: "Task ran successfully" });
      onRefresh();
    } catch {
      toast({ title: "ERROR", description: "Task execution failed", variant: "destructive" });
    }
  };

  const handleDelete = async (taskId: number) => {
    try {
      await fetch(`${API_BASE}/api/tasks/${taskId}`, {
        method: "DELETE",
        headers: getAuthHeaders(),
      });
      toast({ title: "DELETED", description: "Task purged" });
      onRefresh();
    } catch {
      toast({ title: "ERROR", description: "Failed to delete task", variant: "destructive" });
    }
  };

  const handleToggleActive = async (task: ScheduledTask) => {
    try {
      await fetch(`${API_BASE}/api/tasks/${task.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json", ...getAuthHeaders() },
        body: JSON.stringify({ is_active: !task.is_active }),
      });
      onRefresh();
    } catch { /* */ }
  };

  const formatTimeAgo = (dateStr: string | null) => {
    if (!dateStr) return "Never";
    const diff = Date.now() - new Date(dateStr).getTime();
    const mins = Math.floor(diff / 60000);
    if (mins < 1) return "Just now";
    if (mins < 60) return `${mins}m ago`;
    const hours = Math.floor(mins / 60);
    if (hours < 24) return `${hours}h ago`;
    return `${Math.floor(hours / 24)}d ago`;
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-3">
        <h2 className="font-display text-[10px] tracking-[0.15em] text-trident-amber text-glow-amber uppercase">
          MONITORING TASKS
        </h2>
        <button
          onClick={() => { resetForm(); setShowForm(!showForm); }}
          className="flex items-center gap-1.5 px-2 py-1 text-[9px] font-mono uppercase tracking-widest text-trident-cyan border border-trident-cyan/30 hover:bg-trident-cyan/10 transition-all"
          data-testid="button-new-task"
        >
          <Plus className="w-3 h-3" />
          NEW TASK
        </button>
      </div>

      {/* Task creation form */}
      {showForm && (
        <div className="border border-trident-cyan/30 bg-[#0a1628] p-4 mb-3 space-y-3" data-testid="form-new-task">
          <FormField label="TASK NAME" value={taskName} onChange={setTaskName} placeholder="VM Health Check" />
          <FormField label="DESCRIPTION" value={taskDesc} onChange={setTaskDesc} placeholder="Check all VMs are running" />

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-mono text-[8px] uppercase tracking-widest text-trident-text/40 mb-1">TOOL</label>
              <select
                value={taskTool}
                onChange={(e) => { setTaskTool(e.target.value as ToolName); setTaskAction(""); }}
                className="w-full font-mono text-xs bg-[#050a0e] border border-trident-border text-trident-text px-2 py-1.5 focus:border-trident-cyan focus:outline-none uppercase"
                data-testid="select-task-tool"
              >
                {(Object.keys(TOOL_DEFS) as ToolName[]).map((tn) => (
                  <option key={tn} value={tn}>{TOOL_DEFS[tn].label}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block font-mono text-[8px] uppercase tracking-widest text-trident-text/40 mb-1">ACTION</label>
              <select
                value={taskAction}
                onChange={(e) => setTaskAction(e.target.value)}
                className="w-full font-mono text-xs bg-[#050a0e] border border-trident-border text-trident-text px-2 py-1.5 focus:border-trident-cyan focus:outline-none uppercase"
                data-testid="select-task-action"
              >
                <option value="">-- SELECT --</option>
                {TOOL_DEFS[taskTool].actions.map((a) => (
                  <option key={a.value} value={a.value}>{a.label}</option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className="block font-mono text-[8px] uppercase tracking-widest text-trident-text/40 mb-1">PARAMS (JSON)</label>
            <textarea
              value={taskParams}
              onChange={(e) => setTaskParams(e.target.value)}
              rows={2}
              className="w-full font-mono text-xs bg-[#050a0e] border border-trident-border text-trident-text px-2 py-1.5 resize-none focus:border-trident-cyan focus:outline-none placeholder:text-trident-text/15"
              data-testid="textarea-task-params"
            />
          </div>

          {/* Schedule presets */}
          <div>
            <label className="block font-mono text-[8px] uppercase tracking-widest text-trident-text/40 mb-1">SCHEDULE</label>
            <div className="flex items-center gap-1 mb-2">
              {CRON_PRESETS.map((p) => (
                <button
                  key={p.value}
                  onClick={() => setTaskCron(p.value)}
                  className={`px-2 py-1 text-[8px] font-mono uppercase border transition-all ${
                    taskCron === p.value
                      ? "border-trident-cyan text-trident-cyan bg-trident-cyan/10"
                      : "border-trident-border text-trident-text/40 hover:border-trident-cyan/50"
                  }`}
                >
                  {p.label}
                </button>
              ))}
            </div>
            <input
              type="text"
              value={taskCron}
              onChange={(e) => setTaskCron(e.target.value)}
              className="w-full font-mono text-xs bg-[#050a0e] border border-trident-border text-trident-text px-2 py-1.5 focus:border-trident-cyan focus:outline-none"
              placeholder="*/5 * * * *"
              data-testid="input-cron"
            />
          </div>

          {/* Alert condition */}
          <div className="border border-trident-border/50 p-2 space-y-2">
            <label className="block font-mono text-[8px] uppercase tracking-widest text-trident-amber/60">ALERT CONDITION (OPTIONAL)</label>
            <div className="grid grid-cols-4 gap-2">
              <input
                type="text"
                value={alertField}
                onChange={(e) => setAlertField(e.target.value)}
                placeholder="data.used_pct"
                className="font-mono text-[10px] bg-[#050a0e] border border-trident-border text-trident-text px-1.5 py-1 focus:border-trident-amber focus:outline-none placeholder:text-trident-text/15"
                data-testid="input-alert-field"
              />
              <select
                value={alertOp}
                onChange={(e) => setAlertOp(e.target.value)}
                className="font-mono text-[10px] bg-[#050a0e] border border-trident-border text-trident-text px-1.5 py-1 focus:border-trident-amber focus:outline-none"
                data-testid="select-alert-op"
              >
                <option value=">">{">"}</option>
                <option value="<">{"<"}</option>
                <option value="==">{"=="}</option>
                <option value="!=">{"!="}</option>
                <option value=">=">{">="}</option>
                <option value="<=">{"<="}</option>
              </select>
              <input
                type="text"
                value={alertValue}
                onChange={(e) => setAlertValue(e.target.value)}
                placeholder="80"
                className="font-mono text-[10px] bg-[#050a0e] border border-trident-border text-trident-text px-1.5 py-1 focus:border-trident-amber focus:outline-none placeholder:text-trident-text/15"
                data-testid="input-alert-value"
              />
              <input
                type="text"
                value={alertMessage}
                onChange={(e) => setAlertMessage(e.target.value)}
                placeholder="Alert msg"
                className="font-mono text-[10px] bg-[#050a0e] border border-trident-border text-trident-text px-1.5 py-1 focus:border-trident-amber focus:outline-none placeholder:text-trident-text/15"
                data-testid="input-alert-message"
              />
            </div>
          </div>

          <div className="flex items-center gap-2 pt-1">
            <button
              onClick={handleSave}
              className="flex items-center gap-1.5 px-3 py-2 text-[9px] font-display uppercase tracking-widest border border-trident-cyan text-trident-cyan hover:bg-trident-cyan/10 transition-all"
              data-testid="button-save-task"
            >
              <Check className="w-3 h-3" />
              {editingId ? "UPDATE TASK" : "CREATE TASK"}
            </button>
            <button
              onClick={resetForm}
              className="flex items-center gap-1.5 px-3 py-2 text-[9px] font-mono uppercase tracking-widest text-trident-text/40 border border-trident-border hover:text-trident-text/60 transition-all"
              data-testid="button-cancel-task"
            >
              <X className="w-3 h-3" />
              CANCEL
            </button>
          </div>
        </div>
      )}

      {/* Task list */}
      {loading ? (
        <div className="text-center py-6">
          <Loader2 className="w-5 h-5 text-trident-cyan animate-spin mx-auto" />
        </div>
      ) : tasks.length === 0 ? (
        <div className="border border-trident-border bg-[#0a1628]/50 p-6 text-center">
          <Clock className="w-5 h-5 text-trident-text/20 mx-auto mb-2" />
          <p className="font-mono text-[9px] text-trident-text/30 uppercase tracking-widest">NO MONITORING TASKS CONFIGURED</p>
        </div>
      ) : (
        <div className="space-y-1">
          {tasks.map((task) => {
            let lastResultSummary = "";
            if (task.last_result) {
              try {
                const lr = JSON.parse(task.last_result);
                if (lr.success) lastResultSummary = "✓ Success";
                else lastResultSummary = `✗ ${lr.error || "Failed"}`;
              } catch {
                lastResultSummary = "—";
              }
            }

            return (
              <div key={task.id} className="border border-trident-border bg-[#0a1628]/80 px-4 py-2.5" data-testid={`task-${task.id}`}>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => handleToggleActive(task)}
                      className={`w-2 h-2 rounded-full ${task.is_active ? "bg-[#00ff41] animate-pulse" : "bg-trident-text/20"}`}
                      data-testid={`button-toggle-task-${task.id}`}
                    />
                    <span className="font-mono text-xs text-trident-text uppercase tracking-wider">
                      {task.name}
                    </span>
                    <span className="font-mono text-[8px] text-trident-text/30 uppercase">
                      {task.schedule_cron}
                    </span>
                    <span className="font-mono text-[8px] text-trident-cyan/50">
                      {task.tool_name}_{task.tool_action}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => handleRunNow(task.id)}
                      className="px-1.5 py-0.5 text-[8px] font-mono uppercase text-trident-cyan border border-trident-cyan/20 hover:bg-trident-cyan/10 transition-all"
                      data-testid={`button-run-task-${task.id}`}
                    >
                      RUN NOW
                    </button>
                    <button
                      onClick={() => handleEdit(task)}
                      className="p-0.5 text-trident-text/30 hover:text-trident-amber transition-colors"
                      data-testid={`button-edit-task-${task.id}`}
                    >
                      <Pencil className="w-3 h-3" />
                    </button>
                    <button
                      onClick={() => handleDelete(task.id)}
                      className="p-0.5 text-trident-text/30 hover:text-trident-red transition-colors"
                      data-testid={`button-delete-task-${task.id}`}
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </div>
                </div>
                {(task.last_run || task.alert_condition) && (
                  <div className="flex items-center gap-4 mt-1.5 pl-5">
                    {task.last_run && (
                      <span className="font-mono text-[8px] text-trident-text/30">
                        Last: {formatTimeAgo(task.last_run)} — {lastResultSummary}
                      </span>
                    )}
                    {task.alert_condition && (
                      <span className="font-mono text-[8px] text-trident-amber/50">
                        Alert if: {(() => {
                          try {
                            const ac = JSON.parse(task.alert_condition);
                            return `${ac.field} ${ac.operator} ${ac.value}`;
                          } catch { return "configured"; }
                        })()}
                      </span>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════
// QUICK EXECUTE
// ═══════════════════════════════════════════════════

function QuickExecute() {
  const [tool, setTool] = useState<ToolName>("system");
  const [action, setAction] = useState("");
  const [params, setParams] = useState("{}");
  const [result, setResult] = useState<string | null>(null);
  const [executing, setExecuting] = useState(false);
  const [execTime, setExecTime] = useState<number | null>(null);

  const handleExecute = async () => {
    if (!action) return;
    setExecuting(true);
    setResult(null);
    const start = Date.now();
    try {
      let parsedParams = {};
      try { parsedParams = JSON.parse(params); } catch { /* */ }

      const res = await fetch(`${API_BASE}/api/tools/execute`, {
        method: "POST",
        headers: { "Content-Type": "application/json", ...getAuthHeaders() },
        body: JSON.stringify({ tool_name: tool, action, params: parsedParams }),
      });
      const data = await res.json();
      setExecTime(Date.now() - start);
      setResult(JSON.stringify(data, null, 2));
    } catch (err: any) {
      setExecTime(Date.now() - start);
      setResult(JSON.stringify({ error: err.message }, null, 2));
    } finally {
      setExecuting(false);
    }
  };

  return (
    <div>
      <h2 className="font-display text-[10px] tracking-[0.15em] text-trident-amber text-glow-amber uppercase mb-3">
        QUICK EXECUTE
      </h2>
      <div className="border border-trident-border bg-[#0a1628]/80">
        <div className="p-3 space-y-3">
          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="block font-mono text-[8px] uppercase tracking-widest text-trident-text/40 mb-1">TOOL</label>
              <select
                value={tool}
                onChange={(e) => { setTool(e.target.value as ToolName); setAction(""); }}
                className="w-full font-mono text-xs bg-[#050a0e] border border-trident-border text-trident-text px-2 py-1.5 focus:border-trident-cyan focus:outline-none uppercase"
                data-testid="select-exec-tool"
              >
                {(Object.keys(TOOL_DEFS) as ToolName[]).map((tn) => (
                  <option key={tn} value={tn}>{TOOL_DEFS[tn].label}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block font-mono text-[8px] uppercase tracking-widest text-trident-text/40 mb-1">ACTION</label>
              <select
                value={action}
                onChange={(e) => setAction(e.target.value)}
                className="w-full font-mono text-xs bg-[#050a0e] border border-trident-border text-trident-text px-2 py-1.5 focus:border-trident-cyan focus:outline-none uppercase"
                data-testid="select-exec-action"
              >
                <option value="">-- SELECT --</option>
                {TOOL_DEFS[tool].actions.map((a) => (
                  <option key={a.value} value={a.value}>{a.label}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block font-mono text-[8px] uppercase tracking-widest text-trident-text/40 mb-1">PARAMS</label>
              <input
                type="text"
                value={params}
                onChange={(e) => setParams(e.target.value)}
                className="w-full font-mono text-xs bg-[#050a0e] border border-trident-border text-trident-text px-2 py-1.5 focus:border-trident-cyan focus:outline-none"
                placeholder='{}'
                data-testid="input-exec-params"
              />
            </div>
          </div>
          <button
            onClick={handleExecute}
            disabled={!action || executing}
            className="flex items-center gap-1.5 px-4 py-2 text-[9px] font-display uppercase tracking-widest border border-[#00ff41] text-[#00ff41] hover:bg-[#00ff41]/10 transition-all disabled:opacity-30"
            data-testid="button-execute"
          >
            {executing ? <Loader2 className="w-3 h-3 animate-spin" /> : <Zap className="w-3 h-3" />}
            EXECUTE
          </button>
        </div>

        {/* Output */}
        {result !== null && (
          <div className="border-t border-trident-border">
            <div className="flex items-center justify-between px-3 py-1.5 bg-[#050a0e]">
              <span className="font-mono text-[8px] text-trident-text/30 uppercase tracking-widest">
                <Terminal className="w-3 h-3 inline mr-1.5" />
                OUTPUT
              </span>
              {execTime !== null && (
                <span className="font-mono text-[8px] text-trident-cyan/50">
                  {execTime}ms
                </span>
              )}
            </div>
            <pre
              className="p-3 font-mono text-[10px] text-[#00ff41] bg-[#050a0e] max-h-[300px] overflow-auto whitespace-pre-wrap"
              data-testid="text-exec-output"
            >
              {result}
            </pre>
          </div>
        )}
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════
// RUN HISTORY
// ═══════════════════════════════════════════════════

function RunHistory({ runs, tasks }: { runs: TaskRun[]; tasks: ScheduledTask[] }) {
  const [expanded, setExpanded] = useState(false);
  const [expandedRun, setExpandedRun] = useState<number | null>(null);

  const getTaskName = (taskId: number) => {
    const task = tasks.find((t) => t.id === taskId);
    return task?.name || `Task #${taskId}`;
  };

  const statusIcon = (status: string) => {
    switch (status) {
      case "success": return <Check className="w-3 h-3 text-[#00ff41]" />;
      case "failed": return <X className="w-3 h-3 text-trident-red" />;
      case "alerted": return <AlertTriangle className="w-3 h-3 text-trident-amber" />;
      default: return <Loader2 className="w-3 h-3 text-trident-cyan animate-spin" />;
    }
  };

  const formatDuration = (start: string, end: string | null) => {
    if (!end) return "—";
    const ms = new Date(end).getTime() - new Date(start).getTime();
    return ms < 1000 ? `${ms}ms` : `${(ms / 1000).toFixed(1)}s`;
  };

  return (
    <div>
      <button
        onClick={() => setExpanded(!expanded)}
        className="flex items-center gap-2 mb-3"
        data-testid="button-toggle-history"
      >
        {expanded ? <ChevronDown className="w-3 h-3 text-trident-amber" /> : <ChevronRight className="w-3 h-3 text-trident-amber" />}
        <h2 className="font-display text-[10px] tracking-[0.15em] text-trident-amber text-glow-amber uppercase">
          TASK RUN HISTORY ({runs.length})
        </h2>
      </button>

      {expanded && (
        <div className="border border-trident-border bg-[#0a1628]/80">
          {runs.length === 0 ? (
            <div className="p-6 text-center">
              <p className="font-mono text-[9px] text-trident-text/30 uppercase tracking-widest">NO RUNS RECORDED</p>
            </div>
          ) : (
            <div className="divide-y divide-trident-border/50">
              {runs.slice(0, 20).map((run) => (
                <div key={run.id}>
                  <div
                    className="flex items-center justify-between px-4 py-2 cursor-pointer hover:bg-trident-cyan/5 transition-colors"
                    onClick={() => setExpandedRun(expandedRun === run.id ? null : run.id)}
                    data-testid={`run-${run.id}`}
                  >
                    <div className="flex items-center gap-3">
                      {statusIcon(run.status)}
                      <span className="font-mono text-[10px] text-trident-text uppercase">{getTaskName(run.task_id)}</span>
                    </div>
                    <div className="flex items-center gap-4">
                      <span className="font-mono text-[8px] text-trident-text/30">
                        {new Date(run.started_at).toLocaleString()}
                      </span>
                      <span className="font-mono text-[8px] text-trident-cyan/50">
                        {formatDuration(run.started_at, run.completed_at)}
                      </span>
                      {run.alert_triggered ? (
                        <span className="px-1.5 py-0.5 text-[7px] font-mono uppercase text-trident-amber border border-trident-amber/30 bg-trident-amber/5">
                          ALERT
                        </span>
                      ) : null}
                    </div>
                  </div>
                  {expandedRun === run.id && (
                    <div className="px-4 py-2 bg-[#050a0e]/80 border-t border-trident-border/30">
                      <pre className="font-mono text-[9px] text-[#00ff41]/80 max-h-[200px] overflow-auto whitespace-pre-wrap">
                        {run.result ? JSON.stringify(JSON.parse(run.result), null, 2) : run.error || "No data"}
                      </pre>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
