import { useState, useEffect, useCallback } from "react";
import {
  GalleryHorizontalEnd,
  Heart,
  Download,
  Trash2,
  X,
  ChevronLeft,
  ChevronRight,
  RefreshCw,
  Loader2,
  ImageOff,
  Star,
} from "lucide-react";
import { useAuth, getAuthHeaders } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";

const API_BASE = "__PORT_5000__".startsWith("__") ? "" : "__PORT_5000__";

// ═══════════════════════════════════════════════════
// TYPES
// ═══════════════════════════════════════════════════
interface GalleryImage {
  id: number;
  prompt: string;
  negative_prompt: string;
  width: number;
  height: number;
  steps: number;
  cfg_scale: number;
  seed: number;
  actual_seed: number | null;
  model: string;
  created_at: string;
  is_favorite: number;
  imageUrl: string;
}

function formatDate(iso: string): string {
  try {
    const d = new Date(iso);
    return d.toLocaleDateString("en-US", { month: "short", day: "2-digit", year: "numeric" });
  } catch {
    return "";
  }
}

function formatSize(bytes: number): string {
  if (!bytes) return "0 B";
  const mb = bytes / (1024 * 1024);
  if (mb >= 1) return `${mb.toFixed(1)} MB`;
  const kb = bytes / 1024;
  return `${kb.toFixed(0)} KB`;
}

// ═══════════════════════════════════════════════════
// LIGHTBOX
// ═══════════════════════════════════════════════════
function Lightbox({
  image,
  images,
  onClose,
  onPrev,
  onNext,
}: {
  image: GalleryImage;
  images: GalleryImage[];
  onClose: () => void;
  onPrev: () => void;
  onNext: () => void;
}) {
  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
      if (e.key === "ArrowLeft") onPrev();
      if (e.key === "ArrowRight") onNext();
    };
    window.addEventListener("keydown", handleKey);
    return () => window.removeEventListener("keydown", handleKey);
  }, [onClose, onPrev, onNext]);

  const idx = images.findIndex((i) => i.id === image.id);

  return (
    <div
      className="fixed inset-0 z-50 bg-black/90 flex items-center justify-center"
      onClick={onClose}
      data-testid="lightbox-overlay"
    >
      <button
        onClick={onClose}
        className="absolute top-4 right-4 z-50 text-trident-text/60 hover:text-trident-cyan transition-colors"
        data-testid="button-lightbox-close"
      >
        <X className="w-6 h-6" />
      </button>

      {idx > 0 && (
        <button
          onClick={(e) => { e.stopPropagation(); onPrev(); }}
          className="absolute left-4 top-1/2 -translate-y-1/2 z-50 text-trident-text/40 hover:text-trident-cyan transition-colors p-2"
          data-testid="button-lightbox-prev"
        >
          <ChevronLeft className="w-8 h-8" />
        </button>
      )}

      {idx < images.length - 1 && (
        <button
          onClick={(e) => { e.stopPropagation(); onNext(); }}
          className="absolute right-4 top-1/2 -translate-y-1/2 z-50 text-trident-text/40 hover:text-trident-cyan transition-colors p-2"
          data-testid="button-lightbox-next"
        >
          <ChevronRight className="w-8 h-8" />
        </button>
      )}

      <div
        className="max-w-[90vw] max-h-[90vh] flex flex-col items-center"
        onClick={(e) => e.stopPropagation()}
      >
        <img
          src={`${API_BASE}${image.imageUrl}`}
              onError={(e) => { const t = e.target as HTMLImageElement; if (!t.dataset.retried) { t.dataset.retried="1"; fetch(`${API_BASE}${image.imageUrl}`, { headers: getAuthHeaders() }).then(r=>r.blob()).then(b=>{t.src=URL.createObjectURL(b)}).catch(()=>{}); } }}
          alt={image.prompt}
          className="max-w-full max-h-[75vh] object-contain border border-trident-border"
          crossOrigin="use-credentials"
        />
        <div className="mt-4 text-center space-y-1 max-w-2xl">
          <p className="font-mono text-xs text-trident-text leading-relaxed" style={{ textTransform: "none" }}>
            {image.prompt}
          </p>
          <div className="flex items-center justify-center gap-3 text-[9px] font-mono uppercase tracking-widest text-trident-text/30">
            <span>SEED: <span className="text-trident-cyan/60">{image.actual_seed ?? image.seed}</span></span>
            <span className="text-trident-border">|</span>
            <span>{image.width}×{image.height}</span>
            <span className="text-trident-border">|</span>
            <span>{image.model}</span>
            <span className="text-trident-border">|</span>
            <span>{formatDate(image.created_at)}</span>
          </div>
        </div>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════
// MAIN GALLERY
// ═══════════════════════════════════════════════════
export default function DashboardGallery() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [filter, setFilter] = useState<"all" | "favorites">("all");
  const [sort, setSort] = useState<"newest" | "oldest">("newest");
  const [page, setPage] = useState(1);
  const [allImages, setAllImages] = useState<GalleryImage[]>([]);
  const [lightboxImage, setLightboxImage] = useState<GalleryImage | null>(null);
  const PAGE_SIZE = 20;

  // Fetch gallery page
  const { data, isLoading, isFetching, refetch } = useQuery({
    queryKey: ["/api/imagegen/gallery", page],
    queryFn: async () => {
      const res = await fetch(`${API_BASE}/api/imagegen/gallery?page=${page}&limit=${PAGE_SIZE}`, {
        headers: getAuthHeaders(),
      });
      if (!res.ok) throw new Error("FAILED TO LOAD GALLERY");
      return res.json() as Promise<{ images: GalleryImage[]; total: number; page: number; pages: number }>;
    },
    staleTime: 0,
  });

  // Accumulate images for "load more"
  useEffect(() => {
    if (data?.images) {
      if (page === 1) {
        setAllImages(data.images);
      } else {
        setAllImages((prev) => {
          const existingIds = new Set(prev.map((i) => i.id));
          const newImages = data.images.filter((i) => !existingIds.has(i.id));
          return [...prev, ...newImages];
        });
      }
    }
  }, [data, page]);

  // Filter and sort
  const filteredImages = allImages
    .filter((img) => filter === "all" || img.is_favorite === 1)
    .sort((a, b) => {
      if (sort === "newest") return new Date(b.created_at).getTime() - new Date(a.created_at).getTime();
      return new Date(a.created_at).getTime() - new Date(b.created_at).getTime();
    });

  const totalCount = data?.total ?? 0;
  const favoriteCount = allImages.filter((i) => i.is_favorite === 1).length;
  const hasMore = data ? page < data.pages : false;

  // Toggle favorite
  const favMutation = useMutation({
    mutationFn: async (imageId: number) => {
      const res = await fetch(`${API_BASE}/api/imagegen/image/${imageId}/favorite`, {
        method: "PATCH",
        headers: getAuthHeaders(),
      });
      if (!res.ok) throw new Error("FAILED");
      return res.json();
    },
    onSuccess: (result, imageId) => {
      setAllImages((prev) =>
        prev.map((img) => (img.id === imageId ? { ...img, is_favorite: result.is_favorite } : img))
      );
    },
  });

  // Delete image
  const deleteMutation = useMutation({
    mutationFn: async (imageId: number) => {
      const res = await fetch(`${API_BASE}/api/imagegen/image/${imageId}`, {
        method: "DELETE",
        headers: getAuthHeaders(),
      });
      if (!res.ok) throw new Error("FAILED");
      return res.json();
    },
    onSuccess: (_result, imageId) => {
      setAllImages((prev) => prev.filter((img) => img.id !== imageId));
      if (lightboxImage?.id === imageId) setLightboxImage(null);
      toast({
        title: ">> IMAGE PURGED",
        description: "ASSET REMOVED FROM DATABASE",
        className: "terminal-text border-trident-border bg-trident-surface",
      });
    },
  });

  // Download
  const handleDownload = useCallback(async (image: GalleryImage) => {
    try {
      const res = await fetch(`${API_BASE}${image.imageUrl}`, {
        headers: getAuthHeaders(),
      });
      if (!res.ok) throw new Error("FAILED");
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `trident_${image.id}_${image.actual_seed ?? image.seed}.png`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch {
      toast({
        title: ">> ERROR",
        description: "DOWNLOAD FAILED",
        variant: "destructive",
        className: "border-[#ff2244] bg-trident-surface text-[#ff2244]",
      });
    }
  }, [toast]);

  // Lightbox navigation
  const lightboxIdx = lightboxImage ? filteredImages.findIndex((i) => i.id === lightboxImage.id) : -1;
  const handlePrev = useCallback(() => {
    if (lightboxIdx > 0) setLightboxImage(filteredImages[lightboxIdx - 1]);
  }, [lightboxIdx, filteredImages]);
  const handleNext = useCallback(() => {
    if (lightboxIdx < filteredImages.length - 1) setLightboxImage(filteredImages[lightboxIdx + 1]);
  }, [lightboxIdx, filteredImages]);

  const handleRefresh = () => {
    setPage(1);
    setAllImages([]);
    refetch();
  };

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="trident-panel p-4 mb-4">
        <div className="flex items-center justify-between">
          <h1 className="font-display text-sm tracking-[0.15em] text-trident-amber text-glow-amber flex items-center gap-2">
            <GalleryHorizontalEnd className="w-4 h-4" />
            ASSET DATABASE
          </h1>

          <div className="flex items-center gap-3">
            {/* Filter tabs */}
            <div className="flex items-center border border-trident-border">
              <button
                onClick={() => setFilter("all")}
                className={`px-3 py-1 text-[10px] font-mono uppercase tracking-widest transition-colors ${
                  filter === "all"
                    ? "bg-trident-cyan/10 text-trident-cyan border-r border-trident-border"
                    : "text-trident-text/40 hover:text-trident-cyan border-r border-trident-border"
                }`}
                data-testid="button-filter-all"
              >
                ALL
              </button>
              <button
                onClick={() => setFilter("favorites")}
                className={`px-3 py-1 text-[10px] font-mono uppercase tracking-widest transition-colors flex items-center gap-1 ${
                  filter === "favorites"
                    ? "bg-trident-amber/10 text-trident-amber"
                    : "text-trident-text/40 hover:text-trident-amber"
                }`}
                data-testid="button-filter-favorites"
              >
                <Star className="w-3 h-3" />
                FAVORITES
              </button>
            </div>

            {/* Sort */}
            <select
              value={sort}
              onChange={(e) => setSort(e.target.value as "newest" | "oldest")}
              className="appearance-none bg-transparent border border-trident-border px-2 py-1 text-[10px] font-mono uppercase tracking-widest text-trident-text/60 cursor-pointer"
              data-testid="select-sort"
            >
              <option value="newest" className="bg-trident-surface">NEWEST</option>
              <option value="oldest" className="bg-trident-surface">OLDEST</option>
            </select>

            {/* Refresh */}
            <button
              onClick={handleRefresh}
              className="p-1.5 border border-trident-border text-trident-text/40 hover:text-trident-cyan hover:border-trident-cyan/30 transition-colors"
              data-testid="button-refresh-gallery"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isFetching ? "animate-spin" : ""}`} />
            </button>
          </div>
        </div>

        {/* Stats bar */}
        <div className="mt-3 flex items-center gap-4 text-[10px] font-mono uppercase tracking-widest text-trident-text/40">
          <span>{totalCount} <span className="text-trident-cyan">IMAGES</span></span>
          <span className="text-trident-border">|</span>
          <span>{favoriteCount} <span className="text-trident-amber">FAVORITES</span></span>
        </div>
      </div>

      {/* Gallery grid */}
      <div className="flex-1 overflow-auto">
        {isLoading ? (
          <div className="flex items-center justify-center h-64">
            <div className="flex items-center gap-2">
              {[0, 1, 2].map((i) => (
                <span
                  key={i}
                  className="inline-block w-2 h-2 rounded-full bg-trident-cyan pulse-dot"
                  style={{ animationDelay: `${i * 0.3}s` }}
                />
              ))}
              <span className="text-xs font-mono uppercase tracking-widest text-trident-text/40 ml-2">
                LOADING ASSET DATABASE...
              </span>
            </div>
          </div>
        ) : filteredImages.length === 0 ? (
          <div className="flex items-center justify-center h-64">
            <div className="text-center space-y-3">
              <ImageOff className="w-8 h-8 text-trident-text/20 mx-auto" />
              <p className="font-mono text-[10px] uppercase tracking-widest text-trident-text/30">
                {filter === "favorites"
                  ? "NO FAVORITES MARKED — USE ♡ TO TAG ASSETS"
                  : "NO ASSETS IN DATABASE — USE IMAGE GEN TO CREATE"}
              </p>
            </div>
          </div>
        ) : (
          <>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-3 pb-4">
              {filteredImages.map((img) => (
                <div
                  key={img.id}
                  className={`group relative border transition-all cursor-pointer ${
                    img.is_favorite === 1
                      ? "border-trident-amber/40 shadow-[0_0_8px_rgba(255,107,0,0.15)]"
                      : "border-trident-border hover:border-trident-cyan/30"
                  }`}
                  style={{ backgroundColor: "#0a1628" }}
                  data-testid={`card-image-${img.id}`}
                >
                  {/* Thumbnail */}
                  <div
                    className="relative aspect-square overflow-hidden"
                    onClick={() => setLightboxImage(img)}
                  >
                    <img
                      src={`${API_BASE}${img.imageUrl}`}
                    onError={(e) => { const t = e.target as HTMLImageElement; if (!t.dataset.retried) { t.dataset.retried="1"; fetch(`${API_BASE}${img.imageUrl}`, { headers: getAuthHeaders() }).then(r=>r.blob()).then(b=>{t.src=URL.createObjectURL(b)}).catch(()=>{}); } }}
                      alt={img.prompt}
                      className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                      crossOrigin="use-credentials"
                      loading="lazy"
                    />

                    {/* Hover overlay with full prompt + buttons */}
                    <div className="absolute inset-0 bg-black/70 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col justify-between p-2">
                      <p
                        className="font-mono text-[10px] text-trident-text leading-relaxed line-clamp-4"
                        style={{ textTransform: "none" }}
                      >
                        {img.prompt}
                      </p>
                      <div className="flex items-center justify-end gap-1.5 mt-1">
                        <button
                          onClick={(e) => { e.stopPropagation(); favMutation.mutate(img.id); }}
                          className={`p-1.5 border transition-colors ${
                            img.is_favorite === 1
                              ? "border-trident-amber/40 text-trident-amber bg-trident-amber/10"
                              : "border-trident-border text-trident-text/40 hover:text-trident-amber hover:border-trident-amber/30"
                          }`}
                          data-testid={`button-fav-${img.id}`}
                        >
                          <Heart className={`w-3 h-3 ${img.is_favorite === 1 ? "fill-current" : ""}`} />
                        </button>
                        <button
                          onClick={(e) => { e.stopPropagation(); handleDownload(img); }}
                          className="p-1.5 border border-trident-border text-trident-text/40 hover:text-trident-cyan hover:border-trident-cyan/30 transition-colors"
                          data-testid={`button-download-${img.id}`}
                        >
                          <Download className="w-3 h-3" />
                        </button>
                        <button
                          onClick={(e) => { e.stopPropagation(); deleteMutation.mutate(img.id); }}
                          className="p-1.5 border border-trident-border text-trident-text/40 hover:text-trident-red hover:border-trident-red/30 transition-colors"
                          data-testid={`button-delete-${img.id}`}
                        >
                          <Trash2 className="w-3 h-3" />
                        </button>
                      </div>
                    </div>

                    {/* Favorite indicator */}
                    {img.is_favorite === 1 && (
                      <div className="absolute top-1.5 right-1.5 text-trident-amber">
                        <Heart className="w-3 h-3 fill-current" />
                      </div>
                    )}
                  </div>

                  {/* Info footer */}
                  <div className="px-2 py-1.5 border-t border-trident-border/50">
                    <p
                      className="font-mono text-[10px] text-trident-text/60 truncate"
                      style={{ textTransform: "none" }}
                    >
                      {img.prompt.length > 40 ? img.prompt.slice(0, 40) + "…" : img.prompt}
                    </p>
                    <div className="flex items-center justify-between mt-0.5 text-[8px] font-mono uppercase tracking-widest text-trident-text/25">
                      <span>{img.width}×{img.height}</span>
                      <span>{formatDate(img.created_at)}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Load more */}
            {hasMore && (
              <div className="flex justify-center pb-6">
                <button
                  onClick={() => setPage((p) => p + 1)}
                  disabled={isFetching}
                  className="trident-btn trident-btn-primary px-6 py-2 text-xs flex items-center gap-2 disabled:opacity-50"
                  data-testid="button-load-more"
                >
                  {isFetching ? (
                    <>
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      LOADING...
                    </>
                  ) : (
                    "[ LOAD MORE ]"
                  )}
                </button>
              </div>
            )}
          </>
        )}
      </div>

      {/* Lightbox */}
      {lightboxImage && (
        <Lightbox
          image={lightboxImage}
          images={filteredImages}
          onClose={() => setLightboxImage(null)}
          onPrev={handlePrev}
          onNext={handleNext}
        />
      )}
    </div>
  );
}
