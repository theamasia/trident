import { useState, useEffect, useRef, useCallback } from "react";
import { useAuth, getAuthHeaders } from "@/hooks/use-auth";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import {
  Image,
  Loader2,
  Heart,
  Download,
  Trash2,
  Wifi,
  WifiOff,
  Dice5,
  Sparkles,
  ChevronDown,
  X,
  AlertTriangle,
} from "lucide-react";

// ═══════════════════════════════════════════════════
// API Base for deployment compatibility
// ═══════════════════════════════════════════════════
const API_BASE = "__PORT_5000__".startsWith("__") ? "" : "__PORT_5000__";

// ═══════════════════════════════════════════════════
// Types
// ═══════════════════════════════════════════════════
interface ImageGenStatus {
  online: boolean;
  backend: "automatic1111" | "diffusers" | "offline";
}

interface SDModel {
  title: string;
  model_name: string;
  hash: string;
}

interface GalleryImage {
  id: number;
  prompt: string;
  negative_prompt: string;
  width: number;
  height: number;
  steps: number;
  cfg_scale: number;
  seed: number;
  actual_seed: number;
  model: string;
  created_at: string;
  is_favorite: number;
  imageUrl: string;
}

interface GalleryResponse {
  images: GalleryImage[];
  total: number;
  page: number;
  pages: number;
}

interface GenerateResult {
  id: number;
  imageUrl: string;
  seed: number;
  width: number;
  height: number;
  elapsed_ms: number;
}

// ═══════════════════════════════════════════════════
// Component
// ═══════════════════════════════════════════════════
export default function DashboardImageGen() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // ─── Generation Form State ───────────────────────
  const [prompt, setPrompt] = useState("");
  const [negativePrompt, setNegativePrompt] = useState("");
  const [selectedModel, setSelectedModel] = useState("");
  const [width, setWidth] = useState(512);
  const [height, setHeight] = useState(512);
  const [steps, setSteps] = useState(20);
  const [cfgScale, setCfgScale] = useState(7.0);
  const [seed, setSeed] = useState(-1);
  const [sampler, setSampler] = useState("DPM++ 2M Karras");

  // ─── Generation State ────────────────────────────
  const [isGenerating, setIsGenerating] = useState(false);
  const [generateStart, setGenerateStart] = useState<number | null>(null);
  const [elapsedTime, setElapsedTime] = useState(0);

  // ─── Display State ───────────────────────────────
  const [currentImage, setCurrentImage] = useState<(GalleryImage & { elapsed_ms?: number }) | null>(null);
  const [galleryPage, setGalleryPage] = useState(1);
  const [lightboxOpen, setLightboxOpen] = useState(false);

  // ─── Timer ───────────────────────────────────────
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    if (isGenerating && generateStart) {
      timerRef.current = setInterval(() => {
        setElapsedTime(Math.floor((Date.now() - generateStart) / 1000));
      }, 200);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
      setElapsedTime(0);
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isGenerating, generateStart]);

  // ═══════════════════════════════════════════════════
  // Queries
  // ═══════════════════════════════════════════════════

  const { data: statusData } = useQuery<ImageGenStatus>({
    queryKey: ["/api/imagegen/status"],
    refetchInterval: 10000,
    queryFn: async () => {
      const res = await fetch(`${API_BASE}/api/imagegen/status`, { headers: getAuthHeaders() });
      if (!res.ok) throw new Error("Failed");
      return res.json();
    },
  });

  const { data: modelsData } = useQuery<SDModel[]>({
    queryKey: ["/api/imagegen/models"],
    queryFn: async () => {
      const res = await fetch(`${API_BASE}/api/imagegen/models`, { headers: getAuthHeaders() });
      if (!res.ok) return [];
      return res.json();
    },
    retry: false,
  });

  const { data: galleryData, refetch: refetchGallery } = useQuery<GalleryResponse>({
    queryKey: ["/api/imagegen/gallery", galleryPage],
    queryFn: async () => {
      const res = await fetch(`${API_BASE}/api/imagegen/gallery?page=${galleryPage}&limit=20`, {
        headers: getAuthHeaders(),
      });
      if (!res.ok) throw new Error("Failed");
      return res.json();
    },
  });

  const isOnline = statusData?.online ?? false;
  const backendLabel = statusData?.backend === "automatic1111"
    ? "A1111"
    : statusData?.backend === "diffusers"
    ? "DIFFUSERS"
    : "OFFLINE";

  // ═══════════════════════════════════════════════════
  // Generate
  // ═══════════════════════════════════════════════════

  const generate = useCallback(async () => {
    if (!prompt.trim()) {
      toast({ title: "VISUAL DIRECTIVE REQUIRED", description: "Enter a prompt to generate", variant: "destructive" });
      return;
    }
    if (!isOnline) {
      toast({ title: "ENGINE OFFLINE", description: "Visual synthesis engine is not running", variant: "destructive" });
      return;
    }

    setIsGenerating(true);
    setGenerateStart(Date.now());

    try {
      const res = await fetch(`${API_BASE}/api/imagegen/generate`, {
        method: "POST",
        headers: { "Content-Type": "application/json", ...getAuthHeaders() },
        body: JSON.stringify({
          prompt: prompt.trim(),
          negative_prompt: negativePrompt.trim(),
          width,
          height,
          steps,
          cfg_scale: cfgScale,
          seed,
          model: selectedModel || undefined,
        }),
      });

      const data = await res.json();
      if (!res.ok || data.error) {
        throw new Error(data.error || "Generation failed");
      }

      const result = data as GenerateResult;
      setCurrentImage({
        id: result.id,
        imageUrl: result.imageUrl,
        prompt: prompt.trim(),
        negative_prompt: negativePrompt.trim(),
        width: result.width ?? width,
        height: result.height ?? height,
        steps,
        cfg_scale: cfgScale,
        seed,
        actual_seed: result.seed,
        model: selectedModel || "stable-diffusion",
        created_at: new Date().toISOString(),
        is_favorite: 0,
        elapsed_ms: result.elapsed_ms,
      });

      // Refresh gallery
      queryClient.invalidateQueries({ queryKey: ["/api/imagegen/gallery"] });

      toast({ title: "SYNTHESIS COMPLETE", description: `Seed: ${result.seed} | ${(result.elapsed_ms / 1000).toFixed(1)}s` });
    } catch (err: any) {
      toast({ title: "SYNTHESIS FAILED", description: err.message, variant: "destructive" });
    } finally {
      setIsGenerating(false);
      setGenerateStart(null);
    }
  }, [prompt, negativePrompt, width, height, steps, cfgScale, seed, selectedModel, isOnline, toast, queryClient]);

  // ═══════════════════════════════════════════════════
  // Actions
  // ═══════════════════════════════════════════════════

  const toggleFavorite = async (id: number) => {
    try {
      const res = await fetch(`${API_BASE}/api/imagegen/image/${id}/favorite`, {
        method: "PATCH",
        headers: getAuthHeaders(),
      });
      if (!res.ok) throw new Error("Failed");
      const data = await res.json();
      if (currentImage?.id === id) {
        setCurrentImage({ ...currentImage, is_favorite: data.is_favorite });
      }
      queryClient.invalidateQueries({ queryKey: ["/api/imagegen/gallery"] });
    } catch {
      toast({ title: "ACTION FAILED", variant: "destructive" });
    }
  };

  const deleteImage = async (id: number) => {
    try {
      const res = await fetch(`${API_BASE}/api/imagegen/image/${id}`, {
        method: "DELETE",
        headers: getAuthHeaders(),
      });
      if (!res.ok) throw new Error("Failed");
      if (currentImage?.id === id) setCurrentImage(null);
      queryClient.invalidateQueries({ queryKey: ["/api/imagegen/gallery"] });
      toast({ title: "IMAGE PURGED" });
    } catch {
      toast({ title: "DELETE FAILED", variant: "destructive" });
    }
  };

  const downloadImage = (img: GalleryImage) => {
    const link = document.createElement("a");
    link.href = `${API_BASE}${img.imageUrl}`;
    link.download = `trident_${img.id}_${img.actual_seed}.png`;
    // We need to fetch with auth and create a blob URL
    fetch(`${API_BASE}${img.imageUrl}`, { headers: getAuthHeaders() })
      .then((r) => r.blob())
      .then((blob) => {
        const url = URL.createObjectURL(blob);
        link.href = url;
        link.click();
        URL.revokeObjectURL(url);
      });
  };

  const selectGalleryImage = (img: GalleryImage) => {
    setCurrentImage(img);
    setPrompt(img.prompt);
    setNegativePrompt(img.negative_prompt || "");
    setWidth(img.width ?? 512);
    setHeight(img.height ?? 512);
    setSteps(img.steps ?? 20);
    setCfgScale(img.cfg_scale ?? 7.0);
  };

  // ═══════════════════════════════════════════════════
  // Render
  // ═══════════════════════════════════════════════════

  const images = galleryData?.images ?? [];

  return (
    <div className="flex flex-col lg:flex-row h-full gap-0 overflow-hidden" style={{ backgroundColor: "#050a0e" }}>
      {/* ═══ LEFT: GENERATION CONTROLS ═══ */}
      <div
        className="w-full lg:w-[400px] lg:min-w-[400px] flex flex-col border-r overflow-y-auto"
        style={{ borderColor: "#1a3a4a" }}
      >
        {/* Header */}
        <div className="scanlines px-4 py-3 border-b" style={{ borderColor: "#1a3a4a", background: "#0a1628" }}>
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4" style={{ color: "#00f0ff" }} />
            <h2
              className="text-xs font-display tracking-widest uppercase"
              style={{ color: "#00f0ff", fontFamily: "Orbitron, sans-serif" }}
            >
              VISUAL SYNTHESIS ENGINE
            </h2>
          </div>
        </div>

        {/* Status Bar */}
        <div className="px-4 py-2 border-b flex items-center justify-between" style={{ borderColor: "#1a3a4a", background: "#080e14" }}>
          <div className="flex items-center gap-2">
            {isOnline ? (
              <Wifi className="w-3.5 h-3.5" style={{ color: "#00ff41" }} />
            ) : (
              <WifiOff className="w-3.5 h-3.5" style={{ color: "#ff2244" }} />
            )}
            <span
              className="text-[10px] uppercase tracking-wider font-mono font-bold"
              style={{ color: isOnline ? "#00ff41" : "#ff2244" }}
              data-testid="status-sd-connection"
            >
              {isOnline ? "SD ONLINE" : "SD OFFLINE"}
            </span>
          </div>
          <span
            className="text-[10px] uppercase tracking-wider font-mono"
            style={{ color: "#3a5a6a" }}
            data-testid="text-backend-type"
          >
            BACKEND: {backendLabel}
          </span>
        </div>

        {/* Offline Warning */}
        {!isOnline && (
          <div className="mx-4 mt-3 p-3 border" style={{ borderColor: "#ff6b00", background: "rgba(255, 107, 0, 0.05)" }}>
            <div className="flex items-start gap-2">
              <AlertTriangle className="w-4 h-4 mt-0.5 flex-shrink-0" style={{ color: "#ff6b00" }} />
              <div>
                <p className="text-[10px] uppercase tracking-wider font-mono font-bold" style={{ color: "#ff6b00" }}>
                  VISUAL SYNTHESIS ENGINE OFFLINE
                </p>
                <p className="text-[10px] font-mono mt-1" style={{ color: "#b0d0e0" }}>
                  RUN <span style={{ color: "#00ff41" }}>scripts/setup-imagegen.sh</span> TO INSTALL
                </p>
                <p className="text-[10px] font-mono mt-0.5" style={{ color: "#3a5a6a" }}>
                  OR <span style={{ color: "#00ff41" }}>scripts/setup-imagegen-cpu.sh</span> FOR CPU MODE
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Controls */}
        <div className="flex-1 overflow-y-auto px-4 py-3 space-y-4">
          {/* Prompt */}
          <div>
            <label className="block text-[10px] uppercase tracking-widest font-mono font-bold mb-1.5" style={{ color: "#00f0ff" }}>
              VISUAL DIRECTIVE
            </label>
            <textarea
              className="trident-input w-full px-3 py-2 text-xs resize-none"
              rows={6}
              placeholder="Describe the image to generate..."
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) generate();
              }}
              data-testid="input-prompt"
              style={{ textTransform: "none" }}
            />
          </div>

          {/* Negative Prompt */}
          <div>
            <label className="block text-[10px] uppercase tracking-widest font-mono font-bold mb-1.5" style={{ color: "#3a5a6a" }}>
              NEGATIVE DIRECTIVE
            </label>
            <textarea
              className="trident-input w-full px-3 py-2 text-xs resize-none"
              rows={3}
              placeholder="Elements to exclude..."
              value={negativePrompt}
              onChange={(e) => setNegativePrompt(e.target.value)}
              data-testid="input-negative-prompt"
              style={{ textTransform: "none" }}
            />
          </div>

          {/* Separator */}
          <div className="border-t" style={{ borderColor: "#1a3a4a" }} />

          {/* Model */}
          <div>
            <label className="block text-[10px] uppercase tracking-widest font-mono font-bold mb-1.5" style={{ color: "#00f0ff" }}>
              MODEL
            </label>
            <div className="relative">
              <select
                className="trident-input w-full px-3 py-2 text-xs appearance-none pr-8"
                value={selectedModel}
                onChange={(e) => setSelectedModel(e.target.value)}
                disabled={!isOnline}
                data-testid="select-model"
              >
                {!isOnline && <option value="">SD OFFLINE</option>}
                {isOnline && <option value="">DEFAULT MODEL</option>}
                {(modelsData ?? []).map((m) => (
                  <option key={m.model_name} value={m.model_name}>
                    {m.title}
                  </option>
                ))}
              </select>
              <ChevronDown
                className="absolute right-2 top-1/2 -translate-y-1/2 w-3.5 h-3.5 pointer-events-none"
                style={{ color: "#3a5a6a" }}
              />
            </div>
          </div>

          {/* Width × Height */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-[10px] uppercase tracking-widest font-mono font-bold mb-1.5" style={{ color: "#00f0ff" }}>
                WIDTH
              </label>
              <div className="relative">
                <select
                  className="trident-input w-full px-3 py-2 text-xs appearance-none pr-8"
                  value={width}
                  onChange={(e) => setWidth(Number(e.target.value))}
                  data-testid="select-width"
                >
                  <option value={512}>512 PX</option>
                  <option value={640}>640 PX</option>
                  <option value={768}>768 PX</option>
                  <option value={1024}>1024 PX</option>
                </select>
                <ChevronDown className="absolute right-2 top-1/2 -translate-y-1/2 w-3.5 h-3.5 pointer-events-none" style={{ color: "#3a5a6a" }} />
              </div>
            </div>
            <div>
              <label className="block text-[10px] uppercase tracking-widest font-mono font-bold mb-1.5" style={{ color: "#00f0ff" }}>
                HEIGHT
              </label>
              <div className="relative">
                <select
                  className="trident-input w-full px-3 py-2 text-xs appearance-none pr-8"
                  value={height}
                  onChange={(e) => setHeight(Number(e.target.value))}
                  data-testid="select-height"
                >
                  <option value={512}>512 PX</option>
                  <option value={640}>640 PX</option>
                  <option value={768}>768 PX</option>
                  <option value={1024}>1024 PX</option>
                </select>
                <ChevronDown className="absolute right-2 top-1/2 -translate-y-1/2 w-3.5 h-3.5 pointer-events-none" style={{ color: "#3a5a6a" }} />
              </div>
            </div>
          </div>

          {/* Steps Slider */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-[10px] uppercase tracking-widest font-mono font-bold" style={{ color: "#00f0ff" }}>
                STEPS
              </label>
              <span className="text-[10px] font-mono font-bold" style={{ color: "#00ff41" }} data-testid="text-steps-value">
                {steps}
              </span>
            </div>
            <input
              type="range"
              min={1}
              max={50}
              step={1}
              value={steps}
              onChange={(e) => setSteps(Number(e.target.value))}
              className="w-full accent-cyan-400"
              style={{ accentColor: "#00f0ff" }}
              data-testid="slider-steps"
            />
            <div className="flex justify-between text-[9px] font-mono" style={{ color: "#3a5a6a" }}>
              <span>1</span>
              <span>50</span>
            </div>
          </div>

          {/* CFG Scale Slider */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-[10px] uppercase tracking-widest font-mono font-bold" style={{ color: "#00f0ff" }}>
                CFG SCALE
              </label>
              <span className="text-[10px] font-mono font-bold" style={{ color: "#00ff41" }} data-testid="text-cfg-value">
                {cfgScale.toFixed(1)}
              </span>
            </div>
            <input
              type="range"
              min={1}
              max={20}
              step={0.5}
              value={cfgScale}
              onChange={(e) => setCfgScale(Number(e.target.value))}
              className="w-full"
              style={{ accentColor: "#00f0ff" }}
              data-testid="slider-cfg"
            />
            <div className="flex justify-between text-[9px] font-mono" style={{ color: "#3a5a6a" }}>
              <span>1</span>
              <span>20</span>
            </div>
          </div>

          {/* Seed */}
          <div>
            <label className="block text-[10px] uppercase tracking-widest font-mono font-bold mb-1.5" style={{ color: "#00f0ff" }}>
              SEED
            </label>
            <div className="flex gap-2">
              <input
                type="number"
                className="trident-input flex-1 px-3 py-2 text-xs"
                value={seed}
                onChange={(e) => setSeed(Number(e.target.value))}
                data-testid="input-seed"
                style={{ textTransform: "none" }}
              />
              <button
                className="trident-btn trident-btn-secondary px-3 py-2 text-[10px] flex items-center gap-1.5 whitespace-nowrap"
                onClick={() => setSeed(-1)}
                data-testid="button-random-seed"
              >
                <Dice5 className="w-3 h-3" />
                RANDOM
              </button>
            </div>
          </div>

          {/* Sampler */}
          <div>
            <label className="block text-[10px] uppercase tracking-widest font-mono font-bold mb-1.5" style={{ color: "#00f0ff" }}>
              SAMPLER
            </label>
            <div className="relative">
              <select
                className="trident-input w-full px-3 py-2 text-xs appearance-none pr-8"
                value={sampler}
                onChange={(e) => setSampler(e.target.value)}
                data-testid="select-sampler"
              >
                <option value="DPM++ 2M Karras">DPM++ 2M KARRAS</option>
                <option value="Euler a">EULER A</option>
                <option value="DDIM">DDIM</option>
                <option value="Euler">EULER</option>
              </select>
              <ChevronDown className="absolute right-2 top-1/2 -translate-y-1/2 w-3.5 h-3.5 pointer-events-none" style={{ color: "#3a5a6a" }} />
            </div>
          </div>
        </div>

        {/* Generate Button */}
        <div className="px-4 py-3 border-t" style={{ borderColor: "#1a3a4a", background: "#0a1628" }}>
          <button
            className="trident-btn w-full py-3 text-xs tracking-widest flex items-center justify-center gap-2 transition-all"
            style={{
              background: isGenerating ? "#1a3a4a" : "#ff6b00",
              color: isGenerating ? "#ff6b00" : "#000",
              border: `1px solid ${isGenerating ? "#ff6b00" : "#ff6b00"}`,
              cursor: isGenerating || !isOnline ? "not-allowed" : "pointer",
              opacity: !isOnline && !isGenerating ? 0.4 : 1,
            }}
            onClick={generate}
            disabled={isGenerating || !isOnline}
            data-testid="button-generate"
          >
            {isGenerating ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span className="animate-pulse">&gt;&gt; RENDERING NEURAL VISUALS</span>
                <span className="font-mono text-[10px] ml-1" style={{ color: "#ff6b00" }}>
                  {elapsedTime}s
                </span>
              </>
            ) : (
              <>[ SYNTHESIZE ]</>
            )}
          </button>
          {isGenerating && (
            <div className="mt-2 h-1 w-full overflow-hidden" style={{ background: "#1a3a4a" }}>
              <div
                className="h-full animate-pulse"
                style={{
                  background: "linear-gradient(90deg, #ff6b00, #00f0ff, #ff6b00)",
                  backgroundSize: "200% 100%",
                  animation: "shimmer 2s linear infinite",
                  width: "100%",
                }}
              />
            </div>
          )}
        </div>
      </div>

      {/* ═══ RIGHT: OUTPUT & GALLERY ═══ */}
      <div className="flex-1 flex flex-col overflow-hidden" style={{ background: "#050a0e" }}>
        {/* Current Output */}
        <div className="flex-1 min-h-0 overflow-y-auto">
          {currentImage ? (
            <div className="p-4">
              {/* Large Image Display */}
              <div
                className="relative border overflow-hidden cursor-pointer group"
                style={{ borderColor: "#1a3a4a", background: "#0a1628" }}
                onClick={() => setLightboxOpen(true)}
              >
                <img
                  src={`${API_BASE}${currentImage.imageUrl}`}
                  alt={currentImage.prompt}
                  className="w-full max-h-[60vh] object-contain"
                  data-testid="img-current-output"
                  crossOrigin="use-credentials"
                  onError={(e) => {
                    // If auth is needed, try adding headers via fetch
                    const target = e.target as HTMLImageElement;
                    if (!target.dataset.retried) {
                      target.dataset.retried = "1";
                      fetch(`${API_BASE}${currentImage.imageUrl}`, { headers: getAuthHeaders() })
                        .then((r) => r.blob())
                        .then((blob) => {
                          target.src = URL.createObjectURL(blob);
                        })
                        .catch(() => {});
                    }
                  }}
                />
                <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors" />
              </div>

              {/* Image Info */}
              <div className="mt-3 p-3 border" style={{ borderColor: "#1a3a4a", background: "#0a1628" }}>
                <p className="text-xs font-mono leading-relaxed" style={{ color: "#b0d0e0" }} data-testid="text-current-prompt">
                  {currentImage.prompt.length > 200 ? currentImage.prompt.slice(0, 200) + "..." : currentImage.prompt}
                </p>
                <div className="flex flex-wrap gap-x-4 gap-y-1 mt-2">
                  <span className="text-[10px] font-mono" style={{ color: "#3a5a6a" }}>
                    SEED: <span style={{ color: "#00ff41" }}>{currentImage.actual_seed ?? currentImage.seed}</span>
                  </span>
                  <span className="text-[10px] font-mono" style={{ color: "#3a5a6a" }}>
                    SIZE: <span style={{ color: "#00f0ff" }}>{currentImage.width}×{currentImage.height}</span>
                  </span>
                  <span className="text-[10px] font-mono" style={{ color: "#3a5a6a" }}>
                    STEPS: <span style={{ color: "#00f0ff" }}>{currentImage.steps}</span>
                  </span>
                  <span className="text-[10px] font-mono" style={{ color: "#3a5a6a" }}>
                    CFG: <span style={{ color: "#00f0ff" }}>{currentImage.cfg_scale}</span>
                  </span>
                  {currentImage.elapsed_ms && (
                    <span className="text-[10px] font-mono" style={{ color: "#3a5a6a" }}>
                      TIME: <span style={{ color: "#ff6b00" }}>{(currentImage.elapsed_ms / 1000).toFixed(1)}s</span>
                    </span>
                  )}
                </div>

                {/* Action buttons */}
                <div className="flex gap-2 mt-3">
                  <button
                    className="trident-btn trident-btn-secondary px-3 py-1.5 text-[10px] flex items-center gap-1.5"
                    onClick={() => toggleFavorite(currentImage.id)}
                    data-testid="button-favorite"
                    style={{
                      borderColor: currentImage.is_favorite ? "#ff6b00" : "#1a3a4a",
                      color: currentImage.is_favorite ? "#ff6b00" : "#00f0ff",
                    }}
                  >
                    <Heart
                      className="w-3 h-3"
                      fill={currentImage.is_favorite ? "#ff6b00" : "none"}
                      style={{ color: currentImage.is_favorite ? "#ff6b00" : "#00f0ff" }}
                    />
                    {currentImage.is_favorite ? "UNFAVORITE" : "FAVORITE"}
                  </button>
                  <button
                    className="trident-btn trident-btn-secondary px-3 py-1.5 text-[10px] flex items-center gap-1.5"
                    onClick={() => downloadImage(currentImage)}
                    data-testid="button-download"
                  >
                    <Download className="w-3 h-3" />
                    DOWNLOAD
                  </button>
                  <button
                    className="trident-btn px-3 py-1.5 text-[10px] flex items-center gap-1.5"
                    style={{ color: "#ff2244", borderColor: "#ff2244", border: "1px solid" }}
                    onClick={() => deleteImage(currentImage.id)}
                    data-testid="button-delete"
                  >
                    <Trash2 className="w-3 h-3" />
                    DELETE
                  </button>
                </div>
              </div>
            </div>
          ) : (
            /* Empty State */
            <div className="flex flex-col items-center justify-center h-full min-h-[300px] px-4">
              <div
                className="w-full max-w-md p-8 border text-center"
                style={{ borderColor: "#1a3a4a", background: "#0a1628" }}
              >
                <Image className="w-12 h-12 mx-auto mb-4" style={{ color: "#1a3a4a" }} />
                <p
                  className="text-sm font-mono tracking-wide cursor-blink"
                  style={{ color: "#3a5a6a" }}
                  data-testid="text-empty-state"
                >
                  &gt;&gt; AWAITING SYNTHESIS DIRECTIVE...
                </p>
                <p className="text-[10px] font-mono mt-2" style={{ color: "#1a3a4a" }}>
                  ENTER A PROMPT AND PRESS SYNTHESIZE
                </p>
              </div>
            </div>
          )}

          {/* Gallery Section */}
          <div className="px-4 pb-4">
            <div className="flex items-center justify-between mb-3 pt-2">
              <h3
                className="text-[10px] uppercase tracking-widest font-mono font-bold"
                style={{ color: "#00f0ff", fontFamily: "Orbitron, sans-serif" }}
              >
                IMAGE ARCHIVE
              </h3>
              <span className="text-[10px] font-mono" style={{ color: "#3a5a6a" }}>
                {galleryData?.total ?? 0} RECORDS
              </span>
            </div>

            {images.length === 0 ? (
              <div
                className="p-6 border text-center"
                style={{ borderColor: "#1a3a4a", background: "#0a1628" }}
              >
                <p className="text-xs font-mono" style={{ color: "#3a5a6a" }} data-testid="text-gallery-empty">
                  NO IMAGES IN ARCHIVE
                </p>
              </div>
            ) : (
              <>
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2">
                  {images.map((img) => (
                    <GalleryThumbnail
                      key={img.id}
                      image={img}
                      isSelected={currentImage?.id === img.id}
                      onSelect={() => selectGalleryImage(img)}
                      onDelete={() => deleteImage(img.id)}
                      onToggleFavorite={() => toggleFavorite(img.id)}
                    />
                  ))}
                </div>

                {/* Pagination */}
                {galleryData && galleryData.pages > 1 && (
                  <div className="flex items-center justify-center gap-2 mt-4">
                    {galleryPage > 1 && (
                      <button
                        className="trident-btn trident-btn-secondary px-3 py-1.5 text-[10px]"
                        onClick={() => setGalleryPage((p) => p - 1)}
                        data-testid="button-prev-page"
                      >
                        &lt; PREV
                      </button>
                    )}
                    <span className="text-[10px] font-mono" style={{ color: "#3a5a6a" }}>
                      PAGE {galleryData.page} / {galleryData.pages}
                    </span>
                    {galleryPage < galleryData.pages && (
                      <button
                        className="trident-btn trident-btn-secondary px-3 py-1.5 text-[10px]"
                        onClick={() => setGalleryPage((p) => p + 1)}
                        data-testid="button-next-page"
                      >
                        NEXT &gt;
                      </button>
                    )}
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      </div>

      {/* Lightbox */}
      {lightboxOpen && currentImage && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 cursor-pointer"
          onClick={() => setLightboxOpen(false)}
        >
          <button
            className="absolute top-4 right-4 p-2"
            style={{ color: "#00f0ff" }}
            onClick={() => setLightboxOpen(false)}
            data-testid="button-close-lightbox"
          >
            <X className="w-6 h-6" />
          </button>
          <img
            src={`${API_BASE}${currentImage.imageUrl}`}
            alt={currentImage.prompt}
            className="max-w-[90vw] max-h-[90vh] object-contain"
            onClick={(e) => e.stopPropagation()}
          />
        </div>
      )}

      {/* Shimmer keyframes (inline style) */}
      <style>{`
        @keyframes shimmer {
          0% { background-position: 200% 0; }
          100% { background-position: -200% 0; }
        }
      `}</style>
    </div>
  );
}

// ═══════════════════════════════════════════════════
// Gallery Thumbnail Component
// ═══════════════════════════════════════════════════
function GalleryThumbnail({
  image,
  isSelected,
  onSelect,
  onDelete,
  onToggleFavorite,
}: {
  image: GalleryImage;
  isSelected: boolean;
  onSelect: () => void;
  onDelete: () => void;
  onToggleFavorite: () => void;
}) {
  const [imgSrc, setImgSrc] = useState<string>("");

  useEffect(() => {
    // Load image with auth headers
    const API = "__PORT_5000__".startsWith("__") ? "" : "__PORT_5000__";
    fetch(`${API}${image.imageUrl}`, { headers: getAuthHeaders() })
      .then((r) => {
        if (r.ok) return r.blob();
        throw new Error("Failed");
      })
      .then((blob) => {
        setImgSrc(URL.createObjectURL(blob));
      })
      .catch(() => {
        // Fallback to direct URL
        setImgSrc(`${API}${image.imageUrl}`);
      });

    return () => {
      if (imgSrc && imgSrc.startsWith("blob:")) {
        URL.revokeObjectURL(imgSrc);
      }
    };
  }, [image.imageUrl]);

  return (
    <div
      className="relative group cursor-pointer overflow-hidden border transition-all"
      style={{
        borderColor: isSelected
          ? "#00f0ff"
          : image.is_favorite
          ? "#ff6b00"
          : "#1a3a4a",
        background: "#0a1628",
        boxShadow: isSelected
          ? "0 0 10px rgba(0, 240, 255, 0.3)"
          : image.is_favorite
          ? "0 0 5px rgba(255, 107, 0, 0.2)"
          : "none",
      }}
      onClick={onSelect}
      data-testid={`card-gallery-image-${image.id}`}
    >
      <div className="aspect-square overflow-hidden">
        {imgSrc ? (
          <img
            src={imgSrc}
            alt={image.prompt}
            className="w-full h-full object-cover transition-transform group-hover:scale-105"
            loading="lazy"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center">
            <Loader2 className="w-4 h-4 animate-spin" style={{ color: "#1a3a4a" }} />
          </div>
        )}
      </div>

      {/* Favorite indicator */}
      {image.is_favorite === 1 && (
        <div className="absolute top-1 right-1">
          <Heart className="w-3 h-3" fill="#ff6b00" style={{ color: "#ff6b00" }} />
        </div>
      )}

      {/* Hover overlay */}
      <div className="absolute inset-0 bg-black/0 group-hover:bg-black/70 transition-all flex flex-col justify-between p-2 opacity-0 group-hover:opacity-100">
        <p className="text-[9px] font-mono leading-tight line-clamp-3" style={{ color: "#b0d0e0" }}>
          {image.prompt}
        </p>
        <div className="flex items-center gap-1 justify-end">
          <button
            className="p-1 hover:opacity-80"
            onClick={(e) => {
              e.stopPropagation();
              onToggleFavorite();
            }}
            data-testid={`button-fav-${image.id}`}
          >
            <Heart
              className="w-3 h-3"
              fill={image.is_favorite ? "#ff6b00" : "none"}
              style={{ color: image.is_favorite ? "#ff6b00" : "#00f0ff" }}
            />
          </button>
          <button
            className="p-1 hover:opacity-80"
            onClick={(e) => {
              e.stopPropagation();
              onDelete();
            }}
            data-testid={`button-del-${image.id}`}
          >
            <Trash2 className="w-3 h-3" style={{ color: "#ff2244" }} />
          </button>
        </div>
      </div>
    </div>
  );
}
