#!/usr/bin/env bash
set -euo pipefail

# ═══════════════════════════════════════════════════════════════════
# TRIDENT — VISUAL SYNTHESIS ENGINE (CPU FALLBACK)
# Lightweight diffusers-based image generation for CPU-only systems
# Exposes the same SDAPI interface as AUTOMATIC1111 on port 7860
# ═══════════════════════════════════════════════════════════════════

# ─── ANSI Color Codes ───────────────────────────────────────────
CYAN='\033[0;36m'
GREEN='\033[0;32m'
AMBER='\033[0;33m'
RED='\033[0;31m'
BOLD='\033[1m'
DIM='\033[2m'
NC='\033[0m'

info()  { echo -e "${CYAN}[ TRIDENT ]${NC} $1"; }
ok()    { echo -e "${GREEN}[   ✓    ]${NC} $1"; }
warn()  { echo -e "${AMBER}[  WARN  ]${NC} $1"; }
fail()  { echo -e "${RED}[  FAIL  ]${NC} $1"; exit 1; }
step()  { echo -e "\n${BOLD}${CYAN}═══════════════════════════════════════════════════${NC}"; echo -e "${BOLD}${CYAN}  STEP $1: $2${NC}"; echo -e "${BOLD}${CYAN}═══════════════════════════════════════════════════${NC}\n"; }

# ─── ASCII Header ───────────────────────────────────────────────
echo -e "${CYAN}${BOLD}"
cat << 'HEADER'

  ████████╗██████╗ ██╗██████╗ ███████╗███╗   ██╗████████╗
  ╚══██╔══╝██╔══██╗██║██╔══██╗██╔════╝████╗  ██║╚══██╔══╝
     ██║   ██████╔╝██║██║  ██║█████╗  ██╔██╗ ██║   ██║
     ██║   ██╔══██╗██║██║  ██║██╔══╝  ██║╚██╗██║   ██║
     ██║   ██║  ██║██║██████╔╝███████╗██║ ╚████║   ██║
     ╚═╝   ╚═╝  ╚═╝╚═╝╚═════╝ ╚══════╝╚═╝  ╚═══╝   ╚═╝

  ▓▓▓  VISUAL SYNTHESIS ENGINE — CPU FALLBACK INSTALLER   ▓▓▓
  ▓▓▓  Backend: HuggingFace Diffusers | Port: 7860        ▓▓▓

HEADER
echo -e "${NC}"

# ─── Root Check ─────────────────────────────────────────────────
if [ "$EUID" -ne 0 ]; then
  fail "This script must be run as root (sudo)."
fi

# ═════════════════════════════════════════════════════════════════
# STEP 1: Install system dependencies
# ═════════════════════════════════════════════════════════════════
step "1/4" "INSTALLING SYSTEM DEPENDENCIES"

apt-get update -qq
apt-get install -y --no-install-recommends python3 python3-pip python3-venv

ok "System dependencies installed"

# ═════════════════════════════════════════════════════════════════
# STEP 2: Create virtual environment and install packages
# ═════════════════════════════════════════════════════════════════
step "2/4" "INSTALLING PYTHON PACKAGES"

INSTALL_DIR="/opt/trident-diffusers"
mkdir -p "$INSTALL_DIR"

if [ ! -d "$INSTALL_DIR/venv" ]; then
  info "Creating Python virtual environment..."
  python3 -m venv "$INSTALL_DIR/venv"
else
  warn "Virtual environment already exists — skipping creation (idempotent)"
fi

source "$INSTALL_DIR/venv/bin/activate"

info "Installing diffusers, transformers, accelerate, and PyTorch (CPU)..."
pip install --quiet --upgrade pip
pip install --quiet \
  diffusers \
  transformers \
  accelerate \
  torch --index-url https://download.pytorch.org/whl/cpu \
  flask \
  flask-cors \
  safetensors \
  Pillow

ok "Python packages installed"

# ═════════════════════════════════════════════════════════════════
# STEP 3: Create Flask API server (A1111-compatible)
# ═════════════════════════════════════════════════════════════════
step "3/4" "CREATING FLASK API SERVER"

cat > "$INSTALL_DIR/server.py" << 'PYEOF'
#!/usr/bin/env python3
"""
TRIDENT Visual Synthesis Engine — CPU Fallback (Diffusers)
Exposes the same /sdapi/v1/* endpoints as AUTOMATIC1111
so TRIDENT backend doesn't need to know which service is running.
"""

import base64
import io
import json
import time
import threading
from flask import Flask, request, jsonify
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

# ─── Global state ───────────────────────────────────────────────
pipe = None
model_id = "stabilityai/stable-diffusion-2-1-base"
model_loaded = False
loading = False
current_progress = {"progress": 0.0, "eta_relative": 0.0, "state": {"skipped": False, "interrupted": False, "job": "", "job_count": 0, "job_timestamp": "", "job_no": 0, "sampling_step": 0, "sampling_steps": 0}}


def load_model():
    """Load the diffusion model (happens on first request or startup)."""
    global pipe, model_loaded, loading
    if model_loaded or loading:
        return
    loading = True
    print("[ TRIDENT ] Loading diffusion model (this may take a few minutes)...")
    try:
        import torch
        from diffusers import StableDiffusionPipeline, DPMSolverMultistepScheduler

        pipe = StableDiffusionPipeline.from_pretrained(
            model_id,
            torch_dtype=torch.float32,
            safety_checker=None,
            requires_safety_checker=False,
        )
        pipe.scheduler = DPMSolverMultistepScheduler.from_config(pipe.scheduler.config)
        # CPU optimization
        pipe = pipe.to("cpu")
        pipe.enable_attention_slicing()
        model_loaded = True
        print("[ TRIDENT ] Model loaded successfully")
    except Exception as e:
        print(f"[ TRIDENT ] ERROR loading model: {e}")
        loading = False
        raise
    finally:
        loading = False


# ─── SDAPI-compatible endpoints ─────────────────────────────────

@app.route("/sdapi/v1/txt2img", methods=["POST"])
def txt2img():
    """Generate image from text prompt — same format as A1111."""
    global current_progress
    if not model_loaded:
        try:
            load_model()
        except Exception as e:
            return jsonify({"error": str(e)}), 500

    data = request.get_json()
    prompt = data.get("prompt", "")
    negative_prompt = data.get("negative_prompt", "")
    width = min(data.get("width", 512), 768)   # CPU limit
    height = min(data.get("height", 512), 768)  # CPU limit
    steps = min(data.get("steps", 20), 30)       # CPU limit
    cfg_scale = data.get("cfg_scale", 7.0)
    seed = data.get("seed", -1)

    import torch
    if seed == -1:
        generator = torch.Generator("cpu")
        seed = generator.initial_seed()
    else:
        generator = torch.Generator("cpu").manual_seed(seed)

    current_progress = {"progress": 0.1, "eta_relative": 60.0, "state": {"skipped": False, "interrupted": False, "job": "txt2img", "job_count": 1, "job_timestamp": str(time.time()), "job_no": 0, "sampling_step": 0, "sampling_steps": steps}}

    try:
        def callback(step_idx, t, latents):
            current_progress["progress"] = step_idx / steps
            current_progress["state"]["sampling_step"] = step_idx

        result = pipe(
            prompt=prompt,
            negative_prompt=negative_prompt,
            width=width,
            height=height,
            num_inference_steps=steps,
            guidance_scale=cfg_scale,
            generator=generator,
            callback=callback,
            callback_steps=1,
        )

        # Encode to base64
        images_b64 = []
        for img in result.images:
            buf = io.BytesIO()
            img.save(buf, format="PNG")
            b64 = base64.b64encode(buf.getvalue()).decode("utf-8")
            images_b64.append(b64)

        current_progress = {"progress": 0.0, "eta_relative": 0.0, "state": {"skipped": False, "interrupted": False, "job": "", "job_count": 0, "job_timestamp": "", "job_no": 0, "sampling_step": 0, "sampling_steps": 0}}

        return jsonify({
            "images": images_b64,
            "parameters": {
                "prompt": prompt,
                "negative_prompt": negative_prompt,
                "width": width,
                "height": height,
                "steps": steps,
                "cfg_scale": cfg_scale,
                "seed": seed,
            },
            "info": json.dumps({
                "seed": seed,
                "all_seeds": [seed],
                "prompt": prompt,
                "negative_prompt": negative_prompt,
                "width": width,
                "height": height,
                "steps": steps,
                "cfg_scale": cfg_scale,
            }),
        })
    except Exception as e:
        current_progress["progress"] = 0.0
        return jsonify({"error": str(e)}), 500


@app.route("/sdapi/v1/sd-models", methods=["GET"])
def sd_models():
    """List available models — compatible with A1111 format."""
    return jsonify([
        {
            "title": "stable-diffusion-2-1-base [diffusers]",
            "model_name": "stable-diffusion-2-1-base",
            "hash": "diffusers-cpu",
            "sha256": "",
            "filename": model_id,
            "config": None,
        }
    ])


@app.route("/sdapi/v1/progress", methods=["GET"])
def progress():
    """Return generation progress — compatible with A1111 format."""
    return jsonify(current_progress)


@app.route("/sdapi/v1/samplers", methods=["GET"])
def samplers():
    """List available samplers."""
    return jsonify([
        {"name": "DPM++ 2M Karras", "aliases": ["dpmpp_2m_karras"]},
        {"name": "Euler a", "aliases": ["euler_a"]},
        {"name": "DDIM", "aliases": ["ddim"]},
        {"name": "Euler", "aliases": ["euler"]},
    ])


@app.route("/", methods=["GET"])
def health():
    """Health check endpoint."""
    return jsonify({"status": "ok", "backend": "diffusers", "model_loaded": model_loaded})


if __name__ == "__main__":
    # Start model loading in background
    threading.Thread(target=load_model, daemon=True).start()
    print("[ TRIDENT ] CPU Diffusers backend starting on port 7860...")
    app.run(host="0.0.0.0", port=7860, threaded=True)
PYEOF

ok "Flask API server written: $INSTALL_DIR/server.py"

# ═════════════════════════════════════════════════════════════════
# STEP 4: Create systemd service
# ═════════════════════════════════════════════════════════════════
step "4/4" "CREATING SYSTEMD SERVICE"

cat > /etc/systemd/system/trident-imagegen.service << EOF
[Unit]
Description=TRIDENT Image Generation Service (CPU Diffusers Fallback)
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=$INSTALL_DIR
ExecStart=$INSTALL_DIR/venv/bin/python $INSTALL_DIR/server.py
Restart=on-failure
RestartSec=30
StandardOutput=journal
StandardError=journal
Environment=HOME=/root
Environment=HF_HOME=$INSTALL_DIR/.cache/huggingface

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable trident-imagegen

ok "Systemd service installed and enabled"

# ═════════════════════════════════════════════════════════════════
# SUMMARY
# ═════════════════════════════════════════════════════════════════
echo ""
echo -e "${CYAN}${BOLD}═══════════════════════════════════════════════════${NC}"
echo -e "${CYAN}${BOLD}  CPU FALLBACK INSTALLATION COMPLETE${NC}"
echo -e "${CYAN}${BOLD}═══════════════════════════════════════════════════${NC}"
echo ""
echo -e "${GREEN}[ TRIDENT ]${NC} Diffusers-based image generation installed"
echo -e "${GREEN}[ TRIDENT ]${NC} Start with: ${BOLD}systemctl start trident-imagegen${NC}"
echo -e "${AMBER}[ TRIDENT ]${NC} NOTE: First start downloads the model (~2GB). Takes 5-10 min."
echo -e "${AMBER}[ TRIDENT ]${NC} CPU generation is SLOW (~2-5 min per 512x512 image)"
echo -e "${GREEN}[ TRIDENT ]${NC} API will be available at: ${BOLD}http://localhost:7860${NC}"
echo ""
echo -e "${DIM}  Compatible with the same /sdapi/v1/* endpoints as AUTOMATIC1111"
echo -e "  TRIDENT will auto-detect which backend is running.${NC}"
echo ""
