#!/usr/bin/env bash
set -euo pipefail

# ═══════════════════════════════════════════════════════════════════
# TRIDENT — VISUAL SYNTHESIS ENGINE INSTALLER
# Installs Stable Diffusion AUTOMATIC1111 WebUI on Ubuntu 24.04
# Runs on port 7860 (internal), accessed via TRIDENT proxy
# ═══════════════════════════════════════════════════════════════════

# ─── ANSI Color Codes ───────────────────────────────────────────
CYAN='\033[0;36m'
GREEN='\033[0;32m'
AMBER='\033[0;33m'
RED='\033[0;31m'
BOLD='\033[1m'
DIM='\033[2m'
NC='\033[0m' # No Color

# ─── Print Functions ────────────────────────────────────────────
info()  { echo -e "${CYAN}[ TRIDENT ]${NC} $1"; }
ok()    { echo -e "${GREEN}[   ✓    ]${NC} $1"; }
warn()  { echo -e "${AMBER}[  WARN  ]${NC} $1"; }
fail()  { echo -e "${RED}[  FAIL  ]${NC} $1"; exit 1; }
step()  { echo -e "\n${BOLD}${CYAN}═══════════════════════════════════════════════════${NC}"; echo -e "${BOLD}${CYAN}  STEP $1: $2${NC}"; echo -e "${BOLD}${CYAN}═══════════════════════════════════════════════════${NC}\n"; }

# ─── ASCII Header ───────────────────────────────────────────────
echo -e "${CYAN}${BOLD}"
cat << 'HEADER'

  ████████╗██████╗ ██╗██████╗ ███████╗███╗   ██╗████████╗
  ╚══██╔══╝██╔══██╗██║██╔══██╗██╔════╝████╗  ██║╚══██╔══╝
     ██║   ██████╔╝██║██║  ██║█████╗  ██╔██╗ ██║   ██║
     ██║   ██╔══██╗██║██║  ██║██╔══╝  ██║╚██╗██║   ██║
     ██║   ██║  ██║██║██████╔╝███████╗██║ ╚████║   ██║
     ╚═╝   ╚═╝  ╚═╝╚═╝╚═════╝ ╚══════╝╚═╝  ╚═══╝   ╚═╝

  ▓▓▓  VISUAL SYNTHESIS ENGINE — AUTOMATIC1111 INSTALLER  ▓▓▓
  ▓▓▓  Target: Ubuntu 24.04 | Port: 7860 | Mode: API      ▓▓▓

HEADER
echo -e "${NC}"

# ─── Root Check ─────────────────────────────────────────────────
if [ "$EUID" -ne 0 ]; then
  fail "This script must be run as root (sudo)."
fi

# ═════════════════════════════════════════════════════════════════
# STEP 1: Install system dependencies
# ═════════════════════════════════════════════════════════════════
step "1/5" "INSTALLING SYSTEM DEPENDENCIES"

info "Updating package index..."
apt-get update -qq

info "Installing required system packages..."
apt-get install -y --no-install-recommends \
  git \
  python3 \
  python3-pip \
  python3-venv \
  wget \
  curl \
  libgl1 \
  libglib2.0-0 \
  libsm6 \
  libxext6 \
  libxrender-dev \
  libgomp1

ok "System dependencies installed"

# ═════════════════════════════════════════════════════════════════
# STEP 2: Clone AUTOMATIC1111 WebUI
# ═════════════════════════════════════════════════════════════════
step "2/5" "CLONING AUTOMATIC1111 WEBUI"

mkdir -p /opt/stable-diffusion
cd /opt/stable-diffusion

if [ -d "stable-diffusion-webui" ]; then
  warn "AUTOMATIC1111 directory already exists — skipping clone (idempotent)"
  cd stable-diffusion-webui
  info "Pulling latest changes..."
  git pull --ff-only || warn "Git pull failed — using existing version"
else
  info "Cloning AUTOMATIC1111 stable-diffusion-webui..."
  git clone https://github.com/AUTOMATIC1111/stable-diffusion-webui.git
  cd stable-diffusion-webui
  ok "Repository cloned successfully"
fi

# ═════════════════════════════════════════════════════════════════
# STEP 3: Download base model (SD 1.5 - ~4GB)
# ═════════════════════════════════════════════════════════════════
step "3/5" "DOWNLOADING BASE MODEL"

mkdir -p models/Stable-diffusion

MODEL_FILE="models/Stable-diffusion/v1-5-pruned-emaonly.safetensors"
MODEL_URL="https://huggingface.co/stable-diffusion-v1-5/stable-diffusion-v1-5/resolve/main/v1-5-pruned-emaonly.safetensors"

if [ -f "$MODEL_FILE" ]; then
  warn "SD 1.5 model already present — skipping download (idempotent)"
  ok "Model file: $MODEL_FILE"
else
  info "Downloading Stable Diffusion 1.5 base model (~4GB)..."
  info "Source: $MODEL_URL"
  wget -q --show-progress -O "$MODEL_FILE" "$MODEL_URL"
  ok "Base model downloaded successfully"
fi

# ═════════════════════════════════════════════════════════════════
# STEP 4: Create launch configuration
# ═════════════════════════════════════════════════════════════════
step "4/5" "CREATING LAUNCH CONFIGURATION"

cat > /opt/stable-diffusion/webui-config.sh << 'CONF'
#!/bin/bash
# TRIDENT Visual Synthesis Engine — AUTOMATIC1111 Launch Config
cd /opt/stable-diffusion/stable-diffusion-webui
export COMMANDLINE_ARGS="--api --nowebui --listen --port 7860 --no-half-vae"
bash webui.sh
CONF
chmod +x /opt/stable-diffusion/webui-config.sh

ok "Launch config written: /opt/stable-diffusion/webui-config.sh"
info "Launch flags: --api --nowebui --listen --port 7860 --no-half-vae"

# ═════════════════════════════════════════════════════════════════
# STEP 5: Create systemd service
# ═════════════════════════════════════════════════════════════════
step "5/5" "CREATING SYSTEMD SERVICE"

cat > /etc/systemd/system/trident-imagegen.service << 'EOF'
[Unit]
Description=TRIDENT Image Generation Service (Stable Diffusion AUTOMATIC1111)
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=/opt/stable-diffusion/stable-diffusion-webui
ExecStart=/opt/stable-diffusion/webui-config.sh
Restart=on-failure
RestartSec=30
StandardOutput=journal
StandardError=journal
Environment=HOME=/root

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable trident-imagegen

ok "Systemd service installed and enabled"

# ═════════════════════════════════════════════════════════════════
# SUMMARY
# ═════════════════════════════════════════════════════════════════
echo ""
echo -e "${CYAN}${BOLD}═══════════════════════════════════════════════════${NC}"
echo -e "${CYAN}${BOLD}  INSTALLATION COMPLETE${NC}"
echo -e "${CYAN}${BOLD}═══════════════════════════════════════════════════${NC}"
echo ""
echo -e "${GREEN}[ TRIDENT ]${NC} Image generation service installed"
echo -e "${GREEN}[ TRIDENT ]${NC} Start with: ${BOLD}systemctl start trident-imagegen${NC}"
echo -e "${AMBER}[ TRIDENT ]${NC} NOTE: First start downloads additional dependencies (~5-10 min)"
echo -e "${GREEN}[ TRIDENT ]${NC} API will be available at: ${BOLD}http://localhost:7860${NC}"
echo ""
echo -e "${AMBER}${BOLD}  ⚠  GPU ACCELERATION NOTE${NC}"
echo -e "${DIM}  CUDA GPU drivers must be installed separately for hardware acceleration."
echo -e "  Without GPU: generation will run on CPU (much slower, ~2-5 min per image)."
echo -e "  With NVIDIA GPU: install CUDA toolkit + drivers for real-time generation."
echo -e "  See: https://developer.nvidia.com/cuda-downloads${NC}"
echo ""
echo -e "${CYAN}${BOLD}  ═══ ALTERNATIVE: CPU-ONLY LIGHTWEIGHT OPTION ═══${NC}"
echo -e "${DIM}  For CPU-only generation without AUTOMATIC1111, run instead:"
echo -e "  ${BOLD}bash scripts/setup-imagegen-cpu.sh${NC}"
echo -e "${DIM}  Uses HuggingFace diffusers + a smaller model. Slower but simpler."
echo -e "  Exposes the same API format so TRIDENT works with either backend.${NC}"
echo ""
