import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { requireAuth, requireAdmin, generateToken } from "./middleware/auth";
import bcrypt from "bcryptjs";
import { z } from "zod";
import multer from "multer";
import http from "http";
import https from "https";
import fs from "fs";
import path from "path";
import crypto from "crypto";
import os from "os";
import dns from "dns";
import net from "net";
import { exec } from "child_process";
import { promisify } from "util";
import { startScheduler, scheduleTask, unscheduleTask, executeTask, setToolExecutor } from "./scheduler";
import type { ScheduledTask } from "@shared/schema";

const execAsync = promisify(exec);

// Validation schemas
const registerSchema = z.object({
  username: z.string().min(3).max(32),
  email: z.string().email(),
  password: z.string().min(8),
});

const loginSchema = z.object({
  email: z.string().email(),
  password: z.string(),
});

const updateUserSchema = z.object({
  role: z.enum(["admin", "power_user", "user"]).optional(),
  is_active: z.boolean().optional(),
});

const updateSettingsSchema = z.object({
  username: z.string().min(3).max(32).optional(),
  email: z.string().email().optional(),
  current_password: z.string().optional(),
  new_password: z.string().min(8).optional(),
});

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {

  // ═══════════════════════════════════════════════════
  // AUTH ROUTES
  // ═══════════════════════════════════════════════════

  // POST /api/auth/register — Create new user
  app.post("/api/auth/register", async (req, res) => {
    try {
      const data = registerSchema.parse(req.body);
      data.email = data.email.toLowerCase().trim();

      // Check uniqueness
      const existingEmail = await storage.getUserByEmail(data.email);
      if (existingEmail) {
        return res.status(409).json({ error: "EMAIL ALREADY REGISTERED" });
      }
      const existingUsername = await storage.getUserByUsername(data.username);
      if (existingUsername) {
        return res.status(409).json({ error: "USERNAME ALREADY TAKEN" });
      }

      const password_hash = await bcrypt.hash(data.password, 12);

      const user = await storage.createUser({
        username: data.username,
        email: data.email,
        password_hash,
        role: "user",
        is_active: true,
      });

      const { password_hash: _, ...safeUser } = user;
      res.status(201).json({ message: "ACCESS GRANTED — AWAIT AUTHENTICATION", user: safeUser });
    } catch (err: any) {
      if (err.name === "ZodError") {
        return res.status(400).json({ error: "INVALID INPUT DATA", details: err.errors });
      }
      console.error("Registration error:", err);
      res.status(500).json({ error: "SYSTEM ERROR — REGISTRATION FAILED" });
    }
  });

  // POST /api/auth/login — Validate credentials, return JWT
  app.post("/api/auth/login", async (req, res) => {
    try {
      const data = loginSchema.parse(req.body);
      data.email = data.email.toLowerCase().trim();

      const user = await storage.getUserByEmail(data.email);
      if (!user) {
        return res.status(401).json({ error: "INVALID CREDENTIALS" });
      }

      if (!user.is_active) {
        return res.status(403).json({ error: "ACCOUNT DEACTIVATED — CONTACT ADMINISTRATOR" });
      }

      const valid = await bcrypt.compare(data.password, user.password_hash);
      if (!valid) {
        return res.status(401).json({ error: "INVALID CREDENTIALS" });
      }

      // Update last login
      await storage.updateUser(user.id, { last_login: new Date().toISOString() });

      const token = generateToken(user.id, user.role);
      const { password_hash: _, ...safeUser } = user;

      res.json({ token, user: safeUser });
    } catch (err: any) {
      if (err.name === "ZodError") {
        return res.status(400).json({ error: "INVALID INPUT DATA" });
      }
      console.error("Login error:", err);
      res.status(500).json({ error: "SYSTEM ERROR — AUTHENTICATION FAILED" });
    }
  });

  // POST /api/auth/logout — Invalidate session
  app.post("/api/auth/logout", requireAuth, async (req, res) => {
    // With JWT, logout is client-side (discard token). 
    // We respond affirmatively.
    res.json({ message: "SESSION TERMINATED" });
  });

  // GET /api/auth/me — Return current user
  app.get("/api/auth/me", requireAuth, async (req, res) => {
    res.json({ user: req.user });
  });

  // ═══════════════════════════════════════════════════
  // USER SETTINGS
  // ═══════════════════════════════════════════════════

  app.patch("/api/auth/settings", requireAuth, async (req, res) => {
    try {
      const data = updateSettingsSchema.parse(req.body);
      const userId = req.user!.id;
      const updateData: any = {};

      if (data.username) updateData.username = data.username;
      if (data.email) updateData.email = data.email;

      if (data.new_password) {
        if (!data.current_password) {
          return res.status(400).json({ error: "CURRENT PASSWORD REQUIRED" });
        }
        const user = await storage.getUser(userId);
        if (!user) return res.status(404).json({ error: "USER NOT FOUND" });
        const valid = await bcrypt.compare(data.current_password, user.password_hash);
        if (!valid) return res.status(401).json({ error: "CURRENT PASSWORD INVALID" });
        updateData.password_hash = await bcrypt.hash(data.new_password, 12);
      }

      const updated = await storage.updateUser(userId, updateData);
      if (!updated) return res.status(404).json({ error: "USER NOT FOUND" });

      const { password_hash: _, ...safeUser } = updated;
      res.json({ user: safeUser });
    } catch (err: any) {
      if (err.name === "ZodError") {
        return res.status(400).json({ error: "INVALID INPUT DATA", details: err.errors });
      }
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  // ═══════════════════════════════════════════════════
  // ADMIN ROUTES
  // ═══════════════════════════════════════════════════

  // GET /api/admin/users — List all users
  app.get("/api/admin/users", requireAdmin, async (req, res) => {
    const allUsers = await storage.getAllUsers();
    res.json({ users: allUsers });
  });

  // PATCH /api/admin/users/:id — Update user role/status
  app.patch("/api/admin/users/:id", requireAdmin, async (req, res) => {
    try {
      const userId = parseInt(String(req.params.id), 10);
      if (isNaN(userId)) return res.status(400).json({ error: "INVALID USER ID" });

      const data = updateUserSchema.parse(req.body);
      const updated = await storage.updateUser(userId, data);
      if (!updated) return res.status(404).json({ error: "USER NOT FOUND" });

      const { password_hash: _, ...safeUser } = updated;
      res.json({ user: safeUser });
    } catch (err: any) {
      if (err.name === "ZodError") {
        return res.status(400).json({ error: "INVALID INPUT DATA" });
      }
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  // DELETE /api/admin/users/:id — Delete user
  app.delete("/api/admin/users/:id", requireAdmin, async (req, res) => {
    const userId = parseInt(String(req.params.id), 10);
    if (isNaN(userId)) return res.status(400).json({ error: "INVALID USER ID" });

    // Prevent self-delete
    if (userId === req.user!.id) {
      return res.status(400).json({ error: "CANNOT DELETE OWN ACCOUNT" });
    }

    const deleted = await storage.deleteUser(userId);
    if (!deleted) return res.status(404).json({ error: "USER NOT FOUND" });

    res.json({ message: "USER ELIMINATED" });
  });

  // ═══════════════════════════════════════════════════
  // PHASE 2 — OLLAMA PROXY ROUTES
  // ═══════════════════════════════════════════════════

  const OLLAMA_BASE = "http://localhost:11434";

  // GET /api/ollama/status — Check if Ollama is reachable
  app.get("/api/ollama/status", requireAuth, async (_req, res) => {
    try {
      const response = await fetch(`${OLLAMA_BASE}/api/version`);
      if (response.ok) {
        const data = await response.json();
        res.json({ online: true, version: data.version || "unknown" });
      } else {
        res.json({ online: false, version: "" });
      }
    } catch {
      res.json({ online: false, version: "" });
    }
  });

  // GET /api/ollama/models — List installed models
  app.get("/api/ollama/models", requireAuth, async (_req, res) => {
    try {
      const response = await fetch(`${OLLAMA_BASE}/api/tags`);
      if (!response.ok) {
        return res.status(502).json({ error: "OLLAMA UNREACHABLE" });
      }
      const data = await response.json();
      const models = (data.models || []).map((m: any) => ({
        name: m.name,
        size: m.size,
        modified_at: m.modified_at,
        details: m.details || {},
      }));
      res.json({ models });
    } catch {
      res.status(502).json({ error: "NEURAL LINK SEVERED — OLLAMA OFFLINE" });
    }
  });

  // POST /api/ollama/pull — Pull a model with SSE progress
  app.post("/api/ollama/pull", requireAuth, async (req, res) => {
    const { model } = req.body;
    if (!model || typeof model !== "string") {
      return res.status(400).json({ error: "MODEL NAME REQUIRED" });
    }

    res.setHeader("Content-Type", "text/event-stream");
    res.setHeader("Cache-Control", "no-cache");
    res.setHeader("Connection", "keep-alive");
    res.flushHeaders();

    try {
      const response = await fetch(`${OLLAMA_BASE}/api/pull`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: model, stream: true }),
      });

      if (!response.ok || !response.body) {
        res.write(`data: {"error":"FAILED TO INITIATE PULL"}\n\n`);
        return res.end();
      }

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split("\n");
        buffer = lines.pop() || "";

        for (const line of lines) {
          if (!line.trim()) continue;
          try {
            const parsed = JSON.parse(line);
            res.write(`data: ${JSON.stringify({
              status: parsed.status || "",
              completed: parsed.completed || 0,
              total: parsed.total || 0,
            })}\n\n`);
          } catch {
            // skip malformed lines
          }
        }
      }

      res.write(`data: {"done":true}\n\n`);
      res.end();
    } catch {
      res.write(`data: {"error":"NEURAL LINK SEVERED — OLLAMA OFFLINE"}\n\n`);
      res.end();
    }
  });

  // DELETE /api/ollama/models/:name — Delete a model
  app.delete("/api/ollama/models/:name", requireAuth, async (req, res) => {
    const modelName = req.params.name;
    try {
      const response = await fetch(`${OLLAMA_BASE}/api/delete`, {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: modelName }),
      });
      if (response.ok) {
        res.json({ message: "MODEL PURGED" });
      } else {
        const err = await response.text();
        res.status(response.status).json({ error: err || "DELETE FAILED" });
      }
    } catch {
      res.status(502).json({ error: "NEURAL LINK SEVERED — OLLAMA OFFLINE" });
    }
  });

  // ═══════════════════════════════════════════════════
  // PHASE 2 — CHAT / STREAMING ROUTE
  // ═══════════════════════════════════════════════════

  const TOOL_DEFINITIONS: Record<string, any> = {
    proxmox_get_nodes: {
      type: "function",
      function: {
        name: "proxmox_get_nodes",
        description: "Get list of all Proxmox hypervisor nodes with their status, CPU and memory usage",
        parameters: { type: "object", properties: {} },
      },
    },
    proxmox_get_vms: {
      type: "function",
      function: {
        name: "proxmox_get_vms",
        description: "Get list of all virtual machines from Proxmox with their status, CPU and memory usage",
        parameters: {
          type: "object",
          properties: {
            node: { type: "string", description: "Proxmox node name (default: pve)" },
          },
        },
      },
    },
    proxmox_get_vm_status: {
      type: "function",
      function: {
        name: "proxmox_get_vm_status",
        description: "Get detailed status of a specific virtual machine",
        parameters: {
          type: "object",
          properties: {
            node: { type: "string", description: "Proxmox node name" },
            vmid: { type: "string", description: "Virtual machine ID" },
          },
          required: ["node", "vmid"],
        },
      },
    },
    proxmox_start_vm: {
      type: "function",
      function: {
        name: "proxmox_start_vm",
        description: "Start a virtual machine on Proxmox",
        parameters: {
          type: "object",
          properties: {
            node: { type: "string", description: "Proxmox node name" },
            vmid: { type: "string", description: "Virtual machine ID" },
          },
          required: ["node", "vmid"],
        },
      },
    },
    proxmox_stop_vm: {
      type: "function",
      function: {
        name: "proxmox_stop_vm",
        description: "Stop a virtual machine on Proxmox",
        parameters: {
          type: "object",
          properties: {
            node: { type: "string", description: "Proxmox node name" },
            vmid: { type: "string", description: "Virtual machine ID" },
          },
          required: ["node", "vmid"],
        },
      },
    },
    proxmox_get_storage: {
      type: "function",
      function: {
        name: "proxmox_get_storage",
        description: "Get storage pools with usage information from Proxmox",
        parameters: {
          type: "object",
          properties: {
            node: { type: "string", description: "Proxmox node name (default: pve)" },
          },
        },
      },
    },
    truenas_get_pools: {
      type: "function",
      function: {
        name: "truenas_get_pools",
        description: "Get list of ZFS storage pools from TrueNAS with status and usage",
        parameters: { type: "object", properties: {} },
      },
    },
    truenas_get_datasets: {
      type: "function",
      function: {
        name: "truenas_get_datasets",
        description: "Get all ZFS datasets from TrueNAS with used and available space",
        parameters: { type: "object", properties: {} },
      },
    },
    truenas_get_alerts: {
      type: "function",
      function: {
        name: "truenas_get_alerts",
        description: "Get active alerts from TrueNAS",
        parameters: { type: "object", properties: {} },
      },
    },
    truenas_get_system_info: {
      type: "function",
      function: {
        name: "truenas_get_system_info",
        description: "Get TrueNAS system information including hostname, version, and uptime",
        parameters: { type: "object", properties: {} },
      },
    },
    truenas_get_disks: {
      type: "function",
      function: {
        name: "truenas_get_disks",
        description: "Get disk list from TrueNAS with temperatures and status",
        parameters: { type: "object", properties: {} },
      },
    },
    truenas_dismiss_alert: {
      type: "function",
      function: {
        name: "truenas_dismiss_alert",
        description: "Dismiss an alert on TrueNAS by UUID",
        parameters: {
          type: "object",
          properties: {
            uuid: { type: "string", description: "Alert UUID to dismiss" },
          },
          required: ["uuid"],
        },
      },
    },
    network_ping: {
      type: "function",
      function: {
        name: "network_ping",
        description: "Ping a host and return packet loss and average RTT",
        parameters: {
          type: "object",
          properties: {
            host: { type: "string", description: "Host or IP to ping" },
            count: { type: "number", description: "Number of pings (default: 4)" },
          },
          required: ["host"],
        },
      },
    },
    network_dns_lookup: {
      type: "function",
      function: {
        name: "network_dns_lookup",
        description: "Perform DNS lookup for a hostname",
        parameters: {
          type: "object",
          properties: {
            hostname: { type: "string", description: "Hostname to resolve" },
          },
          required: ["hostname"],
        },
      },
    },
    network_port_check: {
      type: "function",
      function: {
        name: "network_port_check",
        description: "Check if a TCP port is open on a host",
        parameters: {
          type: "object",
          properties: {
            host: { type: "string", description: "Host or IP to check" },
            port: { type: "number", description: "Port number to check" },
            timeout: { type: "number", description: "Timeout in ms (default: 3000)" },
          },
          required: ["host", "port"],
        },
      },
    },
    network_get_local_hosts: {
      type: "function",
      function: {
        name: "network_get_local_hosts",
        description: "Read /etc/hosts file and return all entries",
        parameters: { type: "object", properties: {} },
      },
    },
    network_traceroute: {
      type: "function",
      function: {
        name: "network_traceroute",
        description: "Run traceroute to a host",
        parameters: {
          type: "object",
          properties: {
            host: { type: "string", description: "Host or IP to trace route to" },
          },
          required: ["host"],
        },
      },
    },
    system_get_metrics: {
      type: "function",
      function: {
        name: "system_get_metrics",
        description: "Get TRIDENT server metrics: CPU usage, memory, disk, uptime, load average",
        parameters: { type: "object", properties: {} },
      },
    },
    system_get_services: {
      type: "function",
      function: {
        name: "system_get_services",
        description: "Get status of TRIDENT services: trident, ollama, trident-voice, trident-imagegen",
        parameters: { type: "object", properties: {} },
      },
    },
    system_get_disk_usage: {
      type: "function",
      function: {
        name: "system_get_disk_usage",
        description: "Get disk usage for all mounted filesystems",
        parameters: { type: "object", properties: {} },
      },
    },
    system_run_command: {
      type: "function",
      function: {
        name: "system_run_command",
        description: "Run an approved system command (admin only). Allowed: df, free, top, ps, netstat, ss, ip, systemctl status",
        parameters: {
          type: "object",
          properties: {
            command: { type: "string", description: "Command to run (must be in whitelist)" },
          },
          required: ["command"],
        },
      },
    },
  };


  function parseToolCallName(name: string): { toolName: string; action: string } {
    const parts = name.split("_");
    const toolName = parts[0];
    const action = parts.slice(1).join("_");
    return { toolName, action };
  }



  const chatStreamSchema = z.object({
    conversationId: z.number(),
    message: z.string().min(1),
    model: z.string().min(1),
    temperature: z.number().min(0).max(2).optional(),
    max_tokens: z.number().min(1).max(65536).optional(),
    top_p: z.number().min(0).max(1).optional(),
    tools_enabled: z.boolean().optional(),
    available_tools: z.array(z.string()).optional(),
  });

  app.post("/api/chat/stream", requireAuth, async (req, res) => {
    try {
      const data = chatStreamSchema.parse(req.body);
      const userId = req.user!.id;

      // Validate ownership
      const conversation = await storage.getConversation(data.conversationId, userId);
      if (!conversation) {
        return res.status(404).json({ error: "CONVERSATION NOT FOUND" });
      }

      // Save user message
      const now = new Date().toISOString();
      await storage.addMessage({
        conversation_id: data.conversationId,
        role: "user",
        content: data.message,
        created_at: now,
      });

      // Update conversation timestamp
      await storage.updateConversation(data.conversationId, userId, { updated_at: now });

      // Build message history
      const dbMessages = await storage.getConversationMessages(data.conversationId);
      const ollamaMessages: { role: string; content: string }[] = [];

      // Add system prompt if exists
      const systemPrompt = conversation.system_prompt;
      if (systemPrompt) {
        ollamaMessages.push({ role: "system", content: systemPrompt });
      }

      for (const msg of dbMessages) {
        if (msg.role === "system") continue; // system prompt handled above
        ollamaMessages.push({ role: msg.role, content: msg.content });
      }

      // Set SSE headers
      res.setHeader("Content-Type", "text/event-stream");
      res.setHeader("Cache-Control", "no-cache");
      res.setHeader("Connection", "keep-alive");
      res.flushHeaders();

      // Build tool definitions if tools are enabled
      const activeToolDefs: any[] = [];
      if (data.tools_enabled && data.available_tools && data.available_tools.length > 0) {
        for (const toolKey of Object.keys(TOOL_DEFINITIONS)) {
          const toolPrefix = toolKey.split('_')[0];
          if (data.available_tools.includes(toolPrefix) || data.available_tools.includes(toolKey)) {
            activeToolDefs.push(TOOL_DEFINITIONS[toolKey]);
          }
        }
      }

      try {
        // If tools are active: use non-streaming first call to detect tool_calls reliably
        // (Ollama streaming chunks tool_calls across multiple lines which is hard to parse)
        if (activeToolDefs.length > 0) {
          const toolRes = await fetch(`${OLLAMA_BASE}/api/chat`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              model: data.model,
              messages: ollamaMessages,
              stream: false,
              tools: activeToolDefs,
              options: {
                temperature: data.temperature ?? 0.7,
                num_predict: data.max_tokens ?? 2048,
                top_p: data.top_p ?? 0.9,
              },
            }),
          });

          if (!toolRes.ok) {
            res.write(`data: {"error":"NEURAL LINK SEVERED — OLLAMA OFFLINE"}\n\n`);
            return res.end();
          }

          const toolJson = await toolRes.json();
          const toolMsg = toolJson.message;

          // Check if model wants to call a tool
          if (toolMsg?.tool_calls && toolMsg.tool_calls.length > 0) {
            for (const toolCall of toolMsg.tool_calls) {
              const fnName = toolCall.function?.name;
              const fnArgs = toolCall.function?.arguments || {};
              if (!fnName) continue;

              res.write(`data: ${JSON.stringify({ tool_call: fnName, args: fnArgs, done: false })}\n\n`);

              const { toolName, action } = parseToolCallName(fnName);
              let toolResult: any;
              try {
                toolResult = await executeTool(toolName, action, fnArgs, userId);
              } catch (e: any) {
                toolResult = { error: e.message, success: false };
              }

              res.write(`data: ${JSON.stringify({ tool_result: fnName, result: toolResult, done: false })}\n\n`);

              ollamaMessages.push({ role: "assistant", content: "", tool_calls: [toolCall] } as any);
              ollamaMessages.push({ role: "tool", content: JSON.stringify(toolResult) } as any);
            }

            // Stream the final response after tool execution
            const finalRes = await fetch(`${OLLAMA_BASE}/api/chat`, {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({
                model: data.model,
                messages: ollamaMessages,
                stream: true,
                options: { temperature: data.temperature ?? 0.7, num_predict: data.max_tokens ?? 2048 },
              }),
            });

            if (finalRes.ok && finalRes.body) {
              const fReader = finalRes.body.getReader();
              const fDecoder = new TextDecoder();
              let fBuffer = "";
              let fullContent = "";
              while (true) {
                const { done, value } = await fReader.read();
                if (done) break;
                fBuffer += fDecoder.decode(value, { stream: true });
                const fLines = fBuffer.split("\n");
                fBuffer = fLines.pop() || "";
                for (const fLine of fLines) {
                  if (!fLine.trim()) continue;
                  try {
                    const fParsed = JSON.parse(fLine);
                    if (fParsed.message?.content) {
                      fullContent += fParsed.message.content;
                      res.write(`data: ${JSON.stringify({ token: fParsed.message.content, done: false })}\n\n`);
                    }
                    if (fParsed.done) {
                      const savedMsg = await storage.addMessage({
                        conversation_id: data.conversationId,
                        role: "assistant",
                        content: fullContent,
                        created_at: new Date().toISOString(),
                      });
                      res.write(`data: ${JSON.stringify({ done: true, messageId: savedMsg.id })}\n\n`);
                    }
                  } catch {}
                }
              }
            }
            return res.end();
          }

          // No tool call — stream the regular response
          if (toolMsg?.content) {
            const savedMsg = await storage.addMessage({
              conversation_id: data.conversationId,
              role: "assistant",
              content: toolMsg.content,
              created_at: new Date().toISOString(),
            });
            // Stream it token by token for smooth UX
            for (const char of toolMsg.content) {
              res.write(`data: ${JSON.stringify({ token: char, done: false })}\n\n`);
            }
            res.write(`data: ${JSON.stringify({ done: true, messageId: savedMsg.id })}\n\n`);
            return res.end();
          }
        }

        // No tools or tools disabled — use regular streaming
        const ollamaRes = await fetch(`${OLLAMA_BASE}/api/chat`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            model: data.model,
            messages: ollamaMessages,
            stream: true,
            options: {
              temperature: data.temperature ?? 0.7,
              num_predict: data.max_tokens ?? 2048,
              top_p: data.top_p ?? 0.9,
            },
          }),
        });

        if (!ollamaRes.ok || !ollamaRes.body) {
          res.write(`data: {"error":"NEURAL LINK SEVERED — OLLAMA OFFLINE"}\n\n`);
          return res.end();
        }

        const reader = ollamaRes.body.getReader();
        const decoder = new TextDecoder();
        let buffer = "";
        let fullContent = "";

        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          buffer += decoder.decode(value, { stream: true });
          const lines = buffer.split("\n");
          buffer = lines.pop() || "";

          for (const line of lines) {
            if (!line.trim()) continue;
            try {
              const parsed = JSON.parse(line);

              // Handle tool calls from Ollama
              if (parsed.message?.tool_calls && parsed.message.tool_calls.length > 0) {
                for (const toolCall of parsed.message.tool_calls) {
                  const fnName = toolCall.function?.name;
                  const fnArgs = toolCall.function?.arguments || {};
                  if (!fnName) continue;

                  // Send tool call notification to client
                  res.write(`data: ${JSON.stringify({ tool_call: fnName, args: fnArgs, done: false })}\n\n`);

                  // Parse tool name and action
                  const { toolName, action } = parseToolCallName(fnName);

                  // Execute the tool
                  let toolResult: any;
                  try {
                    toolResult = await executeTool(toolName, action, fnArgs, userId);
                  } catch (e: any) {
                    toolResult = { error: e.message, success: false };
                  }

                  // Send tool result to client
                  res.write(`data: ${JSON.stringify({ tool_result: fnName, result: toolResult, done: false })}\n\n`);

                  // Add tool call + result to message history and re-query Ollama
                  ollamaMessages.push({ role: "assistant", content: "", tool_calls: [toolCall] } as any);
                  ollamaMessages.push({ role: "tool", content: JSON.stringify(toolResult) } as any);

                  // Continue conversation with tool result
                  const followupRes = await fetch(`${OLLAMA_BASE}/api/chat`, {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({
                      model: data.model,
                      messages: ollamaMessages,
                      stream: true,
                      options: { temperature: data.temperature ?? 0.7, num_predict: data.max_tokens ?? 2048 },
                    }),
                  });

                  if (followupRes.ok && followupRes.body) {
                    const followupReader = followupRes.body.getReader();
                    let followupBuffer = "";
                    while (true) {
                      const { done: fDone, value: fValue } = await followupReader.read();
                      if (fDone) break;
                      followupBuffer += decoder.decode(fValue, { stream: true });
                      const fLines = followupBuffer.split("\n");
                      followupBuffer = fLines.pop() || "";
                      for (const fLine of fLines) {
                        if (!fLine.trim()) continue;
                        try {
                          const fParsed = JSON.parse(fLine);
                          if (fParsed.message?.content) {
                            fullContent += fParsed.message.content;
                            res.write(`data: ${JSON.stringify({ token: fParsed.message.content, done: false })}\n\n`);
                          }
                        } catch {}
                      }
                    }
                  }
                }
                continue;
              }

              if (parsed.message?.content) {
                const token = parsed.message.content;
                fullContent += token;
                res.write(`data: ${JSON.stringify({ token, done: false })}\n\n`);
              }
              if (parsed.done) {
                // Save assistant message
                const savedMsg = await storage.addMessage({
                  conversation_id: data.conversationId,
                  role: "assistant",
                  content: fullContent,
                  created_at: new Date().toISOString(),
                });
                res.write(`data: ${JSON.stringify({ done: true, messageId: savedMsg.id })}\n\n`);
              }
            } catch {
              // skip malformed
            }
          }
        }

        // If we haven't sent done yet (e.g. buffer remaining)
        if (buffer.trim()) {
          try {
            const parsed = JSON.parse(buffer);
            if (parsed.message?.content) {
              fullContent += parsed.message.content;
              res.write(`data: ${JSON.stringify({ token: parsed.message.content, done: false })}\n\n`);
            }
          } catch {}
        }

        res.end();
      } catch (fetchErr) {
        res.write(`data: {"error":"NEURAL LINK SEVERED — OLLAMA OFFLINE"}\n\n`);
        res.end();
      }
    } catch (err: any) {
      if (err.name === "ZodError") {
        return res.status(400).json({ error: "INVALID INPUT DATA", details: err.errors });
      }
      console.error("Chat stream error:", err);
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  // ═══════════════════════════════════════════════════
  // PHASE 2 — CONVERSATION ROUTES
  // ═══════════════════════════════════════════════════

  const createConversationSchema = z.object({
    title: z.string().optional(),
    model: z.string().min(1),
    system_prompt: z.string().optional(),
  });

  const updateConversationSchema = z.object({
    title: z.string().optional(),
    model: z.string().optional(),
    system_prompt: z.string().optional(),
  });

  // GET /api/conversations — List user's conversations
  app.get("/api/conversations", requireAuth, async (req, res) => {
    const userId = req.user!.id;
    const convs = await storage.getUserConversations(userId);
    res.json({ conversations: convs });
  });

  // POST /api/conversations — Create new conversation
  app.post("/api/conversations", requireAuth, async (req, res) => {
    try {
      const data = createConversationSchema.parse(req.body);
      const now = new Date().toISOString();
      const conv = await storage.createConversation({
        user_id: req.user!.id,
        title: data.title || "NEW CONVERSATION",
        model: data.model,
        system_prompt: data.system_prompt || "",
        created_at: now,
        updated_at: now,
      });
      res.status(201).json(conv);
    } catch (err: any) {
      if (err.name === "ZodError") {
        return res.status(400).json({ error: "INVALID INPUT DATA", details: err.errors });
      }
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  // GET /api/conversations/:id — Get conversation + messages
  app.get("/api/conversations/:id", requireAuth, async (req, res) => {
    const convId = parseInt(String(req.params.id), 10);
    if (isNaN(convId)) return res.status(400).json({ error: "INVALID CONVERSATION ID" });

    const conv = await storage.getConversation(convId, req.user!.id);
    if (!conv) return res.status(404).json({ error: "CONVERSATION NOT FOUND" });

    const msgs = await storage.getConversationMessages(convId);
    res.json({ conversation: conv, messages: msgs });
  });

  // PATCH /api/conversations/:id — Update conversation
  app.patch("/api/conversations/:id", requireAuth, async (req, res) => {
    try {
      const convId = parseInt(String(req.params.id), 10);
      if (isNaN(convId)) return res.status(400).json({ error: "INVALID CONVERSATION ID" });

      const data = updateConversationSchema.parse(req.body);
      const updated = await storage.updateConversation(convId, req.user!.id, {
        ...data,
        updated_at: new Date().toISOString(),
      });
      if (!updated) return res.status(404).json({ error: "CONVERSATION NOT FOUND" });
      res.json(updated);
    } catch (err: any) {
      if (err.name === "ZodError") {
        return res.status(400).json({ error: "INVALID INPUT DATA" });
      }
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  // DELETE /api/conversations/:id — Delete conversation + messages
  app.delete("/api/conversations/:id", requireAuth, async (req, res) => {
    const convId = parseInt(String(req.params.id), 10);
    if (isNaN(convId)) return res.status(400).json({ error: "INVALID CONVERSATION ID" });

    const deleted = await storage.deleteConversation(convId, req.user!.id);
    if (!deleted) return res.status(404).json({ error: "CONVERSATION NOT FOUND" });
    res.json({ message: "CONVERSATION PURGED" });
  });

  // ═══════════════════════════════════════════════════
  // PHASE 2 — MODEL CONFIG ROUTES
  // ═══════════════════════════════════════════════════

  const modelConfigSchema = z.object({
    temperature: z.number().min(0).max(2).optional(),
    max_tokens: z.number().min(256).max(65536).optional(),
    top_p: z.number().min(0).max(1).optional(),
    system_prompt: z.string().optional(),
  });

  // GET /api/model-configs/:modelName
  app.get("/api/model-configs/:modelName", requireAuth, async (req, res) => {
    const config = await storage.getModelConfig(req.user!.id, String(req.params.modelName));
    res.json(config || { temperature: 0.7, max_tokens: 2048, top_p: 0.9, system_prompt: "" });
  });

  // PUT /api/model-configs/:modelName
  app.put("/api/model-configs/:modelName", requireAuth, async (req, res) => {
    try {
      const data = modelConfigSchema.parse(req.body);
      const config = await storage.upsertModelConfig(req.user!.id, String(req.params.modelName), data);
      res.json(config);
    } catch (err: any) {
      if (err.name === "ZodError") {
        return res.status(400).json({ error: "INVALID INPUT DATA", details: err.errors });
      }
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  // ═══════════════════════════════════════════════════
  // PHASE 3 — VOICE PROXY ROUTES
  // ═══════════════════════════════════════════════════

  const VOICE_SERVICE_BASE = "http://127.0.0.1:5001";
  const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 25 * 1024 * 1024 } });

  // Helper: proxy request to voice service using Node http module
  function proxyToVoice(
    path: string,
    method: string,
    body: Buffer | string | null,
    contentType: string
  ): Promise<{ statusCode: number; headers: http.IncomingHttpHeaders; body: Buffer }> {
    return new Promise((resolve, reject) => {
      const options = {
        hostname: "127.0.0.1",
        port: 5001,
        path,
        method,
        headers: {
          "Content-Type": contentType,
          ...(body ? { "Content-Length": Buffer.byteLength(body) } : {}),
        },
      };

      const req = http.request(options, (res) => {
        const chunks: Buffer[] = [];
        res.on("data", (chunk: Buffer) => chunks.push(chunk));
        res.on("end", () => {
          resolve({
            statusCode: res.statusCode || 500,
            headers: res.headers,
            body: Buffer.concat(chunks),
          });
        });
      });

      req.on("error", reject);
      req.setTimeout(30000, () => {
        req.destroy();
        reject(new Error("Voice service timeout"));
      });

      if (body) req.write(body);
      req.end();
    });
  }

  // POST /api/voice/stt — Speech-to-text proxy
  app.post("/api/voice/stt", requireAuth, upload.single("audio"), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: "NO AUDIO DATA RECEIVED" });
      }

      const result = await proxyToVoice("/stt", "POST", req.file.buffer, "application/octet-stream");
      const json = JSON.parse(result.body.toString());
      res.status(result.statusCode).json(json);
    } catch {
      res.status(503).json({ error: "VOICE PROCESSING UNIT OFFLINE" });
    }
  });

  // POST /api/voice/tts — Text-to-speech proxy
  app.post("/api/voice/tts", requireAuth, async (req, res) => {
    try {
      const { text, voice } = req.body;
      if (!text || typeof text !== "string") {
        return res.status(400).json({ error: "TEXT PAYLOAD REQUIRED" });
      }

      const payload = JSON.stringify({ text, voice: voice || "lessac" });
      const result = await proxyToVoice("/tts", "POST", payload, "application/json");

      if (result.statusCode === 200) {
        res.setHeader("Content-Type", "audio/wav");
        res.setHeader("Content-Length", result.body.length);
        res.status(200).end(result.body);
      } else {
        const json = JSON.parse(result.body.toString());
        res.status(result.statusCode).json(json);
      }
    } catch {
      res.status(503).json({ error: "VOICE SYNTHESIS UNIT OFFLINE" });
    }
  });

  // GET /api/voice/status — Check if voice service is online via TCP probe
  app.get("/api/voice/status", requireAuth, async (_req, res) => {
    const net = await import("net");
    const socket = new net.Socket();
    let resolved = false;
    const done = (online: boolean) => {
      if (resolved) return;
      resolved = true;
      socket.destroy();
      res.json({ online, voices: online ? ["lessac", "amy"] : [] });
    };
    socket.setTimeout(2000);
    socket.connect(5001, "127.0.0.1", () => done(true));
    socket.on("error", () => done(false));
    socket.on("timeout", () => done(false));
  });

  // GET /api/voice/voices — Available voice profiles
  app.get("/api/voice/voices", requireAuth, async (_req, res) => {
    res.json([
      {
        id: "lessac",
        name: "LESSAC (NEUTRAL)",
        description: "Clear, professional neutral American English voice",
      },
      {
        id: "amy",
        name: "AMY (NEUTRAL)",
        description: "Warm, natural American English female voice",
      },
    ]);
  });

  // ═══════════════════════════════════════════════════
  // PHASE 4 — IMAGE GENERATION ROUTES
  // ═══════════════════════════════════════════════════

  const SD_PORT = 7860;
  const SD_HOST = "127.0.0.1";
  const IMAGE_UPLOAD_DIR = "/opt/trident/uploads/images";

  // Helper: proxy request to Stable Diffusion API
  function proxyToSD(
    sdPath: string,
    method: string,
    body: string | null,
    timeoutMs: number = 300000
  ): Promise<{ statusCode: number; body: string }> {
    return new Promise((resolve, reject) => {
      const options: http.RequestOptions = {
        hostname: SD_HOST,
        port: SD_PORT,
        path: sdPath,
        method,
        headers: {
          "Content-Type": "application/json",
          ...(body ? { "Content-Length": Buffer.byteLength(body) } : {}),
        },
      };

      const req = http.request(options, (res) => {
        const chunks: Buffer[] = [];
        res.on("data", (chunk: Buffer) => chunks.push(chunk));
        res.on("end", () => {
          resolve({
            statusCode: res.statusCode || 500,
            body: Buffer.concat(chunks).toString("utf-8"),
          });
        });
      });

      req.on("error", reject);
      req.setTimeout(timeoutMs, () => {
        req.destroy();
        reject(new Error("SD API timeout"));
      });

      if (body) req.write(body);
      req.end();
    });
  }

  // GET /api/imagegen/status — TCP probe to port 7860
  app.get("/api/imagegen/status", requireAuth, async (_req, res) => {
    const net = await import("net");
    const socket = new net.Socket();
    let resolved = false;
    const done = (online: boolean) => {
      if (resolved) return;
      resolved = true;
      socket.destroy();

      if (!online) {
        return res.json({ online: false, backend: "offline" });
      }

      // Detect backend type by querying models endpoint
      proxyToSD("/sdapi/v1/sd-models", "GET", null, 5000)
        .then((result) => {
          let backend: string = "automatic1111";
          try {
            const models = JSON.parse(result.body);
            if (Array.isArray(models) && models.length > 0 && models[0].hash === "diffusers-cpu") {
              backend = "diffusers";
            }
          } catch {
            // default to automatic1111
          }
          res.json({ online: true, backend });
        })
        .catch(() => {
          res.json({ online: true, backend: "automatic1111" });
        });
    };
    socket.setTimeout(2000);
    socket.connect(SD_PORT, SD_HOST, () => done(true));
    socket.on("error", () => done(false));
    socket.on("timeout", () => done(false));
  });

  // GET /api/imagegen/models — List available SD models
  app.get("/api/imagegen/models", requireAuth, async (_req, res) => {
    try {
      const result = await proxyToSD("/sdapi/v1/sd-models", "GET", null, 10000);
      const models = JSON.parse(result.body);
      res.json(models);
    } catch {
      res.status(503).json({ error: "VISUAL SYNTHESIS ENGINE OFFLINE" });
    }
  });

  // POST /api/imagegen/generate — Generate an image
  app.post("/api/imagegen/generate", requireAuth, async (req, res) => {
    try {
      const { prompt, negative_prompt, width, height, steps, cfg_scale, seed, model } = req.body;
      if (!prompt || typeof prompt !== "string" || prompt.trim().length === 0) {
        return res.status(400).json({ error: "VISUAL DIRECTIVE REQUIRED" });
      }

      const sdPayload = JSON.stringify({
        prompt: prompt.trim(),
        negative_prompt: negative_prompt || "",
        width: width || 512,
        height: height || 512,
        steps: steps || 20,
        cfg_scale: cfg_scale || 7,
        seed: seed ?? -1,
        sampler_name: "DPM++ 2M Karras",
      });

      const startTime = Date.now();
      const result = await proxyToSD("/sdapi/v1/txt2img", "POST", sdPayload, 300000);

      if (result.statusCode !== 200) {
        return res.status(result.statusCode).json({ error: "GENERATION FAILED", details: result.body });
      }

      const sdResponse = JSON.parse(result.body);
      if (!sdResponse.images || sdResponse.images.length === 0) {
        return res.status(500).json({ error: "NO IMAGE DATA RETURNED" });
      }

      // Parse info for actual seed
      let actualSeed = -1;
      try {
        const info = JSON.parse(sdResponse.info || "{}");
        actualSeed = info.seed ?? info.all_seeds?.[0] ?? -1;
      } catch {
        // ignore
      }

      // Save image to disk
      const userId = req.user!.id;
      const userDir = path.join(IMAGE_UPLOAD_DIR, String(userId));
      fs.mkdirSync(userDir, { recursive: true });

      const timestamp = Date.now();
      const filename = `${timestamp}_${crypto.randomBytes(4).toString("hex")}.png`;
      const imagePath = path.join(userDir, filename);
      const imageBuffer = Buffer.from(sdResponse.images[0], "base64");
      fs.writeFileSync(imagePath, imageBuffer);

      // Save record to database
      const now = new Date().toISOString();
      const record = await storage.createGeneratedImage({
        user_id: userId,
        prompt: prompt.trim(),
        negative_prompt: negative_prompt || "",
        model: model || "stable-diffusion",
        width: width || 512,
        height: height || 512,
        steps: steps || 20,
        cfg_scale: cfg_scale || 7.0,
        seed: seed ?? -1,
        actual_seed: actualSeed,
        image_path: imagePath,
        thumbnail_path: imagePath,
        created_at: now,
        is_favorite: 0,
      });

      const elapsed = Date.now() - startTime;
      res.json({
        id: record.id,
        imageUrl: `/api/imagegen/image/${record.id}`,
        seed: actualSeed,
        width: record.width,
        height: record.height,
        elapsed_ms: elapsed,
      });
    } catch (err: any) {
      if (err.message === "SD API timeout") {
        return res.status(504).json({ error: "GENERATION TIMEOUT — IMAGE TOOK TOO LONG" });
      }
      res.status(503).json({ error: "VISUAL SYNTHESIS ENGINE OFFLINE" });
    }
  });

  // GET /api/imagegen/image/:id — Serve image file
  app.get("/api/imagegen/image/:id", requireAuth, async (req, res) => {
    try {
      const imageId = parseInt(String(req.params.id), 10);
      if (isNaN(imageId)) return res.status(400).json({ error: "INVALID IMAGE ID" });

      const image = await storage.getImage(imageId, req.user!.id);
      if (!image) return res.status(404).json({ error: "IMAGE NOT FOUND" });

      if (!fs.existsSync(image.image_path)) {
        return res.status(404).json({ error: "IMAGE FILE MISSING FROM DISK" });
      }

      res.setHeader("Content-Type", "image/png");
      res.setHeader("Cache-Control", "max-age=31536000, immutable");
      const fileBuffer = fs.readFileSync(image.image_path);
      res.send(fileBuffer);
    } catch {
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  // GET /api/imagegen/gallery — Paginated gallery
  app.get("/api/imagegen/gallery", requireAuth, async (req, res) => {
    try {
      const page = Math.max(1, parseInt(String(req.query.page || "1"), 10));
      const limit = Math.min(50, Math.max(1, parseInt(String(req.query.limit || "20"), 10)));
      const offset = (page - 1) * limit;

      const total = await storage.getUserImageCount(req.user!.id);
      const images = await storage.getUserImages(req.user!.id, limit, offset);
      const pages = Math.ceil(total / limit);

      res.json({
        images: images.map((img) => ({
          id: img.id,
          prompt: img.prompt,
          negative_prompt: img.negative_prompt,
          width: img.width,
          height: img.height,
          steps: img.steps,
          cfg_scale: img.cfg_scale,
          seed: img.seed,
          actual_seed: img.actual_seed,
          model: img.model,
          created_at: img.created_at,
          is_favorite: img.is_favorite,
          imageUrl: `/api/imagegen/image/${img.id}`,
        })),
        total,
        page,
        pages,
      });
    } catch {
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  // DELETE /api/imagegen/image/:id — Delete image
  app.delete("/api/imagegen/image/:id", requireAuth, async (req, res) => {
    try {
      const imageId = parseInt(String(req.params.id), 10);
      if (isNaN(imageId)) return res.status(400).json({ error: "INVALID IMAGE ID" });

      const image = await storage.getImage(imageId, req.user!.id);
      if (!image) return res.status(404).json({ error: "IMAGE NOT FOUND" });

      // Delete file from disk
      try {
        if (fs.existsSync(image.image_path)) fs.unlinkSync(image.image_path);
        if (image.thumbnail_path && image.thumbnail_path !== image.image_path && fs.existsSync(image.thumbnail_path)) {
          fs.unlinkSync(image.thumbnail_path);
        }
      } catch {
        // ignore file deletion errors
      }

      await storage.deleteImage(imageId, req.user!.id);
      res.json({ message: "IMAGE PURGED" });
    } catch {
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  // PATCH /api/imagegen/image/:id/favorite — Toggle favorite
  app.patch("/api/imagegen/image/:id/favorite", requireAuth, async (req, res) => {
    try {
      const imageId = parseInt(String(req.params.id), 10);
      if (isNaN(imageId)) return res.status(400).json({ error: "INVALID IMAGE ID" });

      const updated = await storage.toggleFavorite(imageId, req.user!.id);
      if (!updated) return res.status(404).json({ error: "IMAGE NOT FOUND" });

      res.json({
        id: updated.id,
        is_favorite: updated.is_favorite,
      });
    } catch {
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  // ═══════════════════════════════════════════════════
  // PHASE 5 — FILE UPLOAD ROUTES
  // ═══════════════════════════════════════════════════

  const FILE_UPLOAD_DIR = "/opt/trident/uploads/files";
  const MAX_FILE_SIZE = 50 * 1024 * 1024; // 50MB

  const ACCEPTED_MIMES = new Set([
    "application/pdf",
    "text/plain",
    "text/markdown",
    "text/csv",
    "application/json",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    "image/jpeg",
    "image/png",
    "image/gif",
    "image/webp",
  ]);

  const fileUpload = multer({
    storage: multer.memoryStorage(),
    limits: { fileSize: MAX_FILE_SIZE },
  });

  // Helper: extract text from uploaded file
  async function extractTextFromFile(filePath: string, mimeType: string): Promise<string> {
    if (mimeType.startsWith("text/") || mimeType === "application/json") {
      return fs.readFileSync(filePath, "utf-8").slice(0, 50000);
    }
    if (mimeType === "application/pdf") {
      try {
        // eslint-disable-next-line @typescript-eslint/no-var-requires
        const pdfParse = require("pdf-parse");
        const buffer = fs.readFileSync(filePath);
        const data = await pdfParse(buffer);
        return data.text.slice(0, 50000);
      } catch {
        return "[PDF EXTRACTION FAILED]";
      }
    }
    if (mimeType.startsWith("image/")) {
      return `[IMAGE FILE: ${path.basename(filePath)}]`;
    }
    if (mimeType === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' || filePath.endsWith('.docx')) {
      try {
        const mammoth = require('mammoth');
        const result = await mammoth.extractRawText({ path: filePath });
        return result.value.slice(0, 50000);
      } catch (e) { return '[DOCX EXTRACTION FAILED: ' + String(e) + ']'; }
    }
    return `[BINARY FILE: ${path.basename(filePath)} — content not extractable as text]`;
  }

  // POST /api/files/upload/:conversationId — Upload file to conversation
  app.post("/api/files/upload/:conversationId", requireAuth, fileUpload.single("file"), async (req, res) => {
    try {
      const convId = parseInt(String(req.params.conversationId), 10);
      if (isNaN(convId)) return res.status(400).json({ error: "INVALID CONVERSATION ID" });

      const userId = req.user!.id;

      // Validate conversation ownership
      const conv = await storage.getConversation(convId, userId);
      if (!conv) return res.status(404).json({ error: "CONVERSATION NOT FOUND" });

      if (!req.file) {
        return res.status(400).json({ error: "NO FILE RECEIVED" });
      }

      const mimeType = req.file.mimetype;
      if (!ACCEPTED_MIMES.has(mimeType)) {
        return res.status(400).json({ error: `UNSUPPORTED FILE TYPE: ${mimeType}` });
      }

      // Create upload directory
      const userDir = path.join(FILE_UPLOAD_DIR, String(userId));
      fs.mkdirSync(userDir, { recursive: true });

      // Generate stored filename
      const ext = path.extname(req.file.originalname) || ".bin";
      const storedFilename = `${crypto.randomUUID()}${ext}`;
      const filePath = path.join(userDir, storedFilename);

      // Write file to disk
      fs.writeFileSync(filePath, req.file.buffer);

      // Create DB record
      const now = new Date().toISOString();
      const record = await storage.addConversationFile({
        conversation_id: convId,
        user_id: userId,
        filename: req.file.originalname,
        stored_filename: storedFilename,
        file_path: filePath,
        mime_type: mimeType,
        file_size: req.file.size,
        extracted_text: null,
        extraction_status: "pending",
        created_at: now,
      });

      // Trigger async text extraction (don't await)
      extractTextFromFile(filePath, mimeType)
        .then((text) => {
          storage.updateFileExtraction(record.id, text, "done");
        })
        .catch(() => {
          storage.updateFileExtraction(record.id, "", "failed");
        });

      res.status(201).json({
        id: record.id,
        filename: record.filename,
        mime_type: record.mime_type,
        file_size: record.file_size,
        extraction_status: "pending",
      });
    } catch (err: any) {
      console.error("File upload error:", err);
      if (err.code === "LIMIT_FILE_SIZE") {
        return res.status(413).json({ error: "FILE TOO LARGE — MAX 50MB" });
      }
      res.status(500).json({ error: "FILE UPLOAD FAILED" });
    }
  });

  // GET /api/files/content/:fileId — Get extracted text content (must be before /:conversationId)
  app.get("/api/files/content/:fileId", requireAuth, async (req, res) => {
    try {
      const fileId = parseInt(String(req.params.fileId), 10);
      if (isNaN(fileId)) return res.status(400).json({ error: "INVALID FILE ID" });

      const userId = req.user!.id;
      const file = await storage.getConversationFile(fileId, userId);
      if (!file) return res.status(404).json({ error: "FILE NOT FOUND" });

      res.json({
        id: file.id,
        filename: file.filename,
        extraction_status: file.extraction_status,
        extracted_text: file.extracted_text || "",
      });
    } catch {
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  // GET /api/files/:conversationId — List files for a conversation
  app.get("/api/files/:conversationId", requireAuth, async (req, res) => {
    try {
      const convId = parseInt(String(req.params.conversationId), 10);
      if (isNaN(convId)) return res.status(400).json({ error: "INVALID CONVERSATION ID" });

      const userId = req.user!.id;

      // Validate conversation ownership
      const conv = await storage.getConversation(convId, userId);
      if (!conv) return res.status(404).json({ error: "CONVERSATION NOT FOUND" });

      const files = await storage.getConversationFiles(convId);

      // Strip file_path for security
      const safeFiles = files.map(({ file_path, ...rest }) => rest);
      res.json({ files: safeFiles });
    } catch {
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  // DELETE /api/files/:fileId — Delete a file
  app.delete("/api/files/:fileId", requireAuth, async (req, res) => {
    try {
      const fileId = parseInt(String(req.params.fileId), 10);
      if (isNaN(fileId)) return res.status(400).json({ error: "INVALID FILE ID" });

      const userId = req.user!.id;
      const file = await storage.getConversationFile(fileId, userId);
      if (!file) return res.status(404).json({ error: "FILE NOT FOUND" });

      // Delete from disk
      try {
        if (fs.existsSync(file.file_path)) fs.unlinkSync(file.file_path);
      } catch {
        // ignore disk errors
      }

      await storage.deleteConversationFile(fileId, userId);
      res.json({ message: "FILE PURGED" });
    } catch {
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  // ═══════════════════════════════════════════════════
  // PHASE 6 — ADMIN STATS, EXPORT, API KEYS
  // ═══════════════════════════════════════════════════

  // GET /api/admin/stats — System-wide statistics (admin only)
  app.get("/api/admin/stats", requireAdmin, async (_req, res) => {
    try {
      const stats = await storage.getSystemStats();
      const mem = process.memoryUsage();
      res.json({
        users: { total: stats.userCount, active: stats.activeUserCount, admins: stats.adminCount },
        conversations: { total: stats.conversationCount, totalMessages: stats.messageCount },
        images: { total: stats.imageCount, totalSize: stats.imageTotalSize },
        files: { total: stats.fileCount, totalSize: stats.fileTotalSize },
        system: {
          uptime: process.uptime(),
          nodeVersion: process.version,
          platform: process.platform,
          memoryUsed: mem.heapUsed,
          memoryTotal: mem.heapTotal,
        },
      });
    } catch {
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  // GET /api/admin/user-stats/:userId — Per-user usage (admin only)
  app.get("/api/admin/user-stats/:userId", requireAdmin, async (req, res) => {
    try {
      const userId = parseInt(String(req.params.userId), 10);
      if (isNaN(userId)) return res.status(400).json({ error: "INVALID USER ID" });
      const stats = await storage.getUserStats(userId);
      res.json(stats);
    } catch {
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  // GET /api/conversations/:id/export — Export conversation
  app.get("/api/conversations/:id/export", requireAuth, async (req, res) => {
    try {
      const convId = parseInt(String(req.params.id), 10);
      if (isNaN(convId)) return res.status(400).json({ error: "INVALID CONVERSATION ID" });

      const userId = req.user!.id;
      const conv = await storage.getConversation(convId, userId);
      if (!conv) return res.status(404).json({ error: "CONVERSATION NOT FOUND" });

      const msgs = await storage.getConversationMessages(convId);
      const format = String(req.query.format || "json");

      if (format === "markdown") {
        let md = `# ${conv.title}\n\n`;
        md += `**Model:** ${conv.model}\n`;
        md += `**Created:** ${conv.created_at}\n`;
        md += `**Messages:** ${msgs.length}\n\n---\n\n`;
        for (const msg of msgs) {
          const role = msg.role === "user" ? "🟠 **User**" : "🔵 **Assistant**";
          md += `${role} *(${msg.created_at})*\n\n${msg.content}\n\n---\n\n`;
        }
        res.setHeader("Content-Type", "text/markdown; charset=utf-8");
        res.setHeader("Content-Disposition", `attachment; filename="${conv.title.replace(/[^a-zA-Z0-9]/g, "_")}.md"`);
        return res.send(md);
      }

      // Default: JSON
      const data = { conversation: conv, messages: msgs };
      res.setHeader("Content-Type", "application/json; charset=utf-8");
      res.setHeader("Content-Disposition", `attachment; filename="${conv.title.replace(/[^a-zA-Z0-9]/g, "_")}.json"`);
      return res.json(data);
    } catch {
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  // GET /api/keys — List user's API keys
  app.get("/api/keys", requireAuth, async (req, res) => {
    try {
      const keys = await storage.getUserApiKeys(req.user!.id);
      res.json({
        keys: keys.map((k) => ({
          id: k.id,
          name: k.name,
          key_prefix: k.key_prefix,
          created_at: k.created_at,
          last_used: k.last_used,
        })),
      });
    } catch {
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  // POST /api/keys — Generate new API key
  app.post("/api/keys", requireAuth, async (req, res) => {
    try {
      const { name } = req.body;
      if (!name || typeof name !== "string" || name.trim().length === 0) {
        return res.status(400).json({ error: "KEY NAME REQUIRED" });
      }

      const rawKey = "trident_" + crypto.randomBytes(32).toString("hex");
      const keyHash = crypto.createHash("sha256").update(rawKey).digest("hex");
      const keyPrefix = rawKey.slice(0, 16) + "...";

      await storage.createApiKey({
        user_id: req.user!.id,
        key_hash: keyHash,
        key_prefix: keyPrefix,
        name: name.trim(),
        created_at: new Date().toISOString(),
      });

      res.status(201).json({
        key: rawKey,
        prefix: keyPrefix,
        name: name.trim(),
        message: "KEY GENERATED — STORE SECURELY. THIS WILL NOT BE SHOWN AGAIN.",
      });
    } catch {
      res.status(500).json({ error: "KEY GENERATION FAILED" });
    }
  });

  // DELETE /api/keys/:id — Deactivate API key
  app.delete("/api/keys/:id", requireAuth, async (req, res) => {
    try {
      const keyId = parseInt(String(req.params.id), 10);
      if (isNaN(keyId)) return res.status(400).json({ error: "INVALID KEY ID" });

      const deleted = await storage.deactivateApiKey(keyId, req.user!.id);
      if (!deleted) return res.status(404).json({ error: "KEY NOT FOUND" });

      res.json({ message: "KEY REVOKED" });
    } catch {
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  // ═══════════════════════════════════════════════════
  // PHASE 8 — TOOL CONFIGURATION ROUTES
  // ═══════════════════════════════════════════════════

  // GET /api/tools/configs — list user's tool configs
  app.get("/api/tools/configs", requireAuth, async (req, res) => {
    try {
      const configs = await storage.getAllToolConfigs(req.user!.id);
      res.json({ configs });
    } catch {
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  // POST /api/tools/configs — save/update a tool config
  app.post("/api/tools/configs", requireAuth, async (req, res) => {
    try {
      const { tool_name, config, is_enabled } = req.body;
      if (!tool_name || !config) {
        return res.status(400).json({ error: "TOOL NAME AND CONFIG REQUIRED" });
      }
      const configStr = typeof config === "string" ? config : JSON.stringify(config);
      const enabled = is_enabled !== undefined ? (is_enabled ? 1 : 0) : 1;
      const saved = await storage.upsertToolConfig(req.user!.id, tool_name, configStr, enabled);
      res.json(saved);
    } catch {
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  // DELETE /api/tools/configs/:toolName — remove a tool config
  app.delete("/api/tools/configs/:toolName", requireAuth, async (req, res) => {
    try {
      const toolName = String(req.params.toolName);
      const deleted = await storage.deleteToolConfig(req.user!.id, toolName);
      if (!deleted) return res.status(404).json({ error: "TOOL CONFIG NOT FOUND" });
      res.json({ message: "TOOL CONFIG PURGED" });
    } catch {
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  // ═══════════════════════════════════════════════════
  // PHASE 8 — TOOL EXECUTION ENGINE
  // ═══════════════════════════════════════════════════

  // Helper: make HTTPS request to self-signed cert hosts
  function httpsRequest(url: string, options: https.RequestOptions): Promise<any> {
    return new Promise((resolve, reject) => {
      const req = https.request(url, { ...options, rejectUnauthorized: false }, (res) => {
        let data = "";
        res.on("data", (chunk) => (data += chunk));
        res.on("end", () => {
          try {
            resolve(JSON.parse(data));
          } catch {
            resolve(data);
          }
        });
      });
      req.on("error", reject);
      req.setTimeout(15000, () => {
        req.destroy();
        reject(new Error("Request timeout"));
      });
      if (options.method === "POST" || options.method === "DELETE") {
        // For POST/DELETE without body
      }
      req.end();
    });
  }

  function httpsPost(url: string, options: https.RequestOptions, body?: string): Promise<any> {
    return new Promise((resolve, reject) => {
      const req = https.request(url, { ...options, rejectUnauthorized: false, method: "POST" }, (res) => {
        let data = "";
        res.on("data", (chunk) => (data += chunk));
        res.on("end", () => {
          try {
            resolve(JSON.parse(data));
          } catch {
            resolve(data);
          }
        });
      });
      req.on("error", reject);
      req.setTimeout(15000, () => {
        req.destroy();
        reject(new Error("Request timeout"));
      });
      if (body) req.write(body);
      req.end();
    });
  }

  function httpsDelete(url: string, options: https.RequestOptions): Promise<any> {
    return new Promise((resolve, reject) => {
      const req = https.request(url, { ...options, rejectUnauthorized: false, method: "DELETE" }, (res) => {
        let data = "";
        res.on("data", (chunk) => (data += chunk));
        res.on("end", () => {
          try {
            resolve(JSON.parse(data));
          } catch {
            resolve(data);
          }
        });
      });
      req.on("error", reject);
      req.setTimeout(15000, () => {
        req.destroy();
        reject(new Error("Request timeout"));
      });
      req.end();
    });
  }

  // Core tool execution function — shared between API route and scheduler
  async function executeTool(toolName: string, action: string, params: any, userId: number): Promise<any> {
    try {
      switch (toolName) {
        case "proxmox":
          return await executeProxmoxTool(action, params, userId);
        case "truenas":
          return await executeTrueNASTool(action, params, userId);
        case "network":
          return await executeNetworkTool(action, params);
        case "system":
          return await executeSystemTool(action, params, userId);
        default:
          return { error: `Unknown tool: ${toolName}`, success: false };
      }
    } catch (err: any) {
      return { error: err.message || String(err), success: false };
    }
  }

  // Register tool executor with scheduler
  setToolExecutor(executeTool);

  // ─── PROXMOX TOOL ───
  async function executeProxmoxTool(action: string, params: any, userId: number): Promise<any> {
    const config = await storage.getToolConfig(userId, "proxmox");
    if (!config) return { error: "Proxmox not configured", success: false };
    
    const cfg = JSON.parse(config.config);
    const host = cfg.host;
    const port = cfg.port || 8006;
    const baseUrl = `https://${host}:${port}`;
    const headers = {
      Authorization: `PVEAPIToken=${cfg.token_id}=${cfg.token_secret}`,
    };

    switch (action) {
      case "get_nodes": {
        const result = await httpsRequest(`${baseUrl}/api2/json/nodes`, { headers });
        return { success: true, data: result?.data || result };
      }
      case "get_vms": {
        const node = params?.node || "pve";
        const result = await httpsRequest(`${baseUrl}/api2/json/nodes/${node}/qemu`, { headers });
        return { success: true, data: result?.data || result };
      }
      case "get_vm_status": {
        if (!params?.node || !params?.vmid) return { error: "node and vmid required", success: false };
        const result = await httpsRequest(`${baseUrl}/api2/json/nodes/${params.node}/qemu/${params.vmid}/status/current`, { headers });
        return { success: true, data: result?.data || result };
      }
      case "start_vm": {
        if (!params?.node || !params?.vmid) return { error: "node and vmid required", success: false };
        const result = await httpsPost(`${baseUrl}/api2/json/nodes/${params.node}/qemu/${params.vmid}/status/start`, { headers });
        return { success: true, data: result?.data || result };
      }
      case "stop_vm": {
        if (!params?.node || !params?.vmid) return { error: "node and vmid required", success: false };
        const result = await httpsPost(`${baseUrl}/api2/json/nodes/${params.node}/qemu/${params.vmid}/status/stop`, { headers });
        return { success: true, data: result?.data || result };
      }
      case "get_storage": {
        const node = params?.node || "pve";
        const result = await httpsRequest(`${baseUrl}/api2/json/nodes/${node}/storage`, { headers });
        return { success: true, data: result?.data || result };
      }
      default:
        return { error: `Unknown proxmox action: ${action}`, success: false };
    }
  }

  // ─── TRUENAS TOOL ───
  async function executeTrueNASTool(action: string, params: any, userId: number): Promise<any> {
    const config = await storage.getToolConfig(userId, "truenas");
    if (!config) return { error: "TrueNAS not configured", success: false };
    
    const cfg = JSON.parse(config.config);
    const host = cfg.host;
    const baseUrl = `https://${host}`;
    const headers = {
      Authorization: `Bearer ${cfg.api_key}`,
    };

    switch (action) {
      case "get_pools": {
        const result = await httpsRequest(`${baseUrl}/api/v2.0/pool`, { headers });
        return { success: true, data: result };
      }
      case "get_datasets": {
        const result = await httpsRequest(`${baseUrl}/api/v2.0/pool/dataset`, { headers });
        return { success: true, data: result };
      }
      case "get_alerts": {
        const result = await httpsRequest(`${baseUrl}/api/v2.0/alert/list`, { headers });
        return { success: true, data: result };
      }
      case "get_system_info": {
        const result = await httpsRequest(`${baseUrl}/api/v2.0/system/info`, { headers });
        return { success: true, data: result };
      }
      case "get_disks": {
        const result = await httpsRequest(`${baseUrl}/api/v2.0/disk`, { headers });
        return { success: true, data: result };
      }
      case "dismiss_alert": {
        if (!params?.uuid) return { error: "uuid required", success: false };
        const result = await httpsDelete(`${baseUrl}/api/v2.0/alert/dismiss/${params.uuid}`, { headers });
        return { success: true, data: result };
      }
      default:
        return { error: `Unknown truenas action: ${action}`, success: false };
    }
  }

  // ─── NETWORK TOOL ───
  async function executeNetworkTool(action: string, params: any): Promise<any> {
    switch (action) {
      case "ping": {
        if (!params?.host) return { error: "host required", success: false };
        const count = params.count || 4;
        try {
          const { stdout } = await execAsync(`ping -c ${count} ${params.host}`, { timeout: 10000 });
          // Parse packet loss and avg RTT
          const lossMatch = stdout.match(/(\d+\.?\d*)% packet loss/);
          const rttMatch = stdout.match(/rtt min\/avg\/max\/mdev = [\d.]+\/([\d.]+)\//);
          return {
            success: true,
            data: {
              host: params.host,
              packet_loss: lossMatch ? parseFloat(lossMatch[1]) : null,
              avg_rtt_ms: rttMatch ? parseFloat(rttMatch[1]) : null,
              raw: stdout,
            },
          };
        } catch (err: any) {
          return { success: false, error: err.message, data: { raw: err.stdout || err.stderr || "" } };
        }
      }
      case "dns_lookup": {
        if (!params?.hostname) return { error: "hostname required", success: false };
        return new Promise((resolve) => {
          dns.lookup(params.hostname, { all: true }, (err, addresses) => {
            if (err) {
              resolve({ success: false, error: err.message });
            } else {
              resolve({ success: true, data: { hostname: params.hostname, addresses } });
            }
          });
        });
      }
      case "port_check": {
        if (!params?.host || !params?.port) return { error: "host and port required", success: false };
        const timeout = params.timeout || 3000;
        return new Promise((resolve) => {
          const socket = new net.Socket();
          let resolved = false;
          socket.setTimeout(timeout);
          socket.on("connect", () => {
            resolved = true;
            socket.destroy();
            resolve({ success: true, data: { host: params.host, port: params.port, status: "open" } });
          });
          socket.on("timeout", () => {
            if (!resolved) {
              resolved = true;
              socket.destroy();
              resolve({ success: true, data: { host: params.host, port: params.port, status: "closed", reason: "timeout" } });
            }
          });
          socket.on("error", (err: any) => {
            if (!resolved) {
              resolved = true;
              socket.destroy();
              resolve({ success: true, data: { host: params.host, port: params.port, status: "closed", reason: err.message } });
            }
          });
          socket.connect(params.port, params.host);
        });
      }
      case "get_local_hosts": {
        try {
          const hostsContent = fs.readFileSync("/etc/hosts", "utf-8");
          const entries = hostsContent.split("\n")
            .filter((l) => l.trim() && !l.trim().startsWith("#"))
            .map((l) => {
              const parts = l.trim().split(/\s+/);
              return { ip: parts[0], hostnames: parts.slice(1) };
            });
          return { success: true, data: { entries } };
        } catch (err: any) {
          return { success: false, error: err.message };
        }
      }
      case "traceroute": {
        if (!params?.host) return { error: "host required", success: false };
        try {
          const { stdout } = await execAsync(`traceroute -m 15 ${params.host}`, { timeout: 30000 });
          return { success: true, data: { host: params.host, raw: stdout } };
        } catch (err: any) {
          return { success: false, error: err.message, data: { raw: err.stdout || err.stderr || "" } };
        }
      }
      default:
        return { error: `Unknown network action: ${action}`, success: false };
    }
  }

  // ─── SYSTEM TOOL ───
  const ALLOWED_COMMANDS = ["df", "free", "top", "ps", "netstat", "ss", "ip", "systemctl status"];

  async function executeSystemTool(action: string, params: any, userId: number): Promise<any> {
    switch (action) {
      case "get_metrics": {
        const cpus = os.cpus();
        const totalIdle = cpus.reduce((acc, cpu) => acc + cpu.times.idle, 0);
        const totalTick = cpus.reduce((acc, cpu) => acc + Object.values(cpu.times).reduce((a, b) => a + b, 0), 0);
        const cpuUsage = ((1 - totalIdle / totalTick) * 100).toFixed(1);
        
        const totalMem = os.totalmem();
        const freeMem = os.freemem();
        const usedMem = totalMem - freeMem;
        
        let diskUsage = "";
        try {
          const { stdout } = await execAsync("df -h /", { timeout: 5000 });
          diskUsage = stdout;
        } catch { /* ignore */ }
        
        return {
          success: true,
          data: {
            cpu_usage_pct: parseFloat(cpuUsage),
            memory: {
              total_bytes: totalMem,
              used_bytes: usedMem,
              free_bytes: freeMem,
              used_pct: ((usedMem / totalMem) * 100).toFixed(1),
            },
            disk_root: diskUsage.trim(),
            uptime_seconds: os.uptime(),
            load_average: os.loadavg(),
            hostname: os.hostname(),
            platform: os.platform(),
            arch: os.arch(),
          },
        };
      }
      case "get_services": {
        const services = ["trident", "ollama", "trident-voice", "trident-imagegen"];
        const results: Record<string, string> = {};
        for (const svc of services) {
          try {
            const { stdout } = await execAsync(`systemctl is-active ${svc}`, { timeout: 5000 });
            results[svc] = stdout.trim();
          } catch {
            results[svc] = "inactive";
          }
        }
        return { success: true, data: { services: results } };
      }
      case "get_disk_usage": {
        try {
          const { stdout } = await execAsync("df -h", { timeout: 5000 });
          const lines = stdout.trim().split("\n");
          const header = lines[0];
          const entries = lines.slice(1).map((line) => {
            const parts = line.trim().split(/\s+/);
            return {
              filesystem: parts[0],
              size: parts[1],
              used: parts[2],
              available: parts[3],
              use_pct: parts[4],
              mounted_on: parts[5],
            };
          });
          return { success: true, data: { entries } };
        } catch (err: any) {
          return { success: false, error: err.message };
        }
      }
      case "run_command": {
        // Admin only
        const user = await storage.getUser(userId);
        if (!user || user.role !== "admin") {
          return { error: "ADMIN CLEARANCE REQUIRED", success: false };
        }
        if (!params?.command) return { error: "command required", success: false };
        
        const cmd = params.command.trim();
        const isAllowed = ALLOWED_COMMANDS.some((allowed) => cmd.startsWith(allowed));
        if (!isAllowed) {
          return { error: `Command not in whitelist. Allowed: ${ALLOWED_COMMANDS.join(", ")}`, success: false };
        }
        
        try {
          const { stdout, stderr } = await execAsync(cmd, { timeout: 10000 });
          return { success: true, data: { stdout: stdout.trim(), stderr: stderr.trim() } };
        } catch (err: any) {
          return { success: false, error: err.message, data: { stdout: err.stdout || "", stderr: err.stderr || "" } };
        }
      }
      default:
        return { error: `Unknown system action: ${action}`, success: false };
    }
  }

  // POST /api/tools/execute — Execute a tool action
  app.post("/api/tools/execute", requireAuth, async (req, res) => {
    try {
      const { tool_name, action, params } = req.body;
      if (!tool_name || !action) {
        return res.status(400).json({ error: "TOOL NAME AND ACTION REQUIRED" });
      }
      const result = await executeTool(tool_name, action, params || {}, req.user!.id);
      res.json(result);
    } catch (err: any) {
      res.status(500).json({ error: err.message || "TOOL EXECUTION FAILED", success: false });
    }
  });

  // ═══════════════════════════════════════════════════
  // PHASE 8 — OLLAMA TOOL CALLING DEFINITIONS
  // ═══════════════════════════════════════════════════

  // ═══════════════════════════════════════════════════
  // PHASE 8 — SCHEDULED TASKS ROUTES
  // ═══════════════════════════════════════════════════

  // GET /api/tasks/runs/recent — recent runs across all tasks (must be before :id routes)
  app.get("/api/tasks/runs/recent", requireAuth, async (req, res) => {
    try {
      const runs = await storage.getRecentTaskRuns(req.user!.id, 50);
      res.json({ runs });
    } catch {
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  // GET /api/tasks — list user's scheduled tasks
  app.get("/api/tasks", requireAuth, async (req, res) => {
    try {
      const tasks = await storage.getUserScheduledTasks(req.user!.id);
      res.json({ tasks });
    } catch {
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  // POST /api/tasks — create a new scheduled task
  app.post("/api/tasks", requireAuth, async (req, res) => {
    try {
      const { name, description, tool_name, tool_action, tool_params, schedule_cron, alert_condition } = req.body;
      if (!name || !tool_name || !tool_action || !schedule_cron) {
        return res.status(400).json({ error: "MISSING REQUIRED FIELDS" });
      }
      const now = new Date().toISOString();
      const task = await storage.createScheduledTask({
        user_id: req.user!.id,
        name,
        description: description || "",
        tool_name,
        tool_action,
        tool_params: typeof tool_params === "string" ? tool_params : JSON.stringify(tool_params || {}),
        schedule_cron,
        is_active: 1,
        alert_condition: alert_condition ? (typeof alert_condition === "string" ? alert_condition : JSON.stringify(alert_condition)) : null,
        created_at: now,
      });
      // Schedule it
      await scheduleTask(task);
      res.status(201).json(task);
    } catch {
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  // PATCH /api/tasks/:id — update task
  app.patch("/api/tasks/:id", requireAuth, async (req, res) => {
    try {
      const taskId = parseInt(String(req.params.id), 10);
      if (isNaN(taskId)) return res.status(400).json({ error: "INVALID TASK ID" });

      const existing = await storage.getScheduledTask(taskId, req.user!.id);
      if (!existing) return res.status(404).json({ error: "TASK NOT FOUND" });

      const updates: any = {};
      if (req.body.name !== undefined) updates.name = req.body.name;
      if (req.body.description !== undefined) updates.description = req.body.description;
      if (req.body.tool_name !== undefined) updates.tool_name = req.body.tool_name;
      if (req.body.tool_action !== undefined) updates.tool_action = req.body.tool_action;
      if (req.body.tool_params !== undefined) updates.tool_params = typeof req.body.tool_params === "string" ? req.body.tool_params : JSON.stringify(req.body.tool_params);
      if (req.body.schedule_cron !== undefined) updates.schedule_cron = req.body.schedule_cron;
      if (req.body.is_active !== undefined) updates.is_active = req.body.is_active ? 1 : 0;
      if (req.body.alert_condition !== undefined) updates.alert_condition = req.body.alert_condition ? (typeof req.body.alert_condition === "string" ? req.body.alert_condition : JSON.stringify(req.body.alert_condition)) : null;

      const updated = await storage.updateScheduledTask(taskId, req.user!.id, updates);
      if (!updated) return res.status(404).json({ error: "TASK NOT FOUND" });

      // Reschedule
      if (updated.is_active) {
        await scheduleTask(updated);
      } else {
        unscheduleTask(updated.id);
      }

      res.json(updated);
    } catch {
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  // DELETE /api/tasks/:id — delete task
  app.delete("/api/tasks/:id", requireAuth, async (req, res) => {
    try {
      const taskId = parseInt(String(req.params.id), 10);
      if (isNaN(taskId)) return res.status(400).json({ error: "INVALID TASK ID" });

      unscheduleTask(taskId);
      const deleted = await storage.deleteScheduledTask(taskId, req.user!.id);
      if (!deleted) return res.status(404).json({ error: "TASK NOT FOUND" });

      res.json({ message: "TASK PURGED" });
    } catch {
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  // GET /api/tasks/:id/runs — get run history
  app.get("/api/tasks/:id/runs", requireAuth, async (req, res) => {
    try {
      const taskId = parseInt(String(req.params.id), 10);
      if (isNaN(taskId)) return res.status(400).json({ error: "INVALID TASK ID" });

      const runs = await storage.getTaskRuns(taskId, req.user!.id, 20);
      res.json({ runs });
    } catch {
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  // POST /api/tasks/:id/run — manually trigger a task run
  app.post("/api/tasks/:id/run", requireAuth, async (req, res) => {
    try {
      const taskId = parseInt(String(req.params.id), 10);
      if (isNaN(taskId)) return res.status(400).json({ error: "INVALID TASK ID" });

      const task = await storage.getScheduledTask(taskId, req.user!.id);
      if (!task) return res.status(404).json({ error: "TASK NOT FOUND" });

      const result = await executeTask(task);
      res.json(result);
    } catch {
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  // Start the scheduler
  startScheduler(storage).catch((err) => console.error("[SCHEDULER] Start failed:", err));

  return httpServer;
}
