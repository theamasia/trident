import cron from "node-cron";
import type { IStorage } from "./storage";
import type { ScheduledTask } from "@shared/schema";

// Map of taskId -> cron job
const cronJobs = new Map<number, ReturnType<typeof cron.schedule>>();

let storageRef: IStorage | null = null;

// Will be set by routes.ts after tool engine is defined
let executeToolFn: ((toolName: string, action: string, params: any, userId: number) => Promise<any>) | null = null;

export function setToolExecutor(fn: (toolName: string, action: string, params: any, userId: number) => Promise<any>) {
  executeToolFn = fn;
}

export async function startScheduler(storage: IStorage) {
  storageRef = storage;
  console.log("[SCHEDULER] Starting task scheduler...");
  
  try {
    const tasks = await storage.getAllActiveScheduledTasks();
    console.log(`[SCHEDULER] Loading ${tasks.length} active task(s)`);
    
    for (const task of tasks) {
      await scheduleTask(task);
    }
  } catch (err) {
    console.error("[SCHEDULER] Failed to start scheduler:", err);
  }
}

export async function scheduleTask(task: ScheduledTask) {
  if (!storageRef) return;
  
  // Remove existing job if any
  unscheduleTask(task.id);
  
  if (!task.is_active || !cron.validate(task.schedule_cron)) {
    if (!cron.validate(task.schedule_cron)) {
      console.error(`[SCHEDULER] Invalid cron expression for task ${task.id}: ${task.schedule_cron}`);
    }
    return;
  }
  
  const job = cron.schedule(task.schedule_cron, async () => {
    await executeTask(task);
  });
  
  cronJobs.set(task.id, job);
  console.log(`[SCHEDULER] Scheduled task ${task.id} (${task.name}) with cron: ${task.schedule_cron}`);
}

export function unscheduleTask(taskId: number) {
  const existing = cronJobs.get(taskId);
  if (existing) {
    existing.stop();
    cronJobs.delete(taskId);
    console.log(`[SCHEDULER] Unscheduled task ${taskId}`);
  }
}

export async function executeTask(task: ScheduledTask): Promise<any> {
  if (!storageRef || !executeToolFn) {
    console.error("[SCHEDULER] Storage or tool executor not available");
    return null;
  }
  
  const now = new Date().toISOString();
  
  // Create a run record
  const run = await storageRef.createTaskRun({
    task_id: task.id,
    user_id: task.user_id,
    started_at: now,
    status: "running",
  });
  
  try {
    const params = JSON.parse(task.tool_params || "{}");
    const result = await executeToolFn(task.tool_name, task.tool_action, params, task.user_id);
    
    const completedAt = new Date().toISOString();
    let alertTriggered = 0;
    
    // Check alert condition
    if (task.alert_condition && result && !result.error) {
      try {
        const condition = JSON.parse(task.alert_condition);
        alertTriggered = evaluateAlertCondition(result, condition) ? 1 : 0;
        if (alertTriggered) {
          console.log(`[ALERT] ${task.name} — ${condition.message || "Alert condition triggered"}`);
        }
      } catch {
        // Invalid alert condition JSON, skip
      }
    }
    
    // Update run record
    await storageRef.updateTaskRun(run.id, {
      completed_at: completedAt,
      status: alertTriggered ? "alerted" : "success",
      result: JSON.stringify(result),
      alert_triggered: alertTriggered,
    });
    
    // Update task last_run and last_result
    await storageRef.updateScheduledTask(task.id, task.user_id, {
      last_run: completedAt,
      last_result: JSON.stringify(result),
    });
    
    return result;
  } catch (err: any) {
    const completedAt = new Date().toISOString();
    
    await storageRef.updateTaskRun(run.id, {
      completed_at: completedAt,
      status: "failed",
      error: err.message || String(err),
    });
    
    await storageRef.updateScheduledTask(task.id, task.user_id, {
      last_run: completedAt,
      last_result: JSON.stringify({ error: err.message || String(err), success: false }),
    });
    
    return { error: err.message, success: false };
  }
}

function evaluateAlertCondition(result: any, condition: { field: string; operator: string; value: any; message?: string }): boolean {
  try {
    // Navigate to the field value using dot/bracket notation
    const fieldValue = getNestedValue(result, condition.field);
    if (fieldValue === undefined) return false;
    
    const numVal = typeof fieldValue === "number" ? fieldValue : parseFloat(fieldValue);
    const numCondVal = typeof condition.value === "number" ? condition.value : parseFloat(condition.value);
    
    switch (condition.operator) {
      case ">": return numVal > numCondVal;
      case "<": return numVal < numCondVal;
      case ">=": return numVal >= numCondVal;
      case "<=": return numVal <= numCondVal;
      case "==": return String(fieldValue) === String(condition.value);
      case "!=": return String(fieldValue) !== String(condition.value);
      default: return false;
    }
  } catch {
    return false;
  }
}

function getNestedValue(obj: any, path: string): any {
  // Support both dot notation and bracket notation: "pools[0].used_pct" or "data.status"
  const parts = path.replace(/\[(\d+)\]/g, ".$1").split(".");
  let current = obj;
  for (const part of parts) {
    if (current == null) return undefined;
    current = current[part];
  }
  return current;
}
