import { sqliteTable, text, integer, real } from "drizzle-orm/sqlite-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// ═══════════════════════════════════════════════════
// USERS — Core identity table
// ═══════════════════════════════════════════════════
export const users = sqliteTable("users", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  username: text("username").notNull().unique(),
  email: text("email").notNull().unique(),
  password_hash: text("password_hash").notNull(),
  role: text("role", { enum: ["admin", "power_user", "user"] }).notNull().default("user"),
  created_at: text("created_at").notNull().default(""),
  last_login: text("last_login"),
  is_active: integer("is_active", { mode: "boolean" }).notNull().default(true),
});

// ═══════════════════════════════════════════════════
// SESSIONS — Token management
// ═══════════════════════════════════════════════════
export const sessions = sqliteTable("sessions", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  user_id: integer("user_id").notNull(),
  token_hash: text("token_hash").notNull(),
  expires_at: text("expires_at").notNull(),
  created_at: text("created_at").notNull().default(""),
});

// ═══════════════════════════════════════════════════
// Insert schemas (drizzle-zod)
// ═══════════════════════════════════════════════════
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  created_at: true,
  last_login: true,
});

export const insertSessionSchema = createInsertSchema(sessions).omit({
  id: true,
  created_at: true,
});

// ═══════════════════════════════════════════════════
// Types
// ═══════════════════════════════════════════════════
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertSession = z.infer<typeof insertSessionSchema>;
export type Session = typeof sessions.$inferSelect;

// ═══════════════════════════════════════════════════
// Frontend-safe user type (no password hash)
// ═══════════════════════════════════════════════════
export type SafeUser = Omit<User, "password_hash">;

// ═══════════════════════════════════════════════════
// CONVERSATIONS — One per chat session per user
// ═══════════════════════════════════════════════════
export const conversations = sqliteTable("conversations", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  user_id: integer("user_id").notNull(),
  title: text("title").notNull().default("NEW CONVERSATION"),
  model: text("model").notNull(),
  system_prompt: text("system_prompt").default(""),
  created_at: text("created_at").notNull(),
  updated_at: text("updated_at").notNull(),
});

// ═══════════════════════════════════════════════════
// MESSAGES — Individual chat messages
// ═══════════════════════════════════════════════════
export const messages = sqliteTable("messages", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  conversation_id: integer("conversation_id").notNull(),
  role: text("role", { enum: ["user", "assistant", "system"] }).notNull(),
  content: text("content").notNull(),
  created_at: text("created_at").notNull(),
});

// ═══════════════════════════════════════════════════
// MODEL_CONFIGS — Per-user model parameter preferences
// ═══════════════════════════════════════════════════
export const modelConfigs = sqliteTable("model_configs", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  user_id: integer("user_id").notNull(),
  model_name: text("model_name").notNull(),
  temperature: real("temperature").default(0.7),
  max_tokens: integer("max_tokens").default(2048),
  top_p: real("top_p").default(0.9),
  system_prompt: text("system_prompt").default(""),
  updated_at: text("updated_at").notNull(),
});

// ═══════════════════════════════════════════════════
// Insert schemas — Phase 2
// ═══════════════════════════════════════════════════
export const insertConversationSchema = createInsertSchema(conversations).omit({
  id: true,
});

export const insertMessageSchema = createInsertSchema(messages).omit({
  id: true,
});

export const insertModelConfigSchema = createInsertSchema(modelConfigs).omit({
  id: true,
});

// ═══════════════════════════════════════════════════
// Types — Phase 2
// ═══════════════════════════════════════════════════
export type InsertConversation = z.infer<typeof insertConversationSchema>;
export type Conversation = typeof conversations.$inferSelect;
export type InsertMessage = z.infer<typeof insertMessageSchema>;
export type Message = typeof messages.$inferSelect;
export type InsertModelConfig = z.infer<typeof insertModelConfigSchema>;
export type ModelConfig = typeof modelConfigs.$inferSelect;

// ═══════════════════════════════════════════════════
// VOICE_SESSIONS — Phase 3: Voice conversation sessions
// ═══════════════════════════════════════════════════
export const voiceSessions = sqliteTable("voice_sessions", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  user_id: integer("user_id").notNull(),
  conversation_id: integer("conversation_id"),
  created_at: text("created_at").notNull(),
  duration_seconds: integer("duration_seconds").default(0),
  message_count: integer("message_count").default(0),
});

// ═══════════════════════════════════════════════════
// Insert schemas — Phase 3
// ═══════════════════════════════════════════════════
export const insertVoiceSessionSchema = createInsertSchema(voiceSessions).omit({
  id: true,
});

// ═══════════════════════════════════════════════════
// Types — Phase 3
// ═══════════════════════════════════════════════════
export type InsertVoiceSession = z.infer<typeof insertVoiceSessionSchema>;
export type VoiceSession = typeof voiceSessions.$inferSelect;

// ═══════════════════════════════════════════════════
// GENERATED_IMAGES — Phase 4: Image generation history
// ═══════════════════════════════════════════════════
export const generatedImages = sqliteTable("generated_images", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  user_id: integer("user_id").notNull(),
  prompt: text("prompt").notNull(),
  negative_prompt: text("negative_prompt").default(""),
  model: text("model").notNull().default("stable-diffusion"),
  width: integer("width").default(512),
  height: integer("height").default(512),
  steps: integer("steps").default(20),
  cfg_scale: real("cfg_scale").default(7.0),
  seed: integer("seed").default(-1),
  actual_seed: integer("actual_seed"),
  image_path: text("image_path").notNull(),
  thumbnail_path: text("thumbnail_path"),
  created_at: text("created_at").notNull(),
  is_favorite: integer("is_favorite").default(0),
});

// ═══════════════════════════════════════════════════
// Insert schemas — Phase 4
// ═══════════════════════════════════════════════════
export const insertGeneratedImageSchema = createInsertSchema(generatedImages).omit({
  id: true,
});

// ═══════════════════════════════════════════════════
// Types — Phase 4
// ═══════════════════════════════════════════════════
export type InsertGeneratedImage = z.infer<typeof insertGeneratedImageSchema>;
export type GeneratedImage = typeof generatedImages.$inferSelect;

// ═══════════════════════════════════════════════════
// CONVERSATION_FILES — Phase 5: Files attached to conversations for LLM context
// ═══════════════════════════════════════════════════
export const conversationFiles = sqliteTable("conversation_files", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  conversation_id: integer("conversation_id").notNull(),
  user_id: integer("user_id").notNull(),
  filename: text("filename").notNull(),
  stored_filename: text("stored_filename").notNull(),
  file_path: text("file_path").notNull(),
  mime_type: text("mime_type").notNull(),
  file_size: integer("file_size").notNull(),
  extracted_text: text("extracted_text"),
  extraction_status: text("extraction_status").notNull().default("pending"),
  created_at: text("created_at").notNull(),
});

// ═══════════════════════════════════════════════════
// Insert schemas — Phase 5
// ═══════════════════════════════════════════════════
export const insertConversationFileSchema = createInsertSchema(conversationFiles).omit({
  id: true,
});

// ═══════════════════════════════════════════════════
// Types — Phase 5
// ═══════════════════════════════════════════════════
export type InsertConversationFile = z.infer<typeof insertConversationFileSchema>;
export type ConversationFile = typeof conversationFiles.$inferSelect;
