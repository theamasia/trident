import { useState, useEffect, useRef, useCallback } from "react";
import {
  MessageSquare,
  Plus,
  Send,
  Square,
  Trash2,
  Pencil,
  ChevronRight,
  ChevronLeft,
  Save,
  Cpu,
  Bot,
  User,
  Copy,
  Check,
  Loader2,
  AlertTriangle,
  Paperclip,
  FileText,
  Image as ImageIcon,
  File as FileIcon,
  X,
} from "lucide-react";
import { useAuth, getAuthHeaders } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import ReactMarkdown from "react-markdown";
import { Prism as SyntaxHighlighter } from "react-syntax-highlighter";
import { vscDarkPlus } from "react-syntax-highlighter/dist/esm/styles/prism";
import type { Conversation, Message, ConversationFile } from "@shared/schema";
import { useQuery } from "@tanstack/react-query";

const API_BASE = "__PORT_5000__".startsWith("__") ? "" : "__PORT_5000__";

// ═══════════════════════════════════════════════════
// TYPES
// ═══════════════════════════════════════════════════
interface OllamaModel {
  name: string;
  size: number;
  modified_at: string;
  details: Record<string, unknown>;
}

interface StreamingMessage {
  role: "assistant";
  content: string;
  isStreaming: boolean;
}

// ═══════════════════════════════════════════════════
// HELPERS
// ═══════════════════════════════════════════════════
function formatSize(bytes: number): string {
  if (!bytes) return "—";
  const gb = bytes / (1024 * 1024 * 1024);
  if (gb >= 1) return `${gb.toFixed(1)}GB`;
  const mb = bytes / (1024 * 1024);
  return `${mb.toFixed(0)}MB`;
}

function formatTime(iso: string): string {
  try {
    const d = new Date(iso);
    return d.toLocaleTimeString("en-US", { hour12: false, hour: "2-digit", minute: "2-digit" });
  } catch {
    return "";
  }
}

function estimateTokens(text: string): number {
  return Math.ceil(text.length / 4);
}

// ═══════════════════════════════════════════════════
// CODE BLOCK COMPONENT
// ═══════════════════════════════════════════════════
function CodeBlock({ language, children }: { language?: string; children: string }) {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(children);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="relative group my-2">
      <button
        onClick={handleCopy}
        className="absolute top-2 right-2 p-1.5 text-[10px] font-mono uppercase tracking-widest opacity-0 group-hover:opacity-100 transition-opacity border border-trident-border bg-[#0a1628] text-trident-cyan hover:text-trident-green z-10"
        data-testid="button-copy-code"
      >
        {copied ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
      </button>
      <SyntaxHighlighter
        language={language || "text"}
        style={vscDarkPlus}
        customStyle={{
          background: "#050a0e",
          border: "1px solid #1a3a4a",
          borderRadius: "2px",
          fontSize: "12px",
          margin: 0,
          padding: "12px",
        }}
        codeTagProps={{
          style: { color: "#00ff41", fontFamily: "'JetBrains Mono', monospace" },
        }}
      >
        {children}
      </SyntaxHighlighter>
    </div>
  );
}

// ═══════════════════════════════════════════════════
// MAIN COMPONENT
// ═══════════════════════════════════════════════════
export default function DashboardChat() {
  const { toast } = useToast();
  const authHeaders = getAuthHeaders();

  // State
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [activeConvId, setActiveConvId] = useState<number | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [streamingMsg, setStreamingMsg] = useState<StreamingMessage | null>(null);
  const [inputText, setInputText] = useState("");
  const [isStreaming, setIsStreaming] = useState(false);
  const [models, setModels] = useState<OllamaModel[]>([]);
  const [selectedModel, setSelectedModel] = useState("");
  const [temperature, setTemperature] = useState(0.7);
  const [maxTokens, setMaxTokens] = useState(2048);
  const [topP, setTopP] = useState(0.9);
  const [systemPrompt, setSystemPrompt] = useState("");
  const [leftPanelOpen, setLeftPanelOpen] = useState(true);
  const [rightPanelOpen, setRightPanelOpen] = useState(true);
  const [editingTitle, setEditingTitle] = useState(false);
  const [titleDraft, setTitleDraft] = useState("");
  const [loadingConvs, setLoadingConvs] = useState(true);

  const [uploadingFile, setUploadingFile] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const abortRef = useRef<AbortController | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Responsive
  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth < 900) {
        setLeftPanelOpen(false);
        setRightPanelOpen(false);
      } else if (window.innerWidth < 1200) {
        setRightPanelOpen(false);
      }
    };
    handleResize();
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  // Auto-scroll
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, streamingMsg?.content]);

  // Load conversations
  const loadConversations = useCallback(async () => {
    try {
      const res = await fetch(`${API_BASE}/api/conversations`, { headers: authHeaders });
      if (res.ok) {
        const data = await res.json();
        setConversations(data.conversations || []);
      }
    } catch {
      // silent
    } finally {
      setLoadingConvs(false);
    }
  }, []);

  // Load models
  const loadModels = useCallback(async () => {
    try {
      const res = await fetch(`${API_BASE}/api/ollama/models`, { headers: authHeaders });
      if (res.ok) {
        const data = await res.json();
        setModels(data.models || []);
        if (data.models?.length > 0 && !selectedModel) {
          setSelectedModel(data.models[0].name);
        }
      }
    } catch {
      // silent
    }
  }, [selectedModel]);

  useEffect(() => {
    loadConversations();
    loadModels();
  }, []);

  // Load conversation messages
  const loadConversation = useCallback(async (id: number) => {
    try {
      const res = await fetch(`${API_BASE}/api/conversations/${id}`, { headers: authHeaders });
      if (res.ok) {
        const data = await res.json();
        setMessages(data.messages || []);
        if (data.conversation?.model) {
          setSelectedModel(data.conversation.model);
        }
        if (data.conversation?.system_prompt) {
          setSystemPrompt(data.conversation.system_prompt);
        }
      }
    } catch {
      toast({ title: "ERROR", description: "FAILED TO LOAD CONVERSATION", variant: "destructive" });
    }
  }, []);

  const selectConversation = (id: number) => {
    setActiveConvId(id);
    loadConversation(id);
    setStreamingMsg(null);
    // Files will auto-refetch via useQuery when activeConvId changes
  };

  // Create conversation
  const createConversation = async () => {
    const model = selectedModel || models[0]?.name;
    if (!model) {
      toast({ title: "ERROR", description: "NO MODEL AVAILABLE — GO TO MODELS PAGE", variant: "destructive" });
      return;
    }
    try {
      const res = await fetch(`${API_BASE}/api/conversations`, {
        method: "POST",
        headers: { ...authHeaders, "Content-Type": "application/json" },
        body: JSON.stringify({ model, system_prompt: systemPrompt }),
      });
      if (res.ok) {
        const conv = await res.json();
        setConversations((prev) => [conv, ...prev]);
        setActiveConvId(conv.id);
        setMessages([]);
        setStreamingMsg(null);
      }
    } catch {
      toast({ title: "ERROR", description: "FAILED TO CREATE CONVERSATION", variant: "destructive" });
    }
  };

  // Delete conversation
  const deleteConversation = async (id: number, e?: React.MouseEvent) => {
    e?.stopPropagation();
    try {
      await fetch(`${API_BASE}/api/conversations/${id}`, {
        method: "DELETE",
        headers: authHeaders,
      });
      setConversations((prev) => prev.filter((c) => c.id !== id));
      if (activeConvId === id) {
        setActiveConvId(null);
        setMessages([]);
      }
    } catch {
      toast({ title: "ERROR", description: "FAILED TO DELETE", variant: "destructive" });
    }
  };

  // Rename conversation
  const saveTitle = async () => {
    if (!activeConvId || !titleDraft.trim()) {
      setEditingTitle(false);
      return;
    }
    try {
      await fetch(`${API_BASE}/api/conversations/${activeConvId}`, {
        method: "PATCH",
        headers: { ...authHeaders, "Content-Type": "application/json" },
        body: JSON.stringify({ title: titleDraft.trim() }),
      });
      setConversations((prev) =>
        prev.map((c) => (c.id === activeConvId ? { ...c, title: titleDraft.trim() } : c))
      );
    } catch {} finally {
      setEditingTitle(false);
    }
  };

  // Save model params
  const saveModelParams = async () => {
    if (!selectedModel) return;
    try {
      await fetch(`${API_BASE}/api/model-configs/${encodeURIComponent(selectedModel)}`, {
        method: "PUT",
        headers: { ...authHeaders, "Content-Type": "application/json" },
        body: JSON.stringify({ temperature, max_tokens: maxTokens, top_p: topP, system_prompt: systemPrompt }),
      });
      toast({ title: "SAVED", description: "NEURAL PARAMETERS STORED" });
    } catch {
      toast({ title: "ERROR", description: "FAILED TO SAVE PARAMS", variant: "destructive" });
    }
  };

  // Load model config on model change
  useEffect(() => {
    if (!selectedModel) return;
    (async () => {
      try {
        const res = await fetch(`${API_BASE}/api/model-configs/${encodeURIComponent(selectedModel)}`, { headers: authHeaders });
        if (res.ok) {
          const cfg = await res.json();
          if (cfg.temperature != null) setTemperature(cfg.temperature);
          if (cfg.max_tokens != null) setMaxTokens(cfg.max_tokens);
          if (cfg.top_p != null) setTopP(cfg.top_p);
          if (cfg.system_prompt != null) setSystemPrompt(cfg.system_prompt);
        }
      } catch {}
    })();
  }, [selectedModel]);

  // Update conversation model/system_prompt when changed
  useEffect(() => {
    if (!activeConvId || !selectedModel) return;
    fetch(`${API_BASE}/api/conversations/${activeConvId}`, {
      method: "PATCH",
      headers: { ...authHeaders, "Content-Type": "application/json" },
      body: JSON.stringify({ model: selectedModel, system_prompt: systemPrompt }),
    }).catch(() => {});
  }, [selectedModel, systemPrompt, activeConvId]);

  // SEND MESSAGE + STREAM
  const sendMessage = async () => {
    if (!inputText.trim() || isStreaming) return;
    if (!activeConvId) {
      // Auto-create conversation
      const model = selectedModel || models[0]?.name;
      if (!model) {
        toast({ title: "ERROR", description: "NO MODEL AVAILABLE", variant: "destructive" });
        return;
      }
      try {
        const res = await fetch(`${API_BASE}/api/conversations`, {
          method: "POST",
          headers: { ...authHeaders, "Content-Type": "application/json" },
          body: JSON.stringify({ model, system_prompt: systemPrompt, title: inputText.trim().slice(0, 50).toUpperCase() }),
        });
        if (!res.ok) return;
        const conv = await res.json();
        setConversations((prev) => [conv, ...prev]);
        setActiveConvId(conv.id);
        // Now send with the new conv id
        await doStream(conv.id, inputText.trim());
      } catch {
        toast({ title: "ERROR", description: "FAILED TO CREATE CONVERSATION", variant: "destructive" });
      }
      return;
    }
    await doStream(activeConvId, inputText.trim());
  };

  const doStream = async (convId: number, msg: string) => {
    const model = selectedModel || models[0]?.name;
    if (!model) return;

    setIsStreaming(true);
    setInputText("");

    // Add user message to local state immediately (display only the user's actual message)
    const userMsg: Message = {
      id: Date.now(),
      conversation_id: convId,
      role: "user",
      content: msg,
      created_at: new Date().toISOString(),
    };
    setMessages((prev) => [...prev, userMsg]);
    setStreamingMsg({ role: "assistant", content: "", isStreaming: true });

    // Inject file context into the message sent to LLM
    const fileContext = buildFileContext();
    const messageForLLM = fileContext ? `${fileContext}User message: ${msg}` : msg;

    const controller = new AbortController();
    abortRef.current = controller;

    try {
      const res = await fetch(`${API_BASE}/api/chat/stream`, {
        method: "POST",
        headers: { ...authHeaders, "Content-Type": "application/json" },
        body: JSON.stringify({
          conversationId: convId,
          message: messageForLLM,
          model,
          temperature,
          max_tokens: maxTokens,
          top_p: topP,
        }),
        signal: controller.signal,
      });

      if (!res.ok || !res.body) {
        setStreamingMsg(null);
        setIsStreaming(false);
        toast({ title: "ERROR", description: "STREAM FAILED", variant: "destructive" });
        return;
      }

      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";
      let fullContent = "";

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split("\n");
        buffer = lines.pop() || "";

        for (const line of lines) {
          if (!line.startsWith("data: ")) continue;
          const jsonStr = line.slice(6);
          try {
            const parsed = JSON.parse(jsonStr);
            if (parsed.error) {
              toast({ title: "ERROR", description: parsed.error, variant: "destructive" });
              break;
            }
            if (parsed.token) {
              fullContent += parsed.token;
              setStreamingMsg({ role: "assistant", content: fullContent, isStreaming: true });
            }
            if (parsed.done) {
              const finalMsg: Message = {
                id: parsed.messageId || Date.now(),
                conversation_id: convId,
                role: "assistant",
                content: fullContent,
                created_at: new Date().toISOString(),
              };
              setMessages((prev) => [...prev, finalMsg]);
              setStreamingMsg(null);
            }
          } catch {}
        }
      }
    } catch (err: any) {
      if (err.name === "AbortError") {
        // User aborted
        if (streamingMsg?.content) {
          const partialMsg: Message = {
            id: Date.now(),
            conversation_id: convId,
            role: "assistant",
            content: streamingMsg.content + "\n\n[TRANSMISSION ABORTED]",
            created_at: new Date().toISOString(),
          };
          setMessages((prev) => [...prev, partialMsg]);
        }
        setStreamingMsg(null);
      } else {
        toast({ title: "ERROR", description: "NEURAL LINK SEVERED", variant: "destructive" });
      }
    } finally {
      setIsStreaming(false);
      setStreamingMsg(null);
      abortRef.current = null;
      loadConversations(); // refresh list
    }
  };

  const abortStream = () => {
    abortRef.current?.abort();
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  // Auto-resize textarea
  useEffect(() => {
    const ta = textareaRef.current;
    if (ta) {
      ta.style.height = "auto";
      ta.style.height = `${Math.min(ta.scrollHeight, 144)}px`;
    }
  }, [inputText]);

  const activeConv = conversations.find((c) => c.id === activeConvId);

  // ═══════════════════════════════════════════════════
  // PHASE 5 — FILE UPLOAD
  // ═══════════════════════════════════════════════════
  type SafeConversationFile = Omit<ConversationFile, "file_path">;

  const { data: filesData, refetch: refetchFiles } = useQuery<{ files: SafeConversationFile[] }>({
    queryKey: ["/api/files", activeConvId],
    enabled: !!activeConvId,
    staleTime: 0,
    queryFn: async () => {
      if (!activeConvId) return { files: [] };
      const res = await fetch(`${API_BASE}/api/files/${activeConvId}`, { headers: getAuthHeaders() });
      if (!res.ok) return { files: [] };
      return res.json();
    },
  });

  const convFiles: SafeConversationFile[] = filesData?.files || [];

  const MAX_CLIENT_FILE_SIZE = 50 * 1024 * 1024;
  const ACCEPTED_EXTENSIONS = ".pdf,.txt,.md,.csv,.json,.docx,.xlsx,.jpg,.jpeg,.png,.gif,.webp";

  const getFileIcon = (mimeType: string) => {
    if (mimeType === "application/pdf") return <FileText className="w-3 h-3 text-[#ff6b00]" />;
    if (mimeType.startsWith("image/")) return <ImageIcon className="w-3 h-3 text-[#00f0ff]" />;
    if (mimeType.startsWith("text/") || mimeType === "application/json") return <FileText className="w-3 h-3 text-[#00ff41]" />;
    return <FileIcon className="w-3 h-3 text-trident-text/50" />;
  };

  const getChipBorderColor = (mimeType: string) => {
    if (mimeType === "application/pdf") return "border-[#ff6b00]/40";
    if (mimeType.startsWith("image/")) return "border-[#00f0ff]/40";
    if (mimeType.startsWith("text/") || mimeType === "application/json") return "border-[#00ff41]/40";
    return "border-trident-text/20";
  };

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    // Reset input so the same file can be re-selected
    e.target.value = "";

    if (!activeConvId) {
      toast({ title: "ERROR", description: "SELECT A CONVERSATION FIRST", variant: "destructive" });
      return;
    }

    if (file.size > MAX_CLIENT_FILE_SIZE) {
      toast({ title: "ERROR", description: "FILE TOO LARGE — MAX 50MB", variant: "destructive" });
      return;
    }

    setUploadingFile(file.name);
    try {
      const formData = new FormData();
      formData.append("file", file);
      const res = await fetch(`${API_BASE}/api/files/upload/${activeConvId}`, {
        method: "POST",
        headers: getAuthHeaders(),
        body: formData,
      });
      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        throw new Error(errData.error || "UPLOAD FAILED");
      }
      await refetchFiles();
      toast({ title: "UPLOADED", description: `${file.name.toUpperCase()} ATTACHED` });
    } catch (err: any) {
      toast({ title: "UPLOAD FAILED", description: err.message || "UNKNOWN ERROR", variant: "destructive" });
    } finally {
      setUploadingFile(null);
    }
  };

  const handleDeleteFile = async (fileId: number) => {
    try {
      await fetch(`${API_BASE}/api/files/${fileId}`, {
        method: "DELETE",
        headers: getAuthHeaders(),
      });
      refetchFiles();
    } catch {
      toast({ title: "ERROR", description: "FAILED TO DELETE FILE", variant: "destructive" });
    }
  };

  // Build file context for LLM injection
  const buildFileContext = (): string => {
    if (convFiles.length === 0) return "";
    const filesWithText = convFiles.filter(
      (f) => f.extraction_status === "done" && f.extracted_text
    );
    if (filesWithText.length === 0) return "";
    let context = "[ATTACHED FILES CONTEXT]\n";
    for (const f of filesWithText) {
      context += `--- ${f.filename} ---\n${f.extracted_text}\n---\n`;
    }
    context += "[END CONTEXT]\n\n";
    return context;
  };

  // ═══════════════════════════════════════════════════
  // RENDER
  // ═══════════════════════════════════════════════════
  return (
    <div className="h-full flex" data-testid="chat-layout">
      {/* ═══════════ LEFT PANEL — CONVERSATIONS ═══════════ */}
      {leftPanelOpen && (
        <div
          className="w-60 flex-shrink-0 flex flex-col border-r border-trident-border"
          style={{ backgroundColor: "#0a1628" }}
          data-testid="panel-conversations"
        >
          {/* New conversation button */}
          <div className="p-3 border-b border-trident-border">
            <button
              onClick={createConversation}
              className="w-full flex items-center justify-center gap-2 px-3 py-2.5 text-[10px] font-display uppercase tracking-widest bg-trident-amber text-black hover:bg-[#ff8533] transition-all glow-amber-hover"
              data-testid="button-new-conversation"
            >
              <Plus className="w-3.5 h-3.5" />
              NEW CONVERSATION
            </button>
          </div>

          {/* Conversation list */}
          <div className="flex-1 overflow-y-auto">
            {loadingConvs ? (
              <div className="p-4 text-center">
                <Loader2 className="w-4 h-4 animate-spin text-trident-cyan mx-auto" />
              </div>
            ) : conversations.length === 0 ? (
              <div className="p-4 text-center font-mono text-[10px] uppercase tracking-widest text-trident-green/30">
                NO ACTIVE SESSIONS
              </div>
            ) : (
              conversations.map((conv) => (
                <div
                  key={conv.id}
                  onClick={() => selectConversation(conv.id)}
                  className={`group relative px-3 py-3 cursor-pointer transition-all border-l-2 ${
                    conv.id === activeConvId
                      ? "border-trident-cyan bg-trident-cyan/5"
                      : "border-transparent hover:bg-trident-cyan/5 hover:border-trident-cyan/30"
                  }`}
                  data-testid={`conv-item-${conv.id}`}
                >
                  <div className="flex items-start justify-between gap-1">
                    <div className="min-w-0 flex-1">
                      <p
                        className={`font-mono text-[11px] uppercase tracking-wider truncate ${
                          conv.id === activeConvId ? "text-trident-cyan" : "text-trident-text/70"
                        }`}
                      >
                        {conv.title}
                      </p>
                      <div className="flex items-center gap-1.5 mt-0.5">
                        <p className="font-mono text-[9px] uppercase tracking-widest text-trident-text/30">
                          {conv.model}
                        </p>
                        {conv.id === activeConvId && convFiles.length > 0 && (
                          <span className="flex items-center gap-0.5 px-1 py-0 border border-trident-cyan/20 bg-trident-cyan/5" data-testid={`file-count-badge-${conv.id}`}>
                            <Paperclip className="w-2 h-2 text-trident-cyan/50" />
                            <span className="font-mono text-[8px] text-trident-cyan/70">{convFiles.length}</span>
                          </span>
                        )}
                      </div>
                    </div>
                    <button
                      onClick={(e) => deleteConversation(conv.id, e)}
                      className="opacity-0 group-hover:opacity-100 p-1 text-trident-red/50 hover:text-trident-red transition-all"
                      data-testid={`button-delete-conv-${conv.id}`}
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* Toggle left panel */}
      <button
        onClick={() => setLeftPanelOpen(!leftPanelOpen)}
        className="flex-shrink-0 w-5 flex items-center justify-center border-r border-trident-border bg-[#0a1628] text-trident-cyan/40 hover:text-trident-cyan transition-colors"
        data-testid="button-toggle-left-panel"
      >
        {leftPanelOpen ? <ChevronLeft className="w-3 h-3" /> : <ChevronRight className="w-3 h-3" />}
      </button>

      {/* ═══════════ CENTER — MESSAGE AREA ═══════════ */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Top bar */}
        <div
          className="flex items-center justify-between px-4 py-2.5 border-b border-trident-border"
          style={{ backgroundColor: "#0a162890" }}
        >
          <div className="flex items-center gap-3 min-w-0">
            <MessageSquare className="w-4 h-4 text-trident-cyan flex-shrink-0" />
            {editingTitle ? (
              <input
                autoFocus
                value={titleDraft}
                onChange={(e) => setTitleDraft(e.target.value)}
                onBlur={saveTitle}
                onKeyDown={(e) => e.key === "Enter" && saveTitle()}
                className="bg-transparent border-b border-trident-cyan text-trident-cyan font-mono text-xs uppercase tracking-widest outline-none w-48"
                data-testid="input-title-edit"
              />
            ) : (
              <span
                onClick={() => {
                  if (activeConv) {
                    setEditingTitle(true);
                    setTitleDraft(activeConv.title);
                  }
                }}
                className="font-mono text-xs uppercase tracking-widest text-trident-cyan truncate cursor-pointer hover:text-glow-cyan"
                data-testid="text-conversation-title"
              >
                {activeConv?.title || "SELECT OR CREATE CONVERSATION"}
              </span>
            )}
            {activeConv && (
              <button
                onClick={() => { setEditingTitle(true); setTitleDraft(activeConv.title); }}
                className="text-trident-text/30 hover:text-trident-cyan transition-colors"
                data-testid="button-edit-title"
              >
                <Pencil className="w-3 h-3" />
              </button>
            )}
          </div>
          {activeConv && (
            <span className="px-2 py-0.5 text-[9px] font-mono uppercase tracking-widest border border-trident-cyan/30 text-trident-cyan/70 flex-shrink-0">
              {activeConv.model}
            </span>
          )}
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4" data-testid="messages-area">
          {!activeConvId && messages.length === 0 && !streamingMsg ? (
            <div className="h-full flex items-center justify-center">
              <div className="text-center space-y-4 max-w-md">
                <div className="inline-flex p-4 border border-trident-border" style={{ backgroundColor: "#050a0e" }}>
                  <Bot className="w-8 h-8 text-trident-cyan" />
                </div>
                <div className="font-mono text-xs space-y-2">
                  <p className="text-trident-cyan text-glow-cyan uppercase tracking-widest">
                    NEURAL CHAT INTERFACE — ONLINE
                  </p>
                  <p className="text-trident-text/40 uppercase tracking-wider">
                    {selectedModel
                      ? `MODEL: ${selectedModel.toUpperCase()}`
                      : "NO MODEL SELECTED — CONFIGURE IN RIGHT PANEL"}
                  </p>
                  <p className="text-trident-text/30 uppercase tracking-wider text-[10px] mt-4">
                    CREATE A CONVERSATION OR TYPE A MESSAGE TO BEGIN
                  </p>
                </div>
              </div>
            </div>
          ) : messages.length === 0 && !streamingMsg ? (
            <div className="h-full flex items-center justify-center">
              <div className="text-center space-y-3">
                <Cpu className="w-6 h-6 text-trident-cyan/30 mx-auto" />
                <p className="font-mono text-[10px] uppercase tracking-widest text-trident-text/30">
                  AWAITING INPUT — TYPE YOUR COMMAND
                </p>
              </div>
            </div>
          ) : (
            <>
              {messages.map((msg) => (
                <div
                  key={msg.id}
                  className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}
                  data-testid={`message-${msg.role}-${msg.id}`}
                >
                  <div
                    className={`max-w-[80%] ${
                      msg.role === "user"
                        ? "bg-trident-amber/10 border border-trident-amber/20"
                        : "bg-trident-cyan/5 border border-trident-cyan/10 border-l-2 border-l-trident-cyan/40"
                    } px-4 py-3`}
                  >
                    <div className="flex items-center gap-2 mb-2">
                      {msg.role === "user" ? (
                        <User className="w-3 h-3 text-trident-amber" />
                      ) : (
                        <Bot className="w-3 h-3 text-trident-cyan" />
                      )}
                      <span className="font-mono text-[9px] uppercase tracking-widest text-trident-text/40">
                        {msg.role === "user" ? "OPERATOR" : "NEURAL RESPONSE"}
                      </span>
                    </div>
                    {msg.role === "assistant" ? (
                      <div className="font-mono text-xs leading-relaxed text-trident-text prose prose-invert prose-sm max-w-none prose-code:text-[#00ff41] prose-pre:bg-transparent prose-pre:p-0 prose-p:text-trident-text prose-headings:text-trident-cyan prose-strong:text-trident-cyan prose-a:text-trident-cyan">
                        <ReactMarkdown
                          components={{
                            code({ className, children, ...props }) {
                              const match = /language-(\w+)/.exec(className || "");
                              const codeString = String(children).replace(/\n$/, "");
                              if (match) {
                                return <CodeBlock language={match[1]}>{codeString}</CodeBlock>;
                              }
                              return (
                                <code
                                  className="px-1 py-0.5 bg-[#050a0e] border border-trident-border text-[#00ff41] text-[11px]"
                                  {...props}
                                >
                                  {children}
                                </code>
                              );
                            },
                          }}
                        >
                          {msg.content}
                        </ReactMarkdown>
                      </div>
                    ) : (
                      <p className="font-mono text-xs leading-relaxed text-trident-text whitespace-pre-wrap">
                        {msg.content}
                      </p>
                    )}
                    <p className="text-right mt-2 font-mono text-[9px] text-trident-text/20">
                      {formatTime(msg.created_at)}
                    </p>
                  </div>
                </div>
              ))}

              {/* Streaming message */}
              {streamingMsg && (
                <div className="flex justify-start" data-testid="message-streaming">
                  <div className="max-w-[80%] bg-trident-cyan/5 border border-trident-cyan/10 border-l-2 border-l-trident-cyan/40 px-4 py-3">
                    <div className="flex items-center gap-2 mb-2">
                      <Bot className="w-3 h-3 text-trident-cyan" />
                      <span className="font-mono text-[9px] uppercase tracking-widest text-trident-text/40">
                        NEURAL RESPONSE
                      </span>
                      <span className="inline-flex gap-1 ml-2">
                        {[0, 1, 2].map((i) => (
                          <span
                            key={i}
                            className="w-1.5 h-1.5 rounded-full bg-trident-cyan pulse-dot"
                            style={{ animationDelay: `${i * 0.3}s` }}
                          />
                        ))}
                      </span>
                    </div>
                    {streamingMsg.content ? (
                      <div className="font-mono text-xs leading-relaxed text-trident-text prose prose-invert prose-sm max-w-none prose-code:text-[#00ff41] prose-pre:bg-transparent prose-pre:p-0 prose-p:text-trident-text prose-headings:text-trident-cyan prose-strong:text-trident-cyan">
                        <ReactMarkdown
                          components={{
                            code({ className, children, ...props }) {
                              const match = /language-(\w+)/.exec(className || "");
                              const codeString = String(children).replace(/\n$/, "");
                              if (match) {
                                return <CodeBlock language={match[1]}>{codeString}</CodeBlock>;
                              }
                              return (
                                <code
                                  className="px-1 py-0.5 bg-[#050a0e] border border-trident-border text-[#00ff41] text-[11px]"
                                  {...props}
                                >
                                  {children}
                                </code>
                              );
                            },
                          }}
                        >
                          {streamingMsg.content}
                        </ReactMarkdown>
                      </div>
                    ) : (
                      <p className="font-mono text-xs text-trident-cyan/50 animate-pulse">
                        &gt;&gt; PROCESSING NEURAL RESPONSE...
                      </p>
                    )}
                  </div>
                </div>
              )}
            </>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Input bar */}
        <div className="border-t border-trident-border p-3" style={{ backgroundColor: "#0a162890" }}>
          {/* File chips row */}
          {(convFiles.length > 0 || uploadingFile) && (
            <div className="flex items-center gap-1.5 mb-2 overflow-x-auto pb-1 scrollbar-thin" data-testid="file-chips-row">
              {convFiles.map((f) => (
                <div
                  key={f.id}
                  className={`flex items-center gap-1.5 px-2 py-1 border ${getChipBorderColor(f.mime_type)} bg-[#050a0e] flex-shrink-0`}
                  data-testid={`file-chip-${f.id}`}
                >
                  {getFileIcon(f.mime_type)}
                  <span className="font-mono text-[10px] uppercase tracking-wider text-trident-text/70 max-w-[120px] truncate">
                    {f.filename.length > 20 ? f.filename.slice(0, 17) + "..." : f.filename}
                  </span>
                  {f.extraction_status === "pending" && (
                    <Loader2 className="w-2.5 h-2.5 animate-spin text-trident-cyan/50" />
                  )}
                  <button
                    onClick={() => handleDeleteFile(f.id)}
                    className="text-trident-text/30 hover:text-trident-red transition-colors ml-0.5"
                    data-testid={`button-delete-file-${f.id}`}
                  >
                    <X className="w-3 h-3" />
                  </button>
                </div>
              ))}
              {uploadingFile && (
                <div className="flex items-center gap-1.5 px-2 py-1 border border-trident-cyan/20 bg-[#050a0e] flex-shrink-0">
                  <Loader2 className="w-3 h-3 animate-spin text-trident-cyan" />
                  <span className="font-mono text-[10px] uppercase tracking-wider text-trident-cyan/70">
                    UPLOADING {uploadingFile.length > 15 ? uploadingFile.slice(0, 12) + "..." : uploadingFile}
                  </span>
                </div>
              )}
            </div>
          )}

          {/* Hidden file input */}
          <input
            ref={fileInputRef}
            type="file"
            accept={ACCEPTED_EXTENSIONS}
            onChange={handleFileSelect}
            className="hidden"
            data-testid="input-file-upload"
          />

          <div className="flex items-end gap-2">
            {/* Paperclip attach button */}
            <button
              onClick={() => fileInputRef.current?.click()}
              disabled={!!uploadingFile}
              className="flex items-center justify-center p-2.5 text-trident-text/40 hover:text-trident-cyan border border-trident-border bg-[#050a0e] hover:border-trident-cyan/40 transition-all disabled:opacity-30"
              title="ATTACH FILE"
              data-testid="button-attach-file"
            >
              <Paperclip className="w-4 h-4" />
            </button>

            <div className="flex-1 relative">
              <textarea
                ref={textareaRef}
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="ENTER COMMAND..."
                rows={1}
                className="w-full resize-none font-mono text-xs text-trident-text bg-[#050a0e] border border-trident-border px-3 py-2.5 uppercase placeholder:text-trident-text/20 focus:border-trident-cyan focus:outline-none transition-all"
                style={{ maxHeight: "144px" }}
                disabled={isStreaming}
                data-testid="input-chat-message"
              />
              <span className="absolute bottom-1.5 right-2 font-mono text-[9px] text-trident-text/20">
                ~{estimateTokens(inputText)} TK
              </span>
            </div>
            {isStreaming ? (
              <button
                onClick={abortStream}
                className="flex items-center gap-1.5 px-4 py-2.5 text-[10px] font-display uppercase tracking-widest bg-trident-red text-white hover:bg-trident-red/80 transition-all"
                data-testid="button-abort"
              >
                <Square className="w-3 h-3" />
                ABORT
              </button>
            ) : (
              <button
                onClick={sendMessage}
                disabled={!inputText.trim()}
                className="flex items-center gap-1.5 px-4 py-2.5 text-[10px] font-display uppercase tracking-widest bg-trident-amber text-black hover:bg-[#ff8533] disabled:opacity-30 disabled:cursor-not-allowed transition-all glow-amber-hover"
                data-testid="button-transmit"
              >
                <Send className="w-3 h-3" />
                TRANSMIT
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Toggle right panel */}
      <button
        onClick={() => setRightPanelOpen(!rightPanelOpen)}
        className="flex-shrink-0 w-5 flex items-center justify-center border-l border-trident-border bg-[#0a1628] text-trident-cyan/40 hover:text-trident-cyan transition-colors"
        data-testid="button-toggle-right-panel"
      >
        {rightPanelOpen ? <ChevronRight className="w-3 h-3" /> : <ChevronLeft className="w-3 h-3" />}
      </button>

      {/* ═══════════ RIGHT PANEL — MODEL PARAMS ═══════════ */}
      {rightPanelOpen && (
        <div
          className="w-[280px] flex-shrink-0 flex flex-col border-l border-trident-border overflow-y-auto"
          style={{ backgroundColor: "#0a1628" }}
          data-testid="panel-model-params"
        >
          <div className="p-4 border-b border-trident-border">
            <h3 className="font-display text-[10px] tracking-[0.15em] text-trident-amber text-glow-amber uppercase">
              NEURAL PARAMETERS
            </h3>
          </div>

          <div className="p-4 space-y-5">
            {/* Model selector */}
            <div>
              <label className="block font-mono text-[9px] uppercase tracking-widest text-trident-text/50 mb-2">
                MODEL
              </label>
              {models.length === 0 ? (
                <div className="text-center py-3 border border-trident-border/50 bg-[#050a0e]">
                  <AlertTriangle className="w-4 h-4 text-trident-amber/50 mx-auto mb-1" />
                  <p className="font-mono text-[9px] uppercase tracking-widest text-trident-amber/50">
                    NO MODELS LOADED
                  </p>
                  <a
                    href="/#/dashboard/models"
                    onClick={(e) => {
                      e.preventDefault();
                      window.location.hash = "#/dashboard/models";
                    }}
                    className="font-mono text-[9px] uppercase tracking-widest text-trident-cyan hover:text-glow-cyan"
                  >
                    GO TO MODELS
                  </a>
                </div>
              ) : (
                <select
                  value={selectedModel}
                  onChange={(e) => setSelectedModel(e.target.value)}
                  className="w-full font-mono text-xs bg-[#050a0e] border border-trident-border text-trident-text uppercase px-2 py-2 focus:border-trident-cyan focus:outline-none"
                  data-testid="select-model"
                >
                  {models.map((m) => (
                    <option key={m.name} value={m.name}>
                      {m.name} ({formatSize(m.size)})
                    </option>
                  ))}
                </select>
              )}
            </div>

            {/* Temperature */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="font-mono text-[9px] uppercase tracking-widest text-trident-text/50">
                  TEMPERATURE
                </label>
                <span className="font-mono text-[10px] text-trident-cyan tabular-nums">{temperature.toFixed(1)}</span>
              </div>
              <input
                type="range"
                min="0"
                max="2"
                step="0.1"
                value={temperature}
                onChange={(e) => setTemperature(parseFloat(e.target.value))}
                className="w-full accent-trident-cyan h-1 bg-trident-border rounded-none"
                data-testid="slider-temperature"
              />
              <div className="flex justify-between font-mono text-[8px] text-trident-text/20 mt-1">
                <span>PRECISE</span>
                <span>CREATIVE</span>
              </div>
            </div>

            {/* Max Tokens */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="font-mono text-[9px] uppercase tracking-widest text-trident-text/50">
                  MAX TOKENS
                </label>
                <span className="font-mono text-[10px] text-trident-cyan tabular-nums">{maxTokens}</span>
              </div>
              <input
                type="range"
                min="256"
                max="8192"
                step="256"
                value={maxTokens}
                onChange={(e) => setMaxTokens(parseInt(e.target.value))}
                className="w-full accent-trident-cyan h-1 bg-trident-border rounded-none"
                data-testid="slider-max-tokens"
              />
              <div className="flex justify-between font-mono text-[8px] text-trident-text/20 mt-1">
                <span>256</span>
                <span>8192</span>
              </div>
            </div>

            {/* Top-P */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="font-mono text-[9px] uppercase tracking-widest text-trident-text/50">
                  TOP-P
                </label>
                <span className="font-mono text-[10px] text-trident-cyan tabular-nums">{topP.toFixed(2)}</span>
              </div>
              <input
                type="range"
                min="0"
                max="1"
                step="0.05"
                value={topP}
                onChange={(e) => setTopP(parseFloat(e.target.value))}
                className="w-full accent-trident-cyan h-1 bg-trident-border rounded-none"
                data-testid="slider-top-p"
              />
              <div className="flex justify-between font-mono text-[8px] text-trident-text/20 mt-1">
                <span>FOCUSED</span>
                <span>DIVERSE</span>
              </div>
            </div>

            {/* System Prompt */}
            <div>
              <label className="block font-mono text-[9px] uppercase tracking-widest text-trident-amber/70 mb-2">
                OVERRIDE DIRECTIVE
              </label>
              <textarea
                value={systemPrompt}
                onChange={(e) => setSystemPrompt(e.target.value)}
                rows={4}
                placeholder="SYSTEM INSTRUCTIONS..."
                className="w-full font-mono text-xs bg-[#050a0e] border border-trident-border text-trident-text px-2 py-2 resize-none placeholder:text-trident-text/20 focus:border-trident-amber focus:outline-none"
                data-testid="textarea-system-prompt"
              />
            </div>

            {/* Save button */}
            <button
              onClick={saveModelParams}
              className="w-full flex items-center justify-center gap-2 px-3 py-2.5 text-[10px] font-display uppercase tracking-widest border border-trident-cyan text-trident-cyan hover:bg-trident-cyan/10 transition-all glow-cyan-hover"
              data-testid="button-save-params"
            >
              <Save className="w-3 h-3" />
              SAVE PARAMS
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
