import type { Request, Response, NextFunction } from "express";
import jwt from "jsonwebtoken";
import { storage } from "../storage";
import type { SafeUser } from "@shared/schema";

const JWT_SECRET = process.env.JWT_SECRET || "trident-dev-secret-change-in-production";

// Extend Express Request to carry the authenticated user
declare global {
  namespace Express {
    interface Request {
      user?: SafeUser;
    }
  }
}

export function generateToken(userId: number, role: string): string {
  return jwt.sign({ userId, role }, JWT_SECRET, { expiresIn: "24h" });
}

export function verifyToken(token: string): { userId: number; role: string } | null {
  try {
    const decoded = jwt.verify(token, JWT_SECRET) as { userId: number; role: string };
    return decoded;
  } catch {
    return null;
  }
}

// Middleware: require valid JWT
export async function requireAuth(req: Request, res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization;
  const token = authHeader?.startsWith("Bearer ") ? authHeader.slice(7) : null;

  if (!token) {
    return res.status(401).json({ error: "AUTHENTICATION REQUIRED" });
  }

  const decoded = verifyToken(token);
  if (!decoded) {
    return res.status(401).json({ error: "INVALID OR EXPIRED TOKEN" });
  }

  const user = await storage.getUser(decoded.userId);
  if (!user || !user.is_active) {
    return res.status(401).json({ error: "USER NOT FOUND OR DEACTIVATED" });
  }

  // Attach safe user (no password hash) to request
  const { password_hash, ...safeUser } = user;
  req.user = safeUser;
  next();
}

// ═══════════════════════════════════════════════════
// CLEARANCE TIERS
// commander == admin (legacy). operator == power_user (legacy).
// ═══════════════════════════════════════════════════
export const COMMANDER_ROLES = ["admin", "commander"];
export const OPERATOR_ROLES = ["admin", "commander", "operator", "power_user"];
export const INTEL_ROLES = ["admin", "commander", "operator", "intel", "power_user"];
export const OPS_ROLES = ["admin", "commander", "operator", "ops", "power_user"];

function clearanceGate(allowed: string[], message: string) {
  return async function gate(req: Request, res: Response, next: NextFunction) {
    await requireAuth(req, res, () => {
      if (!req.user) {
        return res.status(401).json({ error: "AUTHENTICATION REQUIRED" });
      }
      if (!allowed.includes(req.user.role)) {
        return res.status(403).json({ error: message });
      }
      next();
    });
  };
}

// Middleware: require admin/commander clearance
export const requireAdmin = clearanceGate(
  COMMANDER_ROLES,
  "INSUFFICIENT CLEARANCE — ADMIN ACCESS REQUIRED"
);

// Commander-only (same as admin)
export const requireCommander = clearanceGate(
  COMMANDER_ROLES,
  "INSUFFICIENT CLEARANCE — COMMANDER CLEARANCE REQUIRED"
);

// Operator and above (commander, operator, admin, power_user)
export const requireOperator = clearanceGate(
  OPERATOR_ROLES,
  "INSUFFICIENT CLEARANCE — OPERATOR CLEARANCE REQUIRED"
);

// Intel and above
export const requireIntel = clearanceGate(
  INTEL_ROLES,
  "INSUFFICIENT CLEARANCE — INTEL CLEARANCE REQUIRED"
);

// Ops and above
export const requireOps = clearanceGate(
  OPS_ROLES,
  "INSUFFICIENT CLEARANCE — OPS CLEARANCE REQUIRED"
);

// Helper: is this role commander-tier? (admin treated as commander)
export function isCommander(role?: string | null): boolean {
  return !!role && COMMANDER_ROLES.includes(role);
}
