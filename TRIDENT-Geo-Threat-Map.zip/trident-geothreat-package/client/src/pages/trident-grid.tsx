import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { getAuthHeaders } from "@/hooks/use-auth";
import {
  Network,
  Cpu,
  MemoryStick,
  HardDrive,
  Activity,
  CheckCircle2,
  Server,
  Gauge,
  Copy,
  Check,
  PlusCircle,
  Zap,
} from "lucide-react";

const API_BASE = "__PORT_5000__".startsWith("__") ? "" : "__PORT_5000__";

// ─── Types ────────────────────────────────────────────────────────
interface NodeMetrics {
  cpu_pct?: number;
  ram_pct?: number;
  ram_used_gb?: number;
  ram_available_gb?: number;
  gpu_pct?: number;
  gpu_vram_used_gb?: number;
  gpu_vram_free_gb?: number;
}

interface NodeCapabilities {
  cpu_cores?: number;
  cpu_threads?: number;
  ram_total_gb?: number;
  disk_free_gb?: number;
  gpu?: { detected?: boolean; name?: string; vram_total_gb?: number; vram_free_gb?: number };
  ollama_available?: boolean;
  ollama_models?: string[];
  os?: string;
}

interface GridNode {
  node_id: string;
  name: string;
  ip: string;
  port: number;
  status: string;
  tags: string[];
  capabilities: NodeCapabilities;
  last_metrics: NodeMetrics;
  jobs_completed: number;
  jobs_failed: number;
  dispatch_score: number;
  last_seen_ago_s: number;
}

interface GridJob {
  job_id: string;
  type: string;
  status: string;
  assigned_node: string | null;
  created_at: string;
  started_at: string | null;
  completed_at: string | null;
}

interface GridStatus {
  online: boolean;
  health?: {
    nodes_online?: number;
    nodes_total?: number;
    jobs_running?: number;
    jobs_queued?: number;
  } | null;
}

// ─── Small components ─────────────────────────────────────────────
function MeterBar({ label, value, color, sublabel }: { label: string; value: number; color: string; sublabel?: string }) {
  const pct = Math.max(0, Math.min(100, value || 0));
  const filled = Math.round(pct / 10);
  return (
    <div className="flex items-center gap-2 font-mono text-[10px] uppercase tracking-widest">
      <span className="text-trident-text/50 w-9">{label}</span>
      <span className="tracking-tighter" style={{ color }}>
        {"█".repeat(filled)}
        <span className="text-trident-text/15">{"░".repeat(10 - filled)}</span>
      </span>
      <span className="tabular-nums" style={{ color }}>
        {sublabel !== undefined ? sublabel : `${Math.round(pct)}%`}
      </span>
    </div>
  );
}

function StatCard({ label, value, sub, color, icon: Icon }: { label: string; value: string; sub?: string; color: string; icon: React.ComponentType<{ className?: string; style?: React.CSSProperties }> }) {
  return (
    <div
      className="relative border border-trident-border p-4 overflow-hidden"
      style={{ backgroundColor: "#0a1628" }}
      data-testid={`stat-${label.toLowerCase().replace(/\s/g, "-")}`}
    >
      <div className="flex items-center justify-between mb-2">
        <span className="text-[10px] font-mono uppercase tracking-widest text-trident-text/50">{label}</span>
        <Icon className="w-4 h-4" style={{ color }} />
      </div>
      <div className="font-display text-3xl tabular-nums" style={{ color, textShadow: `0 0 12px ${color}60` }}>
        {value}
      </div>
      {sub && <div className="text-[10px] font-mono uppercase tracking-widest text-trident-text/40 mt-1">{sub}</div>}
    </div>
  );
}

function NodeCard({ node, offline }: { node: GridNode; offline: boolean }) {
  const m = node.last_metrics || {};
  const caps = node.capabilities || {};
  const gpu = caps.gpu || {};
  const degraded = !offline && node.dispatch_score > 80;
  const dotColor = offline ? "#ff2244" : degraded ? "#ff6b00" : "#00ff41";
  const dotLabel = offline ? "OFFLINE" : degraded ? "DEGRADED" : "ONLINE";

  return (
    <div
      className="relative border border-trident-border p-4 flex flex-col gap-3"
      style={{ backgroundColor: "#0a1628" }}
      data-testid={`card-node-${node.node_id}`}
    >
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span
            className={`inline-block w-2 h-2 rounded-full ${!offline ? "animate-pulse" : ""}`}
            style={{ backgroundColor: dotColor, boxShadow: `0 0 8px ${dotColor}` }}
          />
          <span className="font-mono text-[10px] uppercase tracking-widest" style={{ color: dotColor }}>
            {dotLabel}
          </span>
          <span className="font-display text-sm tracking-widest text-trident-cyan ml-1" data-testid={`text-nodename-${node.node_id}`}>
            {node.name?.toUpperCase()}
          </span>
        </div>
        <span className="font-mono text-[10px] text-trident-text/50 tabular-nums">
          {node.ip}
        </span>
      </div>

      {/* Meters */}
      <div className="grid grid-cols-2 gap-x-4 gap-y-1.5">
        <MeterBar label="CPU" value={m.cpu_pct ?? 0} color="#00f0ff" />
        <MeterBar label="RAM" value={m.ram_pct ?? 0} color="#00ff41" />
        {gpu.detected ? (
          <>
            <MeterBar label="GPU" value={m.gpu_pct ?? 0} color="#ff6b00" />
            <MeterBar
              label="VRAM"
              value={gpu.vram_total_gb ? ((m.gpu_vram_used_gb ?? 0) / gpu.vram_total_gb) * 100 : 0}
              color="#ff6b00"
              sublabel={`${m.gpu_vram_used_gb ?? 0} / ${gpu.vram_total_gb ?? 0}GB`}
            />
          </>
        ) : (
          <div className="col-span-2 font-mono text-[10px] uppercase tracking-widest text-trident-text/30">
            NO GPU DETECTED
          </div>
        )}
      </div>

      {/* Tags */}
      {node.tags?.length > 0 && (
        <div className="flex flex-wrap gap-1.5">
          <span className="font-mono text-[9px] uppercase tracking-widest text-trident-text/40 mt-0.5">TAGS:</span>
          {node.tags.map((t) => (
            <span
              key={t}
              className="px-1.5 py-0.5 text-[9px] font-mono uppercase tracking-widest border border-trident-cyan/40 text-trident-cyan bg-trident-cyan/10"
            >
              {t}
            </span>
          ))}
        </div>
      )}

      {/* Models */}
      {caps.ollama_models && caps.ollama_models.length > 0 && (
        <div className="flex flex-wrap gap-1.5">
          <span className="font-mono text-[9px] uppercase tracking-widest text-trident-text/40 mt-0.5">MODELS:</span>
          {caps.ollama_models.slice(0, 6).map((mm) => (
            <span
              key={mm}
              className="px-1.5 py-0.5 text-[9px] font-mono uppercase tracking-widest border border-trident-amber/40 text-trident-amber bg-trident-amber/10"
            >
              {mm}
            </span>
          ))}
        </div>
      )}

      {/* Footer stats */}
      <div className="flex items-center justify-between border-t border-trident-border pt-2 font-mono text-[10px] uppercase tracking-widest">
        <span className="text-trident-text/60">
          SCORE: <span className="text-trident-cyan tabular-nums">{node.dispatch_score}</span>
        </span>
        <span className="text-trident-text/60">
          JOBS: <span className="text-[#00ff41] tabular-nums">{node.jobs_completed}</span> DONE /{" "}
          <span className="text-trident-red tabular-nums">{node.jobs_failed}</span> FAILED
        </span>
        <span className="text-trident-text/40">
          LAST SEEN: {node.last_seen_ago_s ?? "?"}s AGO
        </span>
      </div>
    </div>
  );
}

// ─── Page ─────────────────────────────────────────────────────────
export default function TridentGrid() {
  const [copied, setCopied] = useState(false);
  const installCommand = "curl -fsSL http://192.168.0.7:5000/api/grid/install.sh | sudo bash";

  const { data: status } = useQuery<GridStatus>({
    queryKey: ["/api/grid/status"],
    queryFn: async () => {
      const res = await fetch(`${API_BASE}/api/grid/status`, { headers: getAuthHeaders() });
      if (!res.ok) throw new Error("STATUS FETCH FAILED");
      return res.json();
    },
    staleTime: 0,
    refetchInterval: 5000,
  });

  const { data: nodesData, isLoading: nodesLoading } = useQuery<{ nodes: GridNode[]; count: number }>({
    queryKey: ["/api/grid/nodes"],
    queryFn: async () => {
      const res = await fetch(`${API_BASE}/api/grid/nodes`, { headers: getAuthHeaders() });
      if (!res.ok) throw new Error("NODES FETCH FAILED");
      return res.json();
    },
    staleTime: 0,
    refetchInterval: 5000,
  });

  const { data: jobsData } = useQuery<{ jobs: GridJob[]; total: number }>({
    queryKey: ["/api/grid/jobs"],
    queryFn: async () => {
      const res = await fetch(`${API_BASE}/api/grid/jobs?limit=25`, { headers: getAuthHeaders() });
      if (!res.ok) throw new Error("JOBS FETCH FAILED");
      return res.json();
    },
    staleTime: 0,
    refetchInterval: 10000,
  });

  const nodes = nodesData?.nodes || [];
  const onlineNodes = nodes.filter((n) => n.status === "online");
  const jobs = jobsData?.jobs || [];
  const health = status?.health;

  const nodesOnline = health?.nodes_online ?? onlineNodes.length;
  const nodesTotal = health?.nodes_total ?? nodes.length;
  const jobsRunning = health?.jobs_running ?? jobs.filter((j) => j.status === "running").length;
  const jobsCompleted = nodes.reduce((sum, n) => sum + (n.jobs_completed || 0), 0);

  // Aggregate available compute capacity (100 - avg cpu across online nodes)
  const avgCpu =
    onlineNodes.length > 0
      ? onlineNodes.reduce((s, n) => s + (n.last_metrics?.cpu_pct ?? 0), 0) / onlineNodes.length
      : 0;
  const gridCapacity = onlineNodes.length > 0 ? Math.round(100 - avgCpu) : 0;

  const copyCommand = () => {
    try {
      const ta = document.createElement("textarea");
      ta.value = installCommand;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand("copy");
      document.body.removeChild(ta);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch { /* clipboard blocked */ }
  };

  const jobStatusStyle = (s: string) => {
    if (s === "running") return "text-trident-cyan animate-pulse";
    if (s === "completed") return "text-[#00ff41]";
    if (s === "failed") return "text-trident-red";
    return "text-trident-amber";
  };

  const fmtTime = (iso: string | null) => {
    if (!iso) return "—";
    try {
      return new Date(iso + (iso.endsWith("Z") ? "" : "Z")).toLocaleTimeString("en-US", { hour12: false });
    } catch {
      return "—";
    }
  };

  const fmtDuration = (j: GridJob) => {
    if (!j.started_at) return "—";
    const end = j.completed_at || new Date().toISOString();
    try {
      const ms =
        new Date(end + (end.endsWith("Z") ? "" : "Z")).getTime() -
        new Date(j.started_at + (j.started_at.endsWith("Z") ? "" : "Z")).getTime();
      if (ms < 0) return "—";
      return `${(ms / 1000).toFixed(1)}s`;
    } catch {
      return "—";
    }
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6" data-testid="page-grid">
      {/* ═══════════ HEADER ═══════════ */}
      <div className="flex items-center justify-between border-b border-trident-border pb-4">
        <div>
          <div className="flex items-center gap-3">
            <Network className="w-6 h-6 text-trident-cyan" style={{ filter: "drop-shadow(0 0 8px #00f0ff)" }} />
            <h1 className="font-display text-2xl tracking-[0.15em] text-trident-cyan text-glow-cyan">
              TRIDENT GRID
            </h1>
          </div>
          <p className="font-mono text-[10px] uppercase tracking-[0.3em] text-trident-text/50 mt-1 ml-9">
            DISTRIBUTED COMPUTE NETWORK
          </p>
        </div>
        <div className="flex items-center gap-2 font-mono text-[10px] uppercase tracking-widest">
          <span
            className={`inline-block w-2 h-2 rounded-full ${status?.online ? "animate-pulse" : ""}`}
            style={{ backgroundColor: status?.online ? "#00ff41" : "#ff2244", boxShadow: `0 0 8px ${status?.online ? "#00ff41" : "#ff2244"}` }}
          />
          <span style={{ color: status?.online ? "#00ff41" : "#ff2244" }} data-testid="text-coordinator-status">
            {status?.online ? "COORDINATOR ONLINE" : "COORDINATOR OFFLINE"}
          </span>
        </div>
      </div>

      {/* ═══════════ TOP STATS ═══════════ */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard label="NODES ONLINE" value={`${nodesOnline}/${nodesTotal}`} sub="REGISTERED WORKERS" color="#00f0ff" icon={Server} />
        <StatCard label="JOBS RUNNING" value={String(jobsRunning)} sub="ACTIVE DISPATCH" color="#00ff41" icon={Activity} />
        <StatCard label="JOBS COMPLETED" value={String(jobsCompleted)} sub="TOTAL PROCESSED" color="#ff6b00" icon={CheckCircle2} />
        <StatCard label="GRID CAPACITY" value={`${gridCapacity}%`} sub="AGGREGATE AVAILABLE" color="#00f0ff" icon={Gauge} />
      </div>

      {/* ═══════════ NODE GRID ═══════════ */}
      <div>
        <h2 className="font-display text-sm tracking-[0.2em] text-trident-cyan/80 mb-3 flex items-center gap-2">
          <Cpu className="w-4 h-4" /> WORKER NODES
        </h2>
        {nodesLoading ? (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {[0, 1].map((i) => (
              <div key={i} className="border border-trident-border p-4 h-48 animate-pulse" style={{ backgroundColor: "#0a1628" }} />
            ))}
          </div>
        ) : nodes.length === 0 ? (
          <div
            className="border border-trident-border border-dashed p-10 text-center"
            style={{ backgroundColor: "#0a1628" }}
            data-testid="empty-nodes"
          >
            <Server className="w-8 h-8 text-trident-text/30 mx-auto mb-3" />
            <p className="font-mono text-xs uppercase tracking-widest text-trident-text/50">
              NO WORKER NODES REGISTERED
            </p>
            <p className="font-mono text-[10px] uppercase tracking-widest text-trident-text/30 mt-2">
              DEPLOY A WORKER USING THE COMMAND BELOW
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {nodes.map((node) => (
              <NodeCard key={node.node_id} node={node} offline={node.status !== "online"} />
            ))}
          </div>
        )}
      </div>

      {/* ═══════════ DEPLOY WORKER PANEL ═══════════ */}
      <div className="border border-trident-cyan/30 p-5" style={{ backgroundColor: "#0a1628" }} data-testid="panel-deploy-worker">
        <h2 className="font-display text-sm tracking-[0.2em] text-trident-cyan mb-4 flex items-center gap-2">
          <PlusCircle className="w-4 h-4" /> ADD WORKER NODE
        </h2>
        <p className="font-mono text-[11px] uppercase tracking-widest text-trident-text/60 mb-2">
          RUN THIS COMMAND ON ANY UBUNTU SERVER:
        </p>
        <div className="flex items-stretch gap-2 mb-4">
          <code
            className="flex-1 font-mono text-xs text-trident-green bg-[#050a0e] border border-trident-border px-3 py-2.5 overflow-x-auto whitespace-nowrap"
            data-testid="text-install-command"
          >
            {installCommand}
          </code>
          <button
            onClick={copyCommand}
            className="flex items-center gap-2 px-3 py-2.5 font-mono text-[10px] uppercase tracking-widest border border-trident-cyan/40 text-trident-cyan hover:bg-trident-cyan/10 transition-all"
            data-testid="button-copy-command"
          >
            {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
            {copied ? "COPIED" : "COPY COMMAND"}
          </button>
        </div>
        <p className="font-mono text-[10px] uppercase tracking-widest text-trident-text/50 mb-2">THE INSTALLER WILL:</p>
        <ul className="space-y-1.5">
          {[
            "DETECT GPU, RAM, CPU AUTOMATICALLY",
            "INSTALL DEPENDENCIES",
            "REGISTER WITH TRIDENT AUTOMATICALLY",
            "START AS A BACKGROUND SERVICE",
          ].map((line) => (
            <li key={line} className="flex items-center gap-2 font-mono text-[10px] uppercase tracking-widest text-trident-text/60">
              <Check className="w-3 h-3 text-[#00ff41]" /> {line}
            </li>
          ))}
        </ul>
      </div>

      {/* ═══════════ JOB QUEUE ═══════════ */}
      <div>
        <h2 className="font-display text-sm tracking-[0.2em] text-trident-cyan/80 mb-3 flex items-center gap-2">
          <Zap className="w-4 h-4" /> JOB QUEUE
        </h2>
        <div className="border border-trident-border overflow-hidden" style={{ backgroundColor: "#0a1628" }}>
          <table className="w-full font-mono text-[11px]">
            <thead>
              <tr className="border-b border-trident-border text-trident-text/40 uppercase tracking-widest text-[10px]">
                <th className="text-left px-3 py-2">JOB ID</th>
                <th className="text-left px-3 py-2">TYPE</th>
                <th className="text-left px-3 py-2">STATUS</th>
                <th className="text-left px-3 py-2">NODE</th>
                <th className="text-left px-3 py-2">STARTED</th>
                <th className="text-left px-3 py-2">DURATION</th>
              </tr>
            </thead>
            <tbody>
              {jobs.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-3 py-8 text-center text-trident-text/40 uppercase tracking-widest text-[10px]" data-testid="empty-jobs">
                    NO JOBS DISPATCHED YET
                  </td>
                </tr>
              ) : (
                jobs.map((j) => (
                  <tr key={j.job_id} className="border-b border-trident-border/50 hover:bg-trident-cyan/5" data-testid={`row-job-${j.job_id}`}>
                    <td className="px-3 py-2 text-trident-cyan tabular-nums">{j.job_id}</td>
                    <td className="px-3 py-2 text-trident-text/70 uppercase">{j.type}</td>
                    <td className={`px-3 py-2 uppercase tracking-widest ${jobStatusStyle(j.status)}`}>{j.status}</td>
                    <td className="px-3 py-2 text-trident-text/60">{j.assigned_node || "—"}</td>
                    <td className="px-3 py-2 text-trident-text/50 tabular-nums">{fmtTime(j.started_at)}</td>
                    <td className="px-3 py-2 text-trident-amber tabular-nums">{fmtDuration(j)}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
