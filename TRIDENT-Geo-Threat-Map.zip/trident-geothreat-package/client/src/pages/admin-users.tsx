import { useState, useEffect, Fragment } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import {
  Users,
  Shield,
  ChevronDown,
  ChevronUp,
  Activity,
  Server,
  Cpu,
  HardDrive,
  RefreshCw,
  MessageSquare,
  Image,
  FileText,
  Terminal,
  Plus,
  Search,
  X,
  AlertTriangle,
} from "lucide-react";
import { useAuth, getAuthHeaders } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import type { SafeUser } from "@shared/schema";

const API_BASE = "__PORT_5000__".startsWith("__") ? "" : "__PORT_5000__";

// ═══════════════════════════════════════════════════
// HELPERS
// ═══════════════════════════════════════════════════
function formatBytes(bytes: number): string {
  if (!bytes) return "0 B";
  const gb = bytes / (1024 * 1024 * 1024);
  if (gb >= 1) return `${gb.toFixed(2)} GB`;
  const mb = bytes / (1024 * 1024);
  if (mb >= 1) return `${mb.toFixed(1)} MB`;
  const kb = bytes / 1024;
  return `${kb.toFixed(0)} KB`;
}

function formatUptime(seconds: number): string {
  const d = Math.floor(seconds / 86400);
  const h = Math.floor((seconds % 86400) / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const parts: string[] = [];
  if (d > 0) parts.push(`${d}d`);
  if (h > 0) parts.push(`${h}h`);
  parts.push(`${m}m`);
  return parts.join(" ");
}

// ═══════════════════════════════════════════════════
// TYPES
// ═══════════════════════════════════════════════════
interface SystemStats {
  users: { total: number; active: number; admins: number };
  conversations: { total: number; totalMessages: number };
  images: { total: number; totalSize: number };
  files: { total: number; totalSize: number };
  system: {
    uptime: number;
    nodeVersion: string;
    platform: string;
    memoryUsed: number;
    memoryTotal: number;
  };
}

interface UserStats {
  conversations: number;
  messages: number;
  images: number;
  files: number;
  storageBytes: number;
}

interface ServiceStatus {
  name: string;
  endpoint: string;
  status: "online" | "offline" | "checking";
  lastChecked: string;
}

// ═══════════════════════════════════════════════════
// PERSONNEL TAB (tab 1) — OPERATOR REGISTRY
// ═══════════════════════════════════════════════════

const CLEARANCE_OPTIONS: { value: string; label: string; blurb: string }[] = [
  { value: "commander", label: "COMMANDER", blurb: "FULL SYSTEM ACCESS" },
  { value: "operator", label: "OPERATOR", blurb: "ALL EXCEPT SETTINGS" },
  { value: "intel", label: "INTEL", blurb: "INTEL MODULES ONLY" },
  { value: "ops", label: "OPS", blurb: "CHAT + OPSCENTER ONLY" },
];

// Legacy roles remain selectable so existing accounts can be re-set
const LEGACY_OPTIONS: { value: string; label: string; blurb: string }[] = [
  { value: "admin", label: "ADMIN (LEGACY)", blurb: "TREATED AS COMMANDER" },
  { value: "power_user", label: "POWER USER (LEGACY)", blurb: "TREATED AS OPERATOR" },
  { value: "user", label: "USER (LEGACY)", blurb: "BASELINE ACCESS" },
];

const CLEARANCE_COLOR: Record<string, string> = {
  commander: "#ff6b00",
  admin: "#ff6b00",
  operator: "#00f0ff",
  power_user: "#00f0ff",
  intel: "#00ff41",
  ops: "#a0b4c0",
  user: "#00ff41",
};

function clearanceLabel(role: string): string {
  return role.replace(/_/g, " ").toUpperCase();
}

function ClearanceBadge({ role }: { role: string }) {
  const color = CLEARANCE_COLOR[role] || "#a0b4c0";
  return (
    <span
      className="inline-block px-2 py-0.5 text-[10px] font-mono uppercase tracking-widest border"
      style={{ color, borderColor: `${color}66`, backgroundColor: `${color}14` }}
      data-testid={`badge-clearance-${role}`}
    >
      {clearanceLabel(role)}
    </span>
  );
}

function relativeTime(iso: string | null): string {
  if (!iso) return "NEVER";
  const then = new Date(iso).getTime();
  if (isNaN(then)) return "NEVER";
  const diff = Date.now() - then;
  if (diff < 60_000) return "JUST NOW";
  const mins = Math.floor(diff / 60_000);
  if (mins < 60) return `${mins}M AGO`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `${hours}H AGO`;
  const days = Math.floor(hours / 24);
  if (days < 30) return `${days}D AGO`;
  return new Date(iso).toLocaleDateString("en-US", { month: "short", day: "2-digit", year: "2-digit" }).toUpperCase();
}

// ── Shared modal shell ───────────────────────────────
function ModalShell({
  title,
  onClose,
  children,
  testId,
}: {
  title: string;
  onClose: () => void;
  children: React.ReactNode;
  testId: string;
}) {
  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      style={{ backgroundColor: "rgba(5,10,14,0.85)" }}
      onClick={onClose}
      data-testid={testId}
    >
      <div
        className="w-full max-w-md border"
        style={{ backgroundColor: "#0a1628", borderColor: "#00f0ff40", boxShadow: "0 0 32px rgba(0,240,255,0.12)" }}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between px-4 py-3 border-b" style={{ borderColor: "#12324a" }}>
          <h3 className="font-display text-xs tracking-[0.15em] text-trident-cyan text-glow-cyan">{title}</h3>
          <button
            onClick={onClose}
            className="text-trident-text/40 hover:text-trident-cyan transition-colors"
            data-testid="button-close-modal"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
        <div className="p-4 space-y-4">{children}</div>
      </div>
    </div>
  );
}

function FieldLabel({ children }: { children: React.ReactNode }) {
  return (
    <label className="block text-[10px] font-mono uppercase tracking-widest text-trident-text/40 mb-1">
      {children}
    </label>
  );
}

const inputClass =
  "w-full px-3 py-2 font-mono text-xs bg-[#050a0e] border border-trident-border text-trident-cyan placeholder:text-trident-text/20 focus:outline-none focus:border-trident-cyan/60 transition-colors";

function ClearanceSelect({
  value,
  onChange,
  testId,
  includeLegacy = false,
}: {
  value: string;
  onChange: (v: string) => void;
  testId: string;
  includeLegacy?: boolean;
}) {
  const options = includeLegacy ? [...CLEARANCE_OPTIONS, ...LEGACY_OPTIONS] : CLEARANCE_OPTIONS;
  return (
    <div className="space-y-2">
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className={`${inputClass} appearance-none cursor-pointer`}
        data-testid={testId}
      >
        {options.map((o) => (
          <option key={o.value} value={o.value} className="bg-[#0a1628] text-trident-text">
            {o.label}
          </option>
        ))}
      </select>
      <div className="space-y-1">
        {CLEARANCE_OPTIONS.map((o) => (
          <div
            key={o.value}
            className="flex items-center gap-2 text-[10px] font-mono uppercase tracking-widest"
            style={{ color: value === o.value ? CLEARANCE_COLOR[o.value] : "#a0b4c060" }}
          >
            <span
              className="inline-block w-1.5 h-1.5 rounded-full"
              style={{ backgroundColor: value === o.value ? CLEARANCE_COLOR[o.value] : "#a0b4c040" }}
            />
            <span className="w-24">{o.label}</span>
            <span className="opacity-60">— {o.blurb}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

function PersonnelTab() {
  const { user: currentUser } = useAuth();
  const { toast } = useToast();
  const [search, setSearch] = useState("");
  const [showAdd, setShowAdd] = useState(false);
  const [editTarget, setEditTarget] = useState<SafeUser | null>(null);
  const [revokeTarget, setRevokeTarget] = useState<SafeUser | null>(null);
  const [expandedUser, setExpandedUser] = useState<number | null>(null);
  const [userStats, setUserStats] = useState<Record<number, UserStats>>({});
  const [loadingStats, setLoadingStats] = useState<number | null>(null);

  // Add-operator form state
  const [newUsername, setNewUsername] = useState("");
  const [newEmail, setNewEmail] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [newRole, setNewRole] = useState("operator");
  const [editRole, setEditRole] = useState("operator");

  const okToast = (title: string, description: string) =>
    toast({
      title: `>> ${title}`,
      description,
      className: "terminal-text border-trident-border bg-trident-surface",
    });

  const errToast = (description: string) =>
    toast({
      title: ">> ERROR",
      description,
      variant: "destructive",
      className: "border-[#ff2244] bg-trident-surface text-[#ff2244]",
    });

  // ── Query: personnel roster ────────────────────────
  const { data, isLoading, isError } = useQuery<{ users: SafeUser[] }>({
    queryKey: ["/api/admin/users"],
    queryFn: async () => {
      const r = await fetch(`${API_BASE}/api/admin/users`, { headers: getAuthHeaders() });
      if (!r.ok) throw new Error("FAILED TO LOAD PERSONNEL DATABASE");
      return r.json();
    },
    staleTime: 0,
    refetchInterval: 30000,
  });

  const users = data?.users ?? [];

  const refresh = () => queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });

  // ── Mutations ──────────────────────────────────────
  const createMutation = useMutation({
    mutationFn: async (payload: { username: string; email: string; password: string; role: string }) => {
      const r = await fetch(`${API_BASE}/api/admin/users`, {
        method: "POST",
        headers: { "Content-Type": "application/json", ...getAuthHeaders() },
        body: JSON.stringify(payload),
      });
      const body = await r.json().catch(() => ({}));
      if (!r.ok) throw new Error(body.error || "OPERATOR CREATION FAILED");
      return body;
    },
    onSuccess: () => {
      setShowAdd(false);
      setNewUsername("");
      setNewEmail("");
      setNewPassword("");
      setNewRole("operator");
      refresh();
      okToast("OPERATOR COMMISSIONED", "PERSONNEL RECORD CREATED");
    },
    onError: (e: any) => errToast(String(e.message || "OPERATOR CREATION FAILED").toUpperCase()),
  });

  const roleMutation = useMutation({
    mutationFn: async ({ id, role }: { id: number; role: string }) => {
      const r = await fetch(`${API_BASE}/api/admin/users/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json", ...getAuthHeaders() },
        body: JSON.stringify({ role }),
      });
      const body = await r.json().catch(() => ({}));
      if (!r.ok) throw new Error(body.error || "CLEARANCE UPDATE FAILED");
      return body;
    },
    onSuccess: () => {
      setEditTarget(null);
      refresh();
      okToast("CLEARANCE UPDATED", "ACCESS LEVEL MODIFIED");
    },
    onError: (e: any) => errToast(String(e.message || "CLEARANCE UPDATE FAILED").toUpperCase()),
  });

  const statusMutation = useMutation({
    mutationFn: async ({ id, is_active }: { id: number; is_active: boolean }) => {
      const r = await fetch(`${API_BASE}/api/admin/users/${id}/status`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json", ...getAuthHeaders() },
        body: JSON.stringify({ is_active }),
      });
      const body = await r.json().catch(() => ({}));
      if (!r.ok) throw new Error(body.error || "STATUS UPDATE FAILED");
      return body;
    },
    onSuccess: (_d, vars) => {
      setRevokeTarget(null);
      refresh();
      okToast(vars.is_active ? "ACCESS RESTORED" : "ACCESS REVOKED", "OPERATOR STATUS UPDATED");
    },
    onError: (e: any) => errToast(String(e.message || "STATUS UPDATE FAILED").toUpperCase()),
  });

  // ── Per-user usage drilldown ───────────────────────
  const fetchUserStats = async (userId: number) => {
    if (userStats[userId]) return;
    setLoadingStats(userId);
    try {
      const res = await fetch(`${API_BASE}/api/admin/user-stats/${String(userId)}`, {
        headers: getAuthHeaders(),
      });
      if (!res.ok) throw new Error("FAILED");
      const stats = await res.json();
      setUserStats((prev) => ({ ...prev, [userId]: stats }));
    } catch {
      /* silent */
    } finally {
      setLoadingStats(null);
    }
  };

  const toggleExpand = (userId: number) => {
    if (expandedUser === userId) {
      setExpandedUser(null);
    } else {
      setExpandedUser(userId);
      fetchUserStats(userId);
    }
  };

  // ── Derived stats ──────────────────────────────────
  const total = users.length;
  const commanders = users.filter((u) => u.role === "commander" || u.role === "admin").length;
  const operators = users.filter((u) => u.role === "operator" || u.role === "power_user").length;
  const intelOps = users.filter((u) => u.role === "intel" || u.role === "ops").length;

  const term = search.trim().toLowerCase();
  const filtered = term
    ? users.filter(
        (u) =>
          u.username.toLowerCase().includes(term) ||
          u.email.toLowerCase().includes(term) ||
          u.role.toLowerCase().includes(term)
      )
    : users;

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="flex items-center gap-2">
          {[0, 1, 2].map((i) => (
            <span
              key={i}
              className="inline-block w-2 h-2 rounded-full bg-trident-cyan pulse-dot"
              style={{ animationDelay: `${i * 0.3}s` }}
            />
          ))}
          <span className="text-xs font-mono uppercase tracking-widest text-trident-text/40 ml-2">
            LOADING PERSONNEL RECORDS...
          </span>
        </div>
      </div>
    );
  }

  if (isError) {
    return (
      <div className="flex items-center justify-center h-64 font-mono text-xs uppercase tracking-widest text-[#ff2244]">
        FAILED TO LOAD PERSONNEL DATABASE
      </div>
    );
  }

  return (
    <div className="space-y-4 p-4">
      {/* ── STATS ROW ── */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <PersonnelStat label="TOTAL OPERATORS" value={total} color="#00f0ff" icon={<Users className="w-3.5 h-3.5" />} />
        <PersonnelStat label="COMMANDERS" value={commanders} color="#ff6b00" icon={<Shield className="w-3.5 h-3.5" />} />
        <PersonnelStat label="OPERATORS" value={operators} color="#00f0ff" icon={<Terminal className="w-3.5 h-3.5" />} />
        <PersonnelStat label="INTEL / OPS" value={intelOps} color="#00ff41" icon={<Activity className="w-3.5 h-3.5" />} />
      </div>

      {/* ── SEARCH + ADD ── */}
      <div className="flex flex-wrap items-center gap-3">
        <div className="relative flex-1 min-w-[220px]">
          <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-trident-text/30" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="SEARCH CALLSIGN / EMAIL / CLEARANCE"
            className={`${inputClass} pl-9 uppercase`}
            data-testid="input-search-personnel"
          />
        </div>
        <button
          onClick={() => setShowAdd(true)}
          className="flex items-center gap-1.5 px-4 py-2 text-[10px] font-mono uppercase tracking-widest border transition-colors"
          style={{ color: "#00ff41", borderColor: "#00ff4166", backgroundColor: "#00ff4114" }}
          data-testid="button-add-operator"
        >
          <Plus className="w-3.5 h-3.5" />
          ADD OPERATOR
        </button>
      </div>

      {/* ── TABLE ── */}
      <div className="overflow-x-auto border border-trident-border/40">
        <table className="w-full" data-testid="table-users">
          <thead>
            <tr className="border-b border-trident-border" style={{ backgroundColor: "#050a0e" }}>
              {["CALLSIGN", "EMAIL", "CLEARANCE", "STATUS", "LAST ACTIVE", "ACTIONS"].map((header) => (
                <th
                  key={header}
                  className="px-3 py-3 text-left text-[10px] font-mono uppercase tracking-widest text-trident-cyan/70"
                >
                  {header}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {filtered.map((u) => (
              <Fragment key={u.id}>
                <tr
                  className="border-b border-trident-border/30 hover:bg-trident-cyan/5 transition-colors cursor-pointer"
                  onClick={() => toggleExpand(u.id)}
                  data-testid={`row-user-${u.id}`}
                >
                  <td className="px-3 py-3 font-mono text-xs uppercase text-trident-cyan">
                    <span className="flex items-center gap-1.5">
                      {expandedUser === u.id ? (
                        <ChevronUp className="w-3 h-3 text-trident-text/30" />
                      ) : (
                        <ChevronDown className="w-3 h-3 text-trident-text/30" />
                      )}
                      {u.username}
                      {u.id === currentUser?.id && <span className="text-[9px] text-trident-amber">[YOU]</span>}
                    </span>
                  </td>
                  <td
                    className="px-3 py-3 font-mono text-xs text-trident-text/60"
                    style={{ textTransform: "none" }}
                    data-testid={`text-email-${u.id}`}
                  >
                    {u.email}
                  </td>
                  <td className="px-3 py-3">
                    <ClearanceBadge role={u.role} />
                  </td>
                  <td className="px-3 py-3">
                    <span
                      className="flex items-center gap-1.5 text-[10px] font-mono uppercase tracking-widest"
                      style={{ color: u.is_active ? "#00ff41" : "#ff2244" }}
                      data-testid={`status-user-${u.id}`}
                    >
                      <span
                        className="inline-block w-1.5 h-1.5 rounded-full"
                        style={{
                          backgroundColor: u.is_active ? "#00ff41" : "#ff2244",
                          boxShadow: `0 0 6px ${u.is_active ? "#00ff41" : "#ff2244"}`,
                        }}
                      />
                      {u.is_active ? "ACTIVE" : "REVOKED"}
                    </span>
                  </td>
                  <td className="px-3 py-3 font-mono text-[10px] text-trident-text/40">
                    {relativeTime(u.last_login)}
                  </td>
                  <td className="px-3 py-3" onClick={(e) => e.stopPropagation()}>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => {
                          setEditTarget(u);
                          setEditRole(u.role);
                        }}
                        className="px-2 py-0.5 text-[10px] font-mono uppercase tracking-widest border border-trident-cyan/40 text-trident-cyan/80 hover:text-trident-cyan hover:bg-trident-cyan/10 transition-colors"
                        data-testid={`button-edit-${u.id}`}
                      >
                        EDIT
                      </button>
                      {u.id === currentUser?.id ? (
                        <span className="px-2 py-0.5 text-[10px] font-mono text-trident-text/20 border border-transparent">
                          —
                        </span>
                      ) : u.is_active ? (
                        <button
                          onClick={() => setRevokeTarget(u)}
                          className="px-2 py-0.5 text-[10px] font-mono uppercase tracking-widest border border-[#ff2244]/40 text-[#ff2244]/80 hover:text-[#ff2244] hover:bg-[#ff2244]/10 transition-colors"
                          data-testid={`button-revoke-${u.id}`}
                        >
                          REVOKE
                        </button>
                      ) : (
                        <button
                          onClick={() => statusMutation.mutate({ id: u.id, is_active: true })}
                          className="px-2 py-0.5 text-[10px] font-mono uppercase tracking-widest border border-[#00ff41]/40 text-[#00ff41]/80 hover:text-[#00ff41] hover:bg-[#00ff41]/10 transition-colors"
                          data-testid={`button-restore-${u.id}`}
                        >
                          RESTORE
                        </button>
                      )}
                    </div>
                  </td>
                </tr>

                {/* Expanded usage row */}
                {expandedUser === u.id && (
                  <tr className="border-b border-trident-border/20">
                    <td colSpan={6} className="px-6 py-3" style={{ backgroundColor: "#050a0e" }}>
                      {loadingStats === u.id ? (
                        <span className="text-[10px] font-mono text-trident-text/30">LOADING USAGE DATA...</span>
                      ) : userStats[u.id] ? (
                        <div className="flex flex-wrap items-center gap-6 text-[10px] font-mono uppercase tracking-widest">
                          <span className="text-trident-text/40">
                            <MessageSquare className="w-3 h-3 inline mr-1 text-trident-cyan/50" />
                            {userStats[u.id].conversations} CONVERSATIONS
                          </span>
                          <span className="text-trident-text/40">{userStats[u.id].messages} MESSAGES</span>
                          <span className="text-trident-text/40">
                            <Image className="w-3 h-3 inline mr-1 text-trident-cyan/50" />
                            {userStats[u.id].images} IMAGES
                          </span>
                          <span className="text-trident-text/40">
                            <FileText className="w-3 h-3 inline mr-1 text-trident-cyan/50" />
                            {userStats[u.id].files} FILES
                          </span>
                          <span className="text-trident-text/40">
                            <HardDrive className="w-3 h-3 inline mr-1 text-trident-cyan/50" />
                            {formatBytes(userStats[u.id].storageBytes)} STORAGE
                          </span>
                        </div>
                      ) : (
                        <span className="text-[10px] font-mono text-trident-text/30">NO DATA</span>
                      )}
                    </td>
                  </tr>
                )}
              </Fragment>
            ))}
          </tbody>
        </table>

        {filtered.length === 0 && (
          <div className="text-center py-12 font-mono text-xs text-trident-text/30 uppercase tracking-widest">
            {term ? "NO MATCHING PERSONNEL" : "NO PERSONNEL RECORDS FOUND"}
          </div>
        )}
      </div>

      {/* ── ADD OPERATOR MODAL ── */}
      {showAdd && (
        <ModalShell title="ADD OPERATOR" onClose={() => setShowAdd(false)} testId="modal-add-operator">
          <div>
            <FieldLabel>USERNAME</FieldLabel>
            <input
              value={newUsername}
              onChange={(e) => setNewUsername(e.target.value)}
              className={inputClass}
              placeholder="CALLSIGN"
              data-testid="input-new-username"
            />
          </div>
          <div>
            <FieldLabel>EMAIL</FieldLabel>
            <input
              value={newEmail}
              onChange={(e) => setNewEmail(e.target.value)}
              className={inputClass}
              placeholder="operator@trident.local"
              style={{ textTransform: "none" }}
              data-testid="input-new-email"
            />
          </div>
          <div>
            <FieldLabel>PASSWORD</FieldLabel>
            <input
              type="password"
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
              className={inputClass}
              placeholder="MIN 8 CHARACTERS"
              data-testid="input-new-password"
            />
          </div>
          <div>
            <FieldLabel>CLEARANCE</FieldLabel>
            <ClearanceSelect value={newRole} onChange={setNewRole} testId="select-new-role" />
          </div>
          <div className="flex justify-end gap-2 pt-2 border-t" style={{ borderColor: "#12324a" }}>
            <button
              onClick={() => setShowAdd(false)}
              className="px-3 py-1.5 text-[10px] font-mono uppercase tracking-widest border border-trident-border text-trident-text/50 hover:text-trident-text transition-colors"
              data-testid="button-cancel-add"
            >
              CANCEL
            </button>
            <button
              disabled={createMutation.isPending || !newUsername || !newEmail || newPassword.length < 8}
              onClick={() =>
                createMutation.mutate({
                  username: newUsername.trim(),
                  email: newEmail.trim(),
                  password: newPassword,
                  role: newRole,
                })
              }
              className="px-3 py-1.5 text-[10px] font-mono uppercase tracking-widest border transition-colors disabled:opacity-40"
              style={{ color: "#00ff41", borderColor: "#00ff4166", backgroundColor: "#00ff4114" }}
              data-testid="button-create-operator"
            >
              {createMutation.isPending ? "CREATING..." : "CREATE OPERATOR"}
            </button>
          </div>
        </ModalShell>
      )}

      {/* ── EDIT CLEARANCE MODAL ── */}
      {editTarget && (
        <ModalShell
          title={`EDIT CLEARANCE: ${editTarget.username.toUpperCase()}`}
          onClose={() => setEditTarget(null)}
          testId="modal-edit-clearance"
        >
          <div className="flex items-center gap-2 text-[10px] font-mono uppercase tracking-widest text-trident-text/40">
            CURRENT:
            <ClearanceBadge role={editTarget.role} />
          </div>
          <div>
            <FieldLabel>NEW CLEARANCE</FieldLabel>
            <ClearanceSelect value={editRole} onChange={setEditRole} testId="select-edit-role" includeLegacy />
          </div>
          <div className="flex justify-end gap-2 pt-2 border-t" style={{ borderColor: "#12324a" }}>
            <button
              onClick={() => setEditTarget(null)}
              className="px-3 py-1.5 text-[10px] font-mono uppercase tracking-widest border border-trident-border text-trident-text/50 hover:text-trident-text transition-colors"
              data-testid="button-cancel-edit"
            >
              CANCEL
            </button>
            <button
              disabled={roleMutation.isPending || editRole === editTarget.role}
              onClick={() => roleMutation.mutate({ id: editTarget.id, role: editRole })}
              className="px-3 py-1.5 text-[10px] font-mono uppercase tracking-widest border transition-colors disabled:opacity-40"
              style={{ color: "#00f0ff", borderColor: "#00f0ff66", backgroundColor: "#00f0ff14" }}
              data-testid="button-update-clearance"
            >
              {roleMutation.isPending ? "UPDATING..." : "UPDATE CLEARANCE"}
            </button>
          </div>
        </ModalShell>
      )}

      {/* ── REVOKE ACCESS CONFIRM ── */}
      {revokeTarget && (
        <ModalShell title="REVOKE ACCESS" onClose={() => setRevokeTarget(null)} testId="modal-revoke-access">
          <div
            className="flex items-start gap-2 px-3 py-3 border font-mono text-[11px] uppercase tracking-widest"
            style={{ color: "#ff2244", borderColor: "#ff224466", backgroundColor: "#ff224414" }}
          >
            <AlertTriangle className="w-4 h-4 flex-shrink-0" />
            <div className="space-y-1">
              <div>REVOKE ACCESS FOR {revokeTarget.username.toUpperCase()}?</div>
              <div className="opacity-70">THIS WILL DEACTIVATE THEIR ACCOUNT.</div>
              <div className="opacity-50">RECORD IS RETAINED — ACCESS CAN BE RESTORED.</div>
            </div>
          </div>
          <div className="flex justify-end gap-2 pt-2 border-t" style={{ borderColor: "#12324a" }}>
            <button
              onClick={() => setRevokeTarget(null)}
              className="px-3 py-1.5 text-[10px] font-mono uppercase tracking-widest border border-trident-border text-trident-text/50 hover:text-trident-text transition-colors"
              data-testid="button-cancel-revoke"
            >
              CANCEL
            </button>
            <button
              disabled={statusMutation.isPending}
              onClick={() => statusMutation.mutate({ id: revokeTarget.id, is_active: false })}
              className="px-3 py-1.5 text-[10px] font-mono uppercase tracking-widest border transition-colors disabled:opacity-40"
              style={{ color: "#ff2244", borderColor: "#ff224466", backgroundColor: "#ff224414" }}
              data-testid="button-confirm-revoke"
            >
              {statusMutation.isPending ? "REVOKING..." : "REVOKE ACCESS"}
            </button>
          </div>
        </ModalShell>
      )}
    </div>
  );
}

function PersonnelStat({
  label,
  value,
  color,
  icon,
}: {
  label: string;
  value: number;
  color: string;
  icon: React.ReactNode;
}) {
  return (
    <div
      className="px-3 py-3 border"
      style={{ backgroundColor: "#050a0e", borderColor: `${color}33` }}
      data-testid={`stat-${label.toLowerCase().replace(/[^a-z]+/g, "-")}`}
    >
      <div className="flex items-center gap-1.5 mb-1.5">
        <span style={{ color: `${color}99` }}>{icon}</span>
        <span className="text-[9px] font-mono uppercase tracking-widest text-trident-text/40">{label}</span>
      </div>
      <span className="font-mono text-xl tabular-nums" style={{ color, textShadow: `0 0 10px ${color}55` }}>
        {value}
      </span>
    </div>
  );
}

// ═══════════════════════════════════════════════════
// SYSTEM STATUS TAB (tab 2)
// ═══════════════════════════════════════════════════
function SystemStatusTab() {
  const [stats, setStats] = useState<SystemStats | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [services, setServices] = useState<ServiceStatus[]>([
    { name: "TRIDENT APP", endpoint: "", status: "online", lastChecked: new Date().toISOString() },
    { name: "OLLAMA", endpoint: "/api/ollama/status", status: "checking", lastChecked: "" },
    { name: "VOICE SERVICE", endpoint: "/api/voice/status", status: "checking", lastChecked: "" },
    { name: "IMAGE GEN", endpoint: "/api/imagegen/status", status: "checking", lastChecked: "" },
  ]);

  const fetchStats = async () => {
    try {
      const res = await fetch(`${API_BASE}/api/admin/stats`, {
        headers: getAuthHeaders(),
      });
      if (!res.ok) throw new Error("FAILED");
      const data = await res.json();
      setStats(data);
    } catch {
      // silent
    } finally {
      setIsLoading(false);
    }
  };

  const checkService = async (service: ServiceStatus, index: number) => {
    if (!service.endpoint) return; // Trident is always online
    try {
      const res = await fetch(`${API_BASE}${service.endpoint}`, {
        headers: getAuthHeaders(),
      });
      const now = new Date().toISOString();
      let isOnline = false;
      if (res.ok) {
        try {
          const data = await res.json();
          isOnline = data.online === true;
        } catch {
          isOnline = true; // if no JSON, assume online if 200
        }
      }
      setServices((prev) => {
        const updated = [...prev];
        updated[index] = { ...service, status: isOnline ? "online" : "offline", lastChecked: now };
        return updated;
      });
    } catch {
      setServices((prev) => {
        const updated = [...prev];
        updated[index] = { ...service, status: "offline", lastChecked: new Date().toISOString() };
        return updated;
      });
    }
  };

  const checkAllServices = () => {
    services.forEach((s, i) => checkService(s, i));
  };

  useEffect(() => {
    fetchStats();
    checkAllServices();
    const interval = setInterval(checkAllServices, 10000);
    return () => clearInterval(interval);
  }, []);

  const handleRefresh = () => {
    setIsLoading(true);
    fetchStats();
    checkAllServices();
  };

  if (isLoading || !stats) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="flex items-center gap-2">
          {[0, 1, 2].map((i) => (
            <span
              key={i}
              className="inline-block w-2 h-2 rounded-full bg-trident-cyan pulse-dot"
              style={{ animationDelay: `${i * 0.3}s` }}
            />
          ))}
          <span className="text-xs font-mono uppercase tracking-widest text-trident-text/40 ml-2">
            LOADING SYSTEM STATUS...
          </span>
        </div>
      </div>
    );
  }

  const memPercent = stats.system.memoryTotal > 0
    ? Math.round((stats.system.memoryUsed / stats.system.memoryTotal) * 100)
    : 0;

  return (
    <div className="space-y-4">
      {/* Quick actions */}
      <div className="flex justify-end">
        <button
          onClick={handleRefresh}
          className="flex items-center gap-1.5 px-3 py-1.5 text-[10px] font-mono uppercase tracking-widest border border-trident-border text-trident-text/50 hover:text-trident-cyan hover:border-trident-cyan/30 transition-colors"
          data-testid="button-refresh-stats"
        >
          <RefreshCw className="w-3 h-3" />
          REFRESH ALL
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Platform metrics */}
        <div className="trident-panel p-4 space-y-4">
          <h3 className="font-display text-xs tracking-[0.12em] text-trident-amber border-b border-trident-border pb-2 flex items-center gap-2">
            <Activity className="w-3.5 h-3.5" />
            PLATFORM METRICS
          </h3>

          <div className="grid grid-cols-2 gap-3">
            <StatBlock label="TOTAL USERS" value={stats.users.total} icon={<Users className="w-3 h-3" />} />
            <StatBlock label="ACTIVE USERS" value={stats.users.active} icon={<Shield className="w-3 h-3" />} accent="green" />
            <StatBlock label="ADMINS" value={stats.users.admins} icon={<Shield className="w-3 h-3" />} accent="amber" />
            <StatBlock label="CONVERSATIONS" value={stats.conversations.total} icon={<MessageSquare className="w-3 h-3" />} />
            <StatBlock label="TOTAL MESSAGES" value={stats.conversations.totalMessages} icon={<MessageSquare className="w-3 h-3" />} />
            <StatBlock label="IMAGES GENERATED" value={stats.images.total} icon={<Image className="w-3 h-3" />} />
            <StatBlock label="FILES UPLOADED" value={stats.files.total} icon={<FileText className="w-3 h-3" />} />
            <StatBlock label="FILE STORAGE" value={formatBytes(stats.files.totalSize)} icon={<HardDrive className="w-3 h-3" />} />
          </div>
        </div>

        {/* System info */}
        <div className="trident-panel p-4 space-y-4">
          <h3 className="font-display text-xs tracking-[0.12em] text-trident-amber border-b border-trident-border pb-2 flex items-center gap-2">
            <Server className="w-3.5 h-3.5" />
            SYSTEM INFO
          </h3>

          <div className="space-y-3">
            <div className="flex justify-between text-[10px] font-mono uppercase tracking-widest">
              <span className="text-trident-text/40">UPTIME</span>
              <span className="text-trident-cyan">{formatUptime(stats.system.uptime)}</span>
            </div>
            <div className="flex justify-between text-[10px] font-mono uppercase tracking-widest">
              <span className="text-trident-text/40">NODE VERSION</span>
              <span className="text-trident-cyan">{stats.system.nodeVersion}</span>
            </div>
            <div className="flex justify-between text-[10px] font-mono uppercase tracking-widest">
              <span className="text-trident-text/40">PLATFORM</span>
              <span className="text-trident-cyan">{stats.system.platform}</span>
            </div>

            {/* Memory bar */}
            <div className="space-y-1">
              <div className="flex justify-between text-[10px] font-mono uppercase tracking-widest">
                <span className="text-trident-text/40">MEMORY</span>
                <span className="text-trident-cyan">
                  {formatBytes(stats.system.memoryUsed)} / {formatBytes(stats.system.memoryTotal)} ({memPercent}%)
                </span>
              </div>
              <div className="h-2 bg-[#050a0e] border border-trident-border overflow-hidden">
                <div
                  className="h-full transition-all duration-500"
                  style={{
                    width: `${memPercent}%`,
                    backgroundColor: memPercent > 80 ? "#ff2244" : memPercent > 60 ? "#ff6b00" : "#00f0ff",
                    boxShadow: `0 0 6px ${memPercent > 80 ? "#ff2244" : memPercent > 60 ? "#ff6b00" : "#00f0ff"}40`,
                  }}
                />
              </div>
            </div>
          </div>
        </div>

        {/* Service status */}
        <div className="trident-panel p-4 space-y-4">
          <h3 className="font-display text-xs tracking-[0.12em] text-trident-amber border-b border-trident-border pb-2 flex items-center gap-2">
            <Cpu className="w-3.5 h-3.5" />
            SERVICE STATUS
          </h3>

          <div className="space-y-2">
            {services.map((s) => (
              <div
                key={s.name}
                className="flex items-center justify-between px-3 py-2 border border-trident-border/30"
                style={{ backgroundColor: "#050a0e" }}
                data-testid={`service-${s.name.toLowerCase().replace(/\s/g, "-")}`}
              >
                <div className="flex items-center gap-2">
                  <span
                    className={`inline-block w-2 h-2 rounded-full ${
                      s.status === "online"
                        ? "bg-[#00ff41] shadow-[0_0_4px_#00ff41]"
                        : s.status === "offline"
                        ? "bg-[#ff2244] shadow-[0_0_4px_#ff2244]"
                        : "bg-trident-amber animate-pulse"
                    }`}
                  />
                  <span className="text-[10px] font-mono uppercase tracking-widest text-trident-text/70">
                    {s.name}
                  </span>
                </div>
                <div className="flex items-center gap-3">
                  <span
                    className={`text-[10px] font-mono uppercase tracking-widest font-bold ${
                      s.status === "online"
                        ? "text-[#00ff41] text-glow-green"
                        : s.status === "offline"
                        ? "text-[#ff2244]"
                        : "text-trident-amber"
                    }`}
                  >
                    {s.status === "checking" ? "CHECKING..." : s.status.toUpperCase()}
                  </span>
                  {s.lastChecked && (
                    <span className="text-[8px] font-mono text-trident-text/20">
                      {new Date(s.lastChecked).toLocaleTimeString("en-US", { hour12: false, hour: "2-digit", minute: "2-digit", second: "2-digit" })}
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Server logs hint */}
        <div className="trident-panel p-4 space-y-4">
          <h3 className="font-display text-xs tracking-[0.12em] text-trident-amber border-b border-trident-border pb-2 flex items-center gap-2">
            <Terminal className="w-3.5 h-3.5" />
            SERVER LOGS
          </h3>
          <div className="px-3 py-3 border border-trident-border/30 font-mono text-xs" style={{ backgroundColor: "#050a0e" }}>
            <p className="text-trident-text/40 text-[10px] uppercase tracking-widest mb-2">
              TO VIEW LIVE SERVER LOGS:
            </p>
            <code className="text-[#00ff41] text-[11px]" style={{ textTransform: "none" }}>
              ssh root@server && journalctl -u trident -f
            </code>
          </div>
        </div>
      </div>
    </div>
  );
}

function StatBlock({
  label,
  value,
  icon,
  accent = "cyan",
}: {
  label: string;
  value: number | string;
  icon: React.ReactNode;
  accent?: "cyan" | "green" | "amber";
}) {
  const colorMap = {
    cyan: "text-trident-cyan",
    green: "text-[#00ff41]",
    amber: "text-trident-amber",
  };
  return (
    <div className="px-3 py-2 border border-trident-border/30" style={{ backgroundColor: "#050a0e" }}>
      <div className="flex items-center gap-1.5 mb-1">
        <span className="text-trident-text/30">{icon}</span>
        <span className="text-[8px] font-mono uppercase tracking-widest text-trident-text/30">{label}</span>
      </div>
      <span className={`font-mono text-sm ${colorMap[accent]}`}>
        {typeof value === "number" ? value.toLocaleString() : value}
      </span>
    </div>
  );
}

// ═══════════════════════════════════════════════════
// MAIN ADMIN PAGE — TABBED
// ═══════════════════════════════════════════════════
export default function AdminUsersPage() {
  const [activeTab, setActiveTab] = useState<"personnel" | "system">("personnel");

  return (
    <div className="h-full flex flex-col">
      <div className="trident-panel p-4 mb-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="font-display text-sm tracking-[0.15em] text-trident-amber text-glow-amber flex items-center gap-2">
              <Shield className="w-4 h-4" />
              PERSONNEL MANAGEMENT
            </h1>
            <p className="mt-1 text-[10px] font-mono uppercase tracking-[0.2em] text-trident-text/40">
              TRIDENT OPERATOR REGISTRY
            </p>
          </div>

          {/* Tabs */}
          <div className="flex items-center border border-trident-border">
            <button
              onClick={() => setActiveTab("personnel")}
              className={`px-4 py-1.5 text-[10px] font-mono uppercase tracking-widest transition-colors flex items-center gap-1.5 border-r border-trident-border ${
                activeTab === "personnel"
                  ? "bg-trident-cyan/10 text-trident-cyan"
                  : "text-trident-text/40 hover:text-trident-cyan"
              }`}
              data-testid="tab-personnel"
            >
              <Users className="w-3 h-3" />
              OPERATOR REGISTRY
            </button>
            <button
              onClick={() => setActiveTab("system")}
              className={`px-4 py-1.5 text-[10px] font-mono uppercase tracking-widest transition-colors flex items-center gap-1.5 ${
                activeTab === "system"
                  ? "bg-trident-cyan/10 text-trident-cyan"
                  : "text-trident-text/40 hover:text-trident-cyan"
              }`}
              data-testid="tab-system"
            >
              <Activity className="w-3 h-3" />
              SYSTEM STATUS
            </button>
          </div>
        </div>
      </div>

      <div className="trident-panel flex-1 overflow-auto">
        {activeTab === "personnel" ? <PersonnelTab /> : <SystemStatusTab />}
      </div>
    </div>
  );
}
