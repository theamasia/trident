import { useEffect, useRef, RefObject } from "react";
import L from "leaflet";
import "leaflet/dist/leaflet.css";

// ═══════════════════════════════════════════════════
// useLeafletMap — shared dark-themed Leaflet map foundation
// Used by Phase 7 (Weather) and reused by Phase 8 (ALPR cameras).
//
// Initializes a CartoDB Dark Matter map centered on Denton, NC.
// Returns the Leaflet map instance via a ref so callers can add
// their own overlays (radar/satellite tile layers, markers, circles).
// ═══════════════════════════════════════════════════

export const DENTON_CENTER: [number, number] = [35.6262, -80.1131];
export const CARTO_DARK_URL =
  "https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png";
export const CARTO_ATTRIBUTION =
  '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> &copy; <a href="https://carto.com/attributions">CARTO</a>';

export interface UseLeafletMapOptions {
  center?: [number, number];
  zoom?: number;
  minZoom?: number;
  maxZoom?: number;
  zoomControl?: boolean;
  attributionControl?: boolean;
}

/**
 * Initialize a dark-themed Leaflet map inside `containerRef`.
 * The map instance is stored in the returned ref (`mapRef.current`).
 * Safe against React strict-mode double-invocation and SSR.
 */
export function useLeafletMap(
  containerRef: RefObject<HTMLElement | null>,
  options: UseLeafletMapOptions = {}
) {
  const mapRef = useRef<L.Map | null>(null);

  useEffect(() => {
    if (typeof window === "undefined") return; // SSR guard
    const el = containerRef.current;
    if (!el || mapRef.current) return;

    const map = L.map(el, {
      center: options.center ?? DENTON_CENTER,
      zoom: options.zoom ?? 9,
      minZoom: options.minZoom ?? 3,
      maxZoom: options.maxZoom ?? 18,
      zoomControl: options.zoomControl ?? true,
      attributionControl: options.attributionControl ?? true,
      preferCanvas: true,
    });

    // Base layer — CartoDB Dark Matter
    L.tileLayer(CARTO_DARK_URL, {
      attribution: CARTO_ATTRIBUTION,
      subdomains: "abcd",
      maxZoom: 20,
    }).addTo(map);

    mapRef.current = map;

    // Ensure correct sizing after mount (container may size after paint)
    const resize = () => map.invalidateSize();
    const t = setTimeout(resize, 100);
    window.addEventListener("resize", resize);

    return () => {
      clearTimeout(t);
      window.removeEventListener("resize", resize);
      map.remove();
      mapRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [containerRef]);

  return mapRef;
}
