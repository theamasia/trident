import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { TridentLogo } from "./TridentLogo";
import { useAuth, getAuthHeaders } from "@/hooks/use-auth";
import {
  MessageSquare,
  Box,
  Image,
  Mic,
  GalleryHorizontalEnd,
  Settings,
  LogOut,
  ChevronLeft,
  ChevronRight,
  Shield,
  Users,
  Wrench,
  TrendingUp,
  Network,
  Activity,
  KeyRound,
  X,
  Terminal,
} from "lucide-react";

interface NavItem {
  label: string;
  path: string;
  icon: React.ComponentType<{ className?: string }>;
  roles: string[];
  accent?: boolean;
}

const navItems: NavItem[] = [
  { label: "COMMAND", path: "/command", icon: Terminal, accent: true, roles: ["*"] },
  { label: "CHAT", path: "/dashboard/chat", icon: MessageSquare, roles: ["*"] },
  { label: "MODELS", path: "/dashboard/models", icon: Box, roles: ["commander", "admin", "operator", "power_user", "user"] },
  { label: "IMAGE GEN", path: "/dashboard/imagegen", icon: Image, roles: ["commander", "admin", "operator", "power_user", "user"] },
  { label: "VOICE", path: "/dashboard/voice", icon: Mic, roles: ["commander", "admin", "operator", "power_user", "user"] },
  { label: "GALLERY", path: "/dashboard/gallery", icon: GalleryHorizontalEnd, roles: ["commander", "admin", "operator", "power_user", "user"] },
  { label: "TOOLS", path: "/dashboard/tools", icon: Wrench, roles: ["commander", "admin", "operator", "power_user", "user"] },
  { label: "INTELLIGENCE", path: "/dashboard/intelligence", icon: TrendingUp, roles: ["*"] },
  { label: "INTEL BRIEFS", path: "/intel-briefs", icon: Shield, roles: ["commander", "admin", "operator", "intel", "power_user", "user"] },
  { label: "GRID", path: "/grid", icon: Network, roles: ["commander", "admin", "operator", "power_user"] },
  { label: "OPSCENTER", path: "/opscenter", icon: Activity, roles: ["commander", "admin", "operator", "ops", "power_user"] },
  { label: "SETTINGS", path: "/dashboard/settings", icon: Settings, roles: ["commander", "admin"] },
  { label: "PERSONNEL", path: "/admin/users", icon: Users, roles: ["commander", "admin"] },
];

function navVisible(item: NavItem, role?: string | null): boolean {
  const r = role || "user";
  if (item.roles.includes("*")) return true;
  return item.roles.includes(r);
}

export function DashboardLayout({ children }: { children: React.ReactNode }) {
  const [collapsed, setCollapsed] = useState(false);
  const [showPasswordModal, setShowPasswordModal] = useState(false);
  const [location] = useLocation();
  const { user, logout } = useAuth();
  const [, setLocation] = useLocation();
  const [clock, setClock] = useState("");

  // Live clock
  useEffect(() => {
    const tick = () => {
      const now = new Date();
      setClock(
        now.toLocaleTimeString("en-US", {
          hour12: false,
          hour: "2-digit",
          minute: "2-digit",
          second: "2-digit",
          timeZone: "America/New_York",
        })
      );
    };
    tick();
    const interval = setInterval(tick, 1000);
    return () => clearInterval(interval);
  }, []);

  const handleLogout = () => {
    logout();
    setLocation("/login");
  };

  const roleBadgeColor: Record<string, string> = {
    commander: "text-trident-amber border-trident-amber/40 bg-trident-amber/10",
    admin: "text-trident-amber border-trident-amber/40 bg-trident-amber/10",
    operator: "text-trident-cyan border-trident-cyan/40 bg-trident-cyan/10",
    power_user: "text-trident-cyan border-trident-cyan/40 bg-trident-cyan/10",
    intel: "text-[#00ff41] border-[#00ff41]/40 bg-[#00ff41]/10",
    ops: "text-[#a0b4c0] border-[#a0b4c0]/40 bg-[#a0b4c0]/10",
    user: "text-[#00ff41] border-[#00ff41]/40 bg-[#00ff41]/10",
  };

  return (
    <div className="h-screen flex overflow-hidden" style={{ backgroundColor: "#050a0e" }}>
      {/* ═══════════ SIDEBAR ═══════════ */}
      <aside
        className={`relative flex flex-col border-r border-trident-border scanlines transition-all duration-300 ${
          collapsed ? "w-16" : "w-60"
        }`}
        style={{ backgroundColor: "#0a1628" }}
        data-testid="sidebar"
      >
        {/* Logo area */}
        <div className="flex items-center justify-between px-3 py-4 border-b border-trident-border">
          {!collapsed && <TridentLogo size="sm" showText={true} />}
          {collapsed && <TridentLogo size="sm" showText={false} />}
          <button
            onClick={() => setCollapsed(!collapsed)}
            className="text-trident-cyan/50 hover:text-trident-cyan transition-colors p-1"
            data-testid="button-collapse-sidebar"
          >
            {collapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
          </button>
        </div>

        {/* Nav items */}
        <nav className="flex-1 py-3 space-y-1 px-2 relative z-10">
          {navItems
            .filter((item) => navVisible(item, user?.role))
            .map((item) => {
              const isActive = location === item.path || 
                (item.path !== "/dashboard" && location.startsWith(item.path));
              const Icon = item.icon;

              if (item.accent) {
                return (
                  <Link key={item.path} href={item.path}>
                    <div
                      className={`flex items-center gap-3 px-3 py-2.5 text-xs font-mono uppercase tracking-widest cursor-pointer transition-all group border mb-1 ${
                        isActive
                          ? "text-trident-amber border-trident-amber bg-trident-amber/15"
                          : "text-trident-amber/80 border-trident-amber/40 bg-trident-amber/5 hover:bg-trident-amber/10 hover:text-trident-amber"
                      }`}
                      style={{ textShadow: "0 0 8px #ffb00080", boxShadow: isActive ? "0 0 16px rgba(255,176,0,0.25)" : "0 0 8px rgba(255,176,0,0.1)" }}
                      data-testid={`nav-${item.label.toLowerCase().replace(/\s/g, "-")}`}
                    >
                      <Icon className="w-4 h-4 flex-shrink-0 text-trident-amber" />
                      {!collapsed && <span>{item.label}</span>}
                    </div>
                  </Link>
                );
              }

              return (
                <Link key={item.path} href={item.path}>
                  <div
                    className={`flex items-center gap-3 px-3 py-2.5 text-xs font-mono uppercase tracking-widest cursor-pointer transition-all group ${
                      isActive
                        ? "text-trident-cyan border-l-[3px] border-trident-amber bg-trident-cyan/8"
                        : "text-trident-text/60 hover:text-trident-cyan hover:bg-trident-cyan/5 border-l-2 border-transparent"
                    }`}
                    style={isActive ? { textShadow: "0 0 8px #00f0ff, 0 0 16px #00f0ff50" } : undefined}
                    data-testid={`nav-${item.label.toLowerCase().replace(/\s/g, "-")}`}
                  >
                    <Icon className={`w-4 h-4 flex-shrink-0 ${isActive ? "text-trident-cyan" : "text-trident-text/40 group-hover:text-trident-cyan"}`} />
                    {!collapsed && <span>{item.label}</span>}
                  </div>
                </Link>
              );
            })}
        </nav>

        {/* User info + Logout at bottom */}
        <div className="border-t border-trident-border p-3 relative z-10">
          {!collapsed && user && (
            <div className="mb-3">
              <div className="flex items-center gap-2">
                <Shield className="w-3 h-3 text-trident-cyan/60" />
                <span className="text-xs font-mono uppercase tracking-widest text-trident-text truncate">
                  {user.username}
                </span>
              </div>
              <span
                className={`inline-block mt-1 px-1.5 py-0.5 text-[9px] font-mono uppercase tracking-widest border ${
                  roleBadgeColor[user.role] || roleBadgeColor.user
                }`}
              >
                {user.role}
              </span>
            </div>
          )}
          <button
            onClick={() => setShowPasswordModal(true)}
            className="flex items-center gap-2 w-full px-2 py-2 text-xs font-mono uppercase tracking-widest text-trident-text/60 hover:text-trident-cyan hover:bg-trident-cyan/5 transition-all"
            data-testid="button-change-password"
          >
            <KeyRound className="w-4 h-4" />
            {!collapsed && "CHANGE PASSWORD"}
          </button>
          <button
            onClick={handleLogout}
            className="flex items-center gap-2 w-full px-2 py-2 text-xs font-mono uppercase tracking-widest text-trident-red/70 hover:text-trident-red hover:bg-trident-red/5 transition-all"
            data-testid="button-logout"
          >
            <LogOut className="w-4 h-4" />
            {!collapsed && "LOGOUT"}
          </button>
        </div>
      </aside>

      {showPasswordModal && (
        <ChangePasswordModal onClose={() => setShowPasswordModal(false)} />
      )}

      {/* ═══════════ MAIN CONTENT ═══════════ */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Top header bar */}
        <header
          className="flex items-center justify-between px-4 py-2.5 border-b border-trident-border scanlines relative"
          style={{ backgroundColor: "#0a1628" }}
          data-testid="header"
        >
          <div className="font-display text-xs tracking-[0.15em] text-trident-cyan text-glow-cyan relative z-10">
            TRIDENT SYSTEM
          </div>

          {/* Status strip */}
          <div className="flex items-center gap-3 font-mono text-[10px] uppercase tracking-widest relative z-10">
            <span className="text-[#00ff41] text-glow-green flex items-center gap-1.5">
              <span className="inline-block w-1.5 h-1.5 rounded-full bg-[#00ff41] animate-pulse" />
              SYSTEM ONLINE
            </span>
            <span className="text-trident-border">|</span>
            <span className="text-trident-text/70">
              USER: <span className="text-trident-cyan">{user?.username?.toUpperCase() || "UNKNOWN"}</span>
            </span>
            <span className="text-trident-border">|</span>
            <span className="text-trident-text/70">
              CLEARANCE: <span className="text-trident-amber">{user?.role?.toUpperCase() || "NONE"}</span>
            </span>
          </div>

          {/* Clock */}
          <div className="font-mono text-sm tracking-widest text-trident-cyan text-glow-cyan tabular-nums relative z-10" data-testid="text-clock">
            {clock}
          </div>
        </header>

        {/* Main content area */}
        <main className="flex-1 overflow-auto grid-bg p-4">
          {children}
        </main>

        {/* Attribution footer */}
        <footer className="border-t border-trident-border px-4 py-1.5 text-center" style={{ backgroundColor: "#0a1628" }}>
          <a
            href="https://www.perplexity.ai/computer"
            target="_blank"
            rel="noopener noreferrer"
            className="text-[9px] font-mono uppercase tracking-widest text-trident-border hover:text-trident-cyan/50 transition-colors"
          >
            Created with Perplexity Computer
          </a>
        </footer>
      </div>
    </div>
  );
}

function ChangePasswordModal({ onClose }: { onClose: () => void }) {
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [error, setError] = useState("");
  const [success, setSuccess] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    if (newPassword !== confirmPassword) {
      setError("NEW PASSWORDS DO NOT MATCH");
      return;
    }
    if (newPassword.length < 6) {
      setError("NEW PASSWORD MUST BE AT LEAST 6 CHARACTERS");
      return;
    }
    setSubmitting(true);
    try {
      const res = await fetch("/api/auth/settings", {
        method: "PATCH",
        headers: { ...getAuthHeaders(), "Content-Type": "application/json" },
        body: JSON.stringify({ current_password: currentPassword, new_password: newPassword }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "PASSWORD CHANGE FAILED");
        setSubmitting(false);
        return;
      }
      setSuccess(true);
      setTimeout(onClose, 1500);
    } catch {
      setError("SYSTEM ERROR — TRY AGAIN");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70" onClick={onClose}>
      <div
        className="trident-panel w-full max-w-sm p-5 space-y-4"
        onClick={(e) => e.stopPropagation()}
        data-testid="modal-change-password"
      >
        <div className="flex items-center justify-between">
          <h3 className="font-display text-sm tracking-widest text-trident-cyan">CHANGE PASSWORD</h3>
          <button onClick={onClose} className="text-trident-text/50 hover:text-trident-red">
            <X className="w-4 h-4" />
          </button>
        </div>

        {success ? (
          <div className="text-center py-4 text-trident-green font-mono text-xs uppercase tracking-widest">
            ✓ PASSWORD UPDATED SUCCESSFULLY
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-3">
            {error && (
              <div className="border border-trident-red/40 bg-trident-red/10 p-2 text-[10px] font-mono text-trident-red">
                {error}
              </div>
            )}
            <div className="space-y-1">
              <label className="block text-[9px] font-mono uppercase tracking-widest text-trident-cyan/70">
                CURRENT PASSWORD
              </label>
              <input
                type="password"
                value={currentPassword}
                onChange={(e) => setCurrentPassword(e.target.value)}
                className="trident-input w-full px-3 py-2 text-sm"
                required
                data-testid="input-modal-current-password"
              />
            </div>
            <div className="space-y-1">
              <label className="block text-[9px] font-mono uppercase tracking-widest text-trident-cyan/70">
                NEW PASSWORD
              </label>
              <input
                type="password"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                className="trident-input w-full px-3 py-2 text-sm"
                required
                data-testid="input-modal-new-password"
              />
            </div>
            <div className="space-y-1">
              <label className="block text-[9px] font-mono uppercase tracking-widest text-trident-cyan/70">
                CONFIRM NEW PASSWORD
              </label>
              <input
                type="password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                className="trident-input w-full px-3 py-2 text-sm"
                required
                data-testid="input-modal-confirm-password"
              />
            </div>
            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={onClose}
                className="flex-1 border border-trident-border px-3 py-2 text-[10px] font-mono uppercase tracking-widest text-trident-text/70 hover:text-trident-text"
              >
                CANCEL
              </button>
              <button
                type="submit"
                disabled={submitting}
                className="flex-1 border border-trident-cyan px-3 py-2 text-[10px] font-mono uppercase tracking-widest text-trident-cyan hover:bg-trident-cyan/10 disabled:opacity-50"
                data-testid="button-submit-password-change"
              >
                {submitting ? "UPDATING..." : "UPDATE PASSWORD"}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}
