import { Switch, Route, Router, Redirect, useLocation } from "wouter";
import { useHashLocation } from "wouter/use-hash-location";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useAuth } from "@/hooks/use-auth";
import { useEffect, useState } from "react";

// Pages
import LoginPage from "@/pages/login";
import RegisterPage from "@/pages/register";
import DashboardHome from "@/pages/dashboard-home";
import DashboardChat from "@/pages/dashboard-chat";
import DashboardModels from "@/pages/dashboard-models";
import DashboardSettings from "@/pages/dashboard-settings";
import DashboardStub from "@/pages/dashboard-stub";
import DashboardGallery from "@/pages/dashboard-gallery";
import DashboardVoice from "@/pages/dashboard-voice";
import DashboardImageGen from "@/pages/dashboard-imagegen";
import DashboardTools from "@/pages/dashboard-tools";
import DashboardIntelligence from "@/pages/dashboard-intelligence";
import IntelBriefs from "@/pages/intel-briefs";
import TridentGrid from "@/pages/trident-grid";
import OpsCenter from "@/pages/opscenter";
import TridentCommand from "@/pages/trident-command";
import AdminUsersPage from "@/pages/admin-users";
import NotFound from "@/pages/not-found";

// Layout
import { DashboardLayout } from "@/components/DashboardLayout";

// ═══════════════════════════════════════════════════
// ROLE ACCESS MAP — what each clearance can reach
// ═══════════════════════════════════════════════════
export const ROLE_ACCESS: Record<string, string[]> = {
  commander: ["*"], // all routes
  admin: ["*"], // all routes (legacy commander)
  operator: [
    "/command",
    "/dashboard",
    "/dashboard/chat",
    "/dashboard/models",
    "/dashboard/imagegen",
    "/dashboard/voice",
    "/dashboard/gallery",
    "/dashboard/tools",
    "/dashboard/intelligence",
    "/intelligence",
    "/intel-briefs",
    "/grid",
    "/opscenter",
  ],
  power_user: [
    "/command",
    "/dashboard",
    "/dashboard/chat",
    "/dashboard/models",
    "/dashboard/imagegen",
    "/dashboard/voice",
    "/dashboard/gallery",
    "/dashboard/tools",
    "/dashboard/intelligence",
    "/intelligence",
    "/intel-briefs",
    "/grid",
    "/opscenter",
  ],
  intel: [
    "/command",
    "/dashboard",
    "/dashboard/chat",
    "/dashboard/intelligence",
    "/intelligence",
    "/intel-briefs",
  ],
  ops: ["/command", "/dashboard", "/dashboard/chat", "/opscenter"],
  user: [
    "/command",
    "/dashboard",
    "/dashboard/chat",
    "/dashboard/models",
    "/dashboard/voice",
    "/dashboard/gallery",
    "/dashboard/tools",
    "/dashboard/intelligence",
    "/intelligence",
    "/intel-briefs",
  ],
};

export function canAccess(role: string, path: string): boolean {
  const allowed = ROLE_ACCESS[role] || ROLE_ACCESS["user"];
  if (allowed.includes("*")) return true;
  return allowed.some((p) => path === p || path.startsWith(p + "/"));
}

// ACCESS DENIED interstitial — shown briefly, then redirects to /dashboard
function AccessDenied() {
  const [redirect, setRedirect] = useState(false);

  useEffect(() => {
    const t = setTimeout(() => setRedirect(true), 2000);
    return () => clearTimeout(t);
  }, []);

  if (redirect) return <Redirect to="/dashboard" />;

  return (
    <div
      className="min-h-screen flex items-center justify-center grid-bg"
      style={{ backgroundColor: "#050a0e" }}
      data-testid="access-denied"
    >
      <div
        className="px-6 py-4 border font-mono text-xs uppercase tracking-widest text-center"
        style={{
          borderColor: "#ff2244",
          color: "#ff2244",
          backgroundColor: "rgba(255,34,68,0.08)",
          boxShadow: "0 0 24px rgba(255,34,68,0.2)",
        }}
      >
        <div className="font-display text-sm tracking-[0.2em] mb-1">ACCESS DENIED</div>
        <div className="opacity-70">INSUFFICIENT CLEARANCE</div>
      </div>
    </div>
  );
}

// Protected route wrapper
function ProtectedRoute({ component: Component, adminOnly = false, path, ...props }: any) {
  const { isAuthenticated, isLoading, user } = useAuth();
  const [location] = useLocation();

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center grid-bg" style={{ backgroundColor: "#050a0e" }}>
        <div className="flex items-center gap-2">
          {[0, 1, 2].map((i) => (
            <span
              key={i}
              className="inline-block w-2 h-2 rounded-full bg-trident-cyan pulse-dot"
              style={{ animationDelay: `${i * 0.3}s` }}
            />
          ))}
          <span className="text-xs font-mono uppercase tracking-widest text-trident-text/40 ml-2">
            VERIFYING CLEARANCE...
          </span>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Redirect to="/login" />;
  }

  const role = user?.role || "user";
  const target = path || location;
  const isCommander = role === "admin" || role === "commander";

  if (adminOnly && !isCommander) {
    return <AccessDenied />;
  }

  if (target !== "/dashboard" && !canAccess(role, target)) {
    return <AccessDenied />;
  }

  return (
    <DashboardLayout>
      <Component {...props} />
    </DashboardLayout>
  );
}

function AppRouter() {
  const { checkAuth } = useAuth();

  useEffect(() => {
    checkAuth();
  }, []);

  return (
    <Switch>
      <Route path="/login" component={LoginPage} />
      <Route path="/register" component={RegisterPage} />
      
      {/* Dashboard routes */}
      <Route path="/command">
        {() => <ProtectedRoute component={TridentCommand} />}
      </Route>
      <Route path="/dashboard">
        {() => <ProtectedRoute component={DashboardHome} />}
      </Route>
      <Route path="/dashboard/chat">
        {() => <ProtectedRoute component={DashboardChat} />}
      </Route>
      <Route path="/dashboard/models">
        {() => <ProtectedRoute component={DashboardModels} />}
      </Route>
      <Route path="/dashboard/imagegen">
        {() => <ProtectedRoute component={DashboardImageGen} />}
      </Route>
      <Route path="/dashboard/voice">
        {() => <ProtectedRoute component={DashboardVoice} />}
      </Route>
      <Route path="/dashboard/gallery">
        {() => <ProtectedRoute component={DashboardGallery} />}
      </Route>
      <Route path="/dashboard/tools">
        {() => <ProtectedRoute component={DashboardTools} />}
      </Route>
      <Route path="/dashboard/intelligence">
        {() => <ProtectedRoute component={DashboardIntelligence} />}
      </Route>
      <Route path="/intel-briefs">
        {() => <ProtectedRoute component={IntelBriefs} />}
      </Route>
      <Route path="/grid">
        {() => <ProtectedRoute component={TridentGrid} />}
      </Route>
      <Route path="/opscenter">
        {() => <ProtectedRoute component={OpsCenter} />}
      </Route>
      <Route path="/dashboard/settings">
        {() => <ProtectedRoute component={DashboardSettings} />}
      </Route>
      
      {/* Admin routes */}
      <Route path="/admin/users">
        {() => <ProtectedRoute component={AdminUsersPage} adminOnly={true} />}
      </Route>

      {/* Root redirect */}
      <Route path="/">
        {() => <Redirect to="/login" />}
      </Route>
      
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  // Force dark class on document
  useEffect(() => {
    document.documentElement.classList.add("dark");
  }, []);

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router hook={useHashLocation}>
          <AppRouter />
        </Router>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
