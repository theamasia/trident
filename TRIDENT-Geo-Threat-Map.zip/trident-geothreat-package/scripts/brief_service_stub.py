#!/usr/bin/env python3
"""Minimal stub of brief_service.py for local screenshots/QA only.
Serves the archive endpoints that server/routes.ts proxies to on port 5006.
Not for production — the real brief_service.py handles live fetching + NAS.
"""
from flask import Flask, request, jsonify
import time

app = Flask(__name__)

# In-memory fake NAS archive keyed by safe feed name
ARCHIVE = {
    "defense-news": [
        {"name": "2026-07-24-142212.md", "size_kb": 48.3, "created": "2026-07-24T14:22:12"},
        {"name": "2026-07-24-082207.md", "size_kb": 47.1, "created": "2026-07-24T08:22:07"},
        {"name": "2026-07-23-202158.md", "size_kb": 46.9, "created": "2026-07-23T20:21:58"},
    ]
}

SAMPLE = (
    "# DEFENSE NEWS — ARCHIVED SNAPSHOT\n\n"
    "URL: https://www.defensenews.com\n"
    "Captured: 2026-07-24 14:22:12 UTC\n\n"
    "## TOP STORIES\n\n"
    "- Pentagon accelerates hypersonic glide-vehicle testing schedule for FY27.\n"
    "- NATO members finalize joint air-defense procurement framework.\n"
    "- New maritime domain awareness satellites reach initial operating capability.\n\n"
    "## ANALYSIS\n\n"
    "The shift toward distributed sensing architectures continues to reshape\n"
    "procurement priorities across allied forces. Program offices emphasize\n"
    "resilient, low-latency data links over single high-value platforms.\n\n"
    "(Archived copy preserved on NAS for offline intelligence review.)\n"
)


def _find(name):
    return ARCHIVE.get(name)


@app.post("/feed/fetch-and-archive")
def fetch_and_archive():
    body = request.get_json(force=True, silent=True) or {}
    name = body.get("name", "feed")
    safe = "".join(c if c.isalnum() or c in "-_" else "-" for c in name.lower())
    fn = time.strftime("%Y-%m-%d-%H%M%S.md")
    ARCHIVE.setdefault(safe, []).insert(0, {"name": fn, "size_kb": 48.5, "created": time.strftime("%Y-%m-%dT%H:%M:%S")})
    return jsonify({
        "content": SAMPLE,
        "archived_file": fn,
        "archived_path": f"/mnt/trident-briefs/_web-intel/{safe}/{fn}",
        "length": len(SAMPLE),
        "fetched_at": time.strftime("%Y-%m-%dT%H:%M:%SZ"),
    })


@app.get("/feed/archive/<safe>")
def list_archive(safe):
    files = _find(safe) or []
    return jsonify({"files": files, "count": len(files)})


@app.get("/feed/archive/<safe>/latest")
def latest(safe):
    files = _find(safe) or []
    if not files:
        return jsonify({"content": None, "error": "NO ARCHIVES"}), 404
    return jsonify({"filename": files[0]["name"], "content": SAMPLE})


@app.get("/feed/archive/<safe>/<filename>")
def one(safe, filename):
    return jsonify({"filename": filename, "content": SAMPLE})


@app.get("/feeds/poll-status")
def poll_status():
    return jsonify({"active_polls": ["defense-news"], "count": 1})


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5006)
