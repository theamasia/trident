#!/bin/bash
set -euo pipefail

# ═══════════════════════════════════════════════════════════
# TRIDENT — Admin User Seeding Script
# Creates or updates an admin user in the database
# Usage: ./db-seed-admin.sh [--email admin@example.com] [--password MyPass123!]
# ═══════════════════════════════════════════════════════════

CYAN='\033[0;36m'
GREEN='\033[0;32m'
RED='\033[0;31m'
AMBER='\033[0;33m'
NC='\033[0m'

echo -e "${CYAN}"
cat << 'EOF'
  _____ ____  ___ ____  _____ _   _ _____
 |_   _|  _ \|_ _|  _ \| ____| \ | |_   _|
   | | | |_) || || | | |  _| |  \| | | |
   | | |  _ < | || |_| | |___| |\  | | |
   |_| |_| \_\___|____/|_____|_| \_| |_|

   Admin User Seeding
EOF
echo -e "${NC}"

# ───────────────────────────────────────────
# 1. Parse command-line flags
# --email and --password override config/defaults
# ───────────────────────────────────────────
ADMIN_EMAIL=""
ADMIN_PASSWORD=""

while [[ $# -gt 0 ]]; do
    case $1 in
        --email)
            ADMIN_EMAIL="$2"
            shift 2
            ;;
        --password)
            ADMIN_PASSWORD="$2"
            shift 2
            ;;
        --help|-h)
            echo "Usage: $0 [--email admin@example.com] [--password YourPassword]"
            echo ""
            echo "Options:"
            echo "  --email     Admin email (default: admin@trident.local)"
            echo "  --password  Admin password (default: TridentAdmin1!)"
            echo ""
            echo "Config is sourced from /etc/trident/config.env or .env"
            exit 0
            ;;
        *)
            echo -e "${RED}[ERROR]${NC} Unknown option: $1"
            echo "Use --help for usage info"
            exit 1
            ;;
    esac
done

# ───────────────────────────────────────────
# 2. Source configuration
# ───────────────────────────────────────────
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"

if [ -f "/etc/trident/config.env" ]; then
    echo -e "${CYAN}[TRIDENT]${NC} Loading config from /etc/trident/config.env"
    set -a
    source "/etc/trident/config.env"
    set +a
elif [ -f "$PROJECT_ROOT/.env" ]; then
    echo -e "${CYAN}[TRIDENT]${NC} Loading config from .env"
    set -a
    source "$PROJECT_ROOT/.env"
    set +a
fi

# Apply defaults if not set via flags or config
# CLI flags take priority > config file > hardcoded defaults
ADMIN_EMAIL="${ADMIN_EMAIL:-${ADMIN_EMAIL_FROM_CONFIG:-admin@trident.local}}"
ADMIN_PASSWORD="${ADMIN_PASSWORD:-${ADMIN_PASSWORD_FROM_CONFIG:-TridentAdmin1!}}"

echo -e "${CYAN}[TRIDENT]${NC} Seeding admin user: ${ADMIN_EMAIL}"

# ───────────────────────────────────────────
# 3. Hash password using bcrypt via Node.js
# Uses bcryptjs with cost factor 12
# ───────────────────────────────────────────
echo -e "${CYAN}[TRIDENT]${NC} Hashing password..."
ADMIN_HASH=$(node -e "
  const bcrypt = require('bcryptjs');
  const hash = bcrypt.hashSync(process.argv[1], 12);
  process.stdout.write(hash);
" -- "$ADMIN_PASSWORD")

# ───────────────────────────────────────────
# 4. INSERT or UPDATE admin user
# Uses SQLite (better-sqlite3) for local dev,
# falls back gracefully
# ───────────────────────────────────────────
echo -e "${CYAN}[TRIDENT]${NC} Writing to database..."
cd "$PROJECT_ROOT"

node -e "
  const Database = require('better-sqlite3');
  const db = new Database('data.db');
  db.pragma('journal_mode = WAL');

  // Ensure table exists (safe for fresh databases)
  db.exec(\`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT NOT NULL UNIQUE,
      email TEXT NOT NULL UNIQUE,
      password_hash TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'operator',
      created_at TEXT NOT NULL DEFAULT '',
      last_login TEXT,
      is_active INTEGER NOT NULL DEFAULT 1
    )
  \`);

  // Also create sessions table while we're at it
  db.exec(\`
    CREATE TABLE IF NOT EXISTS sessions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      token_hash TEXT NOT NULL,
      expires_at TEXT NOT NULL,
      created_at TEXT NOT NULL DEFAULT ''
    )
  \`);

  const email = process.argv[1];
  const hash = process.argv[2];
  const now = new Date().toISOString();

  const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(email);
  if (existing) {
    db.prepare('UPDATE users SET password_hash = ?, role = ?, is_active = 1 WHERE email = ?')
      .run(hash, 'commander', email);
    console.log('UPDATED existing admin user');
  } else {
    db.prepare('INSERT INTO users (username, email, password_hash, role, created_at, is_active) VALUES (?, ?, ?, ?, ?, 1)')
      .run('admin', email, hash, 'commander', now);
    console.log('CREATED new admin user');
  }

  db.close();
" -- "$ADMIN_EMAIL" "$ADMIN_HASH"

echo ""
echo -e "${GREEN}═══════════════════════════════════════════════════════${NC}"
echo -e "${GREEN}[ TRIDENT ] Admin user created/updated: ${ADMIN_EMAIL}${NC}"
echo -e "${GREEN}═══════════════════════════════════════════════════════${NC}"
