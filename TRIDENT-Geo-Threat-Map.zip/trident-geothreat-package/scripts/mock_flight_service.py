"""
Temporary mock flight service for screenshot/QA purposes only.
Serves fixed JSON on port 5004 matching flight_service.py's response shape,
including a military aircraft so the MIL badge / red radar triangle can be
visually verified without live OpenSky/dump1090 connectivity.
NOT part of the production TRIDENT codebase — used only for local QA screenshots.
"""
import datetime
from flask import Flask, jsonify
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

DENTON_LAT, DENTON_LON = 35.9096, -80.1206

MOCK_AIRCRAFT = [
    {
        "icao24": "ae1470", "callsign": "RCH412", "origin_country": "United States",
        "latitude": 35.95, "longitude": -80.10, "altitude_m": 9144, "altitude_ft": 30000,
        "velocity_ms": 230, "velocity_kts": 447, "heading": 270, "vertical_rate": 0,
        "on_ground": False, "squawk": "0212", "distance_nm": 8.4, "source": "opensky",
        "is_military": True,
    },
    {
        "icao24": "a1b2c3", "callsign": "DAL1422", "origin_country": "United States",
        "latitude": 35.87, "longitude": -80.05, "altitude_m": 10668, "altitude_ft": 35000,
        "velocity_ms": 245, "velocity_kts": 476, "heading": 90, "vertical_rate": -5,
        "on_ground": False, "squawk": "3141", "distance_nm": 14.2, "source": "opensky",
        "is_military": False,
    },
    {
        "icao24": "c0ffee", "callsign": "N882QT", "origin_country": "United States",
        "latitude": 35.92, "longitude": -80.20, "altitude_m": 1524, "altitude_ft": 5000,
        "velocity_ms": 90, "velocity_kts": 175, "heading": 180, "vertical_rate": 2,
        "on_ground": False, "squawk": "1200", "distance_nm": 5.1, "source": "opensky",
        "is_military": False,
    },
]


@app.route("/health")
def health():
    return jsonify({"status": "ok", "service": "MOCK Flight Intelligence", "data_source": "opensky",
                     "dump1090_configured": False, "opensky_authenticated": True,
                     "location": "Denton, NC", "radius_nm": 40})


@app.route("/aircraft")
def aircraft():
    return jsonify({
        "aircraft": MOCK_AIRCRAFT,
        "count": len(MOCK_AIRCRAFT),
        "source": "opensky",
        "timestamp": datetime.datetime.utcnow().isoformat(),
        "center": {"lat": DENTON_LAT, "lon": DENTON_LON},
        "radius_nm": 40,
    })


@app.route("/stats")
def stats():
    return jsonify({
        "total_flights_recorded": 214,
        "today_count": 37,
        "max_altitude_ft": 41000,
        "max_speed_kts": 512,
        "top_callsigns": [{"callsign": "RCH412", "c": 4}, {"callsign": "DAL1422", "c": 3}],
        "top_countries": [{"origin_country": "United States", "c": 30}],
        "military_flights_today": 3,
    })


@app.route("/history")
def history():
    return jsonify({"flights": [], "total": 0, "limit": 100, "offset": 0})


@app.route("/storage")
def storage():
    return jsonify({"db_size_mb": 2.4, "path": "mock"})


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5004)
