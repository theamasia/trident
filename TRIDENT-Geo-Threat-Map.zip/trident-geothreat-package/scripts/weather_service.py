#!/usr/bin/env python3
"""
TRIDENT Weather Intelligence Service
Open-Meteo + NOAA Weather API — no API keys required
Runs on port 5005
"""
import os, time, datetime, requests
from flask import Flask, jsonify, request
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

# Denton, NC
LAT = 35.6262
LON = -80.1131
NOAA_ZONE = "NCZ040"  # Davidson County NC forecast zone
NOAA_COUNTY = "DavidsonNC"

CACHE = {}
CACHE_TTL = 300  # 5 min

def cached(key, fn, ttl=CACHE_TTL):
    now = time.time()
    if key in CACHE and now - CACHE[key]["ts"] < ttl:
        return CACHE[key]["data"]
    data = fn()
    CACHE[key] = {"data": data, "ts": now}
    return data

@app.route("/health")
def health():
    return jsonify({"status": "ok", "service": "TRIDENT Weather Intelligence", "location": "Denton, NC"})

@app.route("/current")
def current():
    def fetch():
        params = {
            "latitude": LAT, "longitude": LON,
            "current": "temperature_2m,relative_humidity_2m,apparent_temperature,precipitation,rain,wind_speed_10m,wind_direction_10m,wind_gusts_10m,weather_code,cloud_cover,visibility,surface_pressure",
            "temperature_unit": "fahrenheit",
            "wind_speed_unit": "mph",
            "precipitation_unit": "inch",
            "timezone": "America/New_York"
        }
        res = requests.get("https://api.open-meteo.com/v1/forecast", params=params, timeout=10)
        data = res.json()
        current = data.get("current", {})
        units = data.get("current_units", {})

        # WMO weather code to description
        wmo_codes = {
            0: "CLEAR SKY", 1: "MAINLY CLEAR", 2: "PARTLY CLOUDY", 3: "OVERCAST",
            45: "FOG", 48: "ICING FOG", 51: "LIGHT DRIZZLE", 53: "DRIZZLE", 55: "HEAVY DRIZZLE",
            61: "LIGHT RAIN", 63: "RAIN", 65: "HEAVY RAIN", 71: "LIGHT SNOW", 73: "SNOW", 75: "HEAVY SNOW",
            80: "LIGHT SHOWERS", 81: "SHOWERS", 82: "HEAVY SHOWERS",
            95: "THUNDERSTORM", 96: "THUNDERSTORM W/ HAIL", 99: "HEAVY THUNDERSTORM W/ HAIL"
        }
        code = current.get("weather_code", 0)

        return {
            "temperature_f": current.get("temperature_2m"),
            "feels_like_f": current.get("apparent_temperature"),
            "humidity_pct": current.get("relative_humidity_2m"),
            "wind_speed_mph": current.get("wind_speed_10m"),
            "wind_gust_mph": current.get("wind_gusts_10m"),
            "wind_direction_deg": current.get("wind_direction_10m"),
            "precipitation_in": current.get("precipitation"),
            "cloud_cover_pct": current.get("cloud_cover"),
            "visibility_m": current.get("visibility"),
            "surface_pressure_hpa": current.get("surface_pressure"),
            "weather_code": code,
            "condition": wmo_codes.get(code, f"CODE {code}"),
            "time": current.get("time"),
            "source": "Open-Meteo"
        }
    return jsonify(cached("current", fetch, 300))

@app.route("/forecast")
def forecast():
    def fetch():
        params = {
            "latitude": LAT, "longitude": LON,
            "daily": "temperature_2m_max,temperature_2m_min,precipitation_sum,precipitation_probability_max,wind_speed_10m_max,wind_gusts_10m_max,weather_code,sunrise,sunset",
            "hourly": "temperature_2m,precipitation_probability,weather_code,wind_speed_10m,cloud_cover",
            "temperature_unit": "fahrenheit",
            "wind_speed_unit": "mph",
            "precipitation_unit": "inch",
            "timezone": "America/New_York",
            "forecast_days": 7
        }
        res = requests.get("https://api.open-meteo.com/v1/forecast", params=params, timeout=10)
        return res.json()
    return jsonify(cached("forecast", fetch, 1800))

@app.route("/alerts")
def alerts():
    def fetch():
        try:
            # NOAA alerts for NC — Davidson County
            res = requests.get(
                "https://api.weather.gov/alerts/active",
                params={"area": "NC", "status": "actual"},
                headers={"User-Agent": "TRIDENT/1.0 (trident@local)", "Accept": "application/geo+json"},
                timeout=10
            )
            data = res.json()
            features = data.get("features", [])
            alerts = []
            for f in features:
                props = f.get("properties", {})
                # Filter for Davidson County or statewide
                areas = props.get("areaDesc", "")
                if "Davidson" in areas or "Statewide" in areas or not areas:
                    alerts.append({
                        "id": props.get("id", ""),
                        "event": props.get("event", ""),
                        "severity": props.get("severity", ""),
                        "urgency": props.get("urgency", ""),
                        "certainty": props.get("certainty", ""),
                        "headline": props.get("headline", ""),
                        "description": (props.get("description", "") or "")[:500],
                        "instruction": (props.get("instruction", "") or "")[:300],
                        "onset": props.get("onset", ""),
                        "expires": props.get("expires", ""),
                        "area": areas,
                        "sender": props.get("senderName", "NOAA")
                    })
            return {"alerts": alerts, "count": len(alerts), "source": "NOAA Weather API"}
        except Exception as e:
            return {"alerts": [], "count": 0, "error": str(e), "source": "NOAA Weather API"}
    return jsonify(cached("alerts", fetch, 300))

@app.route("/radar-tiles")
def radar_tiles():
    """Return NOAA radar tile URL templates for frontend map"""
    return jsonify({
        "nexrad_base": "https://mesonet.agron.iastate.edu/cache/tile.py/1.0.0/nexrad-n0q-900913/{z}/{x}/{y}.png",
        "nexrad_ridge": "https://opengeo.ncep.noaa.gov/geoserver/conus/conus_bref_qcd/ows?service=wms&version=1.3.0&request=GetMap",
        "note": "Use nexrad_base as a Leaflet tile layer with opacity 0.6"
    })

@app.route("/satellite-tiles")
def satellite_tiles():
    """Return NASA GIBS satellite tile URL templates"""
    return jsonify({
        "goes_east_geocolor": "https://gibs.earthdata.nasa.gov/wmts/epsg3857/best/GOES-East_ABI_GeoColor/default/GoogleMapsCompatible_Level6/{z}/{y}/{x}.jpg",
        "goes_east_ir": "https://gibs.earthdata.nasa.gov/wmts/epsg3857/best/GOES-East_ABI_Band13_Clean_Infrared/default/GoogleMapsCompatible_Level6/{z}/{y}/{x}.jpg",
        "modis_terra": "https://gibs.earthdata.nasa.gov/wmts/epsg3857/best/MODIS_Terra_CorrectedReflectance_TrueColor/default/GoogleMapsCompatible_Level9/{z}/{y}/{x}.jpg",
        "note": "Use as Leaflet tile layers"
    })

@app.route("/astronomy")
def astronomy():
    """Sun/moon data for Denton NC"""
    def fetch():
        try:
            # Open-Meteo for sunrise/sunset
            params = {
                "latitude": LAT, "longitude": LON,
                "daily": "sunrise,sunset,daylight_duration,sunshine_duration",
                "timezone": "America/New_York",
                "forecast_days": 1
            }
            res = requests.get("https://api.open-meteo.com/v1/forecast", params=params, timeout=10)
            data = res.json()
            daily = data.get("daily", {})
            return {
                "sunrise": daily.get("sunrise", [None])[0],
                "sunset": daily.get("sunset", [None])[0],
                "daylight_seconds": daily.get("daylight_duration", [None])[0],
                "sunshine_seconds": daily.get("sunshine_duration", [None])[0],
                "source": "Open-Meteo"
            }
        except Exception as e:
            return {"error": str(e)}
    return jsonify(cached("astronomy", fetch, 3600))

if __name__ == "__main__":
    print("[ TRIDENT ] Weather Intelligence Service starting on port 5005")
    app.run(host="127.0.0.1", port=5005, debug=False)
