#!/usr/bin/env bash
set -euo pipefail

# ─────────────────────────────────────────────────────────────
#  TRIDENT Geo-Intelligence Service — Setup
# ─────────────────────────────────────────────────────────────
cat << 'BANNER'
   ______________  ______  ___________   ________
  /_  __/ __ \/  _/ __ \/ ____/ | / /_  __/
   / / / /_/ // // / / / __/ /  |/ / / /
  / / / _, _// // /_/ / /___/ /|  / / /
 /_/ /_/ |_/___/_____/_____/_/ |_/ /_/
       G E O - I N T E L L I G E N C E   [ PORT 5003 ]
BANNER

# Install deps into a dedicated geo venv
python3 -m venv /opt/trident-geo/venv 2>/dev/null || true
/opt/trident-geo/venv/bin/pip install flask flask-cors requests --quiet

# Copy service file
mkdir -p /opt/trident-geo
cp /opt/trident/scripts/geo_service.py /opt/trident-geo/geo_service.py

# Systemd service
cat > /etc/systemd/system/trident-geo.service << 'EOF'
[Unit]
Description=TRIDENT Geo-Intelligence Service
After=network.target trident.service

[Service]
Type=simple
User=root
WorkingDirectory=/opt/trident-geo
EnvironmentFile=/etc/trident/config.env
ExecStart=/opt/trident-geo/venv/bin/python3 /opt/trident-geo/geo_service.py
Restart=always
RestartSec=10
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable trident-geo
systemctl start trident-geo
sleep 3
systemctl status trident-geo --no-pager | head -5
curl -s http://localhost:5003/health
echo ""
echo "[ TRIDENT ] Geo-Intelligence Service online"
