#!/usr/bin/env python3
"""
TRIDENT Flight Intelligence Service
Primary: OpenSky Network (free, anonymous, 10s rate limit)
Fallback: Local dump1090 SDR server (when configured)
Runs on port 5004
"""
import os, time, datetime, json, math, sqlite3, threading, io, csv
import requests
from flask import Flask, jsonify, request, Response
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

# Denton, NC center
DENTON_LAT = 35.6262
DENTON_LON = -80.1131
RADIUS_NM = 25

# OpenSky bounding box (25nm radius around Denton NC)
LAT_MIN, LAT_MAX = 35.23, 36.02
LON_MIN, LON_MAX = -80.56, -79.66

# Config
OPENSKY_USER = os.environ.get("OPENSKY_USER", "")
OPENSKY_PASS = os.environ.get("OPENSKY_PASS", "")
DUMP1090_URL = os.environ.get("DUMP1090_URL", "")  # e.g. http://192.168.0.x/data/aircraft.json
DB_PATH = os.environ.get("FLIGHT_DB_PATH", "/mnt/trident-briefs/aviation/flights.db")

# Rate limiting: OpenSky anonymous = 10s, authenticated = 5s
OPENSKY_INTERVAL = 5 if (OPENSKY_USER and OPENSKY_PASS) else 10
last_opensky_fetch = 0
cached_aircraft = []
cache_lock = threading.Lock()

def init_db():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS flight_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            icao24 TEXT NOT NULL,
            callsign TEXT,
            origin_country TEXT,
            latitude REAL,
            longitude REAL,
            altitude_m REAL,
            velocity_ms REAL,
            heading REAL,
            vertical_rate REAL,
            on_ground INTEGER,
            squawk TEXT,
            distance_nm REAL,
            first_seen TEXT NOT NULL,
            last_seen TEXT NOT NULL,
            is_military INTEGER DEFAULT 0,
            UNIQUE(icao24, first_seen)
        )
    """)
    # Migrate older DBs that predate the is_military column
    try:
        cols = [r[1] for r in conn.execute("PRAGMA table_info(flight_history)").fetchall()]
        if "is_military" not in cols:
            conn.execute("ALTER TABLE flight_history ADD COLUMN is_military INTEGER DEFAULT 0")
    except Exception:
        pass
    conn.execute("""
        CREATE TABLE IF NOT EXISTS flight_stats (
            date TEXT PRIMARY KEY,
            total_flights INTEGER DEFAULT 0,
            max_altitude_m REAL DEFAULT 0,
            max_speed_ms REAL DEFAULT 0,
            busiest_hour INTEGER DEFAULT 0,
            hour_counts TEXT DEFAULT '{}'
        )
    """)
    conn.commit()
    conn.close()

def haversine_nm(lat1, lon1, lat2, lon2):
    R = 3440.065  # Earth radius in nautical miles
    dlat = math.radians(lat2 - lat1)
    dlon = math.radians(lon2 - lon1)
    a = math.sin(dlat/2)**2 + math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) * math.sin(dlon/2)**2
    return R * 2 * math.asin(math.sqrt(a))

# US military ICAO24 hex ranges (partial list of known blocks)
MILITARY_ICAO_RANGES = [
    (0xADF7C8, 0xAFFFFF),  # US military block
    (0xAE0000, 0xAFFFFF),  # US DoD block
]

MILITARY_CALLSIGN_PATTERNS = [
    r'^RCH\d+',      # Air Mobility Command (Reach)
    r'^CNV\d+',      # Navy
    r'^VVIP\d+',     # VIP transport
    r'^GRZLY\d+',    # Army
    r'^ARMY\d+',
    r'^NAVY\d+',
    r'^MARINE\d+',
    r'^COAST\d+',    # Coast Guard
    r'^SAM\d+',      # Special Air Mission (VIP/Gov)
    r'^HAWK\d+',
    r'^VENOM\d+',
    r'^TREND\d+',
    r'^DOOM\d+',     # B-1 bomber callsigns often use tactical names
    r'^\d{2}-\d{4}$', # Tail number format sometimes used as callsign
]

def is_military_aircraft(icao24, callsign):
    """Detect if aircraft is likely military based on ICAO24 hex and callsign patterns"""
    import re
    try:
        hex_val = int(icao24, 16) if icao24 else 0
        for low, high in MILITARY_ICAO_RANGES:
            if low <= hex_val <= high:
                return True
    except (ValueError, TypeError):
        pass

    if callsign:
        cs = callsign.strip().upper()
        for pattern in MILITARY_CALLSIGN_PATTERNS:
            if re.match(pattern, cs):
                return True
    return False

def parse_opensky_state(s):
    """Parse OpenSky state vector array"""
    if not s or s[5] is None or s[6] is None:
        return None
    lat, lon = s[6], s[5]
    dist = haversine_nm(DENTON_LAT, DENTON_LON, lat, lon)
    return {
        "icao24": s[0],
        "callsign": (s[1] or "").strip() or "UNKNOWN",
        "origin_country": s[2] or "",
        "latitude": lat,
        "longitude": lon,
        "altitude_m": s[7] or s[13] or 0,  # baro or geo altitude
        "altitude_ft": round((s[7] or s[13] or 0) * 3.28084),
        "velocity_ms": s[9] or 0,
        "velocity_kts": round((s[9] or 0) * 1.94384),
        "heading": s[10] or 0,
        "vertical_rate": s[11] or 0,
        "on_ground": bool(s[8]),
        "squawk": s[14] or "",
        "distance_nm": round(dist, 1),
        "last_contact": s[4],
        "source": "opensky",
        "is_military": is_military_aircraft(s[0], (s[1] or "").strip()),
    }

def parse_dump1090_aircraft(a):
    """Parse dump1090 aircraft.json entry"""
    lat = a.get("lat")
    lon = a.get("lon")
    if not lat or not lon:
        return None
    dist = haversine_nm(DENTON_LAT, DENTON_LON, lat, lon)
    if dist > RADIUS_NM:
        return None
    alt_ft = a.get("alt_baro", 0) or 0
    return {
        "icao24": a.get("hex", ""),
        "callsign": (a.get("flight", "") or "").strip() or "UNKNOWN",
        "origin_country": "",
        "latitude": lat,
        "longitude": lon,
        "altitude_m": round(alt_ft / 3.28084),
        "altitude_ft": alt_ft,
        "velocity_ms": round((a.get("gs", 0) or 0) / 1.94384),
        "velocity_kts": a.get("gs", 0) or 0,
        "heading": a.get("track", 0) or 0,
        "vertical_rate": a.get("baro_rate", 0) or 0,
        "on_ground": a.get("alt_baro") == "ground",
        "squawk": a.get("squawk", ""),
        "distance_nm": round(dist, 1),
        "last_contact": int(time.time()),
        "source": "dump1090",
        "is_military": is_military_aircraft(a.get("hex", ""), (a.get("flight", "") or "").strip()),
    }

def fetch_from_dump1090():
    """Fetch from local SDR dump1090 server"""
    try:
        res = requests.get(DUMP1090_URL, timeout=5)
        data = res.json()
        aircraft_list = data.get("aircraft", [])
        result = []
        for a in aircraft_list:
            parsed = parse_dump1090_aircraft(a)
            if parsed:
                result.append(parsed)
        return sorted(result, key=lambda x: x["distance_nm"])
    except Exception as e:
        print(f"[ TRIDENT ] dump1090 error: {e}", flush=True)
        return None

def fetch_from_opensky():
    """Fetch from OpenSky Network"""
    global last_opensky_fetch, cached_aircraft
    now = time.time()
    if now - last_opensky_fetch < OPENSKY_INTERVAL:
        return cached_aircraft
    try:
        url = "https://opensky-network.org/api/states/all"
        params = {"lamin": LAT_MIN, "lamax": LAT_MAX, "lomin": LON_MIN, "lomax": LON_MAX}
        auth = (OPENSKY_USER, OPENSKY_PASS) if OPENSKY_USER else None
        res = requests.get(url, params=params, auth=auth, timeout=15)
        if res.status_code == 200:
            data = res.json()
            states = data.get("states", []) or []
            aircraft = []
            for s in states:
                parsed = parse_opensky_state(s)
                if parsed and parsed["distance_nm"] <= RADIUS_NM:
                    aircraft.append(parsed)
            aircraft = sorted(aircraft, key=lambda x: x["distance_nm"])
            with cache_lock:
                cached_aircraft = aircraft
                last_opensky_fetch = now
            record_aircraft(aircraft)
            return aircraft
        else:
            print(f"[ TRIDENT ] OpenSky error: {res.status_code}", flush=True)
            return cached_aircraft
    except Exception as e:
        print(f"[ TRIDENT ] OpenSky exception: {e}", flush=True)
        return cached_aircraft

def get_aircraft():
    """Get aircraft — dump1090 first, OpenSky fallback"""
    if DUMP1090_URL:
        result = fetch_from_dump1090()
        if result is not None:
            return result, "dump1090"
    result = fetch_from_opensky()
    return result, "opensky"

def record_aircraft(aircraft_list):
    """Record aircraft to history DB"""
    try:
        conn = sqlite3.connect(DB_PATH)
        now_str = datetime.datetime.utcnow().isoformat()
        today = datetime.datetime.utcnow().strftime("%Y-%m-%d")
        for a in aircraft_list:
            if a.get("on_ground"):
                continue
            conn.execute("""
                INSERT INTO flight_history (icao24, callsign, origin_country, latitude, longitude,
                    altitude_m, velocity_ms, heading, vertical_rate, on_ground, squawk,
                    distance_nm, first_seen, last_seen, is_military)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(icao24, first_seen) DO UPDATE SET
                    last_seen=excluded.last_seen,
                    latitude=excluded.latitude,
                    longitude=excluded.longitude,
                    altitude_m=excluded.altitude_m,
                    velocity_ms=excluded.velocity_ms,
                    is_military=excluded.is_military
            """, (
                a["icao24"], a["callsign"], a["origin_country"],
                a["latitude"], a["longitude"], a["altitude_m"],
                a["velocity_ms"], a["heading"], a["vertical_rate"],
                1 if a["on_ground"] else 0, a["squawk"],
                a["distance_nm"], now_str, now_str,
                1 if a.get("is_military") else 0
            ))
        conn.commit()
        conn.close()
    except Exception as e:
        print(f"[ TRIDENT ] DB record error: {e}", flush=True)

@app.route("/health")
def health():
    source = "dump1090" if DUMP1090_URL else "opensky"
    return jsonify({
        "status": "ok",
        "service": "TRIDENT Flight Intelligence",
        "data_source": source,
        "dump1090_configured": bool(DUMP1090_URL),
        "opensky_authenticated": bool(OPENSKY_USER and OPENSKY_PASS),
        "location": "Denton, NC",
        "radius_nm": RADIUS_NM
    })

@app.route("/aircraft")
def aircraft():
    """Live aircraft overhead"""
    result, source = get_aircraft()
    return jsonify({
        "aircraft": result,
        "count": len(result),
        "source": source,
        "timestamp": datetime.datetime.utcnow().isoformat(),
        "center": {"lat": DENTON_LAT, "lon": DENTON_LON},
        "radius_nm": RADIUS_NM
    })

@app.route("/history")
def history():
    """Flight history log"""
    limit = int(request.args.get("limit", 100))
    offset = int(request.args.get("offset", 0))
    date = request.args.get("date", "")
    try:
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        query = "SELECT * FROM flight_history"
        params = []
        if date:
            query += " WHERE DATE(first_seen) = ?"
            params.append(date)
        query += " ORDER BY last_seen DESC LIMIT ? OFFSET ?"
        params.extend([limit, offset])
        rows = conn.execute(query, params).fetchall()
        total = conn.execute("SELECT COUNT(*) FROM flight_history" + (" WHERE DATE(first_seen)=?" if date else ""), ([date] if date else [])).fetchone()[0]
        conn.close()
        return jsonify({
            "flights": [dict(r) for r in rows],
            "total": total,
            "limit": limit,
            "offset": offset
        })
    except Exception as e:
        return jsonify({"error": str(e), "flights": [], "total": 0}), 200

@app.route("/stats")
def stats():
    """Aggregate stats"""
    try:
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        total = conn.execute("SELECT COUNT(DISTINCT icao24 || DATE(first_seen)) FROM flight_history").fetchone()[0]
        today_count = conn.execute("SELECT COUNT(DISTINCT icao24) FROM flight_history WHERE DATE(first_seen)=?", (datetime.datetime.utcnow().strftime("%Y-%m-%d"),)).fetchone()[0]
        max_alt = conn.execute("SELECT MAX(altitude_m) FROM flight_history").fetchone()[0] or 0
        max_speed = conn.execute("SELECT MAX(velocity_ms) FROM flight_history").fetchone()[0] or 0
        top_callsigns = conn.execute("SELECT callsign, COUNT(*) as c FROM flight_history WHERE callsign != 'UNKNOWN' GROUP BY callsign ORDER BY c DESC LIMIT 10").fetchall()
        top_countries = conn.execute("SELECT origin_country, COUNT(*) as c FROM flight_history WHERE origin_country != '' GROUP BY origin_country ORDER BY c DESC LIMIT 5").fetchall()
        military_flights_today = conn.execute(
            "SELECT COUNT(DISTINCT icao24) FROM flight_history WHERE DATE(first_seen)=? AND is_military=1",
            (datetime.datetime.utcnow().strftime("%Y-%m-%d"),)
        ).fetchone()[0]
        conn.close()
        return jsonify({
            "total_flights_recorded": total,
            "today_count": today_count,
            "max_altitude_ft": round(max_alt * 3.28084) if max_alt else 0,
            "max_speed_kts": round(max_speed * 1.94384) if max_speed else 0,
            "top_callsigns": [dict(r) for r in top_callsigns],
            "top_countries": [dict(r) for r in top_countries],
            "military_flights_today": military_flights_today
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 200

CSV_HEADERS = ["icao24", "callsign", "origin_country", "latitude", "longitude",
               "altitude_ft", "speed_kts", "heading", "on_ground", "squawk",
               "distance_nm", "first_seen", "last_seen"]

def _fetch_history_rows(date=""):
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    query = "SELECT * FROM flight_history"
    params = []
    if date:
        query += " WHERE DATE(first_seen) = ?"
        params.append(date)
    query += " ORDER BY last_seen DESC"
    rows = conn.execute(query, params).fetchall()
    conn.close()
    return [dict(r) for r in rows]

def _row_to_export(r):
    alt_m = r.get("altitude_m") or 0
    vel_ms = r.get("velocity_ms") or 0
    return {
        "icao24": r.get("icao24", ""),
        "callsign": r.get("callsign", ""),
        "origin_country": r.get("origin_country", ""),
        "latitude": r.get("latitude", 0),
        "longitude": r.get("longitude", 0),
        "altitude_ft": round(alt_m * 3.28084),
        "speed_kts": round(vel_ms * 1.94384),
        "heading": r.get("heading", 0),
        "on_ground": r.get("on_ground", 0),
        "squawk": r.get("squawk", ""),
        "distance_nm": r.get("distance_nm", 0),
        "first_seen": r.get("first_seen", ""),
        "last_seen": r.get("last_seen", ""),
    }

@app.route("/export/csv")
def export_csv():
    """Export flight_history as CSV download"""
    date = request.args.get("date", "")
    try:
        rows = _fetch_history_rows(date)
        buf = io.StringIO()
        writer = csv.DictWriter(buf, fieldnames=CSV_HEADERS)
        writer.writeheader()
        for r in rows:
            writer.writerow(_row_to_export(r))
        fname = f"trident-flights-{date or datetime.datetime.utcnow().strftime('%Y-%m-%d')}.csv"
        return Response(
            buf.getvalue(),
            mimetype="text/csv",
            headers={"Content-Disposition": f'attachment; filename="{fname}"'}
        )
    except Exception as e:
        return jsonify({"error": str(e)}), 200

@app.route("/export/json")
def export_json():
    """Export flight_history as JSON download"""
    date = request.args.get("date", "")
    try:
        rows = _fetch_history_rows(date)
        exported = [_row_to_export(r) for r in rows]
        payload = json.dumps({
            "service": "TRIDENT Flight Intelligence",
            "location": "Denton, NC",
            "exported_at": datetime.datetime.utcnow().isoformat(),
            "date_filter": date or None,
            "count": len(exported),
            "flights": exported,
        }, indent=2)
        fname = f"trident-flights-{date or datetime.datetime.utcnow().strftime('%Y-%m-%d')}.json"
        return Response(
            payload,
            mimetype="application/json",
            headers={"Content-Disposition": f'attachment; filename="{fname}"'}
        )
    except Exception as e:
        return jsonify({"error": str(e)}), 200

@app.route("/clear", methods=["DELETE"])
def clear():
    """Clear flight history (safety-gated)"""
    if request.headers.get("X-Trident-Confirm") != "CLEAR":
        return jsonify({"deleted": 0, "message": "CONFIRMATION HEADER REQUIRED"}), 400
    date = request.args.get("date", "")
    before = request.args.get("before", "")
    try:
        conn = sqlite3.connect(DB_PATH)
        if date:
            cur = conn.execute("DELETE FROM flight_history WHERE DATE(first_seen) = ?", (date,))
            msg = f"Cleared records for {date}"
        elif before:
            cur = conn.execute("DELETE FROM flight_history WHERE DATE(first_seen) < ?", (before,))
            msg = f"Cleared records before {before}"
        else:
            cur = conn.execute("DELETE FROM flight_history")
            msg = "Cleared ALL flight history"
        deleted = cur.rowcount
        conn.commit()
        conn.execute("VACUUM")
        conn.close()
        return jsonify({"deleted": deleted, "message": msg})
    except Exception as e:
        return jsonify({"deleted": 0, "message": str(e)}), 200

@app.route("/storage")
def storage_info():
    """Show DB storage info"""
    try:
        db_size_mb = round(os.path.getsize(DB_PATH) / (1024 * 1024), 2) if os.path.exists(DB_PATH) else 0
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        total = conn.execute("SELECT COUNT(*) FROM flight_history").fetchone()[0]
        oldest = conn.execute("SELECT MIN(first_seen) FROM flight_history").fetchone()[0]
        newest = conn.execute("SELECT MAX(last_seen) FROM flight_history").fetchone()[0]
        by_date = conn.execute("""
            SELECT DATE(first_seen) as date, COUNT(*) as count
            FROM flight_history
            GROUP BY DATE(first_seen)
            ORDER BY date DESC
            LIMIT 30
        """).fetchall()
        conn.close()
        return jsonify({
            "db_size_mb": db_size_mb,
            "total_records": total,
            "oldest_record": oldest,
            "newest_record": newest,
            "records_by_date": [dict(r) for r in by_date]
        })
    except Exception as e:
        return jsonify({"error": str(e), "db_size_mb": 0, "total_records": 0}), 200

@app.route("/brief/data")
def brief_data():
    """Return structured flight data for brief generation — last N hours or specific date"""
    hours = int(request.args.get("hours", 24))
    date = request.args.get("date", "")
    try:
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        if date:
            where = "WHERE DATE(first_seen) = ?"
            params = [date]
        else:
            cutoff = (datetime.datetime.utcnow() - datetime.timedelta(hours=hours)).isoformat()
            where = "WHERE first_seen >= ?"
            params = [cutoff]

        rows = conn.execute(f"""
            SELECT icao24, callsign, origin_country, latitude, longitude,
                   altitude_m, velocity_ms, heading, on_ground, squawk,
                   distance_nm, first_seen, last_seen
            FROM flight_history {where}
            ORDER BY first_seen DESC
        """, params).fetchall()

        flights = [dict(r) for r in rows]

        # Aggregate stats
        total = len(flights)
        countries = {}
        callsigns = {}
        max_alt = 0
        max_speed = 0
        closest = None
        closest_dist = 9999
        for f in flights:
            c = f.get("origin_country") or "Unknown"
            countries[c] = countries.get(c, 0) + 1
            cs = (f.get("callsign") or "UNKNOWN").strip()
            if cs != "UNKNOWN":
                callsigns[cs] = callsigns.get(cs, 0) + 1
            alt = f.get("altitude_m") or 0
            spd = f.get("velocity_ms") or 0
            dist = f.get("distance_nm") or 9999
            if alt > max_alt: max_alt = alt
            if spd > max_speed: max_speed = spd
            if dist < closest_dist:
                closest_dist = dist
                closest = f

        top_callsigns = sorted(callsigns.items(), key=lambda x: x[1], reverse=True)[:10]
        top_countries = sorted(countries.items(), key=lambda x: x[1], reverse=True)[:5]

        conn.close()
        return jsonify({
            "flights": flights,
            "total": total,
            "period_hours": hours,
            "date_filter": date,
            "stats": {
                "total_flights": total,
                "max_altitude_ft": round(max_alt * 3.28084),
                "max_speed_kts": round(max_speed * 1.94384),
                "top_callsigns": [{"callsign": k, "count": v} for k, v in top_callsigns],
                "top_countries": [{"country": k, "count": v} for k, v in top_countries],
                "closest_approach": closest,
                "closest_distance_nm": round(closest_dist, 1) if closest else None
            }
        })
    except Exception as e:
        return jsonify({"error": str(e), "flights": [], "total": 0}), 200


if __name__ == "__main__":
    print("[ TRIDENT ] Flight Intelligence Service starting on port 5004")
    print(f"[ TRIDENT ] Monitoring Denton, NC ({DENTON_LAT}, {DENTON_LON}) radius {RADIUS_NM}nm")
    print(f"[ TRIDENT ] Data source: {'dump1090 @ ' + DUMP1090_URL if DUMP1090_URL else 'OpenSky Network'}")
    init_db()
    app.run(host="127.0.0.1", port=5004, debug=False)
