#!/usr/bin/env python3
"""
TRIDENT GRID Coordinator
Manages distributed compute worker nodes
Runs on port 5007
"""
import os, time, datetime, json, threading, uuid, hashlib
import requests
from flask import Flask, jsonify, request
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

COORDINATOR_VERSION = "1.0.0"
COORDINATOR_SECRET = os.environ.get("GRID_SECRET", "trident-grid-secret-2026")

# In-memory node registry (persisted to disk)
NODES = {}  # node_id -> node_info
JOBS = {}   # job_id -> job_info
NODES_LOCK = threading.Lock()
JOBS_LOCK = threading.Lock()
DATA_DIR = os.environ.get("GRID_DATA_DIR", "/opt/trident-grid")

# ─── Capability tags ──────────────────────────────────────────────
def compute_capability_tags(node_info):
    """Compute capability tags from node hardware profile"""
    tags = []
    caps = node_info.get("capabilities", {})
    gpu = caps.get("gpu", {})
    ram_gb = caps.get("ram_total_gb", 0)
    cpu_cores = caps.get("cpu_cores", 0)

    # GPU LLM capable
    if gpu.get("detected") and gpu.get("vram_total_gb", 0) >= 8:
        tags.append("GPU-LLM")
    if gpu.get("detected") and gpu.get("vram_total_gb", 0) >= 6:
        tags.append("GPU-IMGGEN")
        tags.append("GPU-STT")

    # CPU tiers
    if cpu_cores >= 8 and ram_gb >= 16:
        tags.append("CPU-HEAVY")
    elif cpu_cores >= 4 and ram_gb >= 8:
        tags.append("CPU-LIGHT")
    else:
        tags.append("CPU-MINIMAL")

    # Ollama available
    if caps.get("ollama_available"):
        tags.append("OLLAMA")
        if caps.get("ollama_models"):
            tags.append("MODELS-READY")

    # Storage
    if caps.get("disk_free_gb", 0) >= 50:
        tags.append("STORAGE")

    return tags

# ─── Dispatch scoring ─────────────────────────────────────────────
def compute_dispatch_score(node_info):
    """Lower score = more available for work"""
    metrics = node_info.get("last_metrics", {})
    cpu_pct = metrics.get("cpu_pct", 50)
    ram_pct = metrics.get("ram_pct", 50)
    gpu_pct = metrics.get("gpu_pct", 0)
    active_jobs = len([j for j in JOBS.values()
                       if j.get("assigned_node") == node_info.get("node_id")
                       and j.get("status") == "running"])

    has_gpu = node_info.get("capabilities", {}).get("gpu", {}).get("detected", False)
    gpu_weight = gpu_pct * 0.5 if has_gpu else 0

    score = (cpu_pct * 0.3) + (ram_pct * 0.2) + gpu_weight + (active_jobs * 15)
    return round(score, 1)

def find_best_node(job_type, required_tags=None, preferred_model=None):
    """Find the best available node for a job"""
    with NODES_LOCK:
        candidates = []
        for node_id, node in NODES.items():
            if node.get("status") != "online":
                continue
            # Check if node has been seen recently (within 30s)
            last_seen = node.get("last_seen", 0)
            if time.time() - last_seen > 30:
                node["status"] = "offline"
                continue

            # Check required tags
            node_tags = node.get("tags", [])
            if required_tags:
                if not all(t in node_tags for t in required_tags):
                    continue

            # Prefer nodes that already have the model pulled
            score = compute_dispatch_score(node)
            if preferred_model:
                models = node.get("capabilities", {}).get("ollama_models", [])
                if preferred_model not in models:
                    score += 20  # Penalty for model not present

            candidates.append((score, node_id, node))

        if not candidates:
            return None

        candidates.sort(key=lambda x: x[0])
        return candidates[0][1], candidates[0][2]

# ─── Persistence ──────────────────────────────────────────────────
def save_state():
    os.makedirs(DATA_DIR, exist_ok=True)
    with open(os.path.join(DATA_DIR, "nodes.json"), "w") as f:
        json.dump(NODES, f, indent=2)

def load_state():
    global NODES
    nodes_file = os.path.join(DATA_DIR, "nodes.json")
    if os.path.exists(nodes_file):
        try:
            with open(nodes_file) as f:
                NODES = json.load(f)
            # Mark all nodes as offline on startup — they'll re-register
            for node in NODES.values():
                node["status"] = "offline"
        except: pass

# ─── Routes ──────────────────────────────────────────────────────
@app.route("/health")
def health():
    with NODES_LOCK:
        online = sum(1 for n in NODES.values() if n.get("status") == "online")
        total = len(NODES)
    with JOBS_LOCK:
        running = sum(1 for j in JOBS.values() if j.get("status") == "running")
        queued = sum(1 for j in JOBS.values() if j.get("status") == "queued")
    return jsonify({
        "status": "ok",
        "service": "TRIDENT GRID Coordinator",
        "version": COORDINATOR_VERSION,
        "nodes_online": online,
        "nodes_total": total,
        "jobs_running": running,
        "jobs_queued": queued,
        "timestamp": datetime.datetime.utcnow().isoformat()
    })

@app.route("/nodes/register", methods=["POST"])
def register_node():
    """Worker node registration endpoint"""
    data = request.get_json()
    if data.get("secret") != COORDINATOR_SECRET:
        return jsonify({"error": "Invalid secret"}), 403

    node_id = data.get("node_id") or str(uuid.uuid4())[:8]
    caps = data.get("capabilities", {})

    with NODES_LOCK:
        NODES[node_id] = {
            "node_id": node_id,
            "name": data.get("name", f"node-{node_id}"),
            "ip": request.remote_addr,
            "port": data.get("port", 5008),
            "status": "online",
            "capabilities": caps,
            "tags": compute_capability_tags({"capabilities": caps}),
            "last_seen": time.time(),
            "registered_at": datetime.datetime.utcnow().isoformat(),
            "last_metrics": {},
            "jobs_completed": 0,
            "jobs_failed": 0,
            "avg_job_time_s": {}
        }
        save_state()

    print(f"[ GRID ] Node registered: {data.get('name')} ({request.remote_addr}) tags={NODES[node_id]['tags']}", flush=True)
    return jsonify({"ok": True, "node_id": node_id, "coordinator_version": COORDINATOR_VERSION})

@app.route("/nodes/heartbeat", methods=["POST"])
def node_heartbeat():
    """Receive heartbeat + metrics from worker node"""
    data = request.get_json()
    node_id = data.get("node_id")
    if not node_id or node_id not in NODES:
        return jsonify({"error": "Unknown node"}), 404

    with NODES_LOCK:
        NODES[node_id]["last_seen"] = time.time()
        NODES[node_id]["status"] = "online"
        NODES[node_id]["last_metrics"] = data.get("metrics", {})
        # Update Ollama models list if provided
        if "ollama_models" in data:
            NODES[node_id]["capabilities"]["ollama_models"] = data["ollama_models"]

    # Check for pending jobs for this node
    pending = []
    with JOBS_LOCK:
        for job_id, job in JOBS.items():
            if job.get("assigned_node") == node_id and job.get("status") == "queued":
                pending.append(job_id)

    return jsonify({"ok": True, "pending_jobs": pending})

@app.route("/nodes")
def list_nodes():
    """List all registered nodes"""
    with NODES_LOCK:
        nodes = []
        for node in NODES.values():
            last_seen = node.get("last_seen", 0)
            if time.time() - last_seen > 30 and node.get("status") == "online":
                node["status"] = "offline"
            n = dict(node)
            n["dispatch_score"] = compute_dispatch_score(node)
            n["last_seen_ago_s"] = round(time.time() - last_seen)
            nodes.append(n)
    return jsonify({"nodes": nodes, "count": len(nodes)})

@app.route("/nodes/<node_id>", methods=["DELETE"])
def remove_node(node_id):
    with NODES_LOCK:
        if node_id in NODES:
            del NODES[node_id]
            save_state()
    return jsonify({"ok": True})

@app.route("/jobs/submit", methods=["POST"])
def submit_job():
    """Submit a job for distributed execution"""
    data = request.get_json()
    job_type = data.get("type", "llm")  # llm, extract, imggen, stt
    payload = data.get("payload", {})
    required_tags = data.get("required_tags", [])
    preferred_model = data.get("preferred_model")

    # Map job types to required tags
    type_tags = {
        "llm": ["OLLAMA"],
        "llm-gpu": ["GPU-LLM", "OLLAMA"],
        "imggen": ["GPU-IMGGEN"],
        "stt": ["GPU-STT"],
        "extract": [],  # any node
        "fetch": [],    # any node
    }
    required = required_tags or type_tags.get(job_type, [])

    job_id = str(uuid.uuid4())[:12]
    result = find_best_node(job_type, required, preferred_model)

    with JOBS_LOCK:
        job = {
            "job_id": job_id,
            "type": job_type,
            "payload": payload,
            "status": "queued" if result else "no_node",
            "assigned_node": result[0] if result else None,
            "created_at": datetime.datetime.utcnow().isoformat(),
            "started_at": None,
            "completed_at": None,
            "result": None,
            "error": None,
        }
        JOBS[job_id] = job

    if result:
        node_id, node = result
        # Fire and forget — send job to worker
        threading.Thread(target=dispatch_to_worker, args=(job_id, node_id, node, payload, job_type), daemon=True).start()
        return jsonify({"job_id": job_id, "status": "dispatched", "node": node.get("name"), "node_ip": node.get("ip")})
    else:
        return jsonify({"job_id": job_id, "status": "no_node_available", "fallback": "local"}), 202

def dispatch_to_worker(job_id, node_id, node, payload, job_type):
    """Send job to worker node"""
    try:
        worker_url = f"http://{node['ip']}:{node['port']}/job/run"
        with JOBS_LOCK:
            JOBS[job_id]["status"] = "running"
            JOBS[job_id]["started_at"] = datetime.datetime.utcnow().isoformat()

        res = requests.post(worker_url, json={"job_id": job_id, "type": job_type, "payload": payload, "secret": COORDINATOR_SECRET}, timeout=300)

        if res.status_code == 200:
            result = res.json()
            with JOBS_LOCK:
                JOBS[job_id]["status"] = "completed"
                JOBS[job_id]["completed_at"] = datetime.datetime.utcnow().isoformat()
                JOBS[job_id]["result"] = result
            with NODES_LOCK:
                if node_id in NODES:
                    NODES[node_id]["jobs_completed"] = NODES[node_id].get("jobs_completed", 0) + 1
        else:
            with JOBS_LOCK:
                JOBS[job_id]["status"] = "failed"
                JOBS[job_id]["error"] = f"Worker returned {res.status_code}"
    except Exception as e:
        with JOBS_LOCK:
            JOBS[job_id]["status"] = "failed"
            JOBS[job_id]["error"] = str(e)
        with NODES_LOCK:
            if node_id in NODES:
                NODES[node_id]["jobs_failed"] = NODES[node_id].get("jobs_failed", 0) + 1

@app.route("/jobs")
def list_jobs():
    limit = int(request.args.get("limit", 50))
    with JOBS_LOCK:
        jobs = sorted(JOBS.values(), key=lambda j: j.get("created_at", ""), reverse=True)[:limit]
    return jsonify({"jobs": list(jobs), "total": len(JOBS)})

@app.route("/jobs/<job_id>")
def get_job(job_id):
    with JOBS_LOCK:
        job = JOBS.get(job_id)
    if not job:
        return jsonify({"error": "Job not found"}), 404
    return jsonify(job)

@app.route("/dispatch/test", methods=["POST"])
def test_dispatch():
    """Test dispatch — find best node without actually running job"""
    data = request.get_json() or {}
    job_type = data.get("type", "llm")
    model = data.get("model")
    result = find_best_node(job_type, [], model)
    if result:
        node_id, node = result
        return jsonify({"best_node": node.get("name"), "node_id": node_id, "score": compute_dispatch_score(node), "tags": node.get("tags", [])})
    return jsonify({"best_node": None, "message": "No eligible nodes online"})

# ─── Background health monitor ────────────────────────────────────
def health_monitor():
    while True:
        time.sleep(15)
        with NODES_LOCK:
            for node in NODES.values():
                last_seen = node.get("last_seen", 0)
                if time.time() - last_seen > 30:
                    if node.get("status") == "online":
                        print(f"[ GRID ] Node offline: {node.get('name')}", flush=True)
                    node["status"] = "offline"

if __name__ == "__main__":
    load_state()
    print(f"[ TRIDENT GRID ] Coordinator starting on port 5007")
    threading.Thread(target=health_monitor, daemon=True).start()
    app.run(host="0.0.0.0", port=5007, debug=False)  # 0.0.0.0 so workers can reach it
