#!/usr/bin/env bash
set -euo pipefail

# ─────────────────────────────────────────────────────────────
#  TRIDENT Security Brief Intelligence Service — Setup
# ─────────────────────────────────────────────────────────────
cat << 'BANNER'
   ______________  ______  ___________   ________
  /_  __/ __ \/  _/ __ \/ ____/ | / /_  __/
   / / / /_/ // // / / / __/ /  |/ / / /
  / / / _, _// // /_/ / /___/ /|  / / /
 /_/ /_/ |_/___/_____/_____/_/ |_/ /_/
    B R I E F   I N T E L L I G E N C E   [ PORT 5006 ]
BANNER

# Install deps into a dedicated briefs venv
python3 -m venv /opt/trident-briefs-svc/venv 2>/dev/null || true
/opt/trident-briefs-svc/venv/bin/pip install --quiet \
  flask flask-cors requests pdfplumber PyPDF2 mammoth beautifulsoup4

# Copy service file
mkdir -p /opt/trident-briefs-svc
cp /opt/trident/scripts/brief_service.py /opt/trident-briefs-svc/brief_service.py

# Ensure NAS intel folders exist
mkdir -p /mnt/trident-briefs/_web-intel 2>/dev/null || true
mkdir -p /mnt/trident-briefs/_drafts 2>/dev/null || true

# Systemd service
cat > /etc/systemd/system/trident-briefs.service << 'EOF'
[Unit]
Description=TRIDENT Brief Intelligence Service
After=network.target trident.service

[Service]
Type=simple
User=root
WorkingDirectory=/opt/trident-briefs-svc
EnvironmentFile=/etc/trident/config.env
Environment=NAS_BRIEFS_PATH=/mnt/trident-briefs
ExecStart=/opt/trident-briefs-svc/venv/bin/python3 /opt/trident-briefs-svc/brief_service.py
Restart=always
RestartSec=10
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable trident-briefs
systemctl start trident-briefs
sleep 3
systemctl status trident-briefs --no-pager | head -5
curl -s http://localhost:5006/health
echo ""
echo "[ TRIDENT ] Brief Intelligence Service online"
