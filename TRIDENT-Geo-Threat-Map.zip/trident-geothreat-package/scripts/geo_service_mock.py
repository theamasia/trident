#!/usr/bin/env python3
"""
Mock harness for testing /gdelt/country-summary without live GDELT network access.
Imports the real geo_service module (with our COUNTRY_COORDS + geocode_country changes)
and monkeypatches the outbound `requests.get` call so the enrichment logic runs for real,
using representative sample GDELT article data.
"""
import sys, os, json
sys.path.insert(0, os.path.dirname(__file__))

import geo_service as gs

SAMPLE_ARTICLES = (
    [{"sourcecountry": "Ukraine"}] * 42 +
    [{"sourcecountry": "Israel"}] * 31 +
    [{"sourcecountry": "Iran"}] * 18 +
    [{"sourcecountry": "Russia"}] * 15 +
    [{"sourcecountry": "Gaza Strip"}] * 12 +
    [{"sourcecountry": "Lebanon"}] * 9 +
    [{"sourcecountry": "Syria"}] * 7 +
    [{"sourcecountry": "Taiwan"}] * 6 +
    [{"sourcecountry": "North Korea"}] * 5 +
    [{"sourcecountry": "Yemen"}] * 5 +
    [{"sourcecountry": "Sudan"}] * 4 +
    [{"sourcecountry": "Freedonia"}] * 3  # unknown/ungeocodable, to test partial-geocode path
)

class FakeResponse:
    def json(self):
        return {"articles": SAMPLE_ARTICLES}

def fake_get(*args, **kwargs):
    return FakeResponse()

gs.requests.get = fake_get

if __name__ == "__main__":
    print("[ MOCK ] Geo-Intelligence Service (GDELT network calls stubbed) starting on port 5003")
    gs.app.run(host="127.0.0.1", port=5003, debug=False)
