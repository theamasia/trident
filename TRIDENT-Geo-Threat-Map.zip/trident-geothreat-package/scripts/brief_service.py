#!/usr/bin/env python3
"""
TRIDENT Security Brief Intelligence Service
Handles NAS folder scanning, file text extraction, web feed fetching
Runs on port 5006
"""
import os, time, datetime, hashlib, json, mimetypes
import threading
import requests
from flask import Flask, jsonify, request
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

NAS_BASE = os.environ.get("NAS_BRIEFS_PATH", "/mnt/trident-briefs")
CACHE = {}

# ─── File text extraction ────────────────────────────────────────
def extract_text(filepath):
    """Extract text from various file types"""
    ext = os.path.splitext(filepath)[1].lower()
    try:
        if ext in ['.txt', '.md', '.csv', '.log', '.json']:
            with open(filepath, 'r', errors='ignore') as f:
                return f.read()[:50000]
        
        elif ext == '.pdf':
            try:
                import pdfplumber
                with pdfplumber.open(filepath) as pdf:
                    return '\n'.join(page.extract_text() or '' for page in pdf.pages)[:50000]
            except ImportError:
                try:
                    import PyPDF2
                    with open(filepath, 'rb') as f:
                        reader = PyPDF2.PdfReader(f)
                        return '\n'.join(page.extract_text() or '' for page in reader.pages)[:50000]
                except: return f"[PDF: {os.path.basename(filepath)} — install pdfplumber for extraction]"
        
        elif ext in ['.docx', '.doc']:
            try:
                import mammoth
                with open(filepath, 'rb') as f:
                    result = mammoth.extract_raw_text(f)
                    return result.value[:50000]
            except: return f"[DOCX: {os.path.basename(filepath)} — install mammoth for extraction]"
        
        elif ext in ['.jpg', '.jpeg', '.png', '.gif', '.bmp', '.webp']:
            return f"[IMAGE: {os.path.basename(filepath)} — visual content, {os.path.getsize(filepath)} bytes]"
        
        elif ext in ['.url']:
            # Windows .url shortcut files contain the URL
            with open(filepath, 'r', errors='ignore') as f:
                for line in f:
                    if line.startswith('URL='):
                        url = line[4:].strip()
                        return fetch_url_content(url)
            return f"[URL file: no URL found]"
        
        elif ext in ['.html', '.htm']:
            try:
                from bs4 import BeautifulSoup
                with open(filepath, 'r', errors='ignore') as f:
                    soup = BeautifulSoup(f.read(), 'html.parser')
                    return soup.get_text(separator='\n')[:50000]
            except: 
                with open(filepath, 'r', errors='ignore') as f:
                    return f.read()[:50000]
        
        else:
            return f"[{ext.upper()} file: {os.path.basename(filepath)} — text extraction not supported]"
    except Exception as e:
        return f"[Error reading {os.path.basename(filepath)}: {str(e)}]"

def fetch_url_content(url):
    """Fetch and extract text from a URL"""
    try:
        res = requests.get(url, timeout=15, headers={'User-Agent': 'TRIDENT/1.0'})
        from bs4 import BeautifulSoup
        soup = BeautifulSoup(res.content, 'html.parser')
        # Remove scripts/styles
        for tag in soup(['script', 'style', 'nav', 'footer']):
            tag.decompose()
        return soup.get_text(separator='\n', strip=True)[:30000]
    except Exception as e:
        return f"[URL fetch error: {str(e)}]"

# ─── NAS folder scanning ─────────────────────────────────────────
SUPPORTED_EXTENSIONS = {'.txt', '.md', '.csv', '.pdf', '.docx', '.doc', 
                         '.jpg', '.jpeg', '.png', '.gif', '.url', '.html', 
                         '.htm', '.json', '.log'}
SKIP_DIRS = {'_briefs', '_web-intel', '_drafts', 'aviation', 'markets', 
              'geo-intel', 'weather', 'uploads'}
SKIP_FILES = {'flights.db', 'flights.db-journal', 'test.txt', 'test-write.txt'}

@app.route("/health")
def health():
    nas_ok = os.path.ismount(NAS_BASE) or os.path.exists(NAS_BASE)
    return jsonify({"status": "ok", "service": "TRIDENT Brief Intelligence", "nas_available": nas_ok, "nas_path": NAS_BASE})

@app.route("/topics")
def list_topics():
    """List all intel topic folders on the NAS"""
    try:
        topics = []
        if not os.path.exists(NAS_BASE):
            return jsonify({"topics": [], "error": "NAS not mounted"})
        
        for entry in sorted(os.scandir(NAS_BASE), key=lambda e: e.name):
            if not entry.is_dir() or entry.name.startswith('_') or entry.name in SKIP_DIRS:
                continue
            
            files = []
            total_size = 0
            for f in os.scandir(entry.path):
                if f.is_file() and f.name not in SKIP_FILES:
                    ext = os.path.splitext(f.name)[1].lower()
                    if ext in SUPPORTED_EXTENSIONS or ext == '':
                        files.append({
                            "name": f.name,
                            "ext": ext,
                            "size": f.stat().st_size,
                            "modified": datetime.datetime.fromtimestamp(f.stat().st_mtime).isoformat()
                        })
                        total_size += f.stat().st_size
            
            briefs_dir = os.path.join(entry.path, '_briefs')
            brief_count = len(os.listdir(briefs_dir)) if os.path.exists(briefs_dir) else 0
            
            topics.append({
                "name": entry.name,
                "path": entry.path,
                "file_count": len(files),
                "files": files,
                "total_size_kb": round(total_size / 1024, 1),
                "brief_count": brief_count,
                "modified": datetime.datetime.fromtimestamp(entry.stat().st_mtime).isoformat()
            })
        
        return jsonify({"topics": topics, "count": len(topics)})
    except Exception as e:
        return jsonify({"topics": [], "error": str(e)})

@app.route("/topic/<topic>/extract")
def extract_topic(topic):
    """Extract text from all files in a topic folder"""
    topic_path = os.path.join(NAS_BASE, topic)
    if not os.path.exists(topic_path):
        return jsonify({"error": f"Topic '{topic}' not found"}), 404
    
    documents = []
    for f in sorted(os.scandir(topic_path), key=lambda e: e.name):
        if not f.is_file() or f.name in SKIP_FILES:
            continue
        ext = os.path.splitext(f.name)[1].lower()
        if ext not in SUPPORTED_EXTENSIONS:
            continue
        
        text = extract_text(f.path)
        file_hash = hashlib.md5(f.name.encode()).hexdigest()[:8]
        documents.append({
            "id": file_hash,
            "name": f.name,
            "ext": ext,
            "size": f.stat().st_size,
            "text": text,
            "text_length": len(text),
            "modified": datetime.datetime.fromtimestamp(f.stat().st_mtime).isoformat()
        })
    
    return jsonify({
        "topic": topic,
        "documents": documents,
        "total_docs": len(documents),
        "total_chars": sum(d["text_length"] for d in documents)
    })

@app.route("/topic/<topic>/briefs")
def list_topic_briefs(topic):
    """List generated briefs for a topic"""
    briefs_dir = os.path.join(NAS_BASE, topic, '_briefs')
    if not os.path.exists(briefs_dir):
        return jsonify({"briefs": []})
    
    briefs = []
    for f in sorted(os.scandir(briefs_dir), key=lambda e: e.stat().st_mtime, reverse=True):
        if f.is_file() and f.name.endswith('.md'):
            briefs.append({
                "name": f.name,
                "size": f.stat().st_size,
                "created": datetime.datetime.fromtimestamp(f.stat().st_mtime).isoformat()
            })
    return jsonify({"topic": topic, "briefs": briefs})

@app.route("/topic/<topic>/brief/<brief_name>")
def get_brief(topic, brief_name):
    """Get content of a specific brief"""
    brief_path = os.path.join(NAS_BASE, topic, '_briefs', brief_name)
    if not os.path.exists(brief_path):
        return jsonify({"error": "Brief not found"}), 404
    with open(brief_path, 'r', errors='ignore') as f:
        return jsonify({"topic": topic, "name": brief_name, "content": f.read()})

@app.route("/topic/<topic>/mkdir", methods=["POST"])
def make_topic(topic):
    """Create a topic folder on the NAS"""
    try:
        topic_path = os.path.join(NAS_BASE, topic)
        os.makedirs(topic_path, exist_ok=True)
        os.makedirs(os.path.join(topic_path, '_briefs'), exist_ok=True)
        return jsonify({"ok": True, "path": topic_path})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 500

@app.route("/topic/<topic>", methods=["DELETE"])
def delete_topic(topic):
    """Delete a topic folder on the NAS"""
    try:
        import shutil
        topic_path = os.path.join(NAS_BASE, topic)
        if os.path.exists(topic_path):
            shutil.rmtree(topic_path)
        return jsonify({"ok": True})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 500

@app.route("/topic/<topic>/brief/save", methods=["POST"])
def save_brief(topic):
    """Save a generated brief .md file to a topic's _briefs folder"""
    try:
        data = request.get_json() or {}
        name = data.get("name", f"brief-{datetime.datetime.utcnow().strftime('%Y%m%d-%H%M%S')}.md")
        content = data.get("content", "")
        briefs_dir = os.path.join(NAS_BASE, topic, '_briefs')
        os.makedirs(briefs_dir, exist_ok=True)
        brief_path = os.path.join(briefs_dir, name)
        with open(brief_path, 'w', errors='ignore') as f:
            f.write(content)
        return jsonify({"ok": True, "path": brief_path, "name": name})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 500

@app.route("/web-intel/save", methods=["POST"])
def save_web_intel():
    """Save a web-intel feed brief .md file to _web-intel folder"""
    try:
        data = request.get_json() or {}
        name = data.get("name", f"web-brief-{datetime.datetime.utcnow().strftime('%Y%m%d-%H%M%S')}.md")
        content = data.get("content", "")
        wi_dir = os.path.join(NAS_BASE, '_web-intel')
        os.makedirs(wi_dir, exist_ok=True)
        brief_path = os.path.join(wi_dir, name)
        with open(brief_path, 'w', errors='ignore') as f:
            f.write(content)
        return jsonify({"ok": True, "path": brief_path, "name": name})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 500

@app.route("/feeds")
def list_feeds():
    """List configured web intel feeds from feeds.json on NAS"""
    feeds_path = os.path.join(NAS_BASE, '_web-intel', 'feeds.json')
    if not os.path.exists(feeds_path):
        return jsonify({"feeds": []})
    try:
        with open(feeds_path) as f:
            data = json.load(f)
        return jsonify({"feeds": data.get("feeds", [])})
    except Exception as e:
        return jsonify({"feeds": [], "error": str(e)})

@app.route("/feeds", methods=["POST"])
def save_feeds():
    """Save web intel feeds configuration and (re)start polling for each feed"""
    os.makedirs(os.path.join(NAS_BASE, '_web-intel'), exist_ok=True)
    feeds_path = os.path.join(NAS_BASE, '_web-intel', 'feeds.json')
    data = request.get_json() or {}

    # Normalize feed schema — ensure poll_interval_hours is present on each feed
    feeds = data.get("feeds", [])
    for feed in feeds:
        if "poll_interval_hours" not in feed:
            feed["poll_interval_hours"] = 6
    data["feeds"] = feeds

    with open(feeds_path, 'w') as f:
        json.dump(data, f, indent=2)

    # Immediately start polling any newly-saved feeds
    started = []
    for feed in feeds:
        name = feed.get("name", "")
        url = feed.get("url", "")
        interval = feed.get("poll_interval_hours", 6)
        if name and url and interval and name not in POLL_THREADS:
            t = threading.Thread(target=poll_feed, args=(name, url, interval), daemon=True)
            t.start()
            POLL_THREADS[name] = t
            started.append(name)

    return jsonify({"ok": True, "started_polling": started})

@app.route("/feed/fetch")
def fetch_feed():
    """Fetch content from a URL for web intel"""
    url = request.args.get("url", "")
    if not url:
        return jsonify({"error": "No URL provided"}), 400
    try:
        content = fetch_url_content(url)
        return jsonify({"url": url, "content": content, "length": len(content), "fetched_at": datetime.datetime.utcnow().isoformat()})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# ─── Archive helpers ──────────────────────────────────────
def get_feed_archive_dir(feed_name):
    """Get the NAS archive folder for a feed"""
    # Sanitize name for filesystem
    safe_name = "".join(c if c.isalnum() or c in "-_" else "-" for c in feed_name.lower())
    return os.path.join(NAS_BASE, "_web-intel", safe_name)

def archive_feed_content(feed_name, url, content):
    """Save fetched content to NAS archive"""
    archive_dir = get_feed_archive_dir(feed_name)
    os.makedirs(archive_dir, exist_ok=True)

    now = datetime.datetime.utcnow()
    date_str = now.strftime("%Y-%m-%d")
    time_str = now.strftime("%H%M%S")
    filename = f"{date_str}-{time_str}.md"
    filepath = os.path.join(archive_dir, filename)

    # Write markdown archive
    doc = f"""# {feed_name} — {now.strftime("%Y-%m-%d %H:%M:%S")} UTC
Source: {url}
Archived: {now.isoformat()}
{'=' * 60}

{content}

{'=' * 60}
ARCHIVED BY TRIDENT // INTEL BRIEFS
"""
    with open(filepath, "w", encoding="utf-8", errors="replace") as f:
        f.write(doc)

    return filepath, filename

@app.route("/feed/fetch-and-archive", methods=["POST"])
def fetch_and_archive():
    """Fetch URL, save to NAS archive, return content"""
    data = request.get_json() or {}
    url = data.get("url", "")
    feed_name = data.get("name", "unknown-feed")

    if not url:
        return jsonify({"error": "No URL provided"}), 400

    try:
        content = fetch_url_content(url)
        filepath, filename = archive_feed_content(feed_name, url, content)
        return jsonify({
            "url": url,
            "content": content,
            "length": len(content),
            "archived_file": filename,
            "archived_path": filepath,
            "fetched_at": datetime.datetime.utcnow().isoformat()
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/feed/archive/<feed_name>")
def list_feed_archive(feed_name):
    """List archived files for a feed"""
    archive_dir = get_feed_archive_dir(feed_name)
    if not os.path.exists(archive_dir):
        return jsonify({"files": [], "feed": feed_name})

    files = []
    for f in sorted(os.scandir(archive_dir), key=lambda e: e.stat().st_mtime, reverse=True):
        if f.is_file() and f.name.endswith(".md"):
            files.append({
                "name": f.name,
                "size_kb": round(f.stat().st_size / 1024, 1),
                "created": datetime.datetime.fromtimestamp(f.stat().st_mtime).isoformat()
            })

    return jsonify({
        "feed": feed_name,
        "files": files,
        "count": len(files),
        "archive_dir": archive_dir
    })

@app.route("/feed/archive/<feed_name>/latest")
def get_latest_archive(feed_name):
    """Get the most recently archived file for a feed"""
    archive_dir = get_feed_archive_dir(feed_name)
    if not os.path.exists(archive_dir):
        return jsonify({"error": "No archive found", "content": None})

    files = sorted(
        [f for f in os.scandir(archive_dir) if f.is_file() and f.name.endswith(".md")],
        key=lambda e: e.stat().st_mtime, reverse=True
    )

    if not files:
        return jsonify({"error": "No archives yet", "content": None})

    latest = files[0]
    with open(latest.path, "r", encoding="utf-8", errors="replace") as f:
        content = f.read()

    return jsonify({
        "feed": feed_name,
        "filename": latest.name,
        "created": datetime.datetime.fromtimestamp(latest.stat().st_mtime).isoformat(),
        "content": content
    })

@app.route("/feed/archive/<feed_name>/<filename>")
def get_archived_file(feed_name, filename):
    """Get content of a specific archived file"""
    # Security: only allow .md files, no path traversal
    if ".." in filename or "/" in filename or not filename.endswith(".md"):
        return jsonify({"error": "Invalid filename"}), 400

    archive_dir = get_feed_archive_dir(feed_name)
    filepath = os.path.join(archive_dir, filename)

    if not os.path.exists(filepath):
        return jsonify({"error": "File not found"}), 404

    with open(filepath, "r", encoding="utf-8", errors="replace") as f:
        content = f.read()

    return jsonify({"feed": feed_name, "filename": filename, "content": content})

# ─── Auto-poll scheduler ───────────────────────────────────
POLL_THREADS = {}

def poll_feed(feed_name, url, interval_hours=6):
    """Background thread that polls a feed on schedule"""
    print(f"[ TRIDENT BRIEFS ] Auto-poll started: {feed_name} every {interval_hours}h", flush=True)
    while True:
        try:
            content = fetch_url_content(url)
            archive_feed_content(feed_name, url, content)
            print(f"[ TRIDENT BRIEFS ] Archived: {feed_name} ({len(content)} chars)", flush=True)
        except Exception as e:
            print(f"[ TRIDENT BRIEFS ] Poll error for {feed_name}: {e}", flush=True)
        time.sleep(interval_hours * 3600)

@app.route("/feeds/start-polling", methods=["POST"])
def start_polling():
    """Start background polling for all configured feeds"""
    feeds_path = os.path.join(NAS_BASE, "_web-intel", "feeds.json")
    if not os.path.exists(feeds_path):
        return jsonify({"started": 0, "message": "No feeds configured"})

    try:
        with open(feeds_path) as f:
            data = json.load(f)
        feeds = data.get("feeds", [])
        started = 0
        for feed in feeds:
            name = feed.get("name", "")
            url = feed.get("url", "")
            interval = feed.get("poll_interval_hours", 6)
            if name and url and interval and name not in POLL_THREADS:
                t = threading.Thread(target=poll_feed, args=(name, url, interval), daemon=True)
                t.start()
                POLL_THREADS[name] = t
                started += 1
        return jsonify({"started": started, "total_feeds": len(feeds), "active_polls": list(POLL_THREADS.keys())})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/feeds/poll-status")
def poll_status():
    """List active polling threads"""
    return jsonify({
        "active_polls": list(POLL_THREADS.keys()),
        "count": len(POLL_THREADS)
    })

if __name__ == "__main__":
    print("[ TRIDENT ] Brief Intelligence Service starting on port 5006")
    # Auto-start feed polling shortly after boot (once Flask is accepting requests)
    def _autostart_polling():
        time.sleep(5)
        try:
            requests.post("http://localhost:5006/feeds/start-polling", timeout=30)
        except Exception as e:
            print(f"[ TRIDENT BRIEFS ] Auto-start polling failed: {e}", flush=True)
    threading.Thread(target=_autostart_polling, daemon=True).start()
    app.run(host="127.0.0.1", port=5006, debug=False)
