#!/usr/bin/env bash
#
# TRIDENT Radio Ops Aggregator Service — installer
# Installs the Python radio ops aggregator (Trunk Recorder/VIPER P25 + dump1090 ADS-B + rtl_433 MQTT)
# as a systemd unit on port 5010. Polls the SDR node (default 192.168.0.172) for all three feeds.
#
set -euo pipefail

SERVICE_NAME="trident-radio-ops"
INSTALL_DIR="/opt/trident-radio-ops"
VENV_DIR="${INSTALL_DIR}/venv"
CONFIG_ENV="/etc/trident/config.env"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PORT=5010

echo "[ TRIDENT ] ═══ Radio Ops Aggregator Service Setup ═══"

# ── 1. Directories ──
echo "[ TRIDENT ] Creating ${INSTALL_DIR} ..."
sudo mkdir -p "${INSTALL_DIR}"
sudo mkdir -p "$(dirname "${CONFIG_ENV}")"

# ── 2. Python venv + dependencies ──
echo "[ TRIDENT ] Building virtualenv at ${VENV_DIR} ..."
sudo python3 -m venv "${VENV_DIR}"
sudo "${VENV_DIR}/bin/pip" install --upgrade pip
sudo "${VENV_DIR}/bin/pip" install flask flask-cors requests paho-mqtt

# ── 3. Deploy service code ──
echo "[ TRIDENT ] Copying radio_ops_service.py ..."
sudo cp "${SCRIPT_DIR}/radio_ops_service.py" "${INSTALL_DIR}/radio_ops_service.py"

# ── 4. Ensure config env exists ──
if [ ! -f "${CONFIG_ENV}" ]; then
  echo "[ TRIDENT ] Creating ${CONFIG_ENV} ..."
  sudo tee "${CONFIG_ENV}" > /dev/null <<'ENVEOF'
# TRIDENT Radio Ops config
# SDR node running Trunk Recorder (VIPER/P25), dump1090 (ADS-B), and rtl_433 (MQTT).
# Override any of these to point at a different SDR node or non-default ports/paths.
SDR_NODE_HOST=192.168.0.172
VIPER_PORT=9001
VIPER_PATH=/api/radio/viper/calls
ADSB_PORT=8080
ADSB_PATH=/data/aircraft.json
MQTT_HOST=192.168.0.172
MQTT_PORT=1883
MQTT_TOPIC_PREFIX=rtl_433
ENVEOF
else
  echo "[ TRIDENT ] ${CONFIG_ENV} already exists — leaving untouched."
fi

# ── 5. systemd unit ──
echo "[ TRIDENT ] Installing systemd unit ${SERVICE_NAME} ..."
sudo tee "/etc/systemd/system/${SERVICE_NAME}.service" > /dev/null <<EOF
[Unit]
Description=TRIDENT Radio Ops Aggregator Service (port ${PORT})
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
WorkingDirectory=${INSTALL_DIR}
EnvironmentFile=${CONFIG_ENV}
ExecStart=${VENV_DIR}/bin/python ${INSTALL_DIR}/radio_ops_service.py
Restart=always
RestartSec=5
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
EOF

# ── 6. Enable + start ──
echo "[ TRIDENT ] Reloading systemd and starting service ..."
sudo systemctl daemon-reload
sudo systemctl enable "${SERVICE_NAME}"
sudo systemctl restart "${SERVICE_NAME}"

# ── 7. Health check ──
echo "[ TRIDENT ] Waiting for service to come online ..."
sleep 3
echo "[ TRIDENT ] Health check:"
curl -fsS "http://127.0.0.1:${PORT}/health" && echo "" || {
  echo "[ TRIDENT ] Health check FAILED — inspect: sudo journalctl -u ${SERVICE_NAME} -n 50"
  exit 1
}

echo "[ TRIDENT ] ═══ Radio Ops Aggregator Service installed on port ${PORT} ═══"
echo "[ TRIDENT ] NOTE: Feeds will report 'offline' until the SDR node at \$SDR_NODE_HOST is reachable."
echo "[ TRIDENT ] Edit ${CONFIG_ENV} to point at a different SDR node without touching code."
