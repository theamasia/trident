#!/usr/bin/env python3
"""
TRIDENT GRID Worker Agent
Self-contained single-file worker node
Deploys via: curl http://COORDINATOR/api/grid/install.sh | sudo bash
Runs on port 5008
"""
import os, sys, time, datetime, json, threading, subprocess, platform
import requests
from flask import Flask, jsonify, request
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

# ─── Config ───────────────────────────────────────────────────────
COORDINATOR_URL = os.environ.get("TRIDENT_COORDINATOR", "http://192.168.0.7:5007")
COORDINATOR_SECRET = os.environ.get("GRID_SECRET", "trident-grid-secret-2026")
WORKER_PORT = int(os.environ.get("WORKER_PORT", "5008"))
NODE_NAME = os.environ.get("NODE_NAME", platform.node())
NODE_ID = os.environ.get("NODE_ID", "")  # Set after first registration
DATA_DIR = os.environ.get("WORKER_DATA_DIR", "/opt/trident-worker")

# ─── Hardware capability detection ───────────────────────────────
def detect_capabilities():
    caps = {}

    # CPU
    try:
        import psutil
        caps["cpu_cores"] = psutil.cpu_count(logical=False) or psutil.cpu_count()
        caps["cpu_threads"] = psutil.cpu_count()
        caps["ram_total_gb"] = round(psutil.virtual_memory().total / (1024**3), 1)
        caps["ram_available_gb"] = round(psutil.virtual_memory().available / (1024**3), 1)
        caps["disk_free_gb"] = round(psutil.disk_usage("/").free / (1024**3), 1)
    except ImportError:
        # Fallback without psutil
        try:
            with open("/proc/cpuinfo") as f:
                cores = len([l for l in f if l.startswith("processor")])
            caps["cpu_cores"] = cores
            caps["cpu_threads"] = cores
        except: caps["cpu_cores"] = 1
        try:
            with open("/proc/meminfo") as f:
                for line in f:
                    if line.startswith("MemTotal"):
                        caps["ram_total_gb"] = round(int(line.split()[1]) / (1024**2), 1)
                    if line.startswith("MemAvailable"):
                        caps["ram_available_gb"] = round(int(line.split()[1]) / (1024**2), 1)
        except: caps["ram_total_gb"] = 8

    # GPU detection
    gpu_info = {"detected": False}
    try:
        result = subprocess.run(
            ["nvidia-smi", "--query-gpu=name,memory.total,memory.free", "--format=csv,noheader,nounits"],
            capture_output=True, text=True, timeout=5
        )
        if result.returncode == 0 and result.stdout.strip():
            parts = result.stdout.strip().split(",")
            if len(parts) >= 3:
                gpu_info = {
                    "detected": True,
                    "name": parts[0].strip(),
                    "vram_total_gb": round(float(parts[1].strip()) / 1024, 1),
                    "vram_free_gb": round(float(parts[2].strip()) / 1024, 1),
                }
    except: pass
    caps["gpu"] = gpu_info

    # Ollama detection
    ollama_available = False
    ollama_models = []
    ollama_url = os.environ.get("OLLAMA_URL", "http://localhost:11434")
    try:
        res = requests.get(f"{ollama_url}/api/tags", timeout=3)
        if res.status_code == 200:
            ollama_available = True
            models_data = res.json().get("models", [])
            ollama_models = [m["name"] for m in models_data]
    except: pass
    caps["ollama_available"] = ollama_available
    caps["ollama_models"] = ollama_models
    caps["ollama_url"] = ollama_url

    # System info
    caps["os"] = platform.system()
    caps["os_version"] = platform.version()[:50]
    caps["python_version"] = sys.version[:20]

    return caps

def get_current_metrics():
    metrics = {}
    try:
        import psutil
        metrics["cpu_pct"] = psutil.cpu_percent(interval=0.5)
        mem = psutil.virtual_memory()
        metrics["ram_pct"] = mem.percent
        metrics["ram_used_gb"] = round(mem.used / (1024**3), 1)
        metrics["ram_available_gb"] = round(mem.available / (1024**3), 1)
    except:
        try:
            with open("/proc/loadavg") as f:
                load = float(f.read().split()[0])
            metrics["cpu_pct"] = min(load * 10, 100)
            metrics["ram_pct"] = 50
        except: metrics["cpu_pct"] = 0

    # GPU metrics
    try:
        result = subprocess.run(
            ["nvidia-smi", "--query-gpu=utilization.gpu,memory.used,memory.free", "--format=csv,noheader,nounits"],
            capture_output=True, text=True, timeout=3
        )
        if result.returncode == 0:
            parts = result.stdout.strip().split(",")
            if len(parts) >= 3:
                metrics["gpu_pct"] = float(parts[0].strip())
                metrics["gpu_vram_used_gb"] = round(float(parts[1].strip()) / 1024, 1)
                metrics["gpu_vram_free_gb"] = round(float(parts[2].strip()) / 1024, 1)
    except: metrics["gpu_pct"] = 0

    return metrics

# ─── Job execution ────────────────────────────────────────────────
def execute_llm_job(payload):
    """Run LLM inference via local Ollama"""
    ollama_url = os.environ.get("OLLAMA_URL", "http://localhost:11434")
    model = payload.get("model", "llama3.2")
    prompt = payload.get("prompt", "")
    messages = payload.get("messages")

    if messages:
        # Chat completion
        res = requests.post(f"{ollama_url}/api/chat", json={"model": model, "messages": messages, "stream": False}, timeout=300)
        data = res.json()
        return {"response": data.get("message", {}).get("content", ""), "model": model, "node": NODE_NAME}
    else:
        # Generate
        res = requests.post(f"{ollama_url}/api/generate", json={"model": model, "prompt": prompt, "stream": False}, timeout=300)
        data = res.json()
        return {"response": data.get("response", ""), "model": model, "node": NODE_NAME}

def execute_extract_job(payload):
    """Extract text from file content (base64 encoded)"""
    import base64, tempfile
    file_content = base64.b64decode(payload.get("content_b64", ""))
    filename = payload.get("filename", "file.txt")
    ext = os.path.splitext(filename)[1].lower()

    with tempfile.NamedTemporaryFile(suffix=ext, delete=False) as tmp:
        tmp.write(file_content)
        tmp_path = tmp.name

    try:
        text = ""
        if ext in ['.txt', '.md', '.csv', '.log']:
            with open(tmp_path, 'r', errors='ignore') as f:
                text = f.read()[:50000]
        elif ext == '.pdf':
            try:
                import pdfplumber
                with pdfplumber.open(tmp_path) as pdf:
                    text = '\n'.join(p.extract_text() or '' for p in pdf.pages)[:50000]
            except: text = f"[PDF extraction failed — install pdfplumber]"
        elif ext in ['.docx']:
            try:
                import mammoth
                with open(tmp_path, 'rb') as f:
                    text = mammoth.extract_raw_text(f).value[:50000]
            except: text = f"[DOCX extraction failed — install mammoth]"
        return {"text": text, "filename": filename, "length": len(text), "node": NODE_NAME}
    finally:
        os.unlink(tmp_path)

def execute_fetch_job(payload):
    """Fetch URL content"""
    url = payload.get("url", "")
    try:
        res = requests.get(url, timeout=15, headers={"User-Agent": "TRIDENT/1.0"})
        try:
            from bs4 import BeautifulSoup
            soup = BeautifulSoup(res.content, 'html.parser')
            for tag in soup(['script', 'style', 'nav', 'footer']): tag.decompose()
            text = soup.get_text(separator='\n', strip=True)[:30000]
        except:
            text = res.text[:30000]
        return {"url": url, "content": text, "length": len(text), "node": NODE_NAME}
    except Exception as e:
        return {"url": url, "error": str(e), "node": NODE_NAME}

# ─── Routes ──────────────────────────────────────────────────────
@app.route("/health")
def health():
    caps = detect_capabilities()
    return jsonify({"status": "ok", "service": "TRIDENT Worker Agent", "name": NODE_NAME, "node_id": NODE_ID, "capabilities_summary": {"gpu": caps["gpu"].get("name", "none"), "ram_gb": caps.get("ram_total_gb", 0), "ollama": caps.get("ollama_available", False)}})

@app.route("/metrics")
def metrics():
    return jsonify(get_current_metrics())

@app.route("/job/run", methods=["POST"])
def run_job():
    """Execute a job dispatched by the coordinator"""
    data = request.get_json()
    if data.get("secret") != COORDINATOR_SECRET:
        return jsonify({"error": "Invalid secret"}), 403

    job_type = data.get("type", "llm")
    payload = data.get("payload", {})

    try:
        if job_type in ["llm", "llm-gpu"]:
            result = execute_llm_job(payload)
        elif job_type == "extract":
            result = execute_extract_job(payload)
        elif job_type in ["fetch"]:
            result = execute_fetch_job(payload)
        else:
            result = {"error": f"Unknown job type: {job_type}"}

        return jsonify({"ok": True, "result": result, "node": NODE_NAME})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e), "node": NODE_NAME}), 500

# ─── Registration & heartbeat ─────────────���───────────────────────
def register_with_coordinator():
    global NODE_ID
    caps = detect_capabilities()

    # Load saved node_id
    id_file = os.path.join(DATA_DIR, "node_id")
    if os.path.exists(id_file):
        with open(id_file) as f:
            NODE_ID = f.read().strip()

    try:
        res = requests.post(f"{COORDINATOR_URL}/nodes/register", json={
            "node_id": NODE_ID or None,
            "name": NODE_NAME,
            "port": WORKER_PORT,
            "capabilities": caps,
            "secret": COORDINATOR_SECRET
        }, timeout=10)

        if res.status_code == 200:
            data = res.json()
            NODE_ID = data.get("node_id", NODE_ID)
            os.makedirs(DATA_DIR, exist_ok=True)
            with open(id_file, "w") as f:
                f.write(NODE_ID)
            print(f"[ WORKER ] Registered with coordinator as {NODE_NAME} (ID: {NODE_ID})", flush=True)
            return True
    except Exception as e:
        print(f"[ WORKER ] Registration failed: {e}", flush=True)
    return False

def heartbeat_loop():
    """Send heartbeat every 10 seconds"""
    global NODE_ID
    # Try registration first
    for attempt in range(5):
        if register_with_coordinator():
            break
        time.sleep(5)

    while True:
        time.sleep(10)
        try:
            # Get Ollama models
            ollama_url = os.environ.get("OLLAMA_URL", "http://localhost:11434")
            try:
                mres = requests.get(f"{ollama_url}/api/tags", timeout=3)
                ollama_models = [m["name"] for m in mres.json().get("models", [])] if mres.status_code == 200 else []
            except: ollama_models = []

            requests.post(f"{COORDINATOR_URL}/nodes/heartbeat", json={
                "node_id": NODE_ID,
                "metrics": get_current_metrics(),
                "ollama_models": ollama_models
            }, timeout=5)
        except: pass

if __name__ == "__main__":
    os.makedirs(DATA_DIR, exist_ok=True)
    print(f"[ TRIDENT WORKER ] Starting agent on port {WORKER_PORT}")
    print(f"[ TRIDENT WORKER ] Coordinator: {COORDINATOR_URL}")
    print(f"[ TRIDENT WORKER ] Node name: {NODE_NAME}")
    threading.Thread(target=heartbeat_loop, daemon=True).start()
    app.run(host="0.0.0.0", port=WORKER_PORT, debug=False)
