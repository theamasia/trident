#!/usr/bin/env bash
set -euo pipefail

# ─────────────────────────────────────────────────────────────
#  TRIDENT GRID Coordinator Service — Setup
#  Distributed compute coordinator on port 5007
# ─────────────────────────────────────────────────────────────
cat << 'BANNER'
   ______________  ______  ___________   ________
  /_  __/ __ \/  _/ __ \/ ____/ | / /_  __/
   / / / /_/ // // / / / __/ /  |/ / / /
  / / / _, _// // /_/ / /___/ /|  / / /
 /_/ /_/ |_/___/_____/_____/_/ |_/ /_/
       G R I D   C O O R D I N A T O R   [ PORT 5007 ]
BANNER

INSTALL_DIR="/opt/trident-grid"
VENV_DIR="$INSTALL_DIR/venv"
CONFIG_DIR="/etc/trident"
CONFIG_ENV="$CONFIG_DIR/config.env"

# Install deps into a dedicated grid venv
mkdir -p "$INSTALL_DIR"
python3 -m venv "$VENV_DIR" 2>/dev/null || true
"$VENV_DIR/bin/pip" install --quiet flask flask-cors requests psutil

# Copy coordinator file
cp /opt/trident/scripts/grid_coordinator.py "$INSTALL_DIR/grid_coordinator.py"

# Ensure config dir + GRID_SECRET present
mkdir -p "$CONFIG_DIR"
touch "$CONFIG_ENV"
if ! grep -q "^GRID_SECRET=" "$CONFIG_ENV" 2>/dev/null; then
  echo "GRID_SECRET=trident-grid-secret-2026" >> "$CONFIG_ENV"
  echo "[ TRIDENT GRID ] Added GRID_SECRET to $CONFIG_ENV"
fi
if ! grep -q "^GRID_DATA_DIR=" "$CONFIG_ENV" 2>/dev/null; then
  echo "GRID_DATA_DIR=$INSTALL_DIR" >> "$CONFIG_ENV"
fi

# Systemd service
cat > /etc/systemd/system/trident-grid.service << 'EOF'
[Unit]
Description=TRIDENT GRID Coordinator
After=network.target trident.service

[Service]
Type=simple
User=root
WorkingDirectory=/opt/trident-grid
EnvironmentFile=/etc/trident/config.env
ExecStart=/opt/trident-grid/venv/bin/python3 /opt/trident-grid/grid_coordinator.py
Restart=always
RestartSec=10
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
EOF

# Open UFW port 5007 so worker nodes on the LAN can reach the coordinator
if command -v ufw >/dev/null 2>&1; then
  ufw allow 5007/tcp || true
  echo "[ TRIDENT GRID ] UFW: opened port 5007/tcp"
fi

systemctl daemon-reload
systemctl enable trident-grid
systemctl start trident-grid
sleep 3
systemctl status trident-grid --no-pager | head -5
echo ""
curl -s http://localhost:5007/health || echo "[ TRIDENT GRID ] Health check pending..."
echo ""
echo "[ TRIDENT GRID ] Coordinator online — workers register at http://192.168.0.7:5007"
