#!/usr/bin/env bash
set -euo pipefail

# ═══════════════════════════════════════════════════════════════════
# TRIDENT — MARKET INTELLIGENCE SERVICE INSTALLER
# Installs the free/open market data microservice (yfinance/FRED/Finnhub)
# Runs on port 5002 (internal), accessed via TRIDENT proxy
# ═══════════════════════════════════════════════════════════════════

# ─── ANSI Color Codes ───────────────────────────────────────────
CYAN='\033[0;36m'
GREEN='\033[0;32m'
AMBER='\033[0;33m'
RED='\033[0;31m'
BOLD='\033[1m'
NC='\033[0m'

info()  { echo -e "${CYAN}[ TRIDENT ]${NC} $1"; }
ok()    { echo -e "${GREEN}[   ✓    ]${NC} $1"; }
warn()  { echo -e "${AMBER}[  WARN  ]${NC} $1"; }
fail()  { echo -e "${RED}[  FAIL  ]${NC} $1"; exit 1; }

echo -e "${BOLD}${CYAN}"
cat << 'BANNER'
  ╔════════════════════════════════════════════════════════════╗
  ║   ▄▄▄█████▓ ██▀███   ██▓▓█████▄ ▓█���███  ███▄    █ ▄▄▄█████▓  ║
  ║   ▓  ██▒ ▓▒▓██ ▒ ██▒▓██▒▒██▀ ██▌▓█   ▀  ██ ▀█   █ ▓  ██▒ ▓▒  ║
  ║   ▒ ▓██░ ▒░▓██ ░▄█ ▒▒██▒░██   █▌▒███   ▓██  ▀█ ██▒▒ ▓██░ ▒░  ║
  ║   ░ ▓██▓ ░ ▒██▀▀█▄  ░██░░▓█▄   ▌▒▓█  ▄ ▓██▒  ▐▌██▒░ ▓██▓ ░   ║
  ║     ▒██▒ ░ ░██▓ ▒██▒░██░░▒████▓ ░▒████▒▒██░   ▓██░  ▒██▒ ░   ║
  ║                                                              ║
  ║        M A R K E T   I N T E L L I G E N C E   v1.0          ║
  ╚════════════════════════════════════════════════════════════╝
BANNER
echo -e "${NC}"

# ─── STEP 1: Dependencies ───────────────────────────────────────
info "Installing Python market data dependencies..."
pip3 install yfinance requests flask flask-cors pandas numpy
ok "Dependencies installed"

# ─── STEP 2: Service directory ──────────────────────────────────
info "Creating service directory /opt/trident-markets ..."
mkdir -p /opt/trident-markets
ok "Directory ready"

# ─── STEP 3: Write the market service ───────────────────────────
info "Writing market_service.py ..."
cat > /opt/trident-markets/market_service.py << 'PYEOF'
#!/usr/bin/env python3
"""
TRIDENT Market Intelligence Service
Provides free market data via yfinance, Finnhub, FRED
Runs on port 5002
"""
import os, json, time, datetime
from flask import Flask, jsonify, request
from flask_cors import CORS
import yfinance as yf
import requests

app = Flask(__name__)
CORS(app)

FINNHUB_KEY = os.environ.get("FINNHUB_API_KEY", "")
FRED_KEY = os.environ.get("FRED_API_KEY", "")
CACHE = {}
CACHE_TTL = 300  # 5 min cache

def cached(key, ttl=CACHE_TTL):
    def decorator(fn):
        def wrapper(*args, **kwargs):
            cache_key = f"{key}:{args}:{kwargs}"
            now = time.time()
            if cache_key in CACHE and now - CACHE[cache_key]["ts"] < ttl:
                return CACHE[cache_key]["data"]
            result = fn(*args, **kwargs)
            CACHE[cache_key] = {"data": result, "ts": now}
            return result
        wrapper.__name__ = fn.__name__
        return wrapper
    return decorator

@app.route("/health")
def health():
    return jsonify({"status": "ok", "service": "TRIDENT Markets"})

@app.route("/quote/<symbol>")
def quote(symbol):
    try:
        ticker = yf.Ticker(symbol.upper())
        info = ticker.fast_info
        hist = ticker.history(period="1d", interval="5m")

        current = float(info.last_price) if hasattr(info, 'last_price') else 0
        prev_close = float(info.previous_close) if hasattr(info, 'previous_close') else 0
        change = current - prev_close
        change_pct = (change / prev_close * 100) if prev_close else 0

        return jsonify({
            "symbol": symbol.upper(),
            "price": round(current, 2),
            "change": round(change, 2),
            "change_pct": round(change_pct, 2),
            "prev_close": round(prev_close, 2),
            "high": round(float(info.day_high), 2) if hasattr(info, 'day_high') else 0,
            "low": round(float(info.day_low), 2) if hasattr(info, 'day_low') else 0,
            "volume": int(info.last_volume) if hasattr(info, 'last_volume') else 0,
            "market_cap": int(info.market_cap) if hasattr(info, 'market_cap') else 0,
            "intraday": [{"t": str(ts), "o": round(float(row["Open"]),2), "h": round(float(row["High"]),2), "l": round(float(row["Low"]),2), "c": round(float(row["Close"]),2), "v": int(row["Volume"])} for ts, row in hist.iterrows()],
            "source": "yfinance"
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/history/<symbol>")
def history(symbol):
    period = request.args.get("period", "1mo")
    interval = request.args.get("interval", "1d")
    try:
        ticker = yf.Ticker(symbol.upper())
        hist = ticker.history(period=period, interval=interval)
        data = [{"t": str(ts.date()), "o": round(float(row["Open"]),2), "h": round(float(row["High"]),2), "l": round(float(row["Low"]),2), "c": round(float(row["Close"]),2), "v": int(row["Volume"])} for ts, row in hist.iterrows()]
        return jsonify({"symbol": symbol.upper(), "period": period, "interval": interval, "data": data})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/quotes")
def quotes():
    symbols = request.args.get("symbols", "SPY,QQQ,DIA,GLD,SLV,USO,BTC-USD,ETH-USD").split(",")
    results = []
    for sym in symbols[:20]:
        try:
            ticker = yf.Ticker(sym.strip().upper())
            info = ticker.fast_info
            current = float(info.last_price) if hasattr(info, 'last_price') else 0
            prev = float(info.previous_close) if hasattr(info, 'previous_close') else 0
            change_pct = ((current - prev) / prev * 100) if prev else 0
            results.append({
                "symbol": sym.strip().upper(),
                "price": round(current, 2),
                "change_pct": round(change_pct, 2),
                "change": round(current - prev, 2)
            })
        except:
            results.append({"symbol": sym.strip().upper(), "price": 0, "change_pct": 0, "change": 0})
    return jsonify({"quotes": results, "ts": datetime.datetime.utcnow().isoformat()})

@app.route("/market-overview")
def market_overview():
    """Key market indices + commodities + crypto"""
    watchlist = {
        "indices": ["^GSPC", "^DJI", "^IXIC", "^RUT", "^VIX"],
        "commodities": ["GC=F", "SI=F", "CL=F", "NG=F", "HG=F"],
        "crypto": ["BTC-USD", "ETH-USD", "SOL-USD"],
        "bonds": ["^TNX", "^TYX", "^IRX"],
        "fx": ["DX-Y.NYB", "EURUSD=X", "GBPUSD=X", "JPY=X"]
    }
    result = {}
    for category, symbols in watchlist.items():
        result[category] = []
        for sym in symbols:
            try:
                ticker = yf.Ticker(sym)
                info = ticker.fast_info
                current = float(info.last_price) if hasattr(info, 'last_price') else 0
                prev = float(info.previous_close) if hasattr(info, 'previous_close') else 0
                change_pct = ((current - prev) / prev * 100) if prev else 0
                result[category].append({
                    "symbol": sym, "price": round(current, 2),
                    "change_pct": round(change_pct, 2), "change": round(current - prev, 2)
                })
            except:
                result[category].append({"symbol": sym, "price": 0, "change_pct": 0, "change": 0})
    return jsonify(result)

@app.route("/news")
def news():
    """Free financial news via yfinance"""
    symbol = request.args.get("symbol", "")
    try:
        if symbol:
            ticker = yf.Ticker(symbol.upper())
            articles = ticker.news or []
        else:
            # General market news via SPY
            ticker = yf.Ticker("SPY")
            articles = ticker.news or []

        cleaned = []
        for a in articles[:20]:
            cleaned.append({
                "title": a.get("title", ""),
                "publisher": a.get("publisher", ""),
                "link": a.get("link", ""),
                "published": a.get("providerPublishTime", 0),
                "summary": a.get("summary", "")[:500] if a.get("summary") else "",
                "type": a.get("type", "STORY")
            })
        return jsonify({"news": cleaned, "symbol": symbol or "MARKET"})
    except Exception as e:
        return jsonify({"error": str(e), "news": []}), 200

@app.route("/fred/<series_id>")
def fred_data(series_id):
    if not FRED_KEY:
        return jsonify({"error": "FRED_API_KEY not set"}), 400
    try:
        url = f"https://api.stlouisfed.org/fred/series/observations"
        params = {"series_id": series_id, "api_key": FRED_KEY, "file_type": "json", "sort_order": "desc", "limit": 12}
        res = requests.get(url, params=params, timeout=10)
        data = res.json()
        observations = [{"date": o["date"], "value": o["value"]} for o in data.get("observations", []) if o["value"] != "."]
        return jsonify({"series": series_id, "data": observations})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/macro")
def macro():
    """Key macro indicators from FRED"""
    if not FRED_KEY:
        return jsonify({"error": "FRED_API_KEY not set", "indicators": []}), 200
    series = [
        ("GDP", "Gross Domestic Product (Billions USD)"),
        ("UNRATE", "Unemployment Rate (%)"),
        ("CPIAUCSL", "CPI All Urban Consumers"),
        ("FEDFUNDS", "Federal Funds Rate (%)"),
        ("DGS10", "10-Year Treasury Yield (%)"),
        ("M2SL", "M2 Money Supply (Billions)"),
        ("DCOILWTICO", "WTI Crude Oil Price"),
    ]
    results = []
    for sid, label in series:
        try:
            url = f"https://api.stlouisfed.org/fred/series/observations"
            params = {"series_id": sid, "api_key": FRED_KEY, "file_type": "json", "sort_order": "desc", "limit": 2}
            res = requests.get(url, params=params, timeout=8)
            data = res.json()
            obs = [o for o in data.get("observations", []) if o["value"] != "."]
            if obs:
                current = obs[0]
                prev = obs[1] if len(obs) > 1 else obs[0]
                results.append({
                    "id": sid, "label": label,
                    "value": current["value"], "date": current["date"],
                    "prev_value": prev["value"], "prev_date": prev["date"]
                })
        except:
            pass
    return jsonify({"indicators": results, "source": "FRED"})

if __name__ == "__main__":
    print("[ TRIDENT ] Market Intelligence Service starting on port 5002")
    app.run(host="127.0.0.1", port=5002, debug=False)
PYEOF
ok "market_service.py written"

# ─── STEP 4: systemd service ────────────────────────────────────
info "Creating systemd service trident-markets ..."
cat > /etc/systemd/system/trident-markets.service << 'EOF'
[Unit]
Description=TRIDENT Market Intelligence Service
After=network.target trident.service

[Service]
Type=simple
User=root
WorkingDirectory=/opt/trident-markets
EnvironmentFile=/etc/trident/config.env
ExecStart=/usr/bin/python3 /opt/trident-markets/market_service.py
Restart=always
RestartSec=10
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable trident-markets
systemctl start trident-markets
sleep 3
systemctl status trident-markets --no-pager || true
ok "Market service running on port 5002"

# ─── STEP 5: Daily Brief cron (systemd timer @ 06:30) ───────────
info "Installing daily brief generator timer (06:30 local)..."
cat > /etc/systemd/system/trident-brief.service << 'EOF'
[Unit]
Description=TRIDENT Daily Market Brief Generator

[Service]
Type=oneshot
ExecStart=/usr/bin/curl -s -X POST http://localhost:5000/api/markets/brief/generate \
  -H "Authorization: Bearer TRIDENT_INTERNAL_KEY" \
  -H "Content-Type: application/json"
EOF

cat > /etc/systemd/system/trident-brief.timer << 'EOF'
[Unit]
Description=TRIDENT Brief — 3x Daily (06:30, 12:30, 18:30)

[Timer]
OnCalendar=*-*-* 06:30:00
OnCalendar=*-*-* 12:30:00
OnCalendar=*-*-* 18:30:00
Persistent=true

[Install]
WantedBy=timers.target
EOF

systemctl daemon-reload
systemctl enable trident-brief.timer
systemctl start trident-brief.timer
ok "Daily brief timer active"

echo -e "\n${BOLD}${GREEN}[ TRIDENT ] Market service running on port 5002${NC}\n"
