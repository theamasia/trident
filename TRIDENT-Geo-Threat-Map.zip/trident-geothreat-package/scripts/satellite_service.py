#!/usr/bin/env python3
"""
TRIDENT Satellite Tracking Service
Uses CelesTrak TLE data + SGP4 propagation for real-time satellite positions
Runs on port 5009
"""
import os, time, datetime, math
import requests
from flask import Flask, jsonify, request
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

# Denton, NC observer location
OBS_LAT = 35.6262
OBS_LON = -80.1131
OBS_ALT_KM = 0.2  # approx elevation in km
RADIUS_MILES = 100  # legacy fallback, no longer used for filtering (see horizon_range_miles)
MIN_ELEVATION_DEG = 0  # 0 = true horizon; raise to e.g. 10 to require satellite well above obstructions
EARTH_RADIUS_KM = 6371.0

CACHE = {}
CACHE_TTL = 3600  # TLE data updates hourly is plenty

# CelesTrak TLE group URLs (no auth required)
TLE_GROUPS = {
    "starlink": "https://celestrak.org/NORAD/elements/gp.php?GROUP=starlink&FORMAT=tle",
    "noaa": "https://celestrak.org/NORAD/elements/gp.php?GROUP=noaa&FORMAT=tle",
    "weather": "https://celestrak.org/NORAD/elements/gp.php?GROUP=weather&FORMAT=tle",
    "gps": "https://celestrak.org/NORAD/elements/gp.php?GROUP=gps-ops&FORMAT=tle",
    "stations": "https://celestrak.org/NORAD/elements/gp.php?GROUP=stations&FORMAT=tle",
    "science": "https://celestrak.org/NORAD/elements/gp.php?GROUP=science&FORMAT=tle",
}

def get_cached(key, ttl=CACHE_TTL):
    if key in CACHE and time.time() - CACHE[key]["ts"] < ttl:
        return CACHE[key]["data"]
    return None

def set_cached(key, data):
    CACHE[key] = {"data": data, "ts": time.time()}

def fetch_tle_group(group):
    """Fetch and parse TLE data for a satellite group"""
    cached = get_cached(f"tle_{group}")
    if cached:
        return cached
    try:
        url = TLE_GROUPS.get(group)
        if not url:
            return []
        res = requests.get(url, timeout=20, headers={"User-Agent": "TRIDENT/1.0"})
        lines = [l.strip() for l in res.text.strip().split("\n") if l.strip()]
        satellites = []
        for i in range(0, len(lines) - 2, 3):
            name = lines[i]
            line1 = lines[i+1]
            line2 = lines[i+2]
            if line1.startswith("1 ") and line2.startswith("2 "):
                satellites.append({"name": name, "line1": line1, "line2": line2, "group": group})
        set_cached(f"tle_{group}", satellites)
        return satellites
    except Exception as e:
        print(f"[ TRIDENT SAT ] TLE fetch error for {group}: {e}", flush=True)
        return []

def haversine_miles(lat1, lon1, lat2, lon2):
    R = 3958.8
    dlat = math.radians(lat2 - lat1)
    dlon = math.radians(lon2 - lon1)
    a = math.sin(dlat/2)**2 + math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) * math.sin(dlon/2)**2
    return R * 2 * math.asin(math.sqrt(a))

def horizon_range_km(alt_km, min_elevation_deg=MIN_ELEVATION_DEG):
    """
    Max ground-track distance (km) at which a satellite at alt_km is still above
    min_elevation_deg from an observer at sea level. Uses the standard line-of-sight
    horizon geometry so higher satellites (GPS/GEO) get a much larger visibility
    radius than low LEO satellites (Starlink) -- matches real observability.
    """
    Re = EARTH_RADIUS_KM
    h = max(alt_km, 1.0)
    el = math.radians(min_elevation_deg)
    # Central angle between observer and sub-satellite point at the given elevation
    # Derived from the law of cosines for the observer-earth_center-satellite triangle
    ratio = (Re / (Re + h)) * math.cos(el)
    ratio = max(-1.0, min(1.0, ratio))
    gamma = math.acos(ratio) - el
    if gamma < 0:
        gamma = 0
    return Re * gamma

def horizon_range_miles(alt_km, min_elevation_deg=MIN_ELEVATION_DEG):
    return horizon_range_km(alt_km, min_elevation_deg) * 0.621371

def propagate_satellite(line1, line2, when=None):
    """Use sgp4 library to compute current lat/lon/alt for a satellite"""
    try:
        from sgp4.api import Satrec, WGS72
        from sgp4.api import jday
        sat = Satrec.twoline2rv(line1, line2)
        dt = when or datetime.datetime.utcnow()
        jd, fr = jday(dt.year, dt.month, dt.day, dt.hour, dt.minute, dt.second + dt.microsecond/1e6)
        e, r, v = sat.sgp4(jd, fr)
        if e != 0:
            return None
        # r is ECI position in km — convert to lat/lon/alt using simple approximation
        x, y, z = r
        # GMST calculation for ECI->ECEF rotation
        gmst = compute_gmst(dt)
        cos_gmst = math.cos(gmst)
        sin_gmst = math.sin(gmst)
        x_ecef = x * cos_gmst + y * sin_gmst
        y_ecef = -x * sin_gmst + y * cos_gmst
        z_ecef = z

        lon = math.degrees(math.atan2(y_ecef, x_ecef))
        r_xy = math.sqrt(x_ecef**2 + y_ecef**2)
        lat = math.degrees(math.atan2(z_ecef, r_xy))
        alt_km = math.sqrt(x**2 + y**2 + z**2) - 6371.0  # approx, subtract Earth radius

        velocity_km_s = math.sqrt(v[0]**2 + v[1]**2 + v[2]**2)

        return {
            "lat": lat,
            "lon": ((lon + 180) % 360) - 180,  # normalize to -180..180
            "alt_km": alt_km,
            "velocity_km_s": round(velocity_km_s, 2)
        }
    except ImportError:
        return None
    except Exception:
        return None

def compute_gmst(dt):
    """Compute Greenwich Mean Sidereal Time in radians"""
    jd = 367*dt.year - int(7*(dt.year + int((dt.month+9)/12))/4) + int(275*dt.month/9) + dt.day + 1721013.5 + (dt.hour + dt.minute/60 + dt.second/3600)/24
    t = (jd - 2451545.0) / 36525.0
    gmst_deg = 280.46061837 + 360.98564736629 * (jd - 2451545.0) + 0.000387933*t*t - t*t*t/38710000.0
    gmst_deg = gmst_deg % 360
    return math.radians(gmst_deg)

def classify_orbit(alt_km):
    """Classify orbit type based on altitude"""
    if alt_km < 2000:
        return "LEO"
    elif alt_km < 35786:
        return "MEO"
    elif 35000 <= alt_km <= 36500:
        return "GEO"
    else:
        return "HEO"

@app.route("/health")
def health():
    try:
        from sgp4.api import Satrec
        sgp4_ok = True
    except ImportError:
        sgp4_ok = False
    return jsonify({"status": "ok", "service": "TRIDENT Satellite Tracking", "sgp4_available": sgp4_ok, "location": "Denton, NC", "filter_mode": "horizon", "min_elevation_deg": MIN_ELEVATION_DEG})

@app.route("/overhead")
def overhead():
    """Get satellites currently within radius of Denton NC, filtered by group"""
    groups = request.args.get("groups", "starlink,noaa,weather,stations").split(",")
    now = datetime.datetime.utcnow()
    results = []

    for group in groups:
        sats = fetch_tle_group(group.strip())
        # Limit starlink to a reasonable sample since there are 6000+ satellites
        sample = sats[:500] if group.strip() == "starlink" else sats

        for sat in sample:
            pos = propagate_satellite(sat["line1"], sat["line2"], now)
            if not pos:
                continue
            dist = haversine_miles(OBS_LAT, OBS_LON, pos["lat"], pos["lon"])
            visible_range = horizon_range_miles(pos["alt_km"])
            if dist <= visible_range:
                results.append({
                    "name": sat["name"],
                    "group": sat["group"],
                    "lat": round(pos["lat"], 4),
                    "lon": round(pos["lon"], 4),
                    "alt_km": round(pos["alt_km"], 1),
                    "velocity_km_s": pos["velocity_km_s"],
                    "orbit_type": classify_orbit(pos["alt_km"]),
                    "distance_miles": round(dist, 1),
                    "visible_range_miles": round(visible_range, 1),
                    "norad_id": sat["line1"][2:7].strip() if len(sat["line1"]) > 7 else ""
                })

    results.sort(key=lambda x: x["distance_miles"])
    return jsonify({
        "satellites": results,
        "count": len(results),
        "groups_queried": groups,
        "center": {"lat": OBS_LAT, "lon": OBS_LON},
        "filter_mode": "horizon",
        "min_elevation_deg": MIN_ELEVATION_DEG,
        "timestamp": now.isoformat()
    })

@app.route("/satellite/<norad_id>")
def satellite_detail(norad_id):
    """Get detailed info + full orbit path for a specific satellite"""
    group = request.args.get("group", "starlink")
    sats = fetch_tle_group(group)
    target = None
    for sat in sats:
        sat_norad = sat["line1"][2:7].strip()
        if sat_norad == norad_id:
            target = sat
            break

    if not target:
        return jsonify({"error": "Satellite not found"}), 404

    now = datetime.datetime.utcnow()
    current_pos = propagate_satellite(target["line1"], target["line2"], now)

    # Compute orbit path — positions over the next 100 minutes at 2-min intervals (typical LEO period)
    orbit_path = []
    for mins_offset in range(0, 102, 2):
        t = now + datetime.timedelta(minutes=mins_offset)
        pos = propagate_satellite(target["line1"], target["line2"], t)
        if pos:
            orbit_path.append({"lat": round(pos["lat"], 3), "lon": round(pos["lon"], 3), "alt_km": round(pos["alt_km"], 1), "t": t.isoformat()})

    # Parse TLE for orbital elements
    line2 = target["line2"]
    inclination = float(line2[8:16].strip())
    raan = float(line2[17:25].strip())
    eccentricity = float("0." + line2[26:33].strip())
    arg_perigee = float(line2[34:42].strip())
    mean_anomaly = float(line2[43:51].strip())
    mean_motion = float(line2[52:63].strip())
    period_minutes = 1440.0 / mean_motion if mean_motion > 0 else 0

    return jsonify({
        "name": target["name"],
        "norad_id": norad_id,
        "group": target["group"],
        "current_position": current_pos,
        "orbit_path": orbit_path,
        "orbital_elements": {
            "inclination_deg": inclination,
            "raan_deg": raan,
            "eccentricity": eccentricity,
            "arg_perigee_deg": arg_perigee,
            "mean_anomaly_deg": mean_anomaly,
            "mean_motion_rev_per_day": mean_motion,
            "period_minutes": round(period_minutes, 1),
            "orbit_type": classify_orbit(current_pos["alt_km"]) if current_pos else "UNKNOWN"
        },
        "tle": {"line1": target["line1"], "line2": target["line2"]}
    })

@app.route("/groups")
def list_groups():
    """List available satellite tracking groups with counts"""
    result = {}
    for group in TLE_GROUPS.keys():
        sats = fetch_tle_group(group)
        result[group] = len(sats)
    return jsonify({"groups": result})

if __name__ == "__main__":
    print("[ TRIDENT ] Satellite Tracking Service starting on port 5009")
    print(f"[ TRIDENT ] Monitoring Denton, NC ({OBS_LAT}, {OBS_LON}) — horizon-based visibility (min elevation {MIN_ELEVATION_DEG}°)")
    app.run(host="127.0.0.1", port=5009, debug=False)
