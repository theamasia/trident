#!/bin/bash
# TRIDENT GRID Worker Node Installer
# Usage: curl http://192.168.0.7:5000/api/grid/install.sh | sudo bash
set -euo pipefail

COORDINATOR_URL="${TRIDENT_COORDINATOR:-http://192.168.0.7:5007}"
WORKER_PORT="${WORKER_PORT:-5008}"
INSTALL_DIR="/opt/trident-worker"
VENV_DIR="$INSTALL_DIR/venv"

echo "[ TRIDENT GRID ] Installing worker agent..."
echo "[ TRIDENT GRID ] Coordinator: $COORDINATOR_URL"

# Install dependencies
apt-get update -qq
apt-get install -y -qq python3 python3-venv python3-pip curl

# Create venv
mkdir -p $INSTALL_DIR
python3 -m venv $VENV_DIR
$VENV_DIR/bin/pip install flask flask-cors requests psutil pdfplumber mammoth beautifulsoup4 --quiet

# Download worker agent from coordinator
curl -fsSL "$COORDINATOR_URL/../api/grid/worker-agent" -o $INSTALL_DIR/trident-worker-agent.py

# Create config
cat > /etc/trident-worker.env << EOF
TRIDENT_COORDINATOR=$COORDINATOR_URL
WORKER_PORT=$WORKER_PORT
NODE_NAME=$(hostname)
GRID_SECRET=trident-grid-secret-2026
WORKER_DATA_DIR=$INSTALL_DIR
EOF

# Create systemd service
cat > /etc/systemd/system/trident-worker.service << 'SVCEOF'
[Unit]
Description=TRIDENT GRID Worker Agent
After=network.target

[Service]
Type=simple
User=root
EnvironmentFile=/etc/trident-worker.env
ExecStart=/opt/trident-worker/venv/bin/python3 /opt/trident-worker/trident-worker-agent.py
Restart=always
RestartSec=10
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
SVCEOF

systemctl daemon-reload
systemctl enable trident-worker
systemctl start trident-worker
sleep 3
systemctl status trident-worker --no-pager | head -5
echo "[ TRIDENT GRID ] Worker agent installed and started"
echo "[ TRIDENT GRID ] Node will appear in TRIDENT GRID dashboard within 30 seconds"
