import { useState, useMemo, useRef, useEffect } from "react";
import {
  TrendingUp,
  TrendingDown,
  Plus,
  X,
  Radio,
  FileText,
  BarChart3,
  Newspaper,
  Loader2,
  RefreshCw,
  Activity,
  Trash2,
  ArrowUpRight,
  ExternalLink,
  Globe,
  Skull,
  Crosshair,
  Database,
  Plane,
  Download,
  Trash2 as TrashIcon,
  AlertTriangle,
  ChevronDown,
  HardDrive,
  CloudSun,
  Wind,
  Droplets,
  Gauge,
  Eye,
  Thermometer,
  Sunrise,
  Sunset,
  MapPin,
  Satellite,
  RadioTower,
  Volume2,
  VolumeX,
} from "lucide-react";
import { getAuthHeaders } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useQueryClient, useMutation } from "@tanstack/react-query";
import type { MarketWatchlist, DailyBrief, GeoBrief } from "@shared/schema";
import { useLeafletMap, DENTON_CENTER } from "@/hooks/useLeafletMap";
import L from "leaflet";

const API_BASE = "__PORT_5000__".startsWith("__") ? "" : "__PORT_5000__";

// ═══════════════════════════════════════════════════
// Types
// ═══════════════════════════════════════════════════
interface QuotePoint { t: string; o: number; h: number; l: number; c: number; v: number; }
interface Quote {
  symbol: string;
  price: number;
  change: number;
  change_pct: number;
  prev_close?: number;
  high?: number;
  low?: number;
  volume?: number;
  market_cap?: number;
  intraday?: QuotePoint[];
}
interface OverviewItem { symbol: string; price: number; change_pct: number; change: number; }
interface MacroIndicator {
  id: string; label: string; value: string; date: string;
  prev_value: string; prev_date: string;
}
interface NewsItem {
  title: string; publisher: string; link: string;
  published: number; summary: string; type: string;
}

type TabKey = "markets" | "brief" | "macro" | "news" | "geo" | "flights" | "weather" | "satellite" | "radioops";

// ── Flight-Intelligence types ──
interface Aircraft {
  icao24: string;
  callsign: string;
  origin_country: string;
  latitude: number;
  longitude: number;
  altitude_m: number;
  altitude_ft: number;
  velocity_ms: number;
  velocity_kts: number;
  heading: number;
  vertical_rate: number;
  on_ground: boolean;
  squawk: string;
  distance_nm: number;
  source: string;
  is_military?: boolean;
}
interface FlightLiveResponse {
  aircraft: Aircraft[];
  count: number;
  source: string;
  timestamp: string;
  center: { lat: number; lon: number };
  radius_nm: number;
}
interface FlightStats {
  total_flights_recorded: number;
  today_count: number;
  max_altitude_ft: number;
  max_speed_kts: number;
  top_callsigns: { callsign: string; c: number }[];
  top_countries: { origin_country: string; c: number }[];
  military_flights_today?: number;
}
interface FlightHistoryRow {
  id: number;
  icao24: string;
  callsign: string;
  origin_country: string;
  altitude_m: number;
  velocity_ms: number;
  heading: number;
  distance_nm: number;
  first_seen: string;
  last_seen: string;
}
interface FlightHistoryResponse {
  flights: FlightHistoryRow[];
  total: number;
  limit: number;
  offset: number;
}
interface FlightHealth {
  status?: string;
  data_source?: string;
  dump1090_configured?: boolean;
  opensky_authenticated?: boolean;
  location?: string;
  radius_nm?: number;
}
interface FlightStorage {
  db_size_mb: number;
  total_records: number;
  oldest_record?: string | null;
  newest_record?: string | null;
  records_by_date?: { date: string; count: number }[];
}

// ── Geo-Intelligence types ──
interface GeoHotspot { country: string; events: number; }
interface GeoThreatSummary {
  acled: {
    total_events_7d?: number;
    total_fatalities_7d?: number;
    top_hotspots?: GeoHotspot[];
    error?: string;
    available?: boolean;
    note?: string;
  };
  gdelt?: {
    total_articles_24h?: number;
    top_hotspots?: GeoHotspot[];
    source?: string;
    error?: string;
  };
  timestamp?: string;
  source?: string;
}
interface GeoArticle {
  title: string;
  link: string;
  published: string;
  description: string;
  source: string;
}

// ── GDELT types ──
interface GdeltCountryMention { country: string; mentions: number; }
interface GdeltCountrySummaryResponse {
  summary: GdeltCountryMention[];
  total_articles: number;
  source?: string;
  period?: string;
  error?: string;
}
interface GdeltEvent {
  title: string;
  url: string;
  domain: string;
  country: string;
  seen_date: string;
  language: string;
  tone: number;
  image?: string;
}
interface GdeltEventsResponse {
  events: GdeltEvent[];
  count: number;
  source?: string;
  note?: string;
  error?: string;
}

// ═══════════════════════════════════════════════════
// Helpers
// ═══════════════════════════════════════════════════
async function apiGet<T>(path: string): Promise<T> {
  const res = await fetch(`${API_BASE}${path}`, { headers: getAuthHeaders() });
  if (!res.ok) throw new Error(`Request failed: ${res.status}`);
  return res.json();
}

function fmtNum(n: number | undefined, digits = 2): string {
  if (n === undefined || n === null || isNaN(n)) return "—";
  return n.toLocaleString("en-US", { minimumFractionDigits: digits, maximumFractionDigits: digits });
}
function fmtCompact(n: number | undefined): string {
  if (!n || isNaN(n)) return "—";
  if (n >= 1e12) return `${(n / 1e12).toFixed(2)}T`;
  if (n >= 1e9) return `${(n / 1e9).toFixed(2)}B`;
  if (n >= 1e6) return `${(n / 1e6).toFixed(2)}M`;
  if (n >= 1e3) return `${(n / 1e3).toFixed(2)}K`;
  return `${n}`;
}
function timeAgo(unixSeconds: number): string {
  if (!unixSeconds) return "";
  const diff = Date.now() / 1000 - unixSeconds;
  if (diff < 60) return "JUST NOW";
  if (diff < 3600) return `${Math.floor(diff / 60)}M AGO`;
  if (diff < 86400) return `${Math.floor(diff / 3600)}H AGO`;
  return `${Math.floor(diff / 86400)}D AGO`;
}

// ═══════════════════════════════════════════════════
// SVG Line Chart
// ���══════════════════════════════════════════════════
function LineChart({
  data,
  height = 240,
  color = "#00f0ff",
}: {
  data: { t: string; c: number }[];
  height?: number;
  color?: string;
}) {
  const W = 800;
  const H = height;
  const padX = 8;
  const padY = 16;

  const geometry = useMemo(() => {
    if (!data || data.length < 2) return null;
    const vals = data.map((d) => d.c);
    const min = Math.min(...vals);
    const max = Math.max(...vals);
    const range = max - min || 1;
    const n = data.length;
    const points = data.map((d, i) => {
      const x = padX + (i / (n - 1)) * (W - padX * 2);
      const y = padY + (1 - (d.c - min) / range) * (H - padY * 2);
      return { x, y, c: d.c, t: d.t };
    });
    const line = points.map((p, i) => `${i === 0 ? "M" : "L"} ${p.x.toFixed(1)} ${p.y.toFixed(1)}`).join(" ");
    const area = `${line} L ${points[points.length - 1].x.toFixed(1)} ${H - padY} L ${points[0].x.toFixed(1)} ${H - padY} Z`;
    const last = points[points.length - 1];
    return { points, line, area, min, max, last };
  }, [data, H]);

  if (!geometry) {
    return (
      <div
        className="flex items-center justify-center border border-trident-border/50 bg-black/40 font-mono text-[10px] uppercase tracking-widest text-trident-text/40"
        style={{ height }}
        data-testid="chart-empty"
      >
        NO SIGNAL DATA
      </div>
    );
  }

  const gridLines = 4;
  return (
    <div className="relative w-full border border-trident-border/50 bg-black/40" style={{ height }}>
      <svg viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none" width="100%" height={height} data-testid="chart-svg">
        <defs>
          <linearGradient id="chartFill" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={color} stopOpacity="0.28" />
            <stop offset="100%" stopColor={color} stopOpacity="0" />
          </linearGradient>
        </defs>
        {/* grid */}
        {Array.from({ length: gridLines + 1 }).map((_, i) => {
          const y = padY + (i / gridLines) * (H - padY * 2);
          return (
            <line key={i} x1={padX} y1={y} x2={W - padX} y2={y}
              stroke="#1a3a4a" strokeWidth="0.5" strokeDasharray="2 4" />
          );
        })}
        {/* current price dashed line */}
        <line x1={padX} y1={geometry.last.y} x2={W - padX} y2={geometry.last.y}
          stroke={color} strokeWidth="0.6" strokeDasharray="4 4" opacity="0.5" />
        {/* area + line */}
        <path d={geometry.area} fill="url(#chartFill)" />
        <path d={geometry.line} fill="none" stroke={color} strokeWidth="1.6"
          style={{ filter: `drop-shadow(0 0 4px ${color}90)` }} />
        {/* current price marker */}
        <circle cx={geometry.last.x} cy={geometry.last.y} r="3" fill={color}
          style={{ filter: `drop-shadow(0 0 6px ${color})` }} />
      </svg>
      {/* Y-axis labels */}
      <div className="pointer-events-none absolute inset-0 flex flex-col justify-between p-1 font-mono text-[9px] tabular-nums text-trident-text/40">
        <span>{fmtNum(geometry.max)}</span>
        <span>{fmtNum(geometry.min)}</span>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════
// Small colored change display
// ═══════════════════════════════════════════════════
function Change({ pct, abs, size = "sm" }: { pct: number; abs?: number; size?: "sm" | "lg" }) {
  const up = pct >= 0;
  const cls = up ? "text-trident-green" : "text-trident-red";
  const Arrow = up ? TrendingUp : TrendingDown;
  return (
    <span className={`inline-flex items-center gap-1 font-mono tabular-nums ${cls} ${size === "lg" ? "text-lg" : "text-xs"}`}>
      <Arrow className={size === "lg" ? "w-4 h-4" : "w-3 h-3"} />
      {abs !== undefined && <span>{up ? "+" : ""}{fmtNum(abs)}</span>}
      <span>({up ? "+" : ""}{fmtNum(pct)}%)</span>
    </span>
  );
}

// ═══════════════════════════════════════════════════
// Minimal markdown renderer (TRIDENT styled)
// ═══════════════════════════════════════════════════
function BriefMarkdown({ content }: { content: string }) {
  const lines = content.split("\n");
  return (
    <div className="space-y-2 font-mono text-sm leading-relaxed text-trident-text/90" data-testid="brief-content">
      {lines.map((raw, i) => {
        const line = raw.trimEnd();
        if (!line.trim()) return <div key={i} className="h-2" />;
        // headings: markdown ## or numbered section headers
        const headingMatch = line.match(/^#{1,6}\s+(.*)$/);
        const numberedSection = line.match(/^\s*(\d+)\.\s+([A-Z][A-Z\s/&-]{3,})$/);
        if (headingMatch || numberedSection) {
          const text = (headingMatch ? headingMatch[1] : `${numberedSection![1]}. ${numberedSection![2]}`).replace(/\*\*/g, "");
          return (
            <h3 key={i} className="pt-3 font-display text-xs uppercase tracking-[0.2em] text-trident-cyan text-glow-cyan">
              {text}
            </h3>
          );
        }
        // bullet
        const bulletMatch = line.match(/^\s*[-*]\s+(.*)$/);
        if (bulletMatch) {
          return (
            <div key={i} className="flex gap-2 pl-2">
              <span className="text-trident-amber">▸</span>
              <span>{bulletMatch[1].replace(/\*\*(.*?)\*\*/g, "$1")}</span>
            </div>
          );
        }
        return <p key={i}>{line.replace(/\*\*(.*?)\*\*/g, "$1")}</p>;
      })}
    </div>
  );
}

// ═══════════════════════════════════════════════════
// Category badge helper
// ═══════════════════════════════════════════════════
function detectCategory(symbol: string): string {
  const s = symbol.toUpperCase();
  if (s.includes("-USD") || s.includes("USDT")) return "crypto";
  if (s.endsWith("=F")) return "commodity";
  if (s.startsWith("^")) return "index";
  if (s.endsWith("=X") || s.includes("USD")) return "fx";
  return "stock";
}

// ═══════════════════════════════════════════════════
// MAIN PAGE
// ═══════════════════════════════════════════════════
export default function DashboardIntelligence() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [tab, setTab] = useState<TabKey>("markets");
  const [selectedSymbol, setSelectedSymbol] = useState<string | null>(null);
  const [histPeriod, setHistPeriod] = useState<string>("intraday");
  const [addOpen, setAddOpen] = useState(false);
  const [newSymbol, setNewSymbol] = useState("");
  const [newsFilter, setNewsFilter] = useState<"MARKET" | "SYMBOL">("MARKET");
  const [selectedBriefId, setSelectedBriefId] = useState<number | null>(null);

  // ── Market service status ──
  const { data: statusData } = useQuery<{ online: boolean }>({
    queryKey: ["/api/markets/status"],
    staleTime: 0,
    refetchInterval: 30000,
    queryFn: () => apiGet("/api/markets/status"),
  });
  const serviceOnline = statusData?.online ?? false;

  // ── Watchlist ──
  const { data: wlData } = useQuery<{ watchlist: MarketWatchlist[] }>({
    queryKey: ["/api/markets/watchlist"],
    staleTime: 0,
    queryFn: () => apiGet("/api/markets/watchlist"),
  });
  const watchlist = wlData?.watchlist ?? [];
  const wlSymbols = watchlist.map((w) => w.symbol).join(",");

  // ── Live quotes for watchlist (auto-refresh 60s) ──
  const { data: quotesData } = useQuery<{ quotes: OverviewItem[] }>({
    queryKey: ["/api/markets/quotes", wlSymbols],
    enabled: wlSymbols.length > 0,
    staleTime: 0,
    refetchInterval: 60000,
    queryFn: () => apiGet(`/api/markets/quotes?symbols=${encodeURIComponent(wlSymbols)}`),
  });
  const quoteMap = useMemo(() => {
    const m: Record<string, OverviewItem> = {};
    (quotesData?.quotes || []).forEach((q) => { m[q.symbol.toUpperCase()] = q; });
    return m;
  }, [quotesData]);

  // ── Add / remove watchlist ──
  const addMut = useMutation({
    mutationFn: async (symbol: string) => {
      const res = await fetch(`${API_BASE}/api/markets/watchlist`, {
        method: "POST",
        headers: { "Content-Type": "application/json", ...getAuthHeaders() },
        body: JSON.stringify({ symbol, category: detectCategory(symbol) }),
      });
      if (!res.ok) {
        const j = await res.json().catch(() => ({}));
        throw new Error(j.error || "FAILED TO ADD");
      }
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/markets/watchlist"] });
      setNewSymbol("");
      setAddOpen(false);
      toast({ title: "SYMBOL ADDED" });
    },
    onError: (e: any) => toast({ title: e.message || "ERROR", variant: "destructive" }),
  });
  const removeMut = useMutation({
    mutationFn: async (id: number) => {
      const res = await fetch(`${API_BASE}/api/markets/watchlist/${id}`, {
        method: "DELETE",
        headers: getAuthHeaders(),
      });
      if (!res.ok) throw new Error("FAILED TO REMOVE");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/markets/watchlist"] });
      toast({ title: "SYMBOL REMOVED" });
    },
  });

  return (
    <div className="flex h-full flex-col" data-testid="page-intelligence">
      {/* ═══════════ HEADER + TABS ═══════════ */}
      <div className="mb-3 flex flex-wrap items-center justify-between gap-3 border-b border-trident-border pb-3">
        <div className="flex items-center gap-2">
          <Activity className="h-5 w-5 text-trident-amber" style={{ filter: "drop-shadow(0 0 6px #ff6b00)" }} />
          <h1 className="font-display text-sm uppercase tracking-[0.25em] text-trident-cyan text-glow-cyan">
            INTELLIGENCE COMMAND
          </h1>
        </div>
        <nav className="flex gap-1">
          {([
            { k: "markets", label: "MARKETS", icon: BarChart3 },
            { k: "brief", label: "BRIEF", icon: FileText },
            { k: "macro", label: "MACRO", icon: TrendingUp },
            { k: "news", label: "NEWS", icon: Newspaper },
            { k: "geo", label: "GEO-INTEL", icon: Globe },
            { k: "flights", label: "FLIGHTS", icon: Plane },
            { k: "satellite", label: "SATELLITE", icon: Satellite },
            { k: "weather", label: "WEATHER", icon: CloudSun },
            { k: "radioops", label: "RADIO OPS", icon: RadioTower },
          ] as { k: TabKey; label: string; icon: any }[]).map(({ k, label, icon: Icon }) => (
            <button
              key={k}
              onClick={() => setTab(k)}
              data-testid={`tab-${k}`}
              className={`flex items-center gap-1.5 border px-3 py-1.5 font-mono text-[10px] uppercase tracking-widest transition-all ${
                tab === k
                  ? "border-trident-cyan/60 bg-trident-cyan/10 text-trident-cyan text-glow-cyan"
                  : "border-trident-border text-trident-text/50 hover:border-trident-cyan/30 hover:text-trident-cyan"
              }`}
            >
              <Icon className="h-3 w-3" />
              {label}
            </button>
          ))}
        </nav>
      </div>

      {/* ═══════════ BODY ═══════════ */}
      {tab === "geo" ? (
        <div className="min-h-0 flex-1 overflow-y-auto">
          <GeoIntelTab />
        </div>
      ) : tab === "flights" ? (
        <div className="min-h-0 flex-1 overflow-y-auto">
          <FlightsTab />
        </div>
      ) : tab === "weather" ? (
        <div className="min-h-0 flex-1 overflow-y-auto">
          <WeatherTab />
        </div>
      ) : tab === "satellite" ? (
        <div className="min-h-0 flex-1 overflow-y-auto">
          <SatelliteTab />
        </div>
      ) : tab === "radioops" ? (
        <div className="min-h-0 flex-1 overflow-y-auto">
          <RadioOpsTab />
        </div>
      ) : (
      <div className="flex min-h-0 flex-1 gap-3">
        {/* ── WATCHLIST PANEL ── */}
        <aside className="flex w-[220px] flex-shrink-0 flex-col border border-trident-border bg-trident-surface/40" data-testid="watchlist-panel">
          <div className="flex items-center justify-between border-b border-trident-border px-3 py-2">
            <span className="font-mono text-[10px] uppercase tracking-widest text-trident-text/60">WATCHLIST</span>
            <span className="flex items-center gap-1.5" title={serviceOnline ? "Market service online" : "Market service offline"}>
              <span
                className={`inline-block h-1.5 w-1.5 rounded-full ${serviceOnline ? "bg-trident-green animate-pulse" : "bg-trident-red"}`}
                style={serviceOnline ? { boxShadow: "0 0 6px #00ff41" } : { boxShadow: "0 0 6px #ff2244" }}
                data-testid="status-market-service"
              />
              <span className={`font-mono text-[8px] uppercase tracking-widest ${serviceOnline ? "text-trident-green" : "text-trident-red"}`}>
                {serviceOnline ? "LIVE" : "OFF"}
              </span>
            </span>
          </div>

          <div className="min-h-0 flex-1 overflow-y-auto">
            {watchlist.length === 0 && (
              <div className="p-3 font-mono text-[10px] uppercase tracking-widest text-trident-text/40">
                NO SYMBOLS TRACKED
              </div>
            )}
            {watchlist.map((w) => {
              const q = quoteMap[w.symbol.toUpperCase()];
              const pct = q?.change_pct ?? 0;
              const up = pct >= 0;
              const active = selectedSymbol === w.symbol;
              return (
                <div
                  key={w.id}
                  onClick={() => { setSelectedSymbol(w.symbol); setHistPeriod("intraday"); setTab("markets"); }}
                  data-testid={`row-watchlist-${w.symbol}`}
                  className={`group flex cursor-pointer items-center justify-between border-l-2 px-3 py-2 transition-all ${
                    active
                      ? "border-trident-amber bg-trident-cyan/8"
                      : "border-transparent hover:bg-trident-cyan/5"
                  }`}
                >
                  <div className="min-w-0">
                    <div className="flex items-center gap-1">
                      <span className="font-mono text-xs font-bold text-trident-text">{w.symbol}</span>
                    </div>
                    <div className="truncate font-mono text-[9px] uppercase tracking-wide text-trident-text/40">
                      {w.name || w.category}
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="text-right">
                      <div className="font-mono text-[11px] tabular-nums text-trident-text/80">
                        {q ? fmtNum(q.price) : "—"}
                      </div>
                      <div className={`flex items-center justify-end gap-0.5 font-mono text-[9px] tabular-nums ${up ? "text-trident-green" : "text-trident-red"}`}>
                        {up ? <TrendingUp className="h-2.5 w-2.5" /> : <TrendingDown className="h-2.5 w-2.5" />}
                        {up ? "+" : ""}{fmtNum(pct)}%
                      </div>
                    </div>
                    <button
                      onClick={(e) => { e.stopPropagation(); removeMut.mutate(w.id); }}
                      className="opacity-0 transition-opacity group-hover:opacity-100"
                      data-testid={`button-remove-${w.symbol}`}
                    >
                      <X className="h-3 w-3 text-trident-red/60 hover:text-trident-red" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Add symbol */}
          <div className="border-t border-trident-border p-2">
            {addOpen ? (
              <div className="space-y-2">
                <input
                  autoFocus
                  value={newSymbol}
                  onChange={(e) => setNewSymbol(e.target.value.toUpperCase())}
                  onKeyDown={(e) => { if (e.key === "Enter" && newSymbol.trim()) addMut.mutate(newSymbol.trim()); }}
                  placeholder="TICKER e.g. AAPL"
                  data-testid="input-add-symbol"
                  className="w-full border border-trident-border bg-black/40 px-2 py-1.5 font-mono text-[11px] uppercase tracking-widest text-trident-cyan placeholder:text-trident-text/30 focus:border-trident-cyan focus:outline-none"
                />
                <div className="flex gap-1">
                  <button
                    onClick={() => newSymbol.trim() && addMut.mutate(newSymbol.trim())}
                    disabled={addMut.isPending}
                    data-testid="button-confirm-add"
                    className="flex-1 border border-trident-green/40 bg-trident-green/10 py-1 font-mono text-[9px] uppercase tracking-widest text-trident-green hover:bg-trident-green/20"
                  >
                    {addMut.isPending ? <Loader2 className="mx-auto h-3 w-3 animate-spin" /> : "CONFIRM"}
                  </button>
                  <button
                    onClick={() => { setAddOpen(false); setNewSymbol(""); }}
                    className="border border-trident-border px-2 py-1 font-mono text-[9px] uppercase tracking-widest text-trident-text/50 hover:text-trident-red"
                  >
                    <X className="h-3 w-3" />
                  </button>
                </div>
              </div>
            ) : (
              <button
                onClick={() => setAddOpen(true)}
                data-testid="button-add-symbol"
                className="flex w-full items-center justify-center gap-1.5 border border-trident-cyan/30 py-1.5 font-mono text-[10px] uppercase tracking-widest text-trident-cyan/70 transition-all hover:border-trident-cyan hover:text-trident-cyan hover:bg-trident-cyan/5"
              >
                <Plus className="h-3 w-3" /> ADD SYMBOL
              </button>
            )}
          </div>
        </aside>

        {/* ── MAIN CONTENT AREA ── */}
        <section className="min-h-0 min-w-0 flex-1 overflow-y-auto border border-trident-border bg-trident-surface/20 p-4">
          {tab === "markets" && (
            <MarketsTab
              symbol={selectedSymbol}
              histPeriod={histPeriod}
              setHistPeriod={setHistPeriod}
              serviceOnline={serviceOnline}
            />
          )}
          {tab === "brief" && (
            <BriefTab
              selectedBriefId={selectedBriefId}
              setSelectedBriefId={setSelectedBriefId}
            />
          )}
          {tab === "macro" && <MacroTab />}
          {tab === "news" && (
            <NewsTab
              filter={newsFilter}
              setFilter={setNewsFilter}
              symbol={selectedSymbol}
            />
          )}
        </section>
      </div>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════
// MARKETS TAB
// ═══════════════════════════════════════════════════
function MarketsTab({
  symbol,
  histPeriod,
  setHistPeriod,
  serviceOnline,
}: {
  symbol: string | null;
  histPeriod: string;
  setHistPeriod: (p: string) => void;
  serviceOnline: boolean;
}) {
  // Quote for selected symbol
  const { data: quote, isLoading: quoteLoading } = useQuery<Quote>({
    queryKey: ["/api/markets/quote", symbol],
    enabled: !!symbol,
    staleTime: 0,
    refetchInterval: 60000,
    queryFn: () => apiGet(`/api/markets/quote/${encodeURIComponent(symbol!)}`),
  });

  // Historical data (when a non-intraday period selected)
  const periodMap: Record<string, string> = { "1W": "5d", "1M": "1mo", "3M": "3mo", "6M": "6mo", "1Y": "1y" };
  const { data: hist } = useQuery<{ data: QuotePoint[] }>({
    queryKey: ["/api/markets/history", symbol, histPeriod],
    enabled: !!symbol && histPeriod !== "intraday",
    staleTime: 0,
    queryFn: () => apiGet(`/api/markets/history/${encodeURIComponent(symbol!)}?period=${periodMap[histPeriod] || "1mo"}&interval=1d`),
  });

  // Market overview (no symbol selected)
  const { data: overview, isLoading: ovLoading } = useQuery<Record<string, OverviewItem[]>>({
    queryKey: ["/api/markets/overview"],
    enabled: !symbol,
    staleTime: 0,
    refetchInterval: 60000,
    queryFn: () => apiGet("/api/markets/overview"),
  });

  if (!serviceOnline) {
    return <OfflineBanner />;
  }

  // ── Symbol detail view ──
  if (symbol) {
    const chartData =
      histPeriod === "intraday"
        ? (quote?.intraday || []).map((p) => ({ t: p.t, c: p.c }))
        : (hist?.data || []).map((p) => ({ t: p.t, c: p.c }));
    const up = (quote?.change_pct ?? 0) >= 0;
    return (
      <div className="space-y-4">
        {/* Price header */}
        <div className="flex flex-wrap items-end justify-between gap-3 border-b border-trident-border pb-3">
          <div>
            <div className="font-display text-lg uppercase tracking-[0.2em] text-trident-cyan text-glow-cyan" data-testid="text-symbol">
              {symbol}
            </div>
            {quoteLoading ? (
              <Loader2 className="mt-2 h-6 w-6 animate-spin text-trident-cyan/50" />
            ) : (
              <div className="mt-1 flex items-baseline gap-3">
                <span className="font-mono text-3xl font-bold tabular-nums text-trident-text" data-testid="text-price">
                  {fmtNum(quote?.price)}
                </span>
                <Change pct={quote?.change_pct ?? 0} abs={quote?.change} size="lg" />
              </div>
            )}
          </div>
          {/* period toggles */}
          <div className="flex gap-1">
            {["intraday", "1W", "1M", "3M", "6M", "1Y"].map((p) => (
              <button
                key={p}
                onClick={() => setHistPeriod(p)}
                data-testid={`button-period-${p}`}
                className={`border px-2 py-1 font-mono text-[9px] uppercase tracking-widest transition-all ${
                  histPeriod === p
                    ? "border-trident-cyan/60 bg-trident-cyan/10 text-trident-cyan"
                    : "border-trident-border text-trident-text/50 hover:text-trident-cyan"
                }`}
              >
                {p === "intraday" ? "1D" : p}
              </button>
            ))}
          </div>
        </div>

        {/* Chart */}
        <LineChart data={chartData} color={up ? "#00ff41" : "#ff2244"} height={260} />

        {/* Stats grid */}
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
          {[
            { label: "HIGH", value: fmtNum(quote?.high) },
            { label: "LOW", value: fmtNum(quote?.low) },
            { label: "VOLUME", value: fmtCompact(quote?.volume) },
            { label: "MKT CAP", value: fmtCompact(quote?.market_cap) },
          ].map((s) => (
            <div key={s.label} className="border border-trident-border bg-black/30 p-3" data-testid={`stat-${s.label}`}>
              <div className="font-mono text-[9px] uppercase tracking-widest text-trident-text/40">{s.label}</div>
              <div className="mt-1 font-mono text-sm tabular-nums text-trident-cyan">{s.value}</div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  // ── Market overview grid ──
  if (ovLoading) {
    return (
      <div className="flex h-40 items-center justify-center">
        <Loader2 className="h-6 w-6 animate-spin text-trident-cyan/50" />
      </div>
    );
  }

  const catLabels: Record<string, string> = {
    indices: "INDICES", commodities: "COMMODITIES", crypto: "CRYPTO",
    bonds: "BONDS / YIELDS", fx: "FOREX",
  };
  return (
    <div className="space-y-5">
      <div className="font-mono text-[10px] uppercase tracking-widest text-trident-text/50">
        SELECT A SYMBOL FROM WATCHLIST FOR DETAILED ANALYSIS — OR REVIEW GLOBAL MARKET STATUS BELOW
      </div>
      {Object.entries(overview || {}).map(([cat, items]) => (
        <div key={cat}>
          <div className="mb-2 font-display text-xs uppercase tracking-[0.2em] text-trident-amber">
            {catLabels[cat] || cat.toUpperCase()}
          </div>
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-5">
            {(items as OverviewItem[]).map((item) => {
              const up = item.change_pct >= 0;
              return (
                <div key={item.symbol} className="border border-trident-border bg-black/30 p-2.5" data-testid={`overview-${item.symbol}`}>
                  <div className="font-mono text-[10px] uppercase tracking-wide text-trident-text/60">{item.symbol}</div>
                  <div className="mt-1 font-mono text-sm tabular-nums text-trident-text">{fmtNum(item.price)}</div>
                  <div className={`mt-0.5 flex items-center gap-0.5 font-mono text-[10px] tabular-nums ${up ? "text-trident-green" : "text-trident-red"}`}>
                    {up ? <TrendingUp className="h-2.5 w-2.5" /> : <TrendingDown className="h-2.5 w-2.5" />}
                    {up ? "+" : ""}{fmtNum(item.change_pct)}%
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      ))}
    </div>
  );
}

// ═══════════════════════════════════════════════════
// BRIEF TAB
// ═══════════════════════════════════════════════════
function BriefTab({
  selectedBriefId,
  setSelectedBriefId,
}: {
  selectedBriefId: number | null;
  setSelectedBriefId: (id: number | null) => void;
}) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: briefData, isLoading } = useQuery<{ brief: DailyBrief | null; today: string }>({
    queryKey: ["/api/markets/brief"],
    staleTime: 0,
    queryFn: () => apiGet("/api/markets/brief"),
  });
  const { data: briefsData } = useQuery<{ briefs: DailyBrief[] }>({
    queryKey: ["/api/markets/briefs"],
    staleTime: 0,
    queryFn: () => apiGet("/api/markets/briefs"),
  });

  const genMut = useMutation({
    mutationFn: async () => {
      const res = await fetch(`${API_BASE}/api/markets/brief/generate`, {
        method: "POST",
        headers: { "Content-Type": "application/json", ...getAuthHeaders() },
      });
      if (!res.ok) {
        const j = await res.json().catch(() => ({}));
        throw new Error(j.error || "GENERATION FAILED");
      }
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/markets/brief"] });
      queryClient.invalidateQueries({ queryKey: ["/api/markets/briefs"] });
      setSelectedBriefId(null);
      toast({ title: "INTELLIGENCE COMPILED" });
    },
    onError: (e: any) => toast({ title: e.message || "ERROR", variant: "destructive" }),
  });

  const briefs = briefsData?.briefs || [];
  const activeBrief =
    selectedBriefId != null
      ? briefs.find((b) => b.id === selectedBriefId) || briefData?.brief || null
      : briefData?.brief || null;

  if (isLoading) {
    return <div className="flex h-40 items-center justify-center"><Loader2 className="h-6 w-6 animate-spin text-trident-cyan/50" /></div>;
  }

  return (
    <div className="grid gap-4 lg:grid-cols-[1fr_240px]">
      {/* Brief content */}
      <div className="min-w-0">
        {genMut.isPending ? (
          <div className="flex flex-col items-center justify-center gap-3 border border-trident-cyan/30 bg-black/40 py-16">
            <Loader2 className="h-8 w-8 animate-spin text-trident-cyan" style={{ filter: "drop-shadow(0 0 8px #00f0ff)" }} />
            <span className="font-mono text-xs uppercase tracking-[0.25em] text-trident-cyan text-glow-cyan animate-pulse" data-testid="text-compiling">
              &gt;&gt; COMPILING INTELLIGENCE...
            </span>
          </div>
        ) : activeBrief ? (
          <div className="border border-trident-border bg-black/30 p-5">
            <div className="mb-4 flex items-center justify-between border-b border-trident-border pb-3">
              <h2 className="font-display text-sm uppercase tracking-[0.2em] text-trident-amber" style={{ textShadow: "0 0 8px #ff6b0080" }}>
                MARKET INTELLIGENCE BRIEF — {activeBrief.date}
              </h2>
              <button
                onClick={() => genMut.mutate()}
                data-testid="button-regenerate-brief"
                className="flex items-center gap-1.5 border border-trident-cyan/30 px-2 py-1 font-mono text-[9px] uppercase tracking-widest text-trident-cyan/70 hover:border-trident-cyan hover:text-trident-cyan"
              >
                <RefreshCw className="h-3 w-3" /> REGEN
              </button>
            </div>
            <BriefMarkdown content={activeBrief.content} />
            <div className="mt-4 border-t border-trident-border pt-2 font-mono text-[9px] uppercase tracking-widest text-trident-text/40">
              GENERATED BY {activeBrief.model_used}
            </div>
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center gap-4 border border-trident-border bg-black/30 py-16">
            <FileText className="h-10 w-10 text-trident-text/30" />
            <span className="font-mono text-xs uppercase tracking-[0.2em] text-trident-text/50" data-testid="text-no-brief">
              NO BRIEF GENERATED TODAY
            </span>
            <button
              onClick={() => genMut.mutate()}
              data-testid="button-generate-brief"
              className="flex items-center gap-2 border border-trident-cyan/50 bg-trident-cyan/10 px-4 py-2 font-mono text-[11px] uppercase tracking-widest text-trident-cyan text-glow-cyan transition-all hover:bg-trident-cyan/20"
            >
              <Radio className="h-4 w-4" /> GENERATE BRIEF
            </button>
          </div>
        )}
      </div>

      {/* Brief history */}
      <div>
        <div className="mb-2 font-mono text-[10px] uppercase tracking-widest text-trident-text/60">BRIEF ARCHIVE</div>
        <div className="space-y-1">
          {briefs.length === 0 && (
            <div className="font-mono text-[10px] uppercase tracking-widest text-trident-text/30">NO PRIOR BRIEFS</div>
          )}
          {briefs.map((b) => (
            <button
              key={b.id}
              onClick={() => setSelectedBriefId(b.id)}
              data-testid={`brief-history-${b.id}`}
              className={`w-full border-l-2 p-2 text-left transition-all ${
                (selectedBriefId ?? briefData?.brief?.id) === b.id
                  ? "border-trident-amber bg-trident-cyan/8"
                  : "border-transparent hover:bg-trident-cyan/5"
              }`}
            >
              <div className="font-mono text-[11px] uppercase tracking-widest text-trident-cyan">{b.date}</div>
              <div className="mt-0.5 truncate font-mono text-[9px] text-trident-text/40">
                {b.content.replace(/[#*\n]/g, " ").slice(0, 100)}
              </div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════
// MACRO TAB
// ═══════════════════════════════════════════════════
function MacroTab() {
  const { data, isLoading } = useQuery<{ indicators: MacroIndicator[]; error?: string }>({
    queryKey: ["/api/markets/macro"],
    staleTime: 0,
    queryFn: () => apiGet("/api/markets/macro"),
  });

  if (isLoading) {
    return <div className="flex h-40 items-center justify-center"><Loader2 className="h-6 w-6 animate-spin text-trident-cyan/50" /></div>;
  }

  const indicators = data?.indicators || [];

  return (
    <div className="space-y-4">
      <div className="font-display text-xs uppercase tracking-[0.2em] text-trident-amber">MACRO INTELLIGENCE</div>
      {indicators.length === 0 ? (
        <div className="border border-trident-border bg-black/30 p-6 font-mono text-[11px] uppercase tracking-widest text-trident-text/50">
          NO MACRO DATA — FRED_API_KEY MAY NOT BE CONFIGURED ON THE MARKET SERVICE
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {indicators.map((m) => {
            const cur = parseFloat(m.value);
            const prev = parseFloat(m.prev_value);
            const delta = cur - prev;
            const up = delta >= 0;
            const hasDelta = !isNaN(delta) && prev !== 0;
            return (
              <div key={m.id} className="border border-trident-border bg-black/30 p-4" data-testid={`macro-${m.id}`}>
                <div className="font-mono text-[10px] uppercase tracking-widest text-trident-text/50">{m.label}</div>
                <div className="mt-2 flex items-end justify-between">
                  <span className="font-mono text-2xl font-bold tabular-nums text-trident-cyan text-glow-cyan">{m.value}</span>
                  {hasDelta && (
                    <span className={`flex items-center gap-0.5 font-mono text-[11px] tabular-nums ${up ? "text-trident-green" : "text-trident-red"}`}>
                      {up ? <TrendingUp className="h-3 w-3" /> : <TrendingDown className="h-3 w-3" />}
                      {up ? "+" : ""}{fmtNum(delta)}
                    </span>
                  )}
                </div>
                <div className="mt-2 flex items-center justify-between font-mono text-[9px] uppercase tracking-wide text-trident-text/40">
                  <span>AS OF {m.date}</span>
                  <span>PREV {m.prev_value}</span>
                </div>
              </div>
            );
          })}
        </div>
      )}
      <div className="border-t border-trident-border pt-3 text-center font-mono text-[9px] uppercase tracking-widest text-trident-text/30">
        POWERED BY FEDERAL RESERVE ECONOMIC DATA
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════
// NEWS TAB
// ═══════════════════════════════════════════════════
function NewsTab({
  filter,
  setFilter,
  symbol,
}: {
  filter: "MARKET" | "SYMBOL";
  setFilter: (f: "MARKET" | "SYMBOL") => void;
  symbol: string | null;
}) {
  const effectiveSymbol = filter === "SYMBOL" && symbol ? symbol : "";
  const { data, isLoading } = useQuery<{ news: NewsItem[]; symbol: string }>({
    queryKey: ["/api/markets/news", effectiveSymbol],
    staleTime: 0,
    refetchInterval: 300000,
    queryFn: () => apiGet(`/api/markets/news${effectiveSymbol ? `?symbol=${encodeURIComponent(effectiveSymbol)}` : ""}`),
  });

  const news = data?.news || [];

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between border-b border-trident-border pb-3">
        <div className="font-display text-xs uppercase tracking-[0.2em] text-trident-amber">INTELLIGENCE FEED</div>
        <div className="flex gap-1">
          {(["MARKET", "SYMBOL"] as const).map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              disabled={f === "SYMBOL" && !symbol}
              data-testid={`news-filter-${f}`}
              className={`border px-3 py-1 font-mono text-[9px] uppercase tracking-widest transition-all disabled:opacity-30 ${
                filter === f
                  ? "border-trident-cyan/60 bg-trident-cyan/10 text-trident-cyan"
                  : "border-trident-border text-trident-text/50 hover:text-trident-cyan"
              }`}
            >
              {f === "SYMBOL" && symbol ? symbol : f}
            </button>
          ))}
        </div>
      </div>

      {isLoading ? (
        <div className="flex h-40 items-center justify-center"><Loader2 className="h-6 w-6 animate-spin text-trident-cyan/50" /></div>
      ) : news.length === 0 ? (
        <div className="border border-trident-border bg-black/30 p-6 font-mono text-[11px] uppercase tracking-widest text-trident-text/50">
          NO INTELLIGENCE FEED AVAILABLE
        </div>
      ) : (
        <div className="space-y-2">
          {news.map((n, i) => (
            <a
              key={i}
              href={n.link}
              target="_blank"
              rel="noopener noreferrer"
              data-testid={`news-item-${i}`}
              className="group block border border-trident-border bg-black/30 p-3 transition-all hover:border-trident-cyan/40 hover:bg-trident-cyan/5"
            >
              <div className="flex items-start justify-between gap-2">
                <span className="font-mono text-sm text-trident-text group-hover:text-trident-cyan">{n.title}</span>
                <ExternalLink className="h-3 w-3 flex-shrink-0 text-trident-text/30 group-hover:text-trident-cyan" />
              </div>
              <div className="mt-1 flex items-center gap-2 font-mono text-[9px] uppercase tracking-widest text-trident-text/40">
                <span className="text-trident-amber">{n.publisher}</span>
                {n.published ? <span>• {timeAgo(n.published)}</span> : null}
              </div>
              {n.summary && (
                <div className="mt-1.5 font-mono text-[11px] leading-relaxed text-trident-text/60 line-clamp-2">
                  {n.summary}
                </div>
              )}
            </a>
          ))}
        </div>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════
// Offline banner
// ═══════════════════════════════════════════════════
function OfflineBanner() {
  return (
    <div className="flex flex-col items-center justify-center gap-3 border border-trident-red/40 bg-trident-red/5 py-16" data-testid="banner-offline">
      <Radio className="h-10 w-10 text-trident-red/60" />
      <span className="font-mono text-xs uppercase tracking-[0.2em] text-trident-red">MARKET SERVICE OFFLINE</span>
      <span className="max-w-md text-center font-mono text-[10px] uppercase tracking-widest text-trident-text/40">
        THE PYTHON MARKET INTELLIGENCE SERVICE (PORT 5002) IS NOT RESPONDING.
        RUN scripts/setup-markets.sh TO DEPLOY IT.
      </span>
    </div>
  );
}

// ═══════════════════════════════════════════════════
// GEO-INTEL TAB (Phase 2)
// ═══════════════════════════════════════════════════
function rssTimeAgo(pub: string): string {
  if (!pub) return "";
  const t = Date.parse(pub);
  if (isNaN(t)) return "";
  const diff = (Date.now() - t) / 1000;
  if (diff < 60) return "JUST NOW";
  if (diff < 3600) return `${Math.floor(diff / 60)}M AGO`;
  if (diff < 86400) return `${Math.floor(diff / 3600)}H AGO`;
  return `${Math.floor(diff / 86400)}D AGO`;
}

function GeoStatCard({
  label,
  value,
  icon: Icon,
  accent = "cyan",
}: {
  label: string;
  value: string;
  icon: any;
  accent?: "cyan" | "red" | "amber" | "green";
}) {
  const color =
    accent === "red" ? "text-trident-red"
    : accent === "amber" ? "text-trident-amber"
    : accent === "green" ? "text-trident-green"
    : "text-trident-cyan";
  return (
    <div className="border border-trident-border bg-black/30 p-4" data-testid={`geo-stat-${label.toLowerCase().replace(/[^a-z0-9]+/g, "-")}`}>
      <div className="flex items-center justify-between">
        <div className="font-mono text-[10px] uppercase tracking-widest text-trident-amber">{label}</div>
        <Icon className={`h-3.5 w-3.5 ${color}`} />
      </div>
      <div className={`mt-2 font-mono text-2xl font-bold tabular-nums ${color} ${accent === "cyan" ? "text-glow-cyan" : ""}`}>
        {value}
      </div>
    </div>
  );
}

function GeoIntelTab() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [feedTab, setFeedTab] = useState<"MILITARY" | "GEOPOLITICAL">("MILITARY");
  const [selectedGeoBriefId, setSelectedGeoBriefId] = useState<number | null>(null);

  // ── Geo service status ──
  const { data: statusData } = useQuery<{ online: boolean }>({
    queryKey: ["/api/geo/status"],
    staleTime: 0,
    refetchInterval: 30000,
    queryFn: () => apiGet("/api/geo/status"),
  });
  const geoOnline = statusData?.online ?? false;

  // ── Threat summary ──
  const { data: threatData, isLoading: threatLoading } = useQuery<GeoThreatSummary>({
    queryKey: ["/api/geo/threat-summary"],
    staleTime: 0,
    refetchInterval: 300000,
    queryFn: () => apiGet("/api/geo/threat-summary"),
  });
  const acled = threatData?.acled || {};
  const hotspots = acled.top_hotspots || [];
  const acledConfigured = acled.available === true && !acled.error && (acled.total_events_7d !== undefined && hotspots.length > 0);
  const maxHotspot = Math.max(1, ...hotspots.map((h) => h.events));

  // ── GDELT — country mentions (24h) — primary conflict/geo-intel source ──
  const { data: gdeltCountryData, isLoading: gdeltCountryLoading } = useQuery<GdeltCountrySummaryResponse>({
    queryKey: ["/api/geo/gdelt/countries"],
    staleTime: 0,
    refetchInterval: 900000,
    queryFn: () => apiGet("/api/geo/gdelt/countries"),
  });
  const gdeltHotspots = gdeltCountryData?.summary || [];
  const maxGdeltHotspot = Math.max(1, ...gdeltHotspots.map((h) => h.mentions));

  // ── GDELT — conflict news feed (24h) ──
  const { data: gdeltEventsData, isLoading: gdeltEventsLoading } = useQuery<GdeltEventsResponse>({
    queryKey: ["/api/geo/gdelt/events"],
    staleTime: 0,
    refetchInterval: 900000,
    queryFn: () => apiGet("/api/geo/gdelt/events"),
  });
  const gdeltArticles = gdeltEventsData?.events || [];

  // ── Intel feed (military / geopolitical) ──
  const { data: milData } = useQuery<{ articles: GeoArticle[] }>({
    queryKey: ["/api/geo/news/military"],
    staleTime: 0,
    refetchInterval: 300000,
    queryFn: () => apiGet("/api/geo/news/military"),
  });
  const { data: geoNewsData } = useQuery<{ articles: GeoArticle[] }>({
    queryKey: ["/api/geo/news/geopolitical"],
    staleTime: 0,
    refetchInterval: 300000,
    queryFn: () => apiGet("/api/geo/news/geopolitical"),
  });
  const feedArticles = (feedTab === "MILITARY" ? milData?.articles : geoNewsData?.articles) || [];

  // ── Geo briefs ──
  const { data: geoBriefData } = useQuery<{ brief: GeoBrief | null; today: string }>({
    queryKey: ["/api/geo/brief"],
    staleTime: 0,
    queryFn: () => apiGet("/api/geo/brief"),
  });
  const { data: geoBriefsData } = useQuery<{ briefs: GeoBrief[] }>({
    queryKey: ["/api/geo/briefs"],
    staleTime: 0,
    queryFn: () => apiGet("/api/geo/briefs"),
  });
  const geoBriefs = geoBriefsData?.briefs || [];
  const activeGeoBrief =
    selectedGeoBriefId != null
      ? geoBriefs.find((b) => b.id === selectedGeoBriefId) || geoBriefData?.brief || null
      : geoBriefData?.brief || null;

  const genMut = useMutation({
    mutationFn: async () => {
      const res = await fetch(`${API_BASE}/api/geo/brief/generate`, {
        method: "POST",
        headers: { "Content-Type": "application/json", ...getAuthHeaders() },
      });
      if (!res.ok) {
        const j = await res.json().catch(() => ({}));
        throw new Error(j.error || "GENERATION FAILED");
      }
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/geo/brief"] });
      queryClient.invalidateQueries({ queryKey: ["/api/geo/briefs"] });
      setSelectedGeoBriefId(null);
      toast({ title: "TACTICAL INTELLIGENCE COMPILED" });
    },
    onError: (e: any) => toast({ title: e.message || "ERROR", variant: "destructive" }),
  });

  const fmtInt = (n: number | undefined) =>
    n === undefined || n === null || isNaN(n) ? "—" : n.toLocaleString("en-US");

  return (
    <div className="space-y-4" data-testid="geo-intel-tab">
      {/* ── Service status indicator ── */}
      <div className="flex items-center justify-between border-b border-trident-border pb-3">
        <div className="flex items-center gap-2">
          <Globe className="h-4 w-4 text-trident-amber" style={{ filter: "drop-shadow(0 0 6px #ff6b00)" }} />
          <span className="font-display text-xs uppercase tracking-[0.2em] text-trident-cyan text-glow-cyan">
            GEO-INTELLIGENCE
          </span>
        </div>
        <span className="flex items-center gap-1.5" data-testid="status-geo-service">
          <span
            className={`inline-block h-2 w-2 rounded-full ${geoOnline ? "bg-trident-green animate-pulse" : "bg-trident-red"}`}
            style={geoOnline ? { boxShadow: "0 0 6px #00ff41" } : { boxShadow: "0 0 6px #ff2244" }}
          />
          <span className={`font-mono text-[9px] uppercase tracking-widest ${geoOnline ? "text-trident-green" : "text-trident-red"}`}>
            {geoOnline ? "GEO SERVICE ONLINE" : "GEO SERVICE OFFLINE — RUN scripts/setup-geo.sh"}
          </span>
        </span>
      </div>

      {/* ── Top stats row ── */}
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <GeoStatCard
          label={acledConfigured ? "CONFLICT EVENTS (7D)" : "ARTICLES (24H)"}
          value={threatLoading ? "..." : acledConfigured ? fmtInt(acled.total_events_7d) : fmtInt(threatData?.gdelt?.total_articles_24h)}
          icon={Crosshair}
          accent="cyan"
        />
        <GeoStatCard
          label="FATALITIES (7D)"
          value={threatLoading ? "..." : acledConfigured ? fmtInt(acled.total_fatalities_7d) : "N/A"}
          icon={Skull}
          accent="red"
        />
        <GeoStatCard
          label="ACTIVE HOTSPOTS"
          value={threatLoading ? "..." : acledConfigured ? fmtInt(hotspots.length) : fmtInt(gdeltHotspots.length)}
          icon={Activity}
          accent="amber"
        />
        <GeoStatCard
          label="DATA SOURCES"
          value="ACLED · GDELT · 6 RSS"
          icon={Database}
          accent="green"
        />
      </div>

      {/* ── Middle row: hotspots + feed ── */}
      <div className="grid gap-3 lg:grid-cols-2">
        {/* Top conflict zones — GDELT primary, ACLED shown too when available */}
        <div className="border border-trident-border bg-black/30 p-4">
          <div className="mb-3 font-display text-[11px] uppercase tracking-[0.2em] text-trident-amber">
            {acledConfigured ? "TOP CONFLICT ZONES (ACLED — 7D EVENTS)" : "TOP CONFLICT ZONES (GDELT — 24H MENTIONS)"}
          </div>
          {acledConfigured ? (
            <div className="space-y-2.5" data-testid="geo-acled-hotspots">
              {hotspots.map((h) => (
                <div key={h.country} className="flex items-center gap-3" data-testid={`geo-hotspot-${h.country}`}>
                  <div className="w-28 flex-shrink-0 truncate font-mono text-[11px] uppercase tracking-wide text-trident-text/80">
                    {h.country}
                  </div>
                  <div className="h-2.5 flex-1 overflow-hidden border border-trident-border bg-black/40">
                    <div
                      className="h-full bg-trident-amber"
                      style={{
                        width: `${Math.max(6, (h.events / maxHotspot) * 100)}%`,
                        boxShadow: "0 0 6px #ff6b00",
                      }}
                    />
                  </div>
                  <div className="w-20 flex-shrink-0 text-right font-mono text-[11px] tabular-nums text-trident-cyan">
                    {h.events} events
                  </div>
                </div>
              ))}
            </div>
          ) : gdeltCountryLoading ? (
            <div className="font-mono text-[10px] uppercase tracking-widest text-trident-text/40">
              LOADING GDELT DATA...
            </div>
          ) : gdeltHotspots.length === 0 ? (
            <div className="font-mono text-[10px] uppercase tracking-widest text-trident-text/40">
              NO CONFLICT ZONES DETECTED
            </div>
          ) : (
            <div className="space-y-2.5" data-testid="geo-gdelt-hotspots">
              {gdeltHotspots.map((h) => (
                <div key={h.country} className="flex items-center gap-3" data-testid={`geo-gdelt-hotspot-${h.country}`}>
                  <div className="w-28 flex-shrink-0 truncate font-mono text-[11px] uppercase tracking-wide text-trident-text/80">
                    {h.country}
                  </div>
                  <div className="h-2.5 flex-1 overflow-hidden border border-trident-border bg-black/40">
                    <div
                      className="h-full bg-trident-cyan"
                      style={{
                        width: `${Math.max(6, (h.mentions / maxGdeltHotspot) * 100)}%`,
                        boxShadow: "0 0 6px #00f0ff",
                      }}
                    />
                  </div>
                  <div className="w-24 flex-shrink-0 text-right font-mono text-[11px] tabular-nums text-trident-cyan">
                    {h.mentions} mentions
                  </div>
                </div>
              ))}
            </div>
          )}
          {!acledConfigured && (
            <div className="mt-3 border border-trident-amber/20 bg-trident-amber/5 p-2 font-mono text-[9px] uppercase leading-relaxed tracking-widest text-trident-amber/70" data-testid="geo-acled-offline">
              ACLED NOT CONFIGURED — USING GDELT AS PRIMARY SOURCE (NO AUTH REQUIRED)
            </div>
          )}
        </div>

        {/* Intel feed */}
        <div className="border border-trident-border bg-black/30 p-4">
          <div className="mb-3 flex items-center justify-between">
            <div className="font-display text-[11px] uppercase tracking-[0.2em] text-trident-amber">INTEL FEED</div>
            <div className="flex gap-1">
              {(["MILITARY", "GEOPOLITICAL"] as const).map((f) => (
                <button
                  key={f}
                  onClick={() => setFeedTab(f)}
                  data-testid={`geo-feed-${f}`}
                  className={`border px-2.5 py-1 font-mono text-[9px] uppercase tracking-widest transition-all ${
                    feedTab === f
                      ? "border-trident-cyan/60 bg-trident-cyan/10 text-trident-cyan"
                      : "border-trident-border text-trident-text/50 hover:text-trident-cyan"
                  }`}
                >
                  {f}
                </button>
              ))}
            </div>
          </div>
          <div className="max-h-[350px] space-y-2 overflow-y-auto pr-1">
            {feedArticles.length === 0 ? (
              <div className="font-mono text-[10px] uppercase tracking-widest text-trident-text/40">
                NO INTEL FEED AVAILABLE
              </div>
            ) : (
              feedArticles.map((a, i) => (
                <a
                  key={i}
                  href={a.link}
                  target="_blank"
                  rel="noopener noreferrer"
                  data-testid={`geo-article-${i}`}
                  className="group block border border-trident-border bg-black/20 p-2.5 transition-all hover:border-trident-cyan/40 hover:bg-trident-cyan/5"
                >
                  <div className="flex items-center gap-2 font-mono text-[8px] uppercase tracking-widest text-trident-text/40">
                    <span className="text-trident-amber">{a.source}</span>
                    {a.published ? <span>• {rssTimeAgo(a.published)}</span> : null}
                  </div>
                  <div className="mt-1 font-mono text-[12px] leading-snug text-trident-text group-hover:text-trident-cyan">
                    {a.title}
                  </div>
                  {a.description && (
                    <div className="mt-1 font-mono text-[10px] leading-relaxed text-trident-text/50 line-clamp-2">
                      {a.description.replace(/<[^>]*>/g, "")}
                    </div>
                  )}
                </a>
              ))
            )}
          </div>
        </div>
      </div>

      {/* ── GDELT conflict news (24h) ── */}
      <div className="border border-trident-border bg-black/30 p-4">
        <div className="mb-3 flex items-center justify-between">
          <div className="font-display text-[11px] uppercase tracking-[0.2em] text-trident-amber">
            GDELT CONFLICT NEWS (24H)
          </div>
          <span className="font-mono text-[9px] uppercase tracking-widest text-trident-text/40">
            {gdeltEventsData?.count ?? 0} ARTICLES
          </span>
        </div>
        <div className="max-h-[400px] space-y-2 overflow-y-auto pr-1" data-testid="gdelt-news-list">
          {gdeltEventsLoading ? (
            <div className="font-mono text-[10px] uppercase tracking-widest text-trident-text/40">
              LOADING GDELT CONFLICT NEWS...
            </div>
          ) : gdeltArticles.length === 0 ? (
            <div className="font-mono text-[10px] uppercase tracking-widest text-trident-text/40">
              NO GDELT CONFLICT NEWS AVAILABLE
            </div>
          ) : (
            gdeltArticles.map((a, i) => (
              <a
                key={i}
                href={a.url}
                target="_blank"
                rel="noopener noreferrer"
                data-testid={`gdelt-article-${i}`}
                className="group block border border-trident-border bg-black/20 p-2.5 transition-all hover:border-trident-cyan/40 hover:bg-trident-cyan/5"
              >
                <div className="flex flex-wrap items-center gap-2 font-mono text-[8px] uppercase tracking-widest text-trident-text/40">
                  <span className="text-trident-amber">{a.domain}</span>
                  {a.country && <span>• {a.country}</span>}
                  {a.seen_date && <span>• {a.seen_date}</span>}
                </div>
                <div className="mt-1 flex items-center gap-1.5 font-mono text-[12px] leading-snug text-trident-text group-hover:text-trident-cyan">
                  {a.title}
                  <ExternalLink className="h-3 w-3 flex-shrink-0 opacity-0 group-hover:opacity-70" />
                </div>
              </a>
            ))
          )}
        </div>
      </div>

      {/* ── Geo-intel brief ── */}
      <div className="grid gap-4 lg:grid-cols-[1fr_240px]">
        <div className="min-w-0">
          {genMut.isPending ? (
            <div className="flex flex-col items-center justify-center gap-3 border border-trident-cyan/30 bg-black/40 py-16">
              <Loader2 className="h-8 w-8 animate-spin text-trident-cyan" style={{ filter: "drop-shadow(0 0 8px #00f0ff)" }} />
              <span className="font-mono text-xs uppercase tracking-[0.25em] text-trident-cyan text-glow-cyan animate-pulse" data-testid="geo-text-compiling">
                &gt;&gt; COMPILING TACTICAL INTELLIGENCE...
              </span>
            </div>
          ) : activeGeoBrief ? (
            <div className="border border-trident-border bg-black/30 p-5">
              <div className="mb-4 flex items-center justify-between border-b border-trident-border pb-3">
                <h2 className="font-display text-sm uppercase tracking-[0.2em] text-trident-amber" style={{ textShadow: "0 0 8px #ff6b0080" }}>
                  GEO-INTEL BRIEF — {activeGeoBrief.date}
                </h2>
                <button
                  onClick={() => genMut.mutate()}
                  data-testid="geo-button-regenerate"
                  className="flex items-center gap-1.5 border border-trident-cyan/30 px-2 py-1 font-mono text-[9px] uppercase tracking-widest text-trident-cyan/70 hover:border-trident-cyan hover:text-trident-cyan"
                >
                  <RefreshCw className="h-3 w-3" /> REGEN
                </button>
              </div>
              <BriefMarkdown content={activeGeoBrief.content} />
              <div className="mt-4 border-t border-trident-border pt-2 font-mono text-[9px] uppercase tracking-widest text-trident-text/40">
                GENERATED BY {activeGeoBrief.model_used} · {activeGeoBrief.region_focus || "GLOBAL"}
              </div>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center gap-4 border border-trident-border bg-black/30 py-16">
              <Globe className="h-10 w-10 text-trident-text/30" />
              <span className="font-mono text-xs uppercase tracking-[0.2em] text-trident-text/50" data-testid="geo-text-no-brief">
                NO GEO-INTEL BRIEF GENERATED TODAY
              </span>
              <button
                onClick={() => genMut.mutate()}
                data-testid="geo-button-generate"
                className="flex items-center gap-2 border border-trident-cyan/50 bg-trident-cyan/10 px-4 py-2 font-mono text-[11px] uppercase tracking-widest text-trident-cyan text-glow-cyan transition-all hover:bg-trident-cyan/20"
              >
                <Radio className="h-4 w-4" /> GENERATE GEO-INTEL BRIEF
              </button>
            </div>
          )}
        </div>

        {/* Brief archive */}
        <div>
          <div className="mb-2 font-mono text-[10px] uppercase tracking-widest text-trident-text/60">GEO-INTEL ARCHIVE</div>
          <div className="space-y-1">
            {geoBriefs.length === 0 && (
              <div className="font-mono text-[10px] uppercase tracking-widest text-trident-text/30">NO PRIOR BRIEFS</div>
            )}
            {geoBriefs.slice(0, 5).map((b) => (
              <button
                key={b.id}
                onClick={() => setSelectedGeoBriefId(b.id)}
                data-testid={`geo-brief-history-${b.id}`}
                className={`w-full border-l-2 p-2 text-left transition-all ${
                  (selectedGeoBriefId ?? geoBriefData?.brief?.id) === b.id
                    ? "border-trident-amber bg-trident-cyan/8"
                    : "border-transparent hover:bg-trident-cyan/5"
                }`}
              >
                <div className="font-mono text-[11px] uppercase tracking-widest text-trident-cyan">{b.date}</div>
                <div className="mt-0.5 truncate font-mono text-[9px] text-trident-text/40">
                  {b.content.replace(/[#*\n]/g, " ").slice(0, 100)}
                </div>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════
// FLIGHTS TAB (Phase 6) — Flight Intelligence over Denton, NC
// ═══════════════════════════════════════════════════

const DENTON_LAT = 35.6262;
const DENTON_LON = -80.1131;
const FLIGHT_RADIUS_NM = 25;

// Compass direction from degrees
function headingToCompass(deg: number): string {
  const dirs = ["N", "NE", "E", "SE", "S", "SW", "W", "NW"];
  return dirs[Math.round(((deg % 360) / 45)) % 8];
}

// Altitude color coding
function altColor(ft: number): string {
  if (ft < 10000) return "#00ff41"; // green
  if (ft <= 35000) return "#00f0ff"; // cyan
  return "#ff6b00"; // amber
}

// Military squawk detection (7500 hijack, 7600 radio fail, 7700 emergency, 7777 mil intercept)
function isMilSquawk(sq: string): boolean {
  return ["7500", "7600", "7700", "7777"].includes((sq || "").trim());
}

// Download a protected file via fetch->blob so auth headers are sent
async function downloadFlightExport(path: string, filename: string): Promise<void> {
  const res = await fetch(`${API_BASE}${path}`, { headers: getAuthHeaders() });
  if (!res.ok) throw new Error(`EXPORT FAILED: ${res.status}`);
  const blob = await res.blob();
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

// ── SVG Radar Display ──
function RadarDisplay({ aircraft }: { aircraft: Aircraft[] }) {
  const SIZE = 340;
  const CENTER = SIZE / 2;
  const MARGIN = 22;
  const maxR = CENTER - MARGIN; // pixels == RADIUS_NM
  const nmToPx = maxR / FLIGHT_RADIUS_NM;

  // Convert lat/lon to SVG x/y relative to Denton center.
  // North = up (negative y), East = right (positive x).
  const project = (lat: number, lon: number) => {
    const dNorthNm = (lat - DENTON_LAT) * 60; // 1 deg lat ≈ 60nm
    const dEastNm = (lon - DENTON_LON) * 60 * Math.cos((DENTON_LAT * Math.PI) / 180);
    return { x: CENTER + dEastNm * nmToPx, y: CENTER - dNorthNm * nmToPx };
  };

  return (
    <svg viewBox={`0 0 ${SIZE} ${SIZE}`} width="100%" style={{ maxWidth: SIZE, display: "block", margin: "0 auto" }} data-testid="radar-display">
      <defs>
        <radialGradient id="radarGlow" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="#00f0ff" stopOpacity="0.06" />
          <stop offset="100%" stopColor="#00f0ff" stopOpacity="0" />
        </radialGradient>
      </defs>
      <rect x="0" y="0" width={SIZE} height={SIZE} fill="#050a0e" />
      <circle cx={CENTER} cy={CENTER} r={maxR} fill="url(#radarGlow)" />
      {/* Range rings at 10, 20, 25 nm */}
      {[10, 20, 25].map((nm) => (
        <g key={nm}>
          <circle cx={CENTER} cy={CENTER} r={nm * nmToPx} fill="none" stroke="#00f0ff" strokeOpacity="0.25" strokeWidth="1" strokeDasharray={nm === 25 ? "0" : "3 4"} />
          <text x={CENTER + 3} y={CENTER - nm * nmToPx + 10} fill="#00f0ff" fillOpacity="0.4" fontSize="8" fontFamily="monospace">{nm}NM</text>
        </g>
      ))}
      {/* Crosshair axes */}
      <line x1={CENTER} y1={MARGIN} x2={CENTER} y2={SIZE - MARGIN} stroke="#00f0ff" strokeOpacity="0.15" strokeWidth="1" />
      <line x1={MARGIN} y1={CENTER} x2={SIZE - MARGIN} y2={CENTER} stroke="#00f0ff" strokeOpacity="0.15" strokeWidth="1" />
      {/* Cardinal labels */}
      <text x={CENTER} y={MARGIN - 6} fill="#00f0ff" fillOpacity="0.6" fontSize="10" fontFamily="monospace" textAnchor="middle">N</text>
      <text x={CENTER} y={SIZE - MARGIN + 14} fill="#00f0ff" fillOpacity="0.6" fontSize="10" fontFamily="monospace" textAnchor="middle">S</text>
      <text x={SIZE - MARGIN + 10} y={CENTER + 3} fill="#00f0ff" fillOpacity="0.6" fontSize="10" fontFamily="monospace" textAnchor="middle">E</text>
      <text x={MARGIN - 10} y={CENTER + 3} fill="#00f0ff" fillOpacity="0.6" fontSize="10" fontFamily="monospace" textAnchor="middle">W</text>
      {/* Center — Denton NC */}
      <circle cx={CENTER} cy={CENTER} r="3" fill="#ff6b00" style={{ filter: "drop-shadow(0 0 4px #ff6b00)" }} />
      <text x={CENTER + 6} y={CENTER + 12} fill="#ff6b00" fontSize="7" fontFamily="monospace">DENTON</text>
      {/* Aircraft */}
      {aircraft.map((a) => {
        const { x, y } = project(a.latitude, a.longitude);
        if (x < 0 || x > SIZE || y < 0 || y > SIZE) return null;
        const color = (isMilSquawk(a.squawk) || a.is_military) ? "#ff2244" : a.altitude_ft > 35000 ? "#ff6b00" : "#00ff41";
        return (
          <g key={a.icao24} transform={`translate(${x}, ${y})`}>
            {/* Triangle pointing in heading direction */}
            <g transform={`rotate(${a.heading})`}>
              <path d="M 0 -5 L 4 5 L 0 2 L -4 5 Z" fill={color} style={{ filter: `drop-shadow(0 0 3px ${color})` }} />
            </g>
            <text x="6" y="3" fill={color} fontSize="6.5" fontFamily="monospace">{a.callsign}</text>
          </g>
        );
      })}
    </svg>
  );
}

function FlightsTab() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [historyPage, setHistoryPage] = useState(0);
  const [dateFilter, setDateFilter] = useState("");
  const [clearOpen, setClearOpen] = useState(false);
  const [clearMode, setClearMode] = useState<null | "today" | "old" | "all">(null);
  const [confirmText, setConfirmText] = useState("");
  const PAGE_SIZE = 50;

  // ── Voice announce toggle — announce new aircraft entering the AO ──
  const [announceEnabled, setAnnounceEnabled] = useState(
    () => localStorage.getItem("trident_flight_voice_announce") === "true"
  );
  const seenAircraftRef = useRef<Set<string>>(new Set());
  const announceInitRef = useRef(false);

  useEffect(() => {
    localStorage.setItem("trident_flight_voice_announce", String(announceEnabled));
  }, [announceEnabled]);

  // ── Live aircraft — refresh every 15 seconds ──
  const { data: liveData } = useQuery<FlightLiveResponse>({
    queryKey: ["/api/flights/live"],
    queryFn: () => apiGet("/api/flights/live"),
    staleTime: 0,
    refetchInterval: 15000,
  });

  // ── Stats — refresh every 5 minutes ──
  const { data: statsData } = useQuery<FlightStats>({
    queryKey: ["/api/flights/stats"],
    queryFn: () => apiGet("/api/flights/stats"),
    staleTime: 0,
    refetchInterval: 300000,
  });

  // ── History — refresh every minute ──
  const { data: historyData } = useQuery<FlightHistoryResponse>({
    queryKey: ["/api/flights/history", historyPage, dateFilter],
    queryFn: () => {
      const qs = new URLSearchParams({ limit: String(PAGE_SIZE), offset: String(historyPage * PAGE_SIZE) });
      if (dateFilter) qs.set("date", dateFilter);
      return apiGet(`/api/flights/history?${qs.toString()}`);
    },
    staleTime: 0,
    refetchInterval: 60000,
  });

  // ── Service health ──
  const { data: healthData } = useQuery<FlightHealth>({
    queryKey: ["/api/flights/health"],
    queryFn: () => apiGet("/api/flights/health"),
    staleTime: 0,
    refetchInterval: 30000,
  });

  // ── Storage info — refresh every 5 minutes ──
  const { data: storageData } = useQuery<FlightStorage>({
    queryKey: ["/api/flights/storage"],
    queryFn: () => apiGet("/api/flights/storage"),
    staleTime: 0,
    refetchInterval: 300000,
  });

  const aircraft = liveData?.aircraft || [];

  // ── Announce newly-detected aircraft entering the AO via TTS ──
  useEffect(() => {
    if (!aircraft.length) return;
    // On first population of the seen-set, just baseline it — don't announce
    // every aircraft already overhead when the tab/toggle first loads.
    if (!announceInitRef.current) {
      seenAircraftRef.current = new Set(aircraft.map((a) => a.callsign));
      announceInitRef.current = true;
      return;
    }
    if (!announceEnabled) {
      seenAircraftRef.current = new Set(aircraft.map((a) => a.callsign));
      return;
    }
    const newAircraft = aircraft.filter((a) => !seenAircraftRef.current.has(a.callsign));

    newAircraft.forEach(async (a) => {
      const text = `New aircraft detected: ${a.callsign || "unknown callsign"}, altitude ${a.altitude_ft.toLocaleString()} feet, ${a.distance_nm} nautical miles ${headingToCompass(a.heading)}.${a.is_military ? " Military aircraft." : ""}`;
      try {
        const res = await fetch(`${API_BASE}/api/command/tts`, {
          method: "POST",
          headers: { ...getAuthHeaders(), "Content-Type": "application/json" },
          body: JSON.stringify({ text }),
        });
        if (res.ok) {
          const blob = await res.blob();
          new Audio(URL.createObjectURL(blob)).play().catch(() => {});
        }
      } catch {}
    });

    seenAircraftRef.current = new Set(aircraft.map((a) => a.callsign));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [liveData, announceEnabled]);

  const source = liveData?.source || healthData?.data_source || "offline";
  const serviceOnline = source !== "offline" && (healthData?.status === "ok" || aircraft.length >= 0 && !!liveData);
  const isOpenSky = source === "opensky";
  const flights = historyData?.flights || [];
  const totalHistory = historyData?.total || 0;
  const totalPages = Math.max(1, Math.ceil(totalHistory / PAGE_SIZE));

  const invalidateAll = () => {
    queryClient.invalidateQueries({ queryKey: ["/api/flights/history"] });
    queryClient.invalidateQueries({ queryKey: ["/api/flights/stats"] });
    queryClient.invalidateQueries({ queryKey: ["/api/flights/storage"] });
  };

  // ── Clear mutation ──
  const clearMut = useMutation({
    mutationFn: async (mode: "today" | "old" | "all") => {
      const qs = new URLSearchParams();
      if (mode === "today") qs.set("date", new Date().toISOString().slice(0, 10));
      if (mode === "old") {
        const d = new Date();
        d.setDate(d.getDate() - 30);
        qs.set("before", d.toISOString().slice(0, 10));
      }
      const res = await fetch(`${API_BASE}/api/flights/clear${qs.toString() ? `?${qs.toString()}` : ""}`, {
        method: "DELETE",
        headers: getAuthHeaders(),
      });
      const j = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(j.message || j.error || "PURGE FAILED");
      return j;
    },
    onSuccess: (j: any) => {
      invalidateAll();
      setClearMode(null);
      setClearOpen(false);
      setConfirmText("");
      toast({ title: `PURGE COMPLETE — ${j.deleted ?? 0} RECORDS DELETED` });
    },
    onError: (e: any) => toast({ title: e.message || "PURGE FAILED", variant: "destructive" }),
  });

  // Estimate records for the pending purge (for the confirmation dialog)
  const pendingCount =
    clearMode === "today"
      ? (storageData?.records_by_date?.find((r) => r.date === new Date().toISOString().slice(0, 10))?.count ?? 0)
      : clearMode === "old"
        ? Math.max(0, (storageData?.total_records ?? 0) - (storageData?.records_by_date || []).reduce((s, r) => s + r.count, 0))
        : (storageData?.total_records ?? 0);

  const clearLabel =
    clearMode === "today" ? "TODAY'S RECORDS" : clearMode === "old" ? "RECORDS OLDER THAN 30 DAYS" : "ALL FLIGHT DATA";

  return (
    <div className="space-y-3 p-1" data-testid="flights-tab">
      {/* ═══ TOP STATUS BAR ═══ */}
      <div className="flex flex-wrap items-center justify-between gap-3 border border-trident-border bg-trident-surface/40 px-3 py-2">
        <div className="flex items-center gap-3">
          <span className="flex items-center gap-1.5">
            <span
              className={`inline-block h-2 w-2 rounded-full ${serviceOnline ? "bg-trident-green animate-pulse" : "bg-trident-red"}`}
              style={{ boxShadow: serviceOnline ? "0 0 6px #00ff41" : "0 0 6px #ff2244" }}
              data-testid="status-flight-service"
            />
            <span className={`font-mono text-[9px] uppercase tracking-widest ${serviceOnline ? "text-trident-green" : "text-trident-red"}`}>
              {serviceOnline ? "ONLINE" : "OFFLINE"}
            </span>
          </span>
          <span
            className={`border px-2 py-0.5 font-mono text-[9px] uppercase tracking-widest ${
              isOpenSky
                ? "border-trident-amber/50 text-trident-amber"
                : source === "dump1090"
                  ? "border-trident-green/50 text-trident-green"
                  : "border-trident-red/50 text-trident-red"
            }`}
            data-testid="badge-data-source"
          >
            {isOpenSky ? "OPENSKY NETWORK" : source === "dump1090" ? "LOCAL SDR — DUMP1090" : "SERVICE OFFLINE"}
          </span>
        </div>
        <div className="flex items-center gap-4">
          <span className="font-mono text-[9px] uppercase tracking-widest text-trident-text/50">
            UPDATED {liveData?.timestamp ? new Date(liveData.timestamp + "Z").toLocaleTimeString("en-US", { hour12: false }) : "—"}
          </span>
          <span className="font-mono text-[10px] uppercase tracking-widest text-trident-cyan text-glow-cyan" data-testid="text-overhead-count">
            {aircraft.length} AIRCRAFT OVERHEAD
          </span>
          <button
            onClick={() => setAnnounceEnabled((v) => !v)}
            data-testid="toggle-voice-announce"
            className={`flex items-center gap-1.5 border px-2 py-1 font-mono text-[9px] uppercase tracking-widest transition-all ${
              announceEnabled
                ? "border-trident-green/60 bg-trident-green/10 text-trident-green"
                : "border-trident-border text-trident-text/50 hover:border-trident-green/30 hover:text-trident-green"
            }`}
          >
            {announceEnabled ? <Volume2 className="h-3 w-3" /> : <VolumeX className="h-3 w-3" />}
            ANNOUNCE AIRCRAFT ENTERING AO
          </button>
        </div>
      </div>

      {/* ═══ STATS ROW ═══ */}
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        {[
          { label: "OVERHEAD NOW", value: `${aircraft.length}`, color: "#00f0ff", testid: "stat-overhead" },
          { label: "TODAY'S FLIGHTS", value: `${statsData?.today_count ?? 0}`, color: "#00ff41", testid: "stat-today" },
          { label: "MAX ALTITUDE", value: `${(statsData?.max_altitude_ft ?? 0).toLocaleString()} FT`, color: "#ff6b00", testid: "stat-maxalt" },
          { label: "MAX SPEED", value: `${(statsData?.max_speed_kts ?? 0).toLocaleString()} KTS`, color: "#00f0ff", testid: "stat-maxspeed" },
          { label: "MILITARY TODAY", value: `${statsData?.military_flights_today ?? 0}`, color: "#ff2244", testid: "stat-military" },
        ].map((s) => (
          <div key={s.label} className="border border-trident-border bg-trident-surface/40 p-3" data-testid={s.testid}>
            <div className="font-mono text-[9px] uppercase tracking-widest text-trident-text/50">{s.label}</div>
            <div className="mt-1 font-display text-lg tracking-wider" style={{ color: s.color, textShadow: `0 0 8px ${s.color}66` }}>
              {s.value}
            </div>
          </div>
        ))}
      </div>

      {/* ═══ MAIN — LIVE TABLE + RADAR ═══ */}
      <div className="grid grid-cols-1 gap-3 lg:grid-cols-[1fr_360px]">
        {/* LEFT — LIVE AIRCRAFT TABLE */}
        <div className="border border-trident-border bg-trident-surface/20">
          <div className="border-b border-trident-border px-3 py-2 font-mono text-[10px] uppercase tracking-widest text-trident-cyan">
            LIVE AIRCRAFT
          </div>
          <div className="max-h-[420px] overflow-y-auto">
            {aircraft.length === 0 ? (
              <div className="p-6 text-center font-mono text-[11px] uppercase tracking-widest text-trident-amber" data-testid="empty-aircraft">
                NO AIRCRAFT DETECTED IN AIRSPACE
              </div>
            ) : (
              <table className="w-full border-collapse font-mono text-[10px]">
                <thead>
                  <tr className="border-b border-trident-border text-trident-text/50">
                    {["CALLSIGN", "ALT (FT)", "SPEED (KTS)", "HEADING", "DIST (NM)", "COUNTRY"].map((h) => (
                      <th key={h} className="px-2 py-1.5 text-left uppercase tracking-widest">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {aircraft.map((a) => (
                    <tr
                      key={a.icao24}
                      className={`border-b border-trident-border/40 hover:bg-trident-cyan/5 ${a.is_military ? "bg-trident-red/10" : ""}`}
                      data-testid={`row-aircraft-${a.icao24}`}
                    >
                      <td className="px-2 py-1.5 text-trident-cyan">
                        {a.callsign}
                        {a.on_ground && (
                          <span className="ml-1.5 border border-trident-red/60 px-1 text-[7px] uppercase tracking-widest text-trident-red">GND</span>
                        )}
                        {(isMilSquawk(a.squawk) || a.is_military) && (
                          <span className="ml-1.5 border border-trident-red text-trident-red text-[8px] px-1 uppercase tracking-widest" data-testid={`badge-mil-${a.icao24}`}>MIL</span>
                        )}
                      </td>
                      <td className="px-2 py-1.5" style={{ color: altColor(a.altitude_ft) }}>{a.altitude_ft.toLocaleString()}</td>
                      <td className="px-2 py-1.5 text-trident-text/80">{a.velocity_kts.toLocaleString()}</td>
                      <td className="px-2 py-1.5 text-trident-text/80">{headingToCompass(a.heading)} {Math.round(a.heading)}°</td>
                      <td className="px-2 py-1.5 text-trident-green">{a.distance_nm.toFixed(1)}</td>
                      <td className="px-2 py-1.5 text-trident-text/50">{a.origin_country || "—"}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </div>

        {/* RIGHT — SVG RADAR */}
        <div className="border border-trident-border bg-trident-surface/20">
          <div className="border-b border-trident-border px-3 py-2 font-mono text-[10px] uppercase tracking-widest text-trident-cyan">
            TACTICAL RADAR — 25NM
          </div>
          <div className="p-3">
            <RadarDisplay aircraft={aircraft} />
            <div className="mt-2 flex justify-center gap-3 font-mono text-[8px] uppercase tracking-widest">
              <span className="text-trident-green">▲ NORMAL</span>
              <span className="text-trident-amber">▲ HIGH ALT</span>
              <span className="text-trident-red">▲ MIL SQUAWK</span>
            </div>
          </div>
        </div>
      </div>

      {/* ═══ FLIGHT LOG ═══ */}
      <div className="border border-trident-border bg-trident-surface/20">
        <div className="flex items-center justify-between border-b border-trident-border px-3 py-2">
          <span className="font-mono text-[10px] uppercase tracking-widest text-trident-cyan">FLIGHT LOG</span>
          <span className="font-mono text-[9px] uppercase tracking-widest text-trident-text/50">{totalHistory.toLocaleString()} RECORDS</span>
        </div>

        {/* Toolbar: export / storage / clear */}
        <div className="flex flex-wrap items-center gap-3 border-b border-trident-border px-3 py-2">
          <button
            onClick={() =>
              downloadFlightExport(
                `/api/flights/export/csv${dateFilter ? `?date=${dateFilter}` : ""}`,
                `trident-flights-${dateFilter || new Date().toISOString().slice(0, 10)}.csv`
              ).catch((e) => toast({ title: e.message, variant: "destructive" }))
            }
            data-testid="button-export-csv"
            className="flex items-center gap-1.5 border border-trident-amber/50 px-2.5 py-1 font-mono text-[9px] uppercase tracking-widest text-trident-amber hover:bg-trident-amber/10"
          >
            <Download className="h-3 w-3" /> EXPORT CSV
          </button>
          <button
            onClick={() =>
              downloadFlightExport(
                `/api/flights/export/json${dateFilter ? `?date=${dateFilter}` : ""}`,
                `trident-flights-${dateFilter || new Date().toISOString().slice(0, 10)}.json`
              ).catch((e) => toast({ title: e.message, variant: "destructive" }))
            }
            data-testid="button-export-json"
            className="flex items-center gap-1.5 border border-trident-amber/50 px-2.5 py-1 font-mono text-[9px] uppercase tracking-widest text-trident-amber hover:bg-trident-amber/10"
          >
            <Download className="h-3 w-3" /> EXPORT JSON
          </button>

          <span className="mx-1 hidden text-trident-border sm:inline">|</span>

          <span className="flex items-center gap-1.5 font-mono text-[9px] uppercase tracking-widest text-trident-text/60" data-testid="text-storage-info">
            <HardDrive className="h-3 w-3 text-trident-cyan" />
            {(storageData?.db_size_mb ?? 0).toFixed(1)} MB / {(storageData?.total_records ?? 0).toLocaleString()} RECORDS
          </span>

          <div className="relative ml-auto">
            <button
              onClick={() => setClearOpen((v) => !v)}
              data-testid="button-clear-menu"
              className="flex items-center gap-1.5 border border-trident-red/50 px-2.5 py-1 font-mono text-[9px] uppercase tracking-widest text-trident-red hover:bg-trident-red/10"
            >
              <AlertTriangle className="h-3 w-3" /> CLEAR DATA <ChevronDown className="h-3 w-3" />
            </button>
            {clearOpen && (
              <div className="absolute right-0 z-20 mt-1 w-56 border border-trident-red/40 bg-trident-surface" style={{ backgroundColor: "#0a1016" }}>
                {[
                  { m: "today" as const, label: "CLEAR TODAY'S RECORDS" },
                  { m: "old" as const, label: "CLEAR OLDER THAN 30 DAYS" },
                  { m: "all" as const, label: "CLEAR ALL FLIGHT DATA" },
                ].map((opt) => (
                  <button
                    key={opt.m}
                    onClick={() => { setClearMode(opt.m); setConfirmText(""); setClearOpen(false); }}
                    data-testid={`clear-opt-${opt.m}`}
                    className="block w-full px-3 py-2 text-left font-mono text-[9px] uppercase tracking-widest text-trident-red hover:bg-trident-red/10"
                  >
                    {opt.label}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Date filter */}
        <div className="flex items-center gap-2 border-b border-trident-border px-3 py-2">
          <span className="font-mono text-[9px] uppercase tracking-widest text-trident-text/50">DATE</span>
          <input
            type="date"
            value={dateFilter}
            onChange={(e) => { setDateFilter(e.target.value); setHistoryPage(0); }}
            data-testid="input-date-filter"
            className="border border-trident-border bg-transparent px-2 py-1 font-mono text-[10px] text-trident-cyan"
          />
          {dateFilter && (
            <button
              onClick={() => { setDateFilter(""); setHistoryPage(0); }}
              data-testid="button-clear-datefilter"
              className="font-mono text-[9px] uppercase tracking-widest text-trident-text/50 hover:text-trident-cyan"
            >
              CLEAR
            </button>
          )}
        </div>

        <div className="max-h-[360px] overflow-y-auto">
          {flights.length === 0 ? (
            <div className="p-6 text-center font-mono text-[11px] uppercase tracking-widest text-trident-amber" data-testid="empty-flightlog">
              NO RECORDED FLIGHTS
            </div>
          ) : (
            <table className="w-full border-collapse font-mono text-[10px]">
              <thead>
                <tr className="border-b border-trident-border text-trident-text/50">
                  {["ICAO24", "CALLSIGN", "ALT", "SPEED", "DIST", "FIRST SEEN", "LAST SEEN"].map((h) => (
                    <th key={h} className="px-2 py-1.5 text-left uppercase tracking-widest">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {flights.map((f) => (
                  <tr key={f.id} className="border-b border-trident-border/40 hover:bg-trident-cyan/5" data-testid={`row-flightlog-${f.id}`}>
                    <td className="px-2 py-1.5 text-trident-text/60">{f.icao24}</td>
                    <td className="px-2 py-1.5 text-trident-cyan">{f.callsign}</td>
                    <td className="px-2 py-1.5 text-trident-text/80">{Math.round((f.altitude_m || 0) * 3.28084).toLocaleString()}</td>
                    <td className="px-2 py-1.5 text-trident-text/80">{Math.round((f.velocity_ms || 0) * 1.94384).toLocaleString()}</td>
                    <td className="px-2 py-1.5 text-trident-green">{(f.distance_nm ?? 0).toFixed(1)}</td>
                    <td className="px-2 py-1.5 text-trident-text/50">{f.first_seen?.replace("T", " ").slice(0, 19)}</td>
                    <td className="px-2 py-1.5 text-trident-text/50">{f.last_seen?.replace("T", " ").slice(0, 19)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>

        {/* Pagination */}
        <div className="flex items-center justify-between border-t border-trident-border px-3 py-2">
          <button
            disabled={historyPage === 0}
            onClick={() => setHistoryPage((p) => Math.max(0, p - 1))}
            data-testid="button-prev-page"
            className="border border-trident-border px-2 py-1 font-mono text-[9px] uppercase tracking-widest text-trident-text/60 disabled:opacity-30 hover:enabled:border-trident-cyan/40 hover:enabled:text-trident-cyan"
          >
            PREV
          </button>
          <span className="font-mono text-[9px] uppercase tracking-widest text-trident-text/50">
            PAGE {historyPage + 1} / {totalPages}
          </span>
          <button
            disabled={historyPage + 1 >= totalPages}
            onClick={() => setHistoryPage((p) => p + 1)}
            data-testid="button-next-page"
            className="border border-trident-border px-2 py-1 font-mono text-[9px] uppercase tracking-widest text-trident-text/60 disabled:opacity-30 hover:enabled:border-trident-cyan/40 hover:enabled:text-trident-cyan"
          >
            NEXT
          </button>
        </div>
      </div>

      {/* ═══ SDR UPGRADE NOTICE ═══ */}
      {isOpenSky && (
        <div className="flex items-start gap-2 border border-trident-cyan/30 bg-trident-cyan/5 p-3" data-testid="sdr-upgrade-notice">
          <span className="mt-0.5 text-trident-cyan">⬡</span>
          <div>
            <div className="font-mono text-[10px] uppercase tracking-widest text-trident-cyan">LOCAL SDR UPGRADE AVAILABLE</div>
            <div className="mt-1 font-mono text-[9px] leading-relaxed text-trident-text/60">
              Install dump1090 on a local server and set DUMP1090_URL in /etc/trident/config.env
              to switch to real-time local ADS-B data with no rate limits.
            </div>
          </div>
        </div>
      )}

      {/* ═══ CLEAR CONFIRMATION DIALOG ═══ */}
      {clearMode && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4" data-testid="clear-dialog">
          <div className="w-full max-w-md border border-trident-red/50 bg-trident-surface p-5" style={{ backgroundColor: "#0a1016" }}>
            <div className="mb-3 flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-trident-red" style={{ filter: "drop-shadow(0 0 6px #ff2244)" }} />
              <span className="font-display text-sm uppercase tracking-widest text-trident-red">CONFIRM DATA PURGE</span>
            </div>
            <p className="mb-3 font-mono text-[11px] leading-relaxed text-trident-text/70">
              This will delete <span className="text-trident-red">{pendingCount.toLocaleString()} RECORDS</span> ({clearLabel}).
              Type <span className="text-trident-cyan">CONFIRM</span> to proceed.
            </p>
            <input
              autoFocus
              value={confirmText}
              onChange={(e) => setConfirmText(e.target.value)}
              placeholder="TYPE CONFIRM"
              data-testid="input-confirm-purge"
              className="mb-4 w-full border border-trident-border bg-transparent px-2 py-1.5 font-mono text-[11px] uppercase tracking-widest text-trident-cyan"
            />
            <div className="flex justify-end gap-2">
              <button
                onClick={() => { setClearMode(null); setConfirmText(""); }}
                data-testid="button-cancel-purge"
                className="border border-trident-border px-3 py-1.5 font-mono text-[10px] uppercase tracking-widest text-trident-text/60 hover:text-trident-cyan"
              >
                CANCEL
              </button>
              <button
                disabled={confirmText !== "CONFIRM" || clearMut.isPending}
                onClick={() => clearMode && clearMut.mutate(clearMode)}
                data-testid="button-confirm-purge"
                className="flex items-center gap-1.5 border border-trident-red/60 bg-trident-red/10 px-3 py-1.5 font-mono text-[10px] uppercase tracking-widest text-trident-red disabled:opacity-30 hover:enabled:bg-trident-red/20"
              >
                <TrashIcon className="h-3 w-3" /> {clearMut.isPending ? "PURGING..." : "PURGE DATA"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ═══ AVIATION INTELLIGENCE BRIEF ═══ */}
      <AviationBriefSection />
    </div>
  );
}

function AviationBriefSection() {
  const [generating, setGenerating] = useState(false);
  const [brief, setBrief] = useState<{content: string; date: string; period: string; model_used: string; saved_to_nas: boolean; nas_path: string | null; stats: any} | null>(null);
  const [error, setError] = useState("");
  const [hours, setHours] = useState("24");
  const [dateFilter, setDateFilter] = useState("");

  const generate = async () => {
    setGenerating(true); setError("");
    try {
      const body: any = {};
      if (dateFilter) body.date = dateFilter;
      else body.hours = hours;
      const res = await fetch("/api/flights/brief/generate", {
        method: "POST",
        headers: { ...getAuthHeaders(), "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      if (!res.ok) throw new Error(`Failed: ${res.status}`);
      setBrief(await res.json());
    } catch (e: any) { setError(e?.message || "Brief generation failed"); }
    finally { setGenerating(false); }
  };

  return (
    <div className="border border-trident-border bg-trident-surface/20" data-testid="aviation-brief-section">
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-trident-border px-3 py-2">
        <span className="font-mono text-[10px] uppercase tracking-widest text-trident-cyan">AVIATION INTELLIGENCE BRIEF</span>
        <div className="flex flex-wrap items-center gap-2">
          <select
            value={hours}
            onChange={e => setHours(e.target.value)}
            disabled={!!dateFilter}
            className="border border-trident-border/60 bg-black/40 px-2 py-1 font-mono text-[10px] text-trident-text disabled:opacity-40"
          >
            <option value="6">LAST 6H</option>
            <option value="12">LAST 12H</option>
            <option value="24">LAST 24H</option>
            <option value="48">LAST 48H</option>
            <option value="168">LAST 7D</option>
          </select>
          <span className="font-mono text-[9px] text-trident-text/40">OR DATE:</span>
          <input
            type="date"
            value={dateFilter}
            onChange={e => setDateFilter(e.target.value)}
            className="border border-trident-border/60 bg-black/40 px-2 py-1 font-mono text-[10px] text-trident-text"
          />
          {dateFilter && <button onClick={() => setDateFilter("")} className="font-mono text-[9px] text-trident-red hover:underline">CLEAR</button>}
          <button
            onClick={generate}
            disabled={generating}
            className="border border-trident-amber px-3 py-1 font-mono text-[10px] uppercase tracking-widest text-trident-amber hover:bg-trident-amber/10 disabled:opacity-50"
          >
            {generating ? ">> GENERATING..." : "GENERATE AVIATION BRIEF"}
          </button>
        </div>
      </div>
      <div className="p-3">
        {error && <div className="mb-2 border border-trident-red/40 bg-trident-red/10 p-2 font-mono text-[10px] text-trident-red">{error}</div>}
        {generating && <div className="font-mono text-[10px] uppercase tracking-widest text-trident-cyan animate-pulse">&gt;&gt; COMPILING AVIATION INTELLIGENCE...</div>}
        {brief && !generating && (
          <div>
            <div className="mb-3 flex flex-wrap gap-3 font-mono text-[9px] uppercase tracking-widest text-trident-text/50">
              <span>DATE: {brief.date}</span>
              <span>PERIOD: {brief.period}</span>
              <span>MODEL: {brief.model_used?.toUpperCase()}</span>
              <span>FLIGHTS: {brief.stats?.total_flights ?? 0}</span>
              {brief.saved_to_nas
                ? <span className="text-trident-green">✓ SAVED — {brief.nas_path}</span>
                : <span className="text-trident-amber">⚠ NAS SAVE FAILED</span>}
            </div>
            <pre className="whitespace-pre-wrap font-mono text-[11px] leading-relaxed text-trident-text">{brief.content}</pre>
          </div>
        )}
        {!brief && !generating && !error && (
          <div className="font-mono text-[10px] uppercase tracking-widest text-trident-text/40">
            SELECT PERIOD AND CLICK GENERATE — BRIEF SAVED TO \\\\192.168.0.20\\BRIEFS\\AVIATION
          </div>
        )}
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════
// WEATHER INTELLIGENCE (Phase 7)
// ═══════════════════════════════════════════════════
interface WeatherCurrent {
  temperature_f: number;
  feels_like_f: number;
  humidity_pct: number;
  wind_speed_mph: number;
  wind_gust_mph: number;
  wind_direction_deg: number;
  precipitation_in: number;
  cloud_cover_pct: number;
  visibility_m: number;
  surface_pressure_hpa: number;
  weather_code: number;
  condition: string;
  time: string;
  source: string;
}
interface WeatherForecast {
  daily?: {
    time: string[];
    temperature_2m_max: number[];
    temperature_2m_min: number[];
    precipitation_sum: number[];
    precipitation_probability_max: number[];
    wind_speed_10m_max: number[];
    wind_gusts_10m_max: number[];
    weather_code: number[];
    sunrise: string[];
    sunset: string[];
  };
  hourly?: {
    time: string[];
    temperature_2m: number[];
    precipitation_probability: number[];
    weather_code: number[];
    wind_speed_10m: number[];
    cloud_cover: number[];
  };
}
interface WeatherAlertItem {
  id: string;
  event: string;
  severity: string;
  urgency: string;
  certainty: string;
  headline: string;
  description: string;
  instruction: string;
  onset: string;
  expires: string;
  area: string;
  sender: string;
}
interface WeatherAlertsResponse {
  alerts: WeatherAlertItem[];
  count: number;
  source: string;
  error?: string;
}
interface WeatherAstronomy {
  sunrise: string | null;
  sunset: string | null;
  daylight_seconds: number | null;
  sunshine_seconds: number | null;
  source: string;
  error?: string;
}
interface RadarTiles { nexrad_base: string; nexrad_ridge: string; note: string; }
interface SatelliteTiles { goes_east_geocolor: string; goes_east_ir: string; modis_terra: string; note: string; }

// ── Weather helpers ──
function degToCardinal(deg: number | undefined): string {
  if (deg === undefined || deg === null || isNaN(deg)) return "—";
  const dirs = ["N", "NE", "E", "SE", "S", "SW", "W", "NW"];
  return dirs[Math.round(deg / 45) % 8];
}
function wmoGlyph(code: number | undefined): string {
  const c = code ?? 0;
  if (c === 0 || c === 1) return "☀";
  if (c === 2) return "⛅";
  if (c === 3) return "☁";
  if (c >= 45 && c <= 48) return "🌫";
  if (c >= 51 && c <= 65) return "🌧";
  if (c >= 71 && c <= 77) return "❄";
  if (c >= 80 && c <= 82) return "🌧";
  if (c >= 95) return "⛈";
  return "☁";
}
function wmoAscii(code: number | undefined): string {
  const c = code ?? 0;
  if (c === 0 || c === 1) return "CLR";
  if (c === 2) return "PCT";
  if (c === 3) return "OVC";
  if (c >= 45 && c <= 48) return "FOG";
  if (c >= 51 && c <= 65) return "RAIN";
  if (c >= 71 && c <= 77) return "SNOW";
  if (c >= 80 && c <= 82) return "RAIN";
  if (c >= 95) return "TSTM";
  return "OVC";
}
function dayAbbrev(isoDate: string): string {
  const d = new Date(isoDate + "T00:00:00");
  return d.toLocaleDateString("en-US", { weekday: "short" }).toUpperCase();
}
function hourLabel(isoTime: string): string {
  const d = new Date(isoTime);
  return d.toLocaleTimeString("en-US", { hour: "numeric", hour12: true }).replace(" ", "").toUpperCase();
}
function timeHM(iso: string | null | undefined): string {
  if (!iso) return "—";
  const d = new Date(iso);
  return d.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit", hour12: false });
}
function secsToHM(s: number | null | undefined): string {
  if (!s || isNaN(s)) return "—";
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  return `${h}h ${m}m`;
}
function severityColor(sev: string): string {
  const s = (sev || "").toLowerCase();
  if (s === "extreme") return "#ff2244";
  if (s === "severe") return "#ff6b00";
  return "#00f0ff";
}

// ── Weather stat card ──
function WxStat({ icon: Icon, label, value, color, testid }: {
  icon: any; label: string; value: string; color: string; testid: string;
}) {
  return (
    <div className="border border-trident-border bg-trident-surface/40 p-3" data-testid={testid}>
      <div className="flex items-center gap-1.5 font-mono text-[9px] uppercase tracking-widest text-trident-text/50">
        <Icon className="h-3 w-3" style={{ color }} />
        {label}
      </div>
      <div className="mt-1 font-display text-base leading-tight tracking-wider" style={{ color, textShadow: `0 0 8px ${color}55` }}>
        {value}
      </div>
    </div>
  );
}

// ── The dark-themed Leaflet weather map (reusable foundation for Phase 8) ──
function WeatherMap({ radar, satellite }: { radar?: RadarTiles; satellite?: SatelliteTiles }) {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const mapRef = useLeafletMap(containerRef, { center: DENTON_CENTER, zoom: 9 });
  const layersRef = useRef<{ radar?: L.TileLayer; sat?: L.TileLayer; ir?: L.TileLayer }>({});
  const overlayInit = useRef(false);
  const [layerOn, setLayerOn] = useState({ radar: true, satellite: false, ir: false });

  // Cache-busting timestamp for the radar tile layer — refreshed every 60s so
  // the NEXRAD imagery doesn't go stale while the WEATHER tab is active.
  const [radarCacheBust, setRadarCacheBust] = useState(() => Date.now());
  useEffect(() => {
    const interval = setInterval(() => setRadarCacheBust(Date.now()), 60000);
    return () => clearInterval(interval);
  }, []);

  // Add center marker + 25nm radius circle once the map exists
  useEffect(() => {
    const map = mapRef.current;
    if (!map || overlayInit.current) return;
    overlayInit.current = true;

    const cyanIcon = L.divIcon({
      className: "",
      html: `<div style="width:14px;height:14px;border-radius:50%;background:#00f0ff;box-shadow:0 0 10px #00f0ff,0 0 4px #fff;border:2px solid #050a0e;"></div>`,
      iconSize: [14, 14],
      iconAnchor: [7, 7],
    });
    L.marker(DENTON_CENTER, { icon: cyanIcon })
      .addTo(map)
      .bindPopup(
        `<div style="font-family:monospace;font-size:11px;letter-spacing:1px;color:#00f0ff;">DENTON, NC — MONITORING CENTER</div>`
      );

    // 25nm radius (1 nm = 1852 m)
    L.circle(DENTON_CENTER, {
      radius: 25 * 1852,
      color: "#00f0ff",
      weight: 1.5,
      dashArray: "6 6",
      fill: false,
      opacity: 0.7,
    }).addTo(map);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mapRef.current]);

  // Manage toggleable overlay layers as tile URLs arrive / toggles change
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;
    const L2 = layersRef.current;

    // RADAR (cache-busted so tiles refresh every 60s while this tab is active)
    if (radar?.nexrad_base) {
      const bustedUrl = `${radar.nexrad_base}${radar.nexrad_base.includes("?") ? "&" : "?"}t=${radarCacheBust}`;
      if (layerOn.radar && !L2.radar) {
        L2.radar = L.tileLayer(bustedUrl, { opacity: 0.6, zIndex: 400 }).addTo(map);
      } else if (!layerOn.radar && L2.radar) {
        map.removeLayer(L2.radar); L2.radar = undefined;
      } else if (layerOn.radar && L2.radar) {
        // Tile layer already exists — push the fresh cache-busted URL so tiles reload
        L2.radar.setUrl(bustedUrl);
      }
    }
    // SATELLITE (GeoColor)
    if (satellite?.goes_east_geocolor) {
      if (layerOn.satellite && !L2.sat) {
        L2.sat = L.tileLayer(satellite.goes_east_geocolor, { opacity: 0.8, zIndex: 300 }).addTo(map);
      } else if (!layerOn.satellite && L2.sat) {
        map.removeLayer(L2.sat); L2.sat = undefined;
      }
    }
    // IR
    if (satellite?.goes_east_ir) {
      if (layerOn.ir && !L2.ir) {
        L2.ir = L.tileLayer(satellite.goes_east_ir, { opacity: 0.7, zIndex: 350 }).addTo(map);
      } else if (!layerOn.ir && L2.ir) {
        map.removeLayer(L2.ir); L2.ir = undefined;
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [radar, satellite, layerOn, mapRef.current, radarCacheBust]);

  const toggle = (k: "radar" | "satellite" | "ir") =>
    setLayerOn((p) => ({ ...p, [k]: !p[k] }));

  const btns: { k: "radar" | "satellite" | "ir"; label: string; color: string }[] = [
    { k: "radar", label: "RADAR", color: "#00ff41" },
    { k: "satellite", label: "SATELLITE", color: "#00f0ff" },
    { k: "ir", label: "IR", color: "#ff6b00" },
  ];

  return (
    <div className="relative border border-trident-border bg-black" data-testid="weather-map-wrap">
      <div ref={containerRef} data-testid="weather-map" style={{ height: 500, width: "100%", background: "#050a0e" }} />
      {/* Layer controls — top right */}
      <div className="absolute right-2 top-2 z-[1000] flex flex-col gap-1 border border-trident-border bg-trident-surface/90 p-1.5 backdrop-blur-sm">
        <div className="px-1 pb-0.5 font-mono text-[8px] uppercase tracking-widest text-trident-text/50">LAYERS</div>
        {btns.map((b) => (
          <button
            key={b.k}
            onClick={() => toggle(b.k)}
            data-testid={`toggle-layer-${b.k}`}
            className="flex items-center justify-between gap-2 border px-2 py-1 font-mono text-[9px] uppercase tracking-widest transition-all"
            style={{
              borderColor: layerOn[b.k] ? `${b.color}99` : "#1a3a4a",
              color: layerOn[b.k] ? b.color : "rgba(200,220,230,0.4)",
              background: layerOn[b.k] ? `${b.color}18` : "transparent",
              textShadow: layerOn[b.k] ? `0 0 6px ${b.color}66` : "none",
            }}
          >
            {b.label}
            <span className="inline-block h-1.5 w-1.5 rounded-full" style={{ background: layerOn[b.k] ? b.color : "#1a3a4a" }} />
          </button>
        ))}
      </div>
    </div>
  );
}

function WeatherTab() {
  const [briefGenerating, setBriefGenerating] = useState(false);
  const [weatherBrief, setWeatherBrief] = useState<{content: string; date: string; model_used: string; saved_to_nas: boolean; nas_path: string | null} | null>(null);
  const [briefError, setBriefError] = useState("");

  const generateWeatherBrief = async () => {
    setBriefGenerating(true);
    setBriefError("");
    try {
      const res = await fetch("/api/weather/brief/generate", {
        method: "POST",
        headers: { ...getAuthHeaders(), "Content-Type": "application/json" },
      });
      if (!res.ok) throw new Error(`Failed: ${res.status}`);
      const data = await res.json();
      setWeatherBrief(data);
    } catch (e: any) {
      setBriefError(e?.message || "Brief generation failed");
    } finally {
      setBriefGenerating(false);
    }
  };
  // ── Service status ──
  const { data: statusData } = useQuery<{ online: boolean }>({
    queryKey: ["/api/weather/status"],
    queryFn: () => apiGet("/api/weather/status"),
    staleTime: 0,
    refetchInterval: 30000,
  });
  const serviceOnline = statusData?.online ?? false;

  // ── Current — refresh every 5 min ──
  const { data: current } = useQuery<WeatherCurrent>({
    queryKey: ["/api/weather/current"],
    queryFn: () => apiGet("/api/weather/current"),
    staleTime: 0,
    refetchInterval: 60000,
  });

  // ── Forecast — refresh every 30 min ──
  const { data: forecast } = useQuery<WeatherForecast>({
    queryKey: ["/api/weather/forecast"],
    queryFn: () => apiGet("/api/weather/forecast"),
    staleTime: 0,
    refetchInterval: 1800000,
  });

  // ── Alerts — refresh every 5 min ──
  const { data: alertsData } = useQuery<WeatherAlertsResponse>({
    queryKey: ["/api/weather/alerts"],
    queryFn: () => apiGet("/api/weather/alerts"),
    staleTime: 0,
    refetchInterval: 300000,
  });

  // ─�� Astronomy — refresh hourly ──
  const { data: astronomy } = useQuery<WeatherAstronomy>({
    queryKey: ["/api/weather/astronomy"],
    queryFn: () => apiGet("/api/weather/astronomy"),
    staleTime: 0,
    refetchInterval: 3600000,
  });

  // ── Tile URLs (rarely change) ──
  const { data: radarTiles } = useQuery<RadarTiles>({
    queryKey: ["/api/weather/radar-tiles"],
    queryFn: () => apiGet("/api/weather/radar-tiles"),
    staleTime: 0,
  });
  const { data: satTiles } = useQuery<SatelliteTiles>({
    queryKey: ["/api/weather/satellite-tiles"],
    queryFn: () => apiGet("/api/weather/satellite-tiles"),
    staleTime: 0,
  });

  const alerts = alertsData?.alerts || [];
  const hasExtreme = alerts.some((a) => (a.severity || "").toLowerCase() === "extreme");

  const visKm = current?.visibility_m ? (current.visibility_m / 1000).toFixed(1) : "—";

  // Sun position progress bar
  const sunPct = useMemo(() => {
    if (!astronomy?.sunrise || !astronomy?.sunset) return 0;
    const rise = new Date(astronomy.sunrise).getTime();
    const set = new Date(astronomy.sunset).getTime();
    const now = Date.now();
    if (now <= rise) return 0;
    if (now >= set) return 100;
    return ((now - rise) / (set - rise)) * 100;
  }, [astronomy]);

  const daily = forecast?.daily;
  const hourly = forecast?.hourly;

  // Next 24 hourly slots starting from now
  const hourSlots = useMemo(() => {
    if (!hourly?.time) return [];
    const now = Date.now();
    const idx = hourly.time.findIndex((t) => new Date(t).getTime() >= now);
    const start = idx < 0 ? 0 : idx;
    return hourly.time.slice(start, start + 24).map((t, i) => ({
      time: t,
      temp: hourly.temperature_2m?.[start + i],
      precip: hourly.precipitation_probability?.[start + i],
      code: hourly.weather_code?.[start + i],
      wind: hourly.wind_speed_10m?.[start + i],
    }));
  }, [hourly]);

  return (
    <div className="space-y-3 p-1" data-testid="weather-tab">
      {/* ═══ STATUS BAR ═══ */}
      <div className="flex flex-wrap items-center justify-between gap-3 border border-trident-border bg-trident-surface/40 px-3 py-2">
        <div className="flex items-center gap-3">
          <span className="flex items-center gap-1.5">
            <span
              className={`inline-block h-2 w-2 rounded-full ${serviceOnline ? "bg-trident-green animate-pulse" : "bg-trident-red"}`}
              style={{ boxShadow: serviceOnline ? "0 0 6px #00ff41" : "0 0 6px #ff2244" }}
              data-testid="status-weather-service"
            />
            <span className={`font-mono text-[9px] uppercase tracking-widest ${serviceOnline ? "text-trident-green" : "text-trident-red"}`}>
              {serviceOnline ? "ONLINE" : "OFFLINE"}
            </span>
          </span>
          <span className="flex items-center gap-1.5 font-mono text-[9px] uppercase tracking-widest text-trident-text/50">
            <MapPin className="h-3 w-3 text-trident-cyan" /> DENTON, NC — DAVIDSON COUNTY
          </span>
        </div>
        <div className="flex items-center gap-4">
          <span className="font-mono text-[9px] uppercase tracking-widest text-trident-text/50">
            SRC OPEN-METEO / NOAA
          </span>
          <span className="font-mono text-[9px] uppercase tracking-widest text-trident-text/50" data-testid="text-weather-updated">
            UPDATED {current?.time ? new Date(current.time).toLocaleTimeString("en-US", { hour12: false }) : "—"}
          </span>
        </div>
      </div>

      {/* ═══ CURRENT CONDITIONS — 6 STAT CARDS ═══ */}
      <div className="grid grid-cols-2 gap-3 md:grid-cols-3 lg:grid-cols-6">
        <WxStat icon={Thermometer} label="TEMPERATURE" color="#ff6b00" testid="stat-temp"
          value={`${current ? Math.round(current.temperature_f) : "—"}°F / FEELS ${current ? Math.round(current.feels_like_f) : "—"}°F`} />
        <WxStat icon={CloudSun} label="CONDITION" color="#00f0ff" testid="stat-condition"
          value={current?.condition || "—"} />
        <WxStat icon={Droplets} label="HUMIDITY" color="#00f0ff" testid="stat-humidity"
          value={`${current?.humidity_pct ?? "—"}%`} />
        <WxStat icon={Wind} label="WIND" color="#00ff41" testid="stat-wind"
          value={`${current ? Math.round(current.wind_speed_mph) : "—"} MPH ${degToCardinal(current?.wind_direction_deg)} / GUSTS ${current ? Math.round(current.wind_gust_mph) : "—"} MPH`} />
        <WxStat icon={Gauge} label="PRESSURE" color="#00f0ff" testid="stat-pressure"
          value={`${current?.surface_pressure_hpa ? Math.round(current.surface_pressure_hpa) : "—"} HPA`} />
        <WxStat icon={Eye} label="VISIBILITY" color="#00ff41" testid="stat-visibility"
          value={`${visKm} KM`} />
      </div>

      {/* ═══ NOAA ALERTS BANNER ═══ */}
      {alerts.length > 0 && (
        <div
          className={`max-h-[180px] overflow-y-auto border ${hasExtreme ? "alert-flash" : ""}`}
          style={{
            borderColor: hasExtreme ? "#ff2244" : "#ff6b00",
            background: hasExtreme ? "rgba(255,34,68,0.08)" : "rgba(255,107,0,0.06)",
          }}
          data-testid="weather-alerts-banner"
        >
          <div className="flex items-center gap-2 border-b px-3 py-1.5" style={{ borderColor: hasExtreme ? "#ff224455" : "#ff6b0055" }}>
            <AlertTriangle className="h-3.5 w-3.5" style={{ color: hasExtreme ? "#ff2244" : "#ff6b00" }} />
            <span className="font-display text-[11px] uppercase tracking-widest" style={{ color: hasExtreme ? "#ff2244" : "#ff6b00" }}>
              {alerts.length} ACTIVE NOAA ALERT{alerts.length > 1 ? "S" : ""}
            </span>
          </div>
          <div className="divide-y divide-trident-border/40">
            {alerts.map((a) => {
              const col = severityColor(a.severity);
              return (
                <div key={a.id} className="px-3 py-2" data-testid={`alert-${a.severity?.toLowerCase() || "unknown"}`}>
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="border px-1.5 py-0.5 font-mono text-[9px] uppercase tracking-widest" style={{ borderColor: `${col}88`, color: col }}>
                      {a.severity || "UNKNOWN"}
                    </span>
                    <span className="font-display text-[11px] uppercase tracking-widest" style={{ color: col }}>
                      {a.event}
                    </span>
                  </div>
                  <div className="mt-1 font-mono text-[10px] leading-relaxed text-trident-text/80">{a.headline}</div>
                  <div className="mt-0.5 font-mono text-[9px] uppercase tracking-widest text-trident-text/40">
                    {a.onset ? new Date(a.onset).toLocaleString("en-US", { hour12: false }) : "—"} → {a.expires ? new Date(a.expires).toLocaleString("en-US", { hour12: false }) : "—"}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ═══ MAP ═══ */}
      <WeatherMap radar={radarTiles} satellite={satTiles} />

      {/* ═══ 7-DAY FORECAST ═══ */}
      <div className="border border-trident-border bg-trident-surface/20">
        <div className="border-b border-trident-border px-3 py-2 font-mono text-[10px] uppercase tracking-widest text-trident-cyan">
          7-DAY FORECAST
        </div>
        <div className="flex gap-2 overflow-x-auto p-3">
          {daily?.time?.map((d, i) => (
            <div key={d} className="flex min-w-[92px] flex-col items-center border border-trident-border/60 bg-black/30 p-2" data-testid={`forecast-day-${i}`}>
              <div className="font-mono text-[10px] uppercase tracking-widest text-trident-cyan">{dayAbbrev(d)}</div>
              <div className="my-1 text-2xl">{wmoGlyph(daily.weather_code?.[i])}</div>
              <div className="font-mono text-[8px] uppercase tracking-widest text-trident-text/40">{wmoAscii(daily.weather_code?.[i])}</div>
              <div className="mt-1 font-mono text-[11px] tabular-nums text-trident-amber">HIGH {Math.round(daily.temperature_2m_max?.[i])}°</div>
              <div className="font-mono text-[11px] tabular-nums text-trident-text/60">LOW {Math.round(daily.temperature_2m_min?.[i])}°</div>
              <div className="mt-1 font-mono text-[9px] tabular-nums text-trident-cyan">{daily.precipitation_probability_max?.[i] ?? 0}% RAIN</div>
            </div>
          )) || (
            <div className="p-2 font-mono text-[10px] uppercase tracking-widest text-trident-text/40">NO FORECAST DATA</div>
          )}
        </div>
      </div>

      {/* ═══ SUNRISE / SUNSET ═══ */}
      <div className="border border-trident-border bg-trident-surface/20 p-3" data-testid="astronomy-row">
        <div className="flex items-center gap-3">
          <span className="flex items-center gap-1.5 font-mono text-[10px] uppercase tracking-widest text-trident-amber">
            <Sunrise className="h-3.5 w-3.5" /> SUNRISE {timeHM(astronomy?.sunrise)}
          </span>
          <div className="relative h-1.5 flex-1 rounded-full bg-black/50">
            <div className="absolute left-0 top-0 h-full rounded-full" style={{ width: `${sunPct}%`, background: "linear-gradient(90deg,#ff6b00,#00f0ff)" }} />
            <div className="absolute top-1/2 h-3 w-3 -translate-y-1/2 rounded-full bg-trident-cyan" style={{ left: `calc(${sunPct}% - 6px)`, boxShadow: "0 0 8px #00f0ff" }} />
          </div>
          <span className="flex items-center gap-1.5 font-mono text-[10px] uppercase tracking-widest text-trident-cyan">
            SUNSET {timeHM(astronomy?.sunset)} <Sunset className="h-3.5 w-3.5" />
          </span>
        </div>
        <div className="mt-2 flex gap-6 font-mono text-[9px] uppercase tracking-widest text-trident-text/50">
          <span>DAYLIGHT: {secsToHM(astronomy?.daylight_seconds)}</span>
          <span>SUNSHINE: {secsToHM(astronomy?.sunshine_seconds)}</span>
        </div>
      </div>

      {/* ═══ HOURLY FORECAST (24H) ═══ */}
      <div className="border border-trident-border bg-trident-surface/20">
        <div className="border-b border-trident-border px-3 py-2 font-mono text-[10px] uppercase tracking-widest text-trident-cyan">
          24-HOUR FORECAST
        </div>
        <div className="flex gap-2 overflow-x-auto p-3">
          {hourSlots.length > 0 ? hourSlots.map((h, i) => (
            <div key={h.time} className="flex min-w-[74px] flex-col items-center border border-trident-border/60 bg-black/30 p-2" data-testid={`forecast-hour-${i}`}>
              <div className="font-mono text-[9px] uppercase tracking-widest text-trident-text/60">{hourLabel(h.time)}</div>
              <div className="my-0.5 text-lg">{wmoGlyph(h.code)}</div>
              <div className="font-mono text-[11px] tabular-nums text-trident-amber">{h.temp !== undefined ? Math.round(h.temp) : "—"}°</div>
              <div className="font-mono text-[9px] tabular-nums text-trident-cyan">{h.precip ?? 0}%</div>
              <div className="font-mono text-[8px] tabular-nums text-trident-text/40">{h.wind !== undefined ? Math.round(h.wind) : "—"} MPH</div>
            </div>
          )) : (
            <div className="p-2 font-mono text-[10px] uppercase tracking-widest text-trident-text/40">NO HOURLY DATA</div>
          )}
        </div>
      </div>

      {/* ═══ WEATHER BRIEF ═══ */}
      <div className="border border-trident-border bg-trident-surface/20">
        <div className="flex items-center justify-between border-b border-trident-border px-3 py-2">
          <span className="font-mono text-[10px] uppercase tracking-widest text-trident-cyan">WEATHER INTELLIGENCE BRIEF</span>
          <button
            onClick={generateWeatherBrief}
            disabled={briefGenerating}
            className="border border-trident-amber px-3 py-1 font-mono text-[10px] uppercase tracking-widest text-trident-amber hover:bg-trident-amber/10 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {briefGenerating ? ">> GENERATING..." : "GENERATE WEATHER BRIEF"}
          </button>
        </div>
        <div className="p-3">
          {briefError && (
            <div className="mb-2 border border-trident-red/40 bg-trident-red/10 p-2 font-mono text-[10px] text-trident-red">{briefError}</div>
          )}
          {briefGenerating && (
            <div className="font-mono text-[10px] uppercase tracking-widest text-trident-cyan animate-pulse">&gt;&gt; COMPILING WEATHER INTELLIGENCE...</div>
          )}
          {weatherBrief && !briefGenerating && (
            <div>
              <div className="mb-2 flex flex-wrap items-center gap-3 font-mono text-[9px] uppercase tracking-widest text-trident-text/50">
                <span>DATE: {weatherBrief.date}</span>
                <span>MODEL: {weatherBrief.model_used?.toUpperCase()}</span>
                {weatherBrief.saved_to_nas
                  ? <span className="text-trident-green">✓ SAVED — {weatherBrief.nas_path}</span>
                  : <span className="text-trident-amber">⚠ NAS SAVE FAILED — CHECK MOUNT</span>}
              </div>
              <pre className="whitespace-pre-wrap font-mono text-[11px] leading-relaxed text-trident-text">{weatherBrief.content}</pre>
            </div>
          )}
          {!weatherBrief && !briefGenerating && !briefError && (
            <div className="font-mono text-[10px] uppercase tracking-widest text-trident-text/40">CLICK GENERATE TO CREATE TODAY'S WEATHER BRIEF — SAVES TO \\\\192.168.0.20\\BRIEFS\\WEATHER</div>
          )}
        </div>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════
// SATELLITE TAB — Real-time satellite tracking over Denton, NC
// CelesTrak TLE data + SGP4 propagation (server-side Python service, port 5009)
// ═══════════════════════════════════════════════════

const SATELLITE_RADIUS_MI = 100; // reference ring only — actual filter is horizon-based (see backend)

interface SatelliteOverheadItem {
  name: string;
  group: string;
  lat: number;
  lon: number;
  alt_km: number;
  velocity_km_s: number;
  orbit_type: string;
  distance_miles: number;
  norad_id: string;
}
interface SatelliteOverheadResponse {
  satellites: SatelliteOverheadItem[];
  count: number;
  groups_queried: string[];
  center: { lat: number; lon: number };
  radius_miles: number;
  timestamp: string;
}
interface SatelliteOrbitPoint { lat: number; lon: number; alt_km: number; t: string; }
interface SatelliteDetailResponse {
  name: string;
  norad_id: string;
  group: string;
  current_position: { lat: number; lon: number; alt_km: number; velocity_km_s: number } | null;
  orbit_path: SatelliteOrbitPoint[];
  orbital_elements: {
    inclination_deg: number;
    raan_deg: number;
    eccentricity: number;
    arg_perigee_deg: number;
    mean_anomaly_deg: number;
    mean_motion_rev_per_day: number;
    period_minutes: number;
    orbit_type: string;
  };
  tle: { line1: string; line2: string };
  error?: string;
}

const SAT_GROUP_OPTIONS: { key: string; label: string }[] = [
  { key: "starlink", label: "STARLINK" },
  { key: "noaa", label: "NOAA/WEATHER" },
  { key: "gps", label: "GPS" },
  { key: "stations", label: "SPACE STATIONS" },
  { key: "science", label: "SCIENCE" },
];

const SAT_GROUP_COLOR: Record<string, string> = {
  starlink: "#00f0ff",
  noaa: "#00ff41",
  weather: "#00ff41",
  gps: "#ff6b00",
  stations: "#ff2244",
  science: "#b388ff",
};

function satGroupColor(group: string): string {
  return SAT_GROUP_COLOR[group] || "#00f0ff";
}

function SatelliteMap({
  satellites,
  onSelect,
  orbitPath,
}: {
  satellites: SatelliteOverheadItem[];
  onSelect: (sat: { norad_id: string; group: string }) => void;
  orbitPath: SatelliteOrbitPoint[] | null;
}) {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const mapRef = useLeafletMap(containerRef, { center: DENTON_CENTER, zoom: 4 });
  const overlayInit = useRef(false);
  const markersLayerRef = useRef<L.LayerGroup | null>(null);
  const orbitLayerRef = useRef<L.Polyline | null>(null);

  // Static AO center marker + radius circle — added once
  useEffect(() => {
    const map = mapRef.current;
    if (!map || overlayInit.current) return;
    overlayInit.current = true;

    const amberIcon = L.divIcon({
      className: "",
      html: `<div style="width:14px;height:14px;border-radius:50%;background:#ff6b00;box-shadow:0 0 10px #ff6b00,0 0 4px #fff;border:2px solid #050a0e;"></div>`,
      iconSize: [14, 14],
      iconAnchor: [7, 7],
    });
    L.marker(DENTON_CENTER, { icon: amberIcon })
      .addTo(map)
      .bindPopup(
        `<div style="font-family:monospace;font-size:11px;letter-spacing:1px;color:#ff6b00;">DENTON, NC — AO CENTER</div>`
      );

    // 100-mile reference ring (1 mile = 1609.34 m) — dashed amber, no fill
    // NOTE: this is a visual distance reference only. The actual overhead filter
    // is horizon-based per-satellite (LEO ~1500mi, GPS/GEO ~5500mi) since higher
    // satellites are visible from much farther away — a fixed ring can't represent that.
    L.circle(DENTON_CENTER, {
      radius: SATELLITE_RADIUS_MI * 1609.34,
      color: "#ff6b00",
      weight: 1.5,
      dashArray: "6 6",
      fill: false,
      opacity: 0.7,
    }).addTo(map);

    markersLayerRef.current = L.layerGroup().addTo(map);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mapRef.current]);

  // Satellite markers — refreshed whenever data changes
  useEffect(() => {
    const map = mapRef.current;
    const layer = markersLayerRef.current;
    if (!map || !layer) return;
    layer.clearLayers();

    satellites.forEach((sat) => {
      const color = satGroupColor(sat.group);
      const isStation = sat.group === "stations";
      const size = isStation ? 16 : 10;
      const icon = L.divIcon({
        className: "",
        html: `<div style="width:${size}px;height:${size}px;border-radius:50%;background:${color};box-shadow:0 0 8px ${color};border:1.5px solid #050a0e;"></div>`,
        iconSize: [size, size],
        iconAnchor: [size / 2, size / 2],
      });
      L.marker([sat.lat, sat.lon], { icon })
        .addTo(layer)
        .bindPopup(
          `<div style="font-family:monospace;font-size:10px;letter-spacing:1px;color:${color};">${sat.name}<br/>ALT ${sat.alt_km} KM &middot; ${sat.orbit_type}</div>`
        )
        .on("click", () => onSelect({ norad_id: sat.norad_id, group: sat.group }));
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [satellites, mapRef.current]);

  // Orbit path polyline — drawn when a satellite's orbit is requested
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;
    if (orbitLayerRef.current) {
      map.removeLayer(orbitLayerRef.current);
      orbitLayerRef.current = null;
    }
    if (orbitPath && orbitPath.length > 1) {
      const latlngs = orbitPath.map((p) => [p.lat, p.lon]) as [number, number][];
      orbitLayerRef.current = L.polyline(latlngs, {
        color: "#00f0ff",
        weight: 2,
        opacity: 0.8,
        dashArray: "3 5",
      }).addTo(map);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [orbitPath, mapRef.current]);

  return (
    <div className="relative border border-trident-border bg-black" data-testid="satellite-map-wrap">
      <div ref={containerRef} data-testid="satellite-map" style={{ height: 500, width: "100%", background: "#050a0e" }} />
    </div>
  );
}

function SatelliteDetailPanel({
  detail,
  isLoading,
  onClose,
  onShowOrbit,
  orbitShown,
}: {
  detail: SatelliteDetailResponse | undefined;
  isLoading: boolean;
  onClose: () => void;
  onShowOrbit: () => void;
  orbitShown: boolean;
}) {
  return (
    <div className="border border-trident-cyan/40 bg-trident-surface/60 p-4" data-testid="satellite-detail-panel">
      <div className="flex items-start justify-between border-b border-trident-border pb-2">
        <div className="font-display text-xs uppercase tracking-[0.2em] text-trident-cyan" style={{ textShadow: "0 0 8px #00f0ff80" }}>
          {isLoading ? "LOADING..." : detail?.name || "UNKNOWN SATELLITE"}
        </div>
        <button
          onClick={onClose}
          className="font-mono text-[10px] text-trident-text/50 hover:text-trident-red"
          data-testid="button-close-satellite-detail"
        >
          [X]
        </button>
      </div>

      {isLoading && (
        <div className="mt-3 font-mono text-[10px] uppercase tracking-widest text-trident-cyan animate-pulse">
          &gt;&gt; QUERYING ORBITAL DATA...
        </div>
      )}

      {!isLoading && detail?.error && (
        <div className="mt-3 font-mono text-[10px] uppercase tracking-widest text-trident-red">{detail.error}</div>
      )}

      {!isLoading && detail && !detail.error && (
        <div className="mt-3 space-y-3">
          <div className="flex flex-wrap gap-x-4 gap-y-1 font-mono text-[9px] uppercase tracking-widest text-trident-text/50">
            <span>NORAD ID: {detail.norad_id}</span>
            <span>GROUP: {detail.group?.toUpperCase()}</span>
          </div>

          <div>
            <div className="font-mono text-[9px] uppercase tracking-widest text-trident-amber">CURRENT POSITION</div>
            <div className="mt-1 grid grid-cols-2 gap-1 font-mono text-[11px] tabular-nums text-trident-text/80">
              <span>LAT: {detail.current_position ? detail.current_position.lat.toFixed(2) : "—"}°</span>
              <span>LON: {detail.current_position ? detail.current_position.lon.toFixed(2) : "—"}°</span>
              <span>ALTITUDE: {detail.current_position ? detail.current_position.alt_km.toFixed(1) : "—"} KM</span>
              <span>VELOCITY: {detail.current_position ? detail.current_position.velocity_km_s.toFixed(2) : "—"} KM/S</span>
            </div>
          </div>

          <div>
            <div className="font-mono text-[9px] uppercase tracking-widest text-trident-amber">ORBITAL ELEMENTS</div>
            <div className="mt-1 grid grid-cols-2 gap-1 font-mono text-[11px] tabular-nums text-trident-text/80">
              <span>ORBIT TYPE: {detail.orbital_elements.orbit_type}</span>
              <span>INCLINATION: {detail.orbital_elements.inclination_deg.toFixed(1)}°</span>
              <span>PERIOD: {detail.orbital_elements.period_minutes.toFixed(1)} MIN</span>
              <span>ECCENTRICITY: {detail.orbital_elements.eccentricity.toFixed(4)}</span>
            </div>
          </div>

          <button
            onClick={onShowOrbit}
            className="w-full border border-trident-cyan px-3 py-1.5 font-mono text-[10px] uppercase tracking-widest text-trident-cyan hover:bg-trident-cyan/10"
            data-testid="button-show-orbit-path"
          >
            {orbitShown ? "✓ ORBIT PATH ON MAP" : "SHOW ORBIT PATH ON MAP"}
          </button>
        </div>
      )}
    </div>
  );
}

function SatelliteTab() {
  const [activeGroups, setActiveGroups] = useState<string[]>(["starlink", "noaa", "weather", "stations"]);
  const [selectedSat, setSelectedSat] = useState<{ norad_id: string; group: string } | null>(null);
  const [showOrbit, setShowOrbit] = useState(false);

  const toggleGroup = (key: string) => {
    setShowOrbit(false);
    setActiveGroups((prev) => {
      if (key === "noaa") {
        // NOAA/WEATHER toggle controls both the "noaa" and "weather" TLE groups together
        const hasEither = prev.includes("noaa") || prev.includes("weather");
        if (hasEither) return prev.filter((g) => g !== "noaa" && g !== "weather");
        return [...prev, "noaa", "weather"];
      }
      return prev.includes(key) ? prev.filter((g) => g !== key) : [...prev, key];
    });
  };

  // ── Service status ──
  const { data: statusData } = useQuery<{ status?: string }>({
    queryKey: ["/api/satellites/status"],
    queryFn: () => apiGet("/api/satellites/status"),
    staleTime: 0,
    refetchInterval: 30000,
  });
  const serviceOnline = statusData?.status === "ok";

  // ── Overhead satellites — refresh every 30s (satellites move fast) ──
  const { data: overhead, isLoading: overheadLoading } = useQuery<SatelliteOverheadResponse>({
    queryKey: ["/api/satellites/overhead", activeGroups.join(",")],
    queryFn: () => apiGet(`/api/satellites/overhead?groups=${activeGroups.join(",")}`),
    staleTime: 0,
    refetchInterval: 30000,
    enabled: activeGroups.length > 0,
  });

  // ── Satellite detail — fetched on selection ──
  const { data: satDetail, isLoading: satDetailLoading } = useQuery<SatelliteDetailResponse>({
    queryKey: ["/api/satellites", selectedSat?.norad_id, selectedSat?.group],
    queryFn: () => apiGet(`/api/satellites/${selectedSat!.norad_id}?group=${selectedSat!.group}`),
    staleTime: 0,
    enabled: !!selectedSat,
  });

  const satellites = overhead?.satellites || [];
  const starlinkCount = satellites.filter((s) => s.group === "starlink").length;
  const weatherCount = satellites.filter((s) => s.group === "noaa" || s.group === "weather").length;

  const handleSelect = (sat: { norad_id: string; group: string }) => {
    setShowOrbit(false);
    setSelectedSat(sat);
  };

  return (
    <div className="space-y-3 p-1" data-testid="satellite-tab">
      {/* ═══ STATUS BAR ═══ */}
      <div className="flex flex-wrap items-center justify-between gap-3 border border-trident-border bg-trident-surface/40 px-3 py-2">
        <div className="flex items-center gap-3">
          <span className="flex items-center gap-1.5">
            <span
              className={`inline-block h-2 w-2 rounded-full ${serviceOnline ? "bg-trident-green animate-pulse" : "bg-trident-red"}`}
              style={{ boxShadow: serviceOnline ? "0 0 6px #00ff41" : "0 0 6px #ff2244" }}
              data-testid="status-satellite-service"
            />
            <span className={`font-mono text-[9px] uppercase tracking-widest ${serviceOnline ? "text-trident-green" : "text-trident-red"}`}>
              ◐ SATELLITE TRACKING — AO: DENTON, NC (HORIZON VISIBILITY)
            </span>
          </span>
        </div>
        <div className="flex items-center gap-4">
          <span className="font-mono text-[9px] uppercase tracking-widest text-trident-text/50">
            SGP4 PROPAGATION // CELESTRAK TLE DATA
          </span>
          <span className="font-mono text-[9px] uppercase tracking-widest text-trident-cyan" data-testid="text-satellite-count">
            [{overhead?.count ?? 0} SATELLITES OVERHEAD]
          </span>
        </div>
      </div>

      {/* ═══ GROUP FILTER TOGGLES ═══ */}
      <div className="flex flex-wrap gap-2" data-testid="satellite-group-toggles">
        {SAT_GROUP_OPTIONS.map((opt) => {
          const active =
            opt.key === "noaa"
              ? activeGroups.includes("noaa") || activeGroups.includes("weather")
              : activeGroups.includes(opt.key);
          return (
            <button
              key={opt.key}
              onClick={() => toggleGroup(opt.key)}
              className={`border px-3 py-1.5 font-mono text-[10px] uppercase tracking-widest transition-colors ${
                active
                  ? "border-trident-cyan bg-trident-cyan/10 text-trident-cyan"
                  : "border-trident-border text-trident-text/40 hover:text-trident-text/70"
              }`}
              data-testid={`toggle-group-${opt.key}`}
            >
              [{active ? "✓" : " "}] {opt.label}
            </button>
          );
        })}
      </div>

      {/* ═══ STATS ROW ═══ */}
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <GeoStatCard label="SATELLITES TRACKED" value={String(overhead?.count ?? "—")} icon={Satellite} accent="cyan" />
        <GeoStatCard label="STARLINK" value={String(starlinkCount)} icon={Globe} accent="cyan" />
        <GeoStatCard label="WEATHER/NOAA" value={String(weatherCount)} icon={CloudSun} accent="green" />
        <GeoStatCard label="DATA SOURCE" value="CELESTRAK (LIVE)" icon={Database} accent="amber" />
      </div>

      {/* ═══ MAP + DETAIL PANEL ═══ */}
      <div className="grid grid-cols-1 gap-3 lg:grid-cols-[1fr_320px]">
        <SatelliteMap
          satellites={satellites}
          onSelect={handleSelect}
          orbitPath={showOrbit ? satDetail?.orbit_path || null : null}
        />
        {selectedSat ? (
          <SatelliteDetailPanel
            detail={satDetail}
            isLoading={satDetailLoading}
            onClose={() => { setSelectedSat(null); setShowOrbit(false); }}
            onShowOrbit={() => setShowOrbit((v) => !v)}
            orbitShown={showOrbit}
          />
        ) : (
          <div className="flex items-center justify-center border border-trident-border bg-trident-surface/20 p-5" data-testid="satellite-detail-empty">
            <span className="font-mono text-[10px] uppercase tracking-widest text-trident-text/40 text-center">
              SELECT A SATELLITE ON THE MAP OR TABLE TO VIEW DETAILS
            </span>
          </div>
        )}
      </div>

      {/* ═══ LIVE SATELLITE TABLE ═══ */}
      <div className="border border-trident-border bg-black/30" data-testid="satellite-table">
        <div className="border-b border-trident-border px-4 py-2 font-display text-[11px] uppercase tracking-[0.2em] text-trident-cyan">
          OVERHEAD SATELLITES {overheadLoading ? "— LOADING..." : ""}
        </div>
        <div className="max-h-[250px] overflow-y-auto">
          <table className="w-full border-collapse">
            <thead className="sticky top-0 bg-black/90">
              <tr className="border-b border-trident-border">
                <th className="px-4 py-2 text-left font-mono text-[9px] uppercase tracking-widest text-trident-text/50">NAME</th>
                <th className="px-4 py-2 text-left font-mono text-[9px] uppercase tracking-widest text-trident-text/50">GROUP</th>
                <th className="px-4 py-2 text-left font-mono text-[9px] uppercase tracking-widest text-trident-text/50">ALT (KM)</th>
                <th className="px-4 py-2 text-left font-mono text-[9px] uppercase tracking-widest text-trident-text/50">DIST (MI)</th>
                <th className="px-4 py-2 text-left font-mono text-[9px] uppercase tracking-widest text-trident-text/50">ORBIT</th>
              </tr>
            </thead>
            <tbody>
              {satellites.length > 0 ? (
                satellites.map((sat) => (
                  <tr
                    key={sat.norad_id + sat.group}
                    onClick={() => handleSelect({ norad_id: sat.norad_id, group: sat.group })}
                    className="cursor-pointer border-b border-trident-border/40 last:border-b-0 hover:bg-trident-cyan/5"
                    data-testid={`satellite-row-${sat.norad_id}`}
                  >
                    <td className="px-4 py-2 font-mono text-[11px] uppercase tracking-wide text-trident-text/80">{sat.name}</td>
                    <td className="px-4 py-2 font-mono text-[10px] uppercase tracking-widest" style={{ color: satGroupColor(sat.group) }}>
                      {sat.group}
                    </td>
                    <td className="px-4 py-2 font-mono text-[11px] tabular-nums text-trident-cyan">{sat.alt_km.toFixed(1)}</td>
                    <td className="px-4 py-2 font-mono text-[11px] tabular-nums text-trident-amber">{sat.distance_miles.toFixed(1)}</td>
                    <td className="px-4 py-2 font-mono text-[10px] uppercase tracking-widest text-trident-text/60">{sat.orbit_type}</td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={5} className="px-4 py-6 text-center font-mono text-[10px] uppercase tracking-widest text-trident-text/40">
                    {serviceOnline ? "NO SATELLITES DETECTED WITHIN RADIUS" : "SATELLITE SERVICE OFFLINE"}
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════
// RADIO OPS TAB (GUI placeholder) — SDR monitoring
// No live radio scanner integration yet.
// ═══════════════════════════════════════════════════

interface RadioBand {
  band: string;
  range: string;
  status: string;
}

const RADIO_BANDS: RadioBand[] = [
  { band: "AVIATION", range: "118-137 MHz", status: "NOT CONFIGURED" },
  { band: "MARINE VHF", range: "156-174 MHz", status: "NOT CONFIGURED" },
  { band: "NOAA WEATHER RADIO", range: "162.4-162.55 MHz", status: "NOT CONFIGURED" },
  { band: "PUBLIC SAFETY", range: "450-470 MHz", status: "NOT CONFIGURED" },
  { band: "AMATEUR (HAM)", range: "144-148 MHz", status: "NOT CONFIGURED" },
  { band: "CB RADIO", range: "26.965-27.405 MHz", status: "NOT CONFIGURED" },
];

function RadioOpsTab() {
  return (
    <div className="space-y-3 p-1" data-testid="radioops-tab">
      {/* ═══ STATUS BAR ═══ */}
      <div className="flex flex-wrap items-center justify-between gap-3 border border-trident-border bg-trident-surface/40 px-3 py-2">
        <div className="flex items-center gap-3">
          <span className="flex items-center gap-1.5">
            <span className="inline-block h-2 w-2 rounded-full bg-trident-amber animate-pulse" style={{ boxShadow: "0 0 6px #ff6b00" }} />
            <span className="font-mono text-[9px] uppercase tracking-widest text-trident-amber" data-testid="status-radioops-service">
              ◐ RADIO OPERATIONS — SDR MONITORING
            </span>
          </span>
        </div>
        <span className="font-mono text-[9px] uppercase tracking-widest text-trident-red/80" data-testid="text-radioops-status">
          STATUS: PLACEHOLDER — AWAITING SDR INTEGRATION
        </span>
      </div>

      {/* ═══ STATS ROW ═══ */}
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <GeoStatCard label="ACTIVE FREQUENCIES" value="—" icon={RadioTower} accent="cyan" />
        <GeoStatCard label="SCANNER STATUS" value="OFFLINE" icon={Activity} accent="red" />
        <GeoStatCard label="LAST CAPTURE" value="—" icon={RefreshCw} accent="amber" />
        <GeoStatCard label="SDR HARDWARE" value="NOT DETECTED" icon={Database} accent="red" />
      </div>

      {/* ═══ FREQUENCY BAND TABLE ═══ */}
      <div className="border border-trident-border bg-black/30" data-testid="radio-band-table">
        <div className="border-b border-trident-border px-4 py-2 font-display text-[11px] uppercase tracking-[0.2em] text-trident-amber">
          FREQUENCY BANDS
        </div>
        <table className="w-full border-collapse">
          <thead>
            <tr className="border-b border-trident-border">
              <th className="px-4 py-2 text-left font-mono text-[9px] uppercase tracking-widest text-trident-text/50">BAND</th>
              <th className="px-4 py-2 text-left font-mono text-[9px] uppercase tracking-widest text-trident-text/50">RANGE</th>
              <th className="px-4 py-2 text-left font-mono text-[9px] uppercase tracking-widest text-trident-text/50">STATUS</th>
            </tr>
          </thead>
          <tbody>
            {RADIO_BANDS.map((b) => (
              <tr key={b.band} className="border-b border-trident-border/40 last:border-b-0" data-testid={`radio-band-${b.band.toLowerCase().replace(/[^a-z0-9]+/g, "-")}`}>
                <td className="px-4 py-2 font-mono text-[11px] uppercase tracking-wide text-trident-text/80">{b.band}</td>
                <td className="px-4 py-2 font-mono text-[11px] tabular-nums text-trident-cyan">{b.range}</td>
                <td className="px-4 py-2 font-mono text-[10px] uppercase tracking-widest text-trident-amber/70">{b.status}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* ═══ INFO PANEL ═══ */}
      <div className="border border-trident-amber/30 bg-trident-amber/5 p-5" data-testid="radioops-not-configured">
        <div className="mb-2 flex items-center gap-2 font-display text-xs uppercase tracking-[0.2em] text-trident-amber" style={{ textShadow: "0 0 8px #ff6b0080" }}>
          ⬡ RADIO OPERATIONS MODULE — PLANNED INTEGRATION
        </div>
        <p className="font-mono text-[11px] leading-relaxed text-trident-text/70">
          This section will provide live SDR-based radio monitoring once hardware
          is connected to a TRIDENT worker node or dedicated SDR server.
        </p>
        <div className="mt-3 font-mono text-[10px] uppercase tracking-widest text-trident-text/50">
          Planned capabilities:
        </div>
        <ul className="mt-1 space-y-1 font-mono text-[10px] uppercase tracking-widest text-trident-text/50">
          <li>• Live audio streaming from configured frequencies</li>
          <li>• Automatic transcription of scanner traffic</li>
          <li>• Frequency activity heatmap</li>
          <li>• Alert triggers on keyword detection</li>
        </ul>
        <div className="mt-4 border-t border-trident-amber/20 pt-2 font-mono text-[10px] uppercase tracking-widest text-trident-amber/80">
          STATUS: AWAITING SDR HARDWARE CONFIGURATION
        </div>
      </div>
    </div>
  );
}
