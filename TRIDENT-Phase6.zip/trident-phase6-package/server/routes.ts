import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { requireAuth, requireAdmin, generateToken } from "./middleware/auth";
import bcrypt from "bcryptjs";
import { z } from "zod";
import multer from "multer";
import http from "http";
import fs from "fs";
import path from "path";
import crypto from "crypto";

// Validation schemas
const registerSchema = z.object({
  username: z.string().min(3).max(32),
  email: z.string().email(),
  password: z.string().min(8),
});

const loginSchema = z.object({
  email: z.string().email(),
  password: z.string(),
});

const updateUserSchema = z.object({
  role: z.enum(["admin", "power_user", "user"]).optional(),
  is_active: z.boolean().optional(),
});

const updateSettingsSchema = z.object({
  username: z.string().min(3).max(32).optional(),
  email: z.string().email().optional(),
  current_password: z.string().optional(),
  new_password: z.string().min(8).optional(),
});

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {

  // ═══════════════════════════════════════════════════
  // AUTH ROUTES
  // ═══════════════════════════════════════════════════

  // POST /api/auth/register — Create new user
  app.post("/api/auth/register", async (req, res) => {
    try {
      const data = registerSchema.parse(req.body);
      data.email = data.email.toLowerCase().trim();

      // Check uniqueness
      const existingEmail = await storage.getUserByEmail(data.email);
      if (existingEmail) {
        return res.status(409).json({ error: "EMAIL ALREADY REGISTERED" });
      }
      const existingUsername = await storage.getUserByUsername(data.username);
      if (existingUsername) {
        return res.status(409).json({ error: "USERNAME ALREADY TAKEN" });
      }

      const password_hash = await bcrypt.hash(data.password, 12);

      const user = await storage.createUser({
        username: data.username,
        email: data.email,
        password_hash,
        role: "user",
        is_active: true,
      });

      const { password_hash: _, ...safeUser } = user;
      res.status(201).json({ message: "ACCESS GRANTED — AWAIT AUTHENTICATION", user: safeUser });
    } catch (err: any) {
      if (err.name === "ZodError") {
        return res.status(400).json({ error: "INVALID INPUT DATA", details: err.errors });
      }
      console.error("Registration error:", err);
      res.status(500).json({ error: "SYSTEM ERROR — REGISTRATION FAILED" });
    }
  });

  // POST /api/auth/login — Validate credentials, return JWT
  app.post("/api/auth/login", async (req, res) => {
    try {
      const data = loginSchema.parse(req.body);
      data.email = data.email.toLowerCase().trim();

      const user = await storage.getUserByEmail(data.email);
      if (!user) {
        return res.status(401).json({ error: "INVALID CREDENTIALS" });
      }

      if (!user.is_active) {
        return res.status(403).json({ error: "ACCOUNT DEACTIVATED — CONTACT ADMINISTRATOR" });
      }

      const valid = await bcrypt.compare(data.password, user.password_hash);
      if (!valid) {
        return res.status(401).json({ error: "INVALID CREDENTIALS" });
      }

      // Update last login
      await storage.updateUser(user.id, { last_login: new Date().toISOString() });

      const token = generateToken(user.id, user.role);
      const { password_hash: _, ...safeUser } = user;

      res.json({ token, user: safeUser });
    } catch (err: any) {
      if (err.name === "ZodError") {
        return res.status(400).json({ error: "INVALID INPUT DATA" });
      }
      console.error("Login error:", err);
      res.status(500).json({ error: "SYSTEM ERROR — AUTHENTICATION FAILED" });
    }
  });

  // POST /api/auth/logout — Invalidate session
  app.post("/api/auth/logout", requireAuth, async (req, res) => {
    // With JWT, logout is client-side (discard token). 
    // We respond affirmatively.
    res.json({ message: "SESSION TERMINATED" });
  });

  // GET /api/auth/me — Return current user
  app.get("/api/auth/me", requireAuth, async (req, res) => {
    res.json({ user: req.user });
  });

  // ═══════════════════════════════════════════════════
  // USER SETTINGS
  // ═══════════════════════════════════════════════════

  app.patch("/api/auth/settings", requireAuth, async (req, res) => {
    try {
      const data = updateSettingsSchema.parse(req.body);
      const userId = req.user!.id;
      const updateData: any = {};

      if (data.username) updateData.username = data.username;
      if (data.email) updateData.email = data.email;

      if (data.new_password) {
        if (!data.current_password) {
          return res.status(400).json({ error: "CURRENT PASSWORD REQUIRED" });
        }
        const user = await storage.getUser(userId);
        if (!user) return res.status(404).json({ error: "USER NOT FOUND" });
        const valid = await bcrypt.compare(data.current_password, user.password_hash);
        if (!valid) return res.status(401).json({ error: "CURRENT PASSWORD INVALID" });
        updateData.password_hash = await bcrypt.hash(data.new_password, 12);
      }

      const updated = await storage.updateUser(userId, updateData);
      if (!updated) return res.status(404).json({ error: "USER NOT FOUND" });

      const { password_hash: _, ...safeUser } = updated;
      res.json({ user: safeUser });
    } catch (err: any) {
      if (err.name === "ZodError") {
        return res.status(400).json({ error: "INVALID INPUT DATA", details: err.errors });
      }
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  // ═══════════════════════════════════════════════════
  // ADMIN ROUTES
  // ═══════════════════════════════════════════════════

  // GET /api/admin/users — List all users
  app.get("/api/admin/users", requireAdmin, async (req, res) => {
    const allUsers = await storage.getAllUsers();
    res.json({ users: allUsers });
  });

  // PATCH /api/admin/users/:id — Update user role/status
  app.patch("/api/admin/users/:id", requireAdmin, async (req, res) => {
    try {
      const userId = parseInt(String(req.params.id), 10);
      if (isNaN(userId)) return res.status(400).json({ error: "INVALID USER ID" });

      const data = updateUserSchema.parse(req.body);
      const updated = await storage.updateUser(userId, data);
      if (!updated) return res.status(404).json({ error: "USER NOT FOUND" });

      const { password_hash: _, ...safeUser } = updated;
      res.json({ user: safeUser });
    } catch (err: any) {
      if (err.name === "ZodError") {
        return res.status(400).json({ error: "INVALID INPUT DATA" });
      }
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  // DELETE /api/admin/users/:id — Delete user
  app.delete("/api/admin/users/:id", requireAdmin, async (req, res) => {
    const userId = parseInt(String(req.params.id), 10);
    if (isNaN(userId)) return res.status(400).json({ error: "INVALID USER ID" });

    // Prevent self-delete
    if (userId === req.user!.id) {
      return res.status(400).json({ error: "CANNOT DELETE OWN ACCOUNT" });
    }

    const deleted = await storage.deleteUser(userId);
    if (!deleted) return res.status(404).json({ error: "USER NOT FOUND" });

    res.json({ message: "USER ELIMINATED" });
  });

  // ═══════════════════════════════════════════════════
  // PHASE 2 — OLLAMA PROXY ROUTES
  // ═══════════════════════════════════════════════════

  const OLLAMA_BASE = "http://localhost:11434";

  // GET /api/ollama/status — Check if Ollama is reachable
  app.get("/api/ollama/status", requireAuth, async (_req, res) => {
    try {
      const response = await fetch(`${OLLAMA_BASE}/api/version`);
      if (response.ok) {
        const data = await response.json();
        res.json({ online: true, version: data.version || "unknown" });
      } else {
        res.json({ online: false, version: "" });
      }
    } catch {
      res.json({ online: false, version: "" });
    }
  });

  // GET /api/ollama/models — List installed models
  app.get("/api/ollama/models", requireAuth, async (_req, res) => {
    try {
      const response = await fetch(`${OLLAMA_BASE}/api/tags`);
      if (!response.ok) {
        return res.status(502).json({ error: "OLLAMA UNREACHABLE" });
      }
      const data = await response.json();
      const models = (data.models || []).map((m: any) => ({
        name: m.name,
        size: m.size,
        modified_at: m.modified_at,
        details: m.details || {},
      }));
      res.json({ models });
    } catch {
      res.status(502).json({ error: "NEURAL LINK SEVERED — OLLAMA OFFLINE" });
    }
  });

  // POST /api/ollama/pull — Pull a model with SSE progress
  app.post("/api/ollama/pull", requireAuth, async (req, res) => {
    const { model } = req.body;
    if (!model || typeof model !== "string") {
      return res.status(400).json({ error: "MODEL NAME REQUIRED" });
    }

    res.setHeader("Content-Type", "text/event-stream");
    res.setHeader("Cache-Control", "no-cache");
    res.setHeader("Connection", "keep-alive");
    res.flushHeaders();

    try {
      const response = await fetch(`${OLLAMA_BASE}/api/pull`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: model, stream: true }),
      });

      if (!response.ok || !response.body) {
        res.write(`data: {"error":"FAILED TO INITIATE PULL"}\n\n`);
        return res.end();
      }

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split("\n");
        buffer = lines.pop() || "";

        for (const line of lines) {
          if (!line.trim()) continue;
          try {
            const parsed = JSON.parse(line);
            res.write(`data: ${JSON.stringify({
              status: parsed.status || "",
              completed: parsed.completed || 0,
              total: parsed.total || 0,
            })}\n\n`);
          } catch {
            // skip malformed lines
          }
        }
      }

      res.write(`data: {"done":true}\n\n`);
      res.end();
    } catch {
      res.write(`data: {"error":"NEURAL LINK SEVERED — OLLAMA OFFLINE"}\n\n`);
      res.end();
    }
  });

  // DELETE /api/ollama/models/:name — Delete a model
  app.delete("/api/ollama/models/:name", requireAuth, async (req, res) => {
    const modelName = req.params.name;
    try {
      const response = await fetch(`${OLLAMA_BASE}/api/delete`, {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: modelName }),
      });
      if (response.ok) {
        res.json({ message: "MODEL PURGED" });
      } else {
        const err = await response.text();
        res.status(response.status).json({ error: err || "DELETE FAILED" });
      }
    } catch {
      res.status(502).json({ error: "NEURAL LINK SEVERED — OLLAMA OFFLINE" });
    }
  });

  // ═══════════════════════════════════════════════════
  // PHASE 2 — CHAT / STREAMING ROUTE
  // ═══════════════════════════════════════════════════

  const chatStreamSchema = z.object({
    conversationId: z.number(),
    message: z.string().min(1),
    model: z.string().min(1),
    temperature: z.number().min(0).max(2).optional(),
    max_tokens: z.number().min(1).max(65536).optional(),
    top_p: z.number().min(0).max(1).optional(),
  });

  app.post("/api/chat/stream", requireAuth, async (req, res) => {
    try {
      const data = chatStreamSchema.parse(req.body);
      const userId = req.user!.id;

      // Validate ownership
      const conversation = await storage.getConversation(data.conversationId, userId);
      if (!conversation) {
        return res.status(404).json({ error: "CONVERSATION NOT FOUND" });
      }

      // Save user message
      const now = new Date().toISOString();
      await storage.addMessage({
        conversation_id: data.conversationId,
        role: "user",
        content: data.message,
        created_at: now,
      });

      // Update conversation timestamp
      await storage.updateConversation(data.conversationId, userId, { updated_at: now });

      // Build message history
      const dbMessages = await storage.getConversationMessages(data.conversationId);
      const ollamaMessages: { role: string; content: string }[] = [];

      // Add system prompt if exists
      const systemPrompt = conversation.system_prompt;
      if (systemPrompt) {
        ollamaMessages.push({ role: "system", content: systemPrompt });
      }

      for (const msg of dbMessages) {
        if (msg.role === "system") continue; // system prompt handled above
        ollamaMessages.push({ role: msg.role, content: msg.content });
      }

      // Set SSE headers
      res.setHeader("Content-Type", "text/event-stream");
      res.setHeader("Cache-Control", "no-cache");
      res.setHeader("Connection", "keep-alive");
      res.flushHeaders();

      try {
        const ollamaRes = await fetch(`${OLLAMA_BASE}/api/chat`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            model: data.model,
            messages: ollamaMessages,
            stream: true,
            options: {
              temperature: data.temperature ?? 0.7,
              num_predict: data.max_tokens ?? 2048,
              top_p: data.top_p ?? 0.9,
            },
          }),
        });

        if (!ollamaRes.ok || !ollamaRes.body) {
          res.write(`data: {"error":"NEURAL LINK SEVERED — OLLAMA OFFLINE"}\n\n`);
          return res.end();
        }

        const reader = ollamaRes.body.getReader();
        const decoder = new TextDecoder();
        let buffer = "";
        let fullContent = "";

        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          buffer += decoder.decode(value, { stream: true });
          const lines = buffer.split("\n");
          buffer = lines.pop() || "";

          for (const line of lines) {
            if (!line.trim()) continue;
            try {
              const parsed = JSON.parse(line);
              if (parsed.message?.content) {
                const token = parsed.message.content;
                fullContent += token;
                res.write(`data: ${JSON.stringify({ token, done: false })}\n\n`);
              }
              if (parsed.done) {
                // Save assistant message
                const savedMsg = await storage.addMessage({
                  conversation_id: data.conversationId,
                  role: "assistant",
                  content: fullContent,
                  created_at: new Date().toISOString(),
                });
                res.write(`data: ${JSON.stringify({ done: true, messageId: savedMsg.id })}\n\n`);
              }
            } catch {
              // skip malformed
            }
          }
        }

        // If we haven't sent done yet (e.g. buffer remaining)
        if (buffer.trim()) {
          try {
            const parsed = JSON.parse(buffer);
            if (parsed.message?.content) {
              fullContent += parsed.message.content;
              res.write(`data: ${JSON.stringify({ token: parsed.message.content, done: false })}\n\n`);
            }
          } catch {}
        }

        res.end();
      } catch (fetchErr) {
        res.write(`data: {"error":"NEURAL LINK SEVERED — OLLAMA OFFLINE"}\n\n`);
        res.end();
      }
    } catch (err: any) {
      if (err.name === "ZodError") {
        return res.status(400).json({ error: "INVALID INPUT DATA", details: err.errors });
      }
      console.error("Chat stream error:", err);
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  // ═══════════════════════════════════════════════════
  // PHASE 2 — CONVERSATION ROUTES
  // ═══════════════════════════════════════════════════

  const createConversationSchema = z.object({
    title: z.string().optional(),
    model: z.string().min(1),
    system_prompt: z.string().optional(),
  });

  const updateConversationSchema = z.object({
    title: z.string().optional(),
    model: z.string().optional(),
    system_prompt: z.string().optional(),
  });

  // GET /api/conversations — List user's conversations
  app.get("/api/conversations", requireAuth, async (req, res) => {
    const userId = req.user!.id;
    const convs = await storage.getUserConversations(userId);
    res.json({ conversations: convs });
  });

  // POST /api/conversations — Create new conversation
  app.post("/api/conversations", requireAuth, async (req, res) => {
    try {
      const data = createConversationSchema.parse(req.body);
      const now = new Date().toISOString();
      const conv = await storage.createConversation({
        user_id: req.user!.id,
        title: data.title || "NEW CONVERSATION",
        model: data.model,
        system_prompt: data.system_prompt || "",
        created_at: now,
        updated_at: now,
      });
      res.status(201).json(conv);
    } catch (err: any) {
      if (err.name === "ZodError") {
        return res.status(400).json({ error: "INVALID INPUT DATA", details: err.errors });
      }
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  // GET /api/conversations/:id — Get conversation + messages
  app.get("/api/conversations/:id", requireAuth, async (req, res) => {
    const convId = parseInt(String(req.params.id), 10);
    if (isNaN(convId)) return res.status(400).json({ error: "INVALID CONVERSATION ID" });

    const conv = await storage.getConversation(convId, req.user!.id);
    if (!conv) return res.status(404).json({ error: "CONVERSATION NOT FOUND" });

    const msgs = await storage.getConversationMessages(convId);
    res.json({ conversation: conv, messages: msgs });
  });

  // PATCH /api/conversations/:id — Update conversation
  app.patch("/api/conversations/:id", requireAuth, async (req, res) => {
    try {
      const convId = parseInt(String(req.params.id), 10);
      if (isNaN(convId)) return res.status(400).json({ error: "INVALID CONVERSATION ID" });

      const data = updateConversationSchema.parse(req.body);
      const updated = await storage.updateConversation(convId, req.user!.id, {
        ...data,
        updated_at: new Date().toISOString(),
      });
      if (!updated) return res.status(404).json({ error: "CONVERSATION NOT FOUND" });
      res.json(updated);
    } catch (err: any) {
      if (err.name === "ZodError") {
        return res.status(400).json({ error: "INVALID INPUT DATA" });
      }
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  // DELETE /api/conversations/:id — Delete conversation + messages
  app.delete("/api/conversations/:id", requireAuth, async (req, res) => {
    const convId = parseInt(String(req.params.id), 10);
    if (isNaN(convId)) return res.status(400).json({ error: "INVALID CONVERSATION ID" });

    const deleted = await storage.deleteConversation(convId, req.user!.id);
    if (!deleted) return res.status(404).json({ error: "CONVERSATION NOT FOUND" });
    res.json({ message: "CONVERSATION PURGED" });
  });

  // ═══════════════════════════════════════════════════
  // PHASE 2 — MODEL CONFIG ROUTES
  // ═══════════════════════════════════════════════════

  const modelConfigSchema = z.object({
    temperature: z.number().min(0).max(2).optional(),
    max_tokens: z.number().min(256).max(65536).optional(),
    top_p: z.number().min(0).max(1).optional(),
    system_prompt: z.string().optional(),
  });

  // GET /api/model-configs/:modelName
  app.get("/api/model-configs/:modelName", requireAuth, async (req, res) => {
    const config = await storage.getModelConfig(req.user!.id, String(req.params.modelName));
    res.json(config || { temperature: 0.7, max_tokens: 2048, top_p: 0.9, system_prompt: "" });
  });

  // PUT /api/model-configs/:modelName
  app.put("/api/model-configs/:modelName", requireAuth, async (req, res) => {
    try {
      const data = modelConfigSchema.parse(req.body);
      const config = await storage.upsertModelConfig(req.user!.id, String(req.params.modelName), data);
      res.json(config);
    } catch (err: any) {
      if (err.name === "ZodError") {
        return res.status(400).json({ error: "INVALID INPUT DATA", details: err.errors });
      }
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  // ═══════════════════════════════════════════════════
  // PHASE 3 — VOICE PROXY ROUTES
  // ═══════════════════════════════════════════════════

  const VOICE_SERVICE_BASE = "http://127.0.0.1:5001";
  const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 25 * 1024 * 1024 } });

  // Helper: proxy request to voice service using Node http module
  function proxyToVoice(
    path: string,
    method: string,
    body: Buffer | string | null,
    contentType: string
  ): Promise<{ statusCode: number; headers: http.IncomingHttpHeaders; body: Buffer }> {
    return new Promise((resolve, reject) => {
      const options = {
        hostname: "127.0.0.1",
        port: 5001,
        path,
        method,
        headers: {
          "Content-Type": contentType,
          ...(body ? { "Content-Length": Buffer.byteLength(body) } : {}),
        },
      };

      const req = http.request(options, (res) => {
        const chunks: Buffer[] = [];
        res.on("data", (chunk: Buffer) => chunks.push(chunk));
        res.on("end", () => {
          resolve({
            statusCode: res.statusCode || 500,
            headers: res.headers,
            body: Buffer.concat(chunks),
          });
        });
      });

      req.on("error", reject);
      req.setTimeout(30000, () => {
        req.destroy();
        reject(new Error("Voice service timeout"));
      });

      if (body) req.write(body);
      req.end();
    });
  }

  // POST /api/voice/stt — Speech-to-text proxy
  app.post("/api/voice/stt", requireAuth, upload.single("audio"), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: "NO AUDIO DATA RECEIVED" });
      }

      const result = await proxyToVoice("/stt", "POST", req.file.buffer, "application/octet-stream");
      const json = JSON.parse(result.body.toString());
      res.status(result.statusCode).json(json);
    } catch {
      res.status(503).json({ error: "VOICE PROCESSING UNIT OFFLINE" });
    }
  });

  // POST /api/voice/tts — Text-to-speech proxy
  app.post("/api/voice/tts", requireAuth, async (req, res) => {
    try {
      const { text, voice } = req.body;
      if (!text || typeof text !== "string") {
        return res.status(400).json({ error: "TEXT PAYLOAD REQUIRED" });
      }

      const payload = JSON.stringify({ text, voice: voice || "lessac" });
      const result = await proxyToVoice("/tts", "POST", payload, "application/json");

      if (result.statusCode === 200) {
        res.setHeader("Content-Type", "audio/wav");
        res.setHeader("Content-Length", result.body.length);
        res.status(200).end(result.body);
      } else {
        const json = JSON.parse(result.body.toString());
        res.status(result.statusCode).json(json);
      }
    } catch {
      res.status(503).json({ error: "VOICE SYNTHESIS UNIT OFFLINE" });
    }
  });

  // GET /api/voice/status — Check if voice service is online via TCP probe
  app.get("/api/voice/status", requireAuth, async (_req, res) => {
    const net = await import("net");
    const socket = new net.Socket();
    let resolved = false;
    const done = (online: boolean) => {
      if (resolved) return;
      resolved = true;
      socket.destroy();
      res.json({ online, voices: online ? ["lessac", "amy"] : [] });
    };
    socket.setTimeout(2000);
    socket.connect(5001, "127.0.0.1", () => done(true));
    socket.on("error", () => done(false));
    socket.on("timeout", () => done(false));
  });

  // GET /api/voice/voices — Available voice profiles
  app.get("/api/voice/voices", requireAuth, async (_req, res) => {
    res.json([
      {
        id: "lessac",
        name: "LESSAC (NEUTRAL)",
        description: "Clear, professional neutral American English voice",
      },
      {
        id: "amy",
        name: "AMY (NEUTRAL)",
        description: "Warm, natural American English female voice",
      },
    ]);
  });

  // ═══════════════════════════════════════════════════
  // PHASE 4 — IMAGE GENERATION ROUTES
  // ═══════════════════════════════════════════════════

  const SD_PORT = 7860;
  const SD_HOST = "127.0.0.1";
  const IMAGE_UPLOAD_DIR = "/opt/trident/uploads/images";

  // Helper: proxy request to Stable Diffusion API
  function proxyToSD(
    sdPath: string,
    method: string,
    body: string | null,
    timeoutMs: number = 300000
  ): Promise<{ statusCode: number; body: string }> {
    return new Promise((resolve, reject) => {
      const options: http.RequestOptions = {
        hostname: SD_HOST,
        port: SD_PORT,
        path: sdPath,
        method,
        headers: {
          "Content-Type": "application/json",
          ...(body ? { "Content-Length": Buffer.byteLength(body) } : {}),
        },
      };

      const req = http.request(options, (res) => {
        const chunks: Buffer[] = [];
        res.on("data", (chunk: Buffer) => chunks.push(chunk));
        res.on("end", () => {
          resolve({
            statusCode: res.statusCode || 500,
            body: Buffer.concat(chunks).toString("utf-8"),
          });
        });
      });

      req.on("error", reject);
      req.setTimeout(timeoutMs, () => {
        req.destroy();
        reject(new Error("SD API timeout"));
      });

      if (body) req.write(body);
      req.end();
    });
  }

  // GET /api/imagegen/status — TCP probe to port 7860
  app.get("/api/imagegen/status", requireAuth, async (_req, res) => {
    const net = await import("net");
    const socket = new net.Socket();
    let resolved = false;
    const done = (online: boolean) => {
      if (resolved) return;
      resolved = true;
      socket.destroy();

      if (!online) {
        return res.json({ online: false, backend: "offline" });
      }

      // Detect backend type by querying models endpoint
      proxyToSD("/sdapi/v1/sd-models", "GET", null, 5000)
        .then((result) => {
          let backend: string = "automatic1111";
          try {
            const models = JSON.parse(result.body);
            if (Array.isArray(models) && models.length > 0 && models[0].hash === "diffusers-cpu") {
              backend = "diffusers";
            }
          } catch {
            // default to automatic1111
          }
          res.json({ online: true, backend });
        })
        .catch(() => {
          res.json({ online: true, backend: "automatic1111" });
        });
    };
    socket.setTimeout(2000);
    socket.connect(SD_PORT, SD_HOST, () => done(true));
    socket.on("error", () => done(false));
    socket.on("timeout", () => done(false));
  });

  // GET /api/imagegen/models — List available SD models
  app.get("/api/imagegen/models", requireAuth, async (_req, res) => {
    try {
      const result = await proxyToSD("/sdapi/v1/sd-models", "GET", null, 10000);
      const models = JSON.parse(result.body);
      res.json(models);
    } catch {
      res.status(503).json({ error: "VISUAL SYNTHESIS ENGINE OFFLINE" });
    }
  });

  // POST /api/imagegen/generate — Generate an image
  app.post("/api/imagegen/generate", requireAuth, async (req, res) => {
    try {
      const { prompt, negative_prompt, width, height, steps, cfg_scale, seed, model } = req.body;
      if (!prompt || typeof prompt !== "string" || prompt.trim().length === 0) {
        return res.status(400).json({ error: "VISUAL DIRECTIVE REQUIRED" });
      }

      const sdPayload = JSON.stringify({
        prompt: prompt.trim(),
        negative_prompt: negative_prompt || "",
        width: width || 512,
        height: height || 512,
        steps: steps || 20,
        cfg_scale: cfg_scale || 7,
        seed: seed ?? -1,
        sampler_name: "DPM++ 2M Karras",
      });

      const startTime = Date.now();
      const result = await proxyToSD("/sdapi/v1/txt2img", "POST", sdPayload, 300000);

      if (result.statusCode !== 200) {
        return res.status(result.statusCode).json({ error: "GENERATION FAILED", details: result.body });
      }

      const sdResponse = JSON.parse(result.body);
      if (!sdResponse.images || sdResponse.images.length === 0) {
        return res.status(500).json({ error: "NO IMAGE DATA RETURNED" });
      }

      // Parse info for actual seed
      let actualSeed = -1;
      try {
        const info = JSON.parse(sdResponse.info || "{}");
        actualSeed = info.seed ?? info.all_seeds?.[0] ?? -1;
      } catch {
        // ignore
      }

      // Save image to disk
      const userId = req.user!.id;
      const userDir = path.join(IMAGE_UPLOAD_DIR, String(userId));
      fs.mkdirSync(userDir, { recursive: true });

      const timestamp = Date.now();
      const filename = `${timestamp}_${crypto.randomBytes(4).toString("hex")}.png`;
      const imagePath = path.join(userDir, filename);
      const imageBuffer = Buffer.from(sdResponse.images[0], "base64");
      fs.writeFileSync(imagePath, imageBuffer);

      // Save record to database
      const now = new Date().toISOString();
      const record = await storage.createGeneratedImage({
        user_id: userId,
        prompt: prompt.trim(),
        negative_prompt: negative_prompt || "",
        model: model || "stable-diffusion",
        width: width || 512,
        height: height || 512,
        steps: steps || 20,
        cfg_scale: cfg_scale || 7.0,
        seed: seed ?? -1,
        actual_seed: actualSeed,
        image_path: imagePath,
        thumbnail_path: imagePath,
        created_at: now,
        is_favorite: 0,
      });

      const elapsed = Date.now() - startTime;
      res.json({
        id: record.id,
        imageUrl: `/api/imagegen/image/${record.id}`,
        seed: actualSeed,
        width: record.width,
        height: record.height,
        elapsed_ms: elapsed,
      });
    } catch (err: any) {
      if (err.message === "SD API timeout") {
        return res.status(504).json({ error: "GENERATION TIMEOUT — IMAGE TOOK TOO LONG" });
      }
      res.status(503).json({ error: "VISUAL SYNTHESIS ENGINE OFFLINE" });
    }
  });

  // GET /api/imagegen/image/:id — Serve image file
  app.get("/api/imagegen/image/:id", requireAuth, async (req, res) => {
    try {
      const imageId = parseInt(String(req.params.id), 10);
      if (isNaN(imageId)) return res.status(400).json({ error: "INVALID IMAGE ID" });

      const image = await storage.getImage(imageId, req.user!.id);
      if (!image) return res.status(404).json({ error: "IMAGE NOT FOUND" });

      if (!fs.existsSync(image.image_path)) {
        return res.status(404).json({ error: "IMAGE FILE MISSING FROM DISK" });
      }

      res.setHeader("Content-Type", "image/png");
      res.setHeader("Cache-Control", "max-age=31536000, immutable");
      const fileBuffer = fs.readFileSync(image.image_path);
      res.send(fileBuffer);
    } catch {
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  // GET /api/imagegen/gallery — Paginated gallery
  app.get("/api/imagegen/gallery", requireAuth, async (req, res) => {
    try {
      const page = Math.max(1, parseInt(String(req.query.page || "1"), 10));
      const limit = Math.min(50, Math.max(1, parseInt(String(req.query.limit || "20"), 10)));
      const offset = (page - 1) * limit;

      const total = await storage.getUserImageCount(req.user!.id);
      const images = await storage.getUserImages(req.user!.id, limit, offset);
      const pages = Math.ceil(total / limit);

      res.json({
        images: images.map((img) => ({
          id: img.id,
          prompt: img.prompt,
          negative_prompt: img.negative_prompt,
          width: img.width,
          height: img.height,
          steps: img.steps,
          cfg_scale: img.cfg_scale,
          seed: img.seed,
          actual_seed: img.actual_seed,
          model: img.model,
          created_at: img.created_at,
          is_favorite: img.is_favorite,
          imageUrl: `/api/imagegen/image/${img.id}`,
        })),
        total,
        page,
        pages,
      });
    } catch {
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  // DELETE /api/imagegen/image/:id — Delete image
  app.delete("/api/imagegen/image/:id", requireAuth, async (req, res) => {
    try {
      const imageId = parseInt(String(req.params.id), 10);
      if (isNaN(imageId)) return res.status(400).json({ error: "INVALID IMAGE ID" });

      const image = await storage.getImage(imageId, req.user!.id);
      if (!image) return res.status(404).json({ error: "IMAGE NOT FOUND" });

      // Delete file from disk
      try {
        if (fs.existsSync(image.image_path)) fs.unlinkSync(image.image_path);
        if (image.thumbnail_path && image.thumbnail_path !== image.image_path && fs.existsSync(image.thumbnail_path)) {
          fs.unlinkSync(image.thumbnail_path);
        }
      } catch {
        // ignore file deletion errors
      }

      await storage.deleteImage(imageId, req.user!.id);
      res.json({ message: "IMAGE PURGED" });
    } catch {
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  // PATCH /api/imagegen/image/:id/favorite — Toggle favorite
  app.patch("/api/imagegen/image/:id/favorite", requireAuth, async (req, res) => {
    try {
      const imageId = parseInt(String(req.params.id), 10);
      if (isNaN(imageId)) return res.status(400).json({ error: "INVALID IMAGE ID" });

      const updated = await storage.toggleFavorite(imageId, req.user!.id);
      if (!updated) return res.status(404).json({ error: "IMAGE NOT FOUND" });

      res.json({
        id: updated.id,
        is_favorite: updated.is_favorite,
      });
    } catch {
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  // ═══════════════════════════════════════════════════
  // PHASE 5 — FILE UPLOAD ROUTES
  // ═══════════════════════════════════════════════════

  const FILE_UPLOAD_DIR = "/opt/trident/uploads/files";
  const MAX_FILE_SIZE = 50 * 1024 * 1024; // 50MB

  const ACCEPTED_MIMES = new Set([
    "application/pdf",
    "text/plain",
    "text/markdown",
    "text/csv",
    "application/json",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    "image/jpeg",
    "image/png",
    "image/gif",
    "image/webp",
  ]);

  const fileUpload = multer({
    storage: multer.memoryStorage(),
    limits: { fileSize: MAX_FILE_SIZE },
  });

  // Helper: extract text from uploaded file
  async function extractTextFromFile(filePath: string, mimeType: string): Promise<string> {
    if (mimeType.startsWith("text/") || mimeType === "application/json") {
      return fs.readFileSync(filePath, "utf-8").slice(0, 50000);
    }
    if (mimeType === "application/pdf") {
      try {
        // eslint-disable-next-line @typescript-eslint/no-var-requires
        const pdfParse = require("pdf-parse");
        const buffer = fs.readFileSync(filePath);
        const data = await pdfParse(buffer);
        return data.text.slice(0, 50000);
      } catch {
        return "[PDF EXTRACTION FAILED]";
      }
    }
    if (mimeType.startsWith("image/")) {
      return `[IMAGE FILE: ${path.basename(filePath)}]`;
    }
    return `[BINARY FILE: ${path.basename(filePath)} — content not extractable as text]`;
  }

  // POST /api/files/upload/:conversationId — Upload file to conversation
  app.post("/api/files/upload/:conversationId", requireAuth, fileUpload.single("file"), async (req, res) => {
    try {
      const convId = parseInt(String(req.params.conversationId), 10);
      if (isNaN(convId)) return res.status(400).json({ error: "INVALID CONVERSATION ID" });

      const userId = req.user!.id;

      // Validate conversation ownership
      const conv = await storage.getConversation(convId, userId);
      if (!conv) return res.status(404).json({ error: "CONVERSATION NOT FOUND" });

      if (!req.file) {
        return res.status(400).json({ error: "NO FILE RECEIVED" });
      }

      const mimeType = req.file.mimetype;
      if (!ACCEPTED_MIMES.has(mimeType)) {
        return res.status(400).json({ error: `UNSUPPORTED FILE TYPE: ${mimeType}` });
      }

      // Create upload directory
      const userDir = path.join(FILE_UPLOAD_DIR, String(userId));
      fs.mkdirSync(userDir, { recursive: true });

      // Generate stored filename
      const ext = path.extname(req.file.originalname) || ".bin";
      const storedFilename = `${crypto.randomUUID()}${ext}`;
      const filePath = path.join(userDir, storedFilename);

      // Write file to disk
      fs.writeFileSync(filePath, req.file.buffer);

      // Create DB record
      const now = new Date().toISOString();
      const record = await storage.addConversationFile({
        conversation_id: convId,
        user_id: userId,
        filename: req.file.originalname,
        stored_filename: storedFilename,
        file_path: filePath,
        mime_type: mimeType,
        file_size: req.file.size,
        extracted_text: null,
        extraction_status: "pending",
        created_at: now,
      });

      // Trigger async text extraction (don't await)
      extractTextFromFile(filePath, mimeType)
        .then((text) => {
          storage.updateFileExtraction(record.id, text, "done");
        })
        .catch(() => {
          storage.updateFileExtraction(record.id, "", "failed");
        });

      res.status(201).json({
        id: record.id,
        filename: record.filename,
        mime_type: record.mime_type,
        file_size: record.file_size,
        extraction_status: "pending",
      });
    } catch (err: any) {
      console.error("File upload error:", err);
      if (err.code === "LIMIT_FILE_SIZE") {
        return res.status(413).json({ error: "FILE TOO LARGE — MAX 50MB" });
      }
      res.status(500).json({ error: "FILE UPLOAD FAILED" });
    }
  });

  // GET /api/files/content/:fileId — Get extracted text content (must be before /:conversationId)
  app.get("/api/files/content/:fileId", requireAuth, async (req, res) => {
    try {
      const fileId = parseInt(String(req.params.fileId), 10);
      if (isNaN(fileId)) return res.status(400).json({ error: "INVALID FILE ID" });

      const userId = req.user!.id;
      const file = await storage.getConversationFile(fileId, userId);
      if (!file) return res.status(404).json({ error: "FILE NOT FOUND" });

      res.json({
        id: file.id,
        filename: file.filename,
        extraction_status: file.extraction_status,
        extracted_text: file.extracted_text || "",
      });
    } catch {
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  // GET /api/files/:conversationId — List files for a conversation
  app.get("/api/files/:conversationId", requireAuth, async (req, res) => {
    try {
      const convId = parseInt(String(req.params.conversationId), 10);
      if (isNaN(convId)) return res.status(400).json({ error: "INVALID CONVERSATION ID" });

      const userId = req.user!.id;

      // Validate conversation ownership
      const conv = await storage.getConversation(convId, userId);
      if (!conv) return res.status(404).json({ error: "CONVERSATION NOT FOUND" });

      const files = await storage.getConversationFiles(convId);

      // Strip file_path for security
      const safeFiles = files.map(({ file_path, ...rest }) => rest);
      res.json({ files: safeFiles });
    } catch {
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  // DELETE /api/files/:fileId — Delete a file
  app.delete("/api/files/:fileId", requireAuth, async (req, res) => {
    try {
      const fileId = parseInt(String(req.params.fileId), 10);
      if (isNaN(fileId)) return res.status(400).json({ error: "INVALID FILE ID" });

      const userId = req.user!.id;
      const file = await storage.getConversationFile(fileId, userId);
      if (!file) return res.status(404).json({ error: "FILE NOT FOUND" });

      // Delete from disk
      try {
        if (fs.existsSync(file.file_path)) fs.unlinkSync(file.file_path);
      } catch {
        // ignore disk errors
      }

      await storage.deleteConversationFile(fileId, userId);
      res.json({ message: "FILE PURGED" });
    } catch {
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  // ═══════════════════════════════════════════════════
  // PHASE 6 — ADMIN STATS, EXPORT, API KEYS
  // ═══════════════════════════════════════════════════

  // GET /api/admin/stats — System-wide statistics (admin only)
  app.get("/api/admin/stats", requireAdmin, async (_req, res) => {
    try {
      const stats = await storage.getSystemStats();
      const mem = process.memoryUsage();
      res.json({
        users: { total: stats.userCount, active: stats.activeUserCount, admins: stats.adminCount },
        conversations: { total: stats.conversationCount, totalMessages: stats.messageCount },
        images: { total: stats.imageCount, totalSize: stats.imageTotalSize },
        files: { total: stats.fileCount, totalSize: stats.fileTotalSize },
        system: {
          uptime: process.uptime(),
          nodeVersion: process.version,
          platform: process.platform,
          memoryUsed: mem.heapUsed,
          memoryTotal: mem.heapTotal,
        },
      });
    } catch {
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  // GET /api/admin/user-stats/:userId — Per-user usage (admin only)
  app.get("/api/admin/user-stats/:userId", requireAdmin, async (req, res) => {
    try {
      const userId = parseInt(String(req.params.userId), 10);
      if (isNaN(userId)) return res.status(400).json({ error: "INVALID USER ID" });
      const stats = await storage.getUserStats(userId);
      res.json(stats);
    } catch {
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  // GET /api/conversations/:id/export — Export conversation
  app.get("/api/conversations/:id/export", requireAuth, async (req, res) => {
    try {
      const convId = parseInt(String(req.params.id), 10);
      if (isNaN(convId)) return res.status(400).json({ error: "INVALID CONVERSATION ID" });

      const userId = req.user!.id;
      const conv = await storage.getConversation(convId, userId);
      if (!conv) return res.status(404).json({ error: "CONVERSATION NOT FOUND" });

      const msgs = await storage.getConversationMessages(convId);
      const format = String(req.query.format || "json");

      if (format === "markdown") {
        let md = `# ${conv.title}\n\n`;
        md += `**Model:** ${conv.model}\n`;
        md += `**Created:** ${conv.created_at}\n`;
        md += `**Messages:** ${msgs.length}\n\n---\n\n`;
        for (const msg of msgs) {
          const role = msg.role === "user" ? "🟠 **User**" : "🔵 **Assistant**";
          md += `${role} *(${msg.created_at})*\n\n${msg.content}\n\n---\n\n`;
        }
        res.setHeader("Content-Type", "text/markdown; charset=utf-8");
        res.setHeader("Content-Disposition", `attachment; filename="${conv.title.replace(/[^a-zA-Z0-9]/g, "_")}.md"`);
        return res.send(md);
      }

      // Default: JSON
      const data = { conversation: conv, messages: msgs };
      res.setHeader("Content-Type", "application/json; charset=utf-8");
      res.setHeader("Content-Disposition", `attachment; filename="${conv.title.replace(/[^a-zA-Z0-9]/g, "_")}.json"`);
      return res.json(data);
    } catch {
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  // GET /api/keys — List user's API keys
  app.get("/api/keys", requireAuth, async (req, res) => {
    try {
      const keys = await storage.getUserApiKeys(req.user!.id);
      res.json({
        keys: keys.map((k) => ({
          id: k.id,
          name: k.name,
          key_prefix: k.key_prefix,
          created_at: k.created_at,
          last_used: k.last_used,
        })),
      });
    } catch {
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  // POST /api/keys — Generate new API key
  app.post("/api/keys", requireAuth, async (req, res) => {
    try {
      const { name } = req.body;
      if (!name || typeof name !== "string" || name.trim().length === 0) {
        return res.status(400).json({ error: "KEY NAME REQUIRED" });
      }

      const rawKey = "trident_" + crypto.randomBytes(32).toString("hex");
      const keyHash = crypto.createHash("sha256").update(rawKey).digest("hex");
      const keyPrefix = rawKey.slice(0, 16) + "...";

      await storage.createApiKey({
        user_id: req.user!.id,
        key_hash: keyHash,
        key_prefix: keyPrefix,
        name: name.trim(),
        created_at: new Date().toISOString(),
      });

      res.status(201).json({
        key: rawKey,
        prefix: keyPrefix,
        name: name.trim(),
        message: "KEY GENERATED — STORE SECURELY. THIS WILL NOT BE SHOWN AGAIN.",
      });
    } catch {
      res.status(500).json({ error: "KEY GENERATION FAILED" });
    }
  });

  // DELETE /api/keys/:id — Deactivate API key
  app.delete("/api/keys/:id", requireAuth, async (req, res) => {
    try {
      const keyId = parseInt(String(req.params.id), 10);
      if (isNaN(keyId)) return res.status(400).json({ error: "INVALID KEY ID" });

      const deleted = await storage.deactivateApiKey(keyId, req.user!.id);
      if (!deleted) return res.status(404).json({ error: "KEY NOT FOUND" });

      res.json({ message: "KEY REVOKED" });
    } catch {
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  return httpServer;
}
