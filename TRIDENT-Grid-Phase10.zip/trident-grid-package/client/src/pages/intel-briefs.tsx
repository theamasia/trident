import { useState, useRef, useEffect } from "react";
import {
  Shield,
  Plus,
  X,
  FileText,
  Folder,
  FolderOpen,
  Loader2,
  Trash2,
  Rss,
  Globe,
  MessageSquare,
  FileSearch,
  ScrollText,
  Send,
  CheckCircle2,
  Download,
  RefreshCw,
  Radio,
  ChevronRight,
  Clock,
} from "lucide-react";
import { getAuthHeaders } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useQueryClient, useMutation } from "@tanstack/react-query";
import type { IntelBrief, WebFeed } from "@shared/schema";

const API_BASE = "__PORT_5000__".startsWith("__") ? "" : "__PORT_5000__";

// ═══════════════════════════════════════════════════
// Types
// ═══════════════════════════════════════════════════
interface TopicFile {
  name: string;
  ext: string;
  size: number;
  modified: string;
}
interface Topic {
  name: string;
  description?: string;
  classification?: string;
  file_count: number;
  files: TopicFile[];
  brief_count: number;
  total_size_kb: number;
  modified?: string;
}
interface ExtractedDoc {
  id: string;
  name: string;
  ext: string;
  size: number;
  text: string;
  text_length: number;
}
interface ChatMsg {
  role: "user" | "assistant";
  content: string;
  docs?: string[];
}

const CLASSIFICATIONS = ["UNCLASSIFIED", "CONFIDENTIAL", "SECRET", "TOP SECRET"];
const FEED_CATEGORIES = ["GENERAL", "MILITARY", "GEOPOLITICAL", "CYBER", "OSINT"];

const PRECONFIGURED_FEEDS = [
  { name: "S2 Underground", url: "https://publish.obsidian.md/s2underground", category: "OSINT" },
  { name: "Defense News", url: "https://www.defensenews.com", category: "MILITARY" },
  { name: "War on the Rocks", url: "https://warontherocks.com", category: "GEOPOLITICAL" },
];

function classColor(c?: string): string {
  switch ((c || "").toUpperCase()) {
    case "TOP SECRET": return "text-trident-red border-trident-red/40 bg-trident-red/10";
    case "SECRET": return "text-trident-amber border-trident-amber/40 bg-trident-amber/10";
    case "CONFIDENTIAL": return "text-trident-cyan border-trident-cyan/40 bg-trident-cyan/10";
    default: return "text-[#00ff41] border-[#00ff41]/40 bg-[#00ff41]/10";
  }
}
function fmtSize(kb: number): string {
  if (kb >= 1024) return `${(kb / 1024).toFixed(1)} MB`;
  return `${kb.toFixed(1)} KB`;
}
function fmtBytes(b: number): string {
  if (b >= 1048576) return `${(b / 1048576).toFixed(1)} MB`;
  if (b >= 1024) return `${(b / 1024).toFixed(1)} KB`;
  return `${b} B`;
}
function relTime(iso?: string | null): string {
  if (!iso) return "NEVER";
  const then = new Date(iso).getTime();
  const diff = Date.now() - then;
  if (isNaN(diff)) return "UNKNOWN";
  const m = Math.floor(diff / 60000);
  if (m < 1) return "JUST NOW";
  if (m < 60) return `${m}M AGO`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}H AGO`;
  return `${Math.floor(h / 24)}D AGO`;
}

export default function IntelBriefs() {
  const { toast } = useToast();
  const qc = useQueryClient();

  const [selectedTopic, setSelectedTopic] = useState<string | null>(null);
  const [selectedFeedId, setSelectedFeedId] = useState<number | null>(null);
  const [subTab, setSubTab] = useState<"files" | "brief" | "chat">("files");

  const [showTopicModal, setShowTopicModal] = useState(false);
  const [showFeedModal, setShowFeedModal] = useState(false);

  // ─── Service status ───
  const { data: status } = useQuery<{ online: boolean }>({
    queryKey: ["/api/intel/status"],
    queryFn: async () => {
      const res = await fetch(`${API_BASE}/api/intel/status`, { headers: getAuthHeaders() });
      if (!res.ok) throw new Error("status failed");
      return res.json();
    },
    staleTime: 0,
    refetchInterval: 15000,
  });

  // ─── Topics ───
  const { data: topicsData, isLoading: topicsLoading } = useQuery<{ topics: Topic[] }>({
    queryKey: ["/api/intel/topics"],
    queryFn: async () => {
      const res = await fetch(`${API_BASE}/api/intel/topics`, { headers: getAuthHeaders() });
      if (!res.ok) throw new Error("topics failed");
      return res.json();
    },
    staleTime: 0,
  });
  const topics = topicsData?.topics || [];

  // ─── Feeds ───
  const { data: feedsData } = useQuery<{ feeds: WebFeed[] }>({
    queryKey: ["/api/intel/feeds"],
    queryFn: async () => {
      const res = await fetch(`${API_BASE}/api/intel/feeds`, { headers: getAuthHeaders() });
      if (!res.ok) throw new Error("feeds failed");
      return res.json();
    },
    staleTime: 0,
  });
  const feeds = feedsData?.feeds || [];

  // Seed pre-configured feeds once, when feeds list is empty
  const seededRef = useRef(false);
  useEffect(() => {
    if (seededRef.current) return;
    if (feedsData && feeds.length === 0) {
      seededRef.current = true;
      (async () => {
        for (const f of PRECONFIGURED_FEEDS) {
          try {
            await fetch(`${API_BASE}/api/intel/feeds`, {
              method: "POST",
              headers: { "Content-Type": "application/json", ...getAuthHeaders() },
              body: JSON.stringify(f),
            });
          } catch { /* ignore */ }
        }
        qc.invalidateQueries({ queryKey: ["/api/intel/feeds"] });
      })();
    }
  }, [feedsData]);

  const selectTopic = (name: string) => {
    setSelectedFeedId(null);
    setSelectedTopic(name);
    setSubTab("files");
  };
  const selectFeed = (id: number) => {
    setSelectedTopic(null);
    setSelectedFeedId(id);
  };

  const activeTopic = topics.find((t) => t.name === selectedTopic) || null;
  const activeFeed = feeds.find((f) => f.id === selectedFeedId) || null;

  return (
    <div className="h-full flex flex-col" data-testid="page-intel-briefs">
      {/* ═══════════ HEADER ═══════════ */}
      <div className="flex items-center justify-between mb-4 pb-3 border-b border-trident-border">
        <div className="flex items-center gap-3">
          <Shield className="w-6 h-6 text-trident-cyan" style={{ filter: "drop-shadow(0 0 6px #00f0ff)" }} />
          <div>
            <h1 className="font-display text-lg tracking-[0.15em] text-trident-cyan text-glow-cyan">
              INTEL BRIEFS
            </h1>
            <p className="text-[10px] font-mono uppercase tracking-widest text-trident-text/40">
              SECURITY BRIEF INTELLIGENCE // NAS + WEB FEEDS
            </p>
          </div>
        </div>
        <div className="flex items-center gap-3 font-mono text-[10px] uppercase tracking-widest">
          <span
            className={`flex items-center gap-1.5 ${status?.online ? "text-[#00ff41] text-glow-green" : "text-trident-red"}`}
            data-testid="status-brief-service"
          >
            <span className={`inline-block w-1.5 h-1.5 rounded-full ${status?.online ? "bg-[#00ff41] animate-pulse" : "bg-trident-red"}`} />
            {status?.online ? "BRIEF SVC ONLINE" : "BRIEF SVC OFFLINE"}
          </span>
          <span className="text-trident-border">|</span>
          <span className="text-trident-text/50">PORT 5006</span>
        </div>
      </div>

      {/* ═══════════ TWO COLUMN LAYOUT ═══════════ */}
      <div className="flex-1 flex gap-4 min-h-0">
        {/* ─── LEFT COLUMN ─── */}
        <div className="w-[300px] flex-shrink-0 flex flex-col gap-4 overflow-y-auto pr-1">
          {/* SECTION A: TOPICS */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <Folder className="w-3.5 h-3.5 text-trident-amber" />
                <h2 className="font-mono text-[11px] uppercase tracking-widest text-trident-amber">
                  INTEL TOPICS
                </h2>
              </div>
              <button
                onClick={() => setShowTopicModal(true)}
                className="flex items-center gap-1 px-2 py-1 text-[9px] font-mono uppercase tracking-widest text-trident-cyan border border-trident-cyan/40 hover:bg-trident-cyan/10 transition-all"
                data-testid="button-new-topic"
              >
                <Plus className="w-3 h-3" /> NEW TOPIC
              </button>
            </div>

            {topicsLoading ? (
              <div className="text-[10px] font-mono uppercase tracking-widest text-trident-text/40 py-4 text-center">
                <Loader2 className="w-4 h-4 animate-spin mx-auto mb-1" /> LOADING TOPICS...
              </div>
            ) : topics.length === 0 ? (
              <div className="border border-dashed border-trident-border p-4 text-center">
                <FileSearch className="w-5 h-5 text-trident-text/30 mx-auto mb-2" />
                <p className="text-[10px] font-mono uppercase tracking-widest text-trident-text/40">
                  NO TOPICS. CREATE ONE TO BEGIN.
                </p>
              </div>
            ) : (
              <div className="space-y-2">
                {topics.map((t) => {
                  const active = selectedTopic === t.name;
                  return (
                    <button
                      key={t.name}
                      onClick={() => selectTopic(t.name)}
                      className={`w-full text-left border p-2.5 transition-all ${
                        active
                          ? "border-trident-cyan bg-trident-cyan/8"
                          : "border-trident-border hover:border-trident-cyan/40 hover:bg-trident-cyan/5"
                      }`}
                      style={active ? { boxShadow: "0 0 12px #00f0ff30" } : undefined}
                      data-testid={`card-topic-${t.name}`}
                    >
                      <div className="flex items-center gap-1.5 mb-1">
                        {active ? (
                          <FolderOpen className="w-3.5 h-3.5 text-trident-cyan flex-shrink-0" />
                        ) : (
                          <ChevronRight className="w-3.5 h-3.5 text-trident-text/40 flex-shrink-0" />
                        )}
                        <span className={`font-mono text-xs uppercase tracking-wider truncate ${active ? "text-trident-cyan" : "text-trident-text/80"}`}>
                          {t.name}
                        </span>
                      </div>
                      <div className="text-[9px] font-mono uppercase tracking-widest text-trident-text/50 pl-5">
                        {t.file_count} FILES · {t.brief_count} BRIEFS
                      </div>
                      <div className="pl-5 mt-1">
                        <span className={`inline-block px-1.5 py-0.5 text-[8px] font-mono uppercase tracking-widest border ${classColor(t.classification)}`}>
                          {t.classification || "UNCLASSIFIED"}
                        </span>
                      </div>
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          {/* SECTION B: WEB INTEL FEEDS */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <Rss className="w-3.5 h-3.5 text-[#00ff41]" />
                <h2 className="font-mono text-[11px] uppercase tracking-widest text-[#00ff41]">
                  WEB INTEL FEEDS
                </h2>
              </div>
              <button
                onClick={() => setShowFeedModal(true)}
                className="flex items-center gap-1 px-2 py-1 text-[9px] font-mono uppercase tracking-widest text-[#00ff41] border border-[#00ff41]/40 hover:bg-[#00ff41]/10 transition-all"
                data-testid="button-add-feed"
              >
                <Plus className="w-3 h-3" /> ADD FEED
              </button>
            </div>

            {feeds.length === 0 ? (
              <div className="border border-dashed border-trident-border p-3 text-center">
                <Globe className="w-4 h-4 text-trident-text/30 mx-auto mb-1" />
                <p className="text-[9px] font-mono uppercase tracking-widest text-trident-text/40">
                  NO FEEDS CONFIGURED
                </p>
              </div>
            ) : (
              <div className="space-y-2">
                {feeds.map((f) => {
                  const active = selectedFeedId === f.id;
                  return (
                    <button
                      key={f.id}
                      onClick={() => selectFeed(f.id)}
                      className={`w-full text-left border p-2.5 transition-all ${
                        active
                          ? "border-[#00ff41] bg-[#00ff41]/8"
                          : "border-trident-border hover:border-[#00ff41]/40 hover:bg-[#00ff41]/5"
                      }`}
                      data-testid={`card-feed-${f.id}`}
                    >
                      <div className="flex items-center gap-1.5 mb-1">
                        <Radio className={`w-3 h-3 flex-shrink-0 ${active ? "text-[#00ff41]" : "text-trident-text/40"}`} />
                        <span className={`font-mono text-xs uppercase tracking-wider truncate ${active ? "text-[#00ff41]" : "text-trident-text/80"}`}>
                          {f.name}
                        </span>
                      </div>
                      <div className="text-[9px] font-mono text-trident-text/40 pl-4 truncate">
                        {f.url}
                      </div>
                      <div className="flex items-center gap-1 text-[8px] font-mono uppercase tracking-widest text-trident-text/50 pl-4 mt-1">
                        <Clock className="w-2.5 h-2.5" /> {relTime(f.lastFetched)}
                        <span className="text-trident-border mx-1">·</span>
                        {f.category}
                      </div>
                    </button>
                  );
                })}
              </div>
            )}
          </div>
        </div>

        {/* ─── RIGHT COLUMN ─── */}
        <div className="flex-1 min-w-0 border border-trident-border bg-[#0a1628]/40 flex flex-col overflow-hidden">
          {activeFeed ? (
            <FeedPanel feed={activeFeed} />
          ) : activeTopic ? (
            <TopicPanel
              topic={activeTopic}
              subTab={subTab}
              setSubTab={setSubTab}
            />
          ) : (
            <div className="flex-1 flex items-center justify-center">
              <div className="text-center">
                <ScrollText className="w-10 h-10 text-trident-text/20 mx-auto mb-3" />
                <p className="font-mono text-xs uppercase tracking-widest text-trident-text/40">
                  SELECT A TOPIC OR FEED
                </p>
                <p className="font-mono text-[10px] uppercase tracking-widest text-trident-text/25 mt-1">
                  TRIDENT BRIEF INTELLIGENCE // AWAITING INPUT
                </p>
              </div>
            </div>
          )}
        </div>
      </div>

      {showTopicModal && <NewTopicModal onClose={() => setShowTopicModal(false)} />}
      {showFeedModal && <AddFeedModal onClose={() => setShowFeedModal(false)} />}
    </div>
  );
}

// ═══════════════════════════════════════════════════
// TOPIC PANEL (files / brief / chat)
// ═══════════════════════════════════════════════════
function TopicPanel({
  topic,
  subTab,
  setSubTab,
}: {
  topic: Topic;
  subTab: "files" | "brief" | "chat";
  setSubTab: (t: "files" | "brief" | "chat") => void;
}) {
  const tabs: { id: "files" | "brief" | "chat"; label: string; icon: any }[] = [
    { id: "files", label: "FILES", icon: FileText },
    { id: "brief", label: "BRIEF", icon: ScrollText },
    { id: "chat", label: "CHAT", icon: MessageSquare },
  ];

  return (
    <div className="flex flex-col h-full">
      {/* Topic header */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-trident-border">
        <div className="flex items-center gap-2 min-w-0">
          <FolderOpen className="w-4 h-4 text-trident-cyan flex-shrink-0" />
          <span className="font-mono text-sm uppercase tracking-widest text-trident-cyan truncate">
            {topic.name}
          </span>
          <span className={`inline-block px-1.5 py-0.5 text-[8px] font-mono uppercase tracking-widest border flex-shrink-0 ${classColor(topic.classification)}`}>
            {topic.classification || "UNCLASSIFIED"}
          </span>
        </div>
        <div className="font-mono text-[9px] uppercase tracking-widest text-trident-text/40">
          {topic.file_count} FILES · {fmtSize(topic.total_size_kb)}
        </div>
      </div>

      {/* Sub-tabs */}
      <div className="flex border-b border-trident-border">
        {tabs.map((t) => {
          const Icon = t.icon;
          const active = subTab === t.id;
          return (
            <button
              key={t.id}
              onClick={() => setSubTab(t.id)}
              className={`flex items-center gap-1.5 px-4 py-2 text-[10px] font-mono uppercase tracking-widest border-b-2 transition-all ${
                active
                  ? "text-trident-cyan border-trident-amber bg-trident-cyan/5"
                  : "text-trident-text/50 border-transparent hover:text-trident-cyan"
              }`}
              data-testid={`tab-${t.id}`}
            >
              <Icon className="w-3.5 h-3.5" /> {t.label}
            </button>
          );
        })}
      </div>

      <div className="flex-1 overflow-hidden">
        {subTab === "files" && <FilesTab topic={topic} />}
        {subTab === "brief" && <BriefTab topic={topic} />}
        {subTab === "chat" && <ChatTab topic={topic} />}
      </div>
    </div>
  );
}

// ─── FILES SUB-TAB ───
function FilesTab({ topic }: { topic: Topic }) {
  const { toast } = useToast();
  const [extracted, setExtracted] = useState<ExtractedDoc[] | null>(null);
  const [extracting, setExtracting] = useState(false);
  const [totalChars, setTotalChars] = useState(0);

  const runExtract = async () => {
    setExtracting(true);
    try {
      const res = await fetch(`${API_BASE}/api/intel/topics/${encodeURIComponent(topic.name)}/extract`, {
        headers: getAuthHeaders(),
      });
      if (!res.ok) throw new Error((await res.json())?.error || "EXTRACTION FAILED");
      const data = await res.json();
      setExtracted(data.documents || []);
      setTotalChars(data.total_chars || 0);
      toast({ title: "EXTRACTION COMPLETE", description: `${data.total_docs} DOCS · ${data.total_chars} CHARS` });
    } catch (e: any) {
      toast({ title: "EXTRACTION FAILED", description: e?.message || "ERROR", variant: "destructive" });
    } finally {
      setExtracting(false);
    }
  };

  const extractedById: Record<string, ExtractedDoc> = {};
  (extracted || []).forEach((d) => { extractedById[d.name] = d; });

  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center justify-between px-4 py-2.5 border-b border-trident-border">
        <div className="font-mono text-[10px] uppercase tracking-widest text-trident-text/60">
          {extracted
            ? `${extracted.length} FILES — ${totalChars.toLocaleString()} CHARS EXTRACTED`
            : `${topic.file_count} FILES IN FOLDER`}
        </div>
        <button
          onClick={runExtract}
          disabled={extracting || topic.file_count === 0}
          className="flex items-center gap-1.5 px-3 py-1.5 text-[10px] font-mono uppercase tracking-widest text-trident-cyan border border-trident-cyan/40 hover:bg-trident-cyan/10 disabled:opacity-40 transition-all"
          data-testid="button-extract-analyze"
        >
          {extracting ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <FileSearch className="w-3.5 h-3.5" />}
          {extracting ? "ANALYZING..." : "EXTRACT & ANALYZE"}
        </button>
      </div>

      <div className="flex-1 overflow-y-auto p-4">
        {topic.files.length === 0 ? (
          <div className="text-center py-8">
            <FileText className="w-6 h-6 text-trident-text/25 mx-auto mb-2" />
            <p className="font-mono text-[10px] uppercase tracking-widest text-trident-text/40">
              NO FILES IN THIS TOPIC FOLDER
            </p>
            <p className="font-mono text-[9px] tracking-wider text-trident-text/30 mt-1">
              ADD FILES TO \\192.168.0.20\briefs\{topic.name}\
            </p>
          </div>
        ) : (
          <table className="w-full text-left">
            <thead>
              <tr className="border-b border-trident-border">
                <th className="py-2 font-mono text-[9px] uppercase tracking-widest text-trident-text/40">NAME</th>
                <th className="py-2 font-mono text-[9px] uppercase tracking-widest text-trident-text/40">TYPE</th>
                <th className="py-2 font-mono text-[9px] uppercase tracking-widest text-trident-text/40">SIZE</th>
                <th className="py-2 font-mono text-[9px] uppercase tracking-widest text-trident-text/40">MODIFIED</th>
                <th className="py-2 font-mono text-[9px] uppercase tracking-widest text-trident-text/40 text-right">EXTRACTED</th>
              </tr>
            </thead>
            <tbody>
              {topic.files.map((f) => {
                const ex = extractedById[f.name];
                return (
                  <tr key={f.name} className="border-b border-trident-border/40" data-testid={`row-file-${f.name}`}>
                    <td className="py-2 font-mono text-[11px] text-trident-text/80 truncate max-w-[220px]">{f.name}</td>
                    <td className="py-2 font-mono text-[10px] text-trident-cyan uppercase">{f.ext || "—"}</td>
                    <td className="py-2 font-mono text-[10px] text-trident-text/50">{fmtBytes(f.size)}</td>
                    <td className="py-2 font-mono text-[9px] text-trident-text/40">{(f.modified || "").slice(0, 10)}</td>
                    <td className="py-2 font-mono text-[10px] text-right">
                      {ex ? (
                        <span className="text-[#00ff41]">{ex.text_length.toLocaleString()} CH</span>
                      ) : (
                        <span className="text-trident-text/25">—</span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}

        {/* Extracted text preview */}
        {extracted && extracted.length > 0 && (
          <div className="mt-6">
            <div className="font-mono text-[10px] uppercase tracking-widest text-trident-amber mb-2">
              EXTRACTED TEXT PREVIEW
            </div>
            <div className="space-y-3">
              {extracted.map((d) => (
                <div key={d.id} className="border border-trident-border p-3 bg-[#050a0e]/60">
                  <div className="font-mono text-[10px] uppercase tracking-widest text-trident-cyan mb-1">
                    {d.name} <span className="text-trident-text/40">· {d.text_length.toLocaleString()} CHARS</span>
                  </div>
                  <pre className="font-mono text-[10px] text-trident-text/60 whitespace-pre-wrap max-h-32 overflow-y-auto leading-relaxed">
                    {d.text.slice(0, 800)}{d.text.length > 800 ? "…" : ""}
                  </pre>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// ─── BRIEF SUB-TAB ───
function BriefTab({ topic }: { topic: Topic }) {
  const { toast } = useToast();
  const qc = useQueryClient();
  const [classification, setClassification] = useState(topic.classification || "UNCLASSIFIED");
  const [focus, setFocus] = useState("");
  const [draft, setDraft] = useState<{ id: number; content: string; title: string } | null>(null);
  const [viewing, setViewing] = useState<IntelBrief | null>(null);

  const { data: briefsData } = useQuery<{ briefs: IntelBrief[] }>({
    queryKey: ["/api/intel/topics", topic.name, "briefs"],
    queryFn: async () => {
      const res = await fetch(`${API_BASE}/api/intel/topics/${encodeURIComponent(topic.name)}/briefs`, {
        headers: getAuthHeaders(),
      });
      if (!res.ok) throw new Error("briefs failed");
      return res.json();
    },
    staleTime: 0,
  });
  const briefs = briefsData?.briefs || [];

  const generate = useMutation({
    mutationFn: async () => {
      const res = await fetch(`${API_BASE}/api/intel/topics/${encodeURIComponent(topic.name)}/brief/generate`, {
        method: "POST",
        headers: { "Content-Type": "application/json", ...getAuthHeaders() },
        body: JSON.stringify({ classification, focus }),
      });
      if (!res.ok) throw new Error((await res.json())?.error || "GENERATION FAILED");
      return res.json();
    },
    onSuccess: (d) => {
      setDraft({ id: d.id, content: d.content, title: d.title });
      setViewing(null);
      qc.invalidateQueries({ queryKey: ["/api/intel/topics", topic.name, "briefs"] });
      toast({ title: "BRIEF GENERATED", description: "DRAFT READY FOR REVIEW" });
    },
    onError: (e: any) => toast({ title: "GENERATION FAILED", description: e?.message, variant: "destructive" }),
  });

  const publish = useMutation({
    mutationFn: async (id: number) => {
      const res = await fetch(`${API_BASE}/api/intel/briefs/${id}/publish`, {
        method: "POST",
        headers: getAuthHeaders(),
      });
      if (!res.ok) throw new Error("PUBLISH FAILED");
      return res.json();
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["/api/intel/topics", topic.name, "briefs"] });
      toast({ title: "BRIEF PUBLISHED", description: "SAVED TO NAS" });
      setDraft(null);
    },
    onError: (e: any) => toast({ title: "PUBLISH FAILED", description: e?.message, variant: "destructive" }),
  });

  const shown = viewing ? { content: viewing.content, title: viewing.title, id: viewing.id, isDraft: viewing.isDraft }
    : draft ? { content: draft.content, title: draft.title, id: draft.id, isDraft: 1 }
    : null;

  return (
    <div className="flex h-full">
      {/* Left: controls + brief display */}
      <div className="flex-1 flex flex-col overflow-hidden">
        <div className="px-4 py-3 border-b border-trident-border space-y-3">
          <div className="flex items-center gap-3">
            <div className="flex-shrink-0">
              <label className="block font-mono text-[9px] uppercase tracking-widest text-trident-text/50 mb-1">CLASSIFICATION</label>
              <select
                value={classification}
                onChange={(e) => setClassification(e.target.value)}
                className="bg-[#050a0e] border border-trident-border text-trident-cyan font-mono text-[10px] uppercase tracking-widest px-2 py-1.5 focus:border-trident-cyan outline-none"
                data-testid="select-classification"
              >
                {CLASSIFICATIONS.map((c) => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
            <div className="flex-1">
              <label className="block font-mono text-[9px] uppercase tracking-widest text-trident-text/50 mb-1">FOCUS (OPTIONAL)</label>
              <input
                value={focus}
                onChange={(e) => setFocus(e.target.value)}
                placeholder="E.G. FINANCIAL LINKS, TIMELINE..."
                className="w-full bg-[#050a0e] border border-trident-border text-trident-text font-mono text-[10px] uppercase tracking-wider px-2 py-1.5 focus:border-trident-cyan outline-none placeholder:text-trident-text/25"
                data-testid="input-focus"
              />
            </div>
          </div>
          <button
            onClick={() => generate.mutate()}
            disabled={generate.isPending || topic.file_count === 0}
            className="w-full flex items-center justify-center gap-2 px-4 py-2 text-[11px] font-mono uppercase tracking-widest text-trident-amber border border-trident-amber/50 hover:bg-trident-amber/10 disabled:opacity-40 transition-all"
            style={{ boxShadow: generate.isPending ? "0 0 12px #ff6b0040" : undefined }}
            data-testid="button-generate-brief"
          >
            {generate.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <ScrollText className="w-4 h-4" />}
            {generate.isPending ? `>> ANALYZING ${topic.file_count} DOCUMENTS...` : "GENERATE BRIEF"}
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-4">
          {shown ? (
            <div>
              <div className="flex items-center justify-between mb-3">
                <div className="font-mono text-[11px] uppercase tracking-widest text-trident-cyan">
                  {shown.title}
                  {shown.isDraft === 1 && <span className="ml-2 text-trident-amber">[DRAFT]</span>}
                  {shown.isDraft === 0 && <span className="ml-2 text-[#00ff41]">[PUBLISHED]</span>}
                </div>
                {shown.isDraft === 1 && (
                  <button
                    onClick={() => publish.mutate(shown.id)}
                    disabled={publish.isPending}
                    className="flex items-center gap-1.5 px-3 py-1.5 text-[10px] font-mono uppercase tracking-widest text-[#00ff41] border border-[#00ff41]/50 hover:bg-[#00ff41]/10 disabled:opacity-40 transition-all"
                    data-testid="button-publish-brief"
                  >
                    {publish.isPending ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <CheckCircle2 className="w-3.5 h-3.5" />}
                    PUBLISH BRIEF
                  </button>
                )}
              </div>
              <div className="border border-trident-border bg-[#050a0e]/60 p-4">
                <pre className="font-mono text-[11px] text-trident-text/85 whitespace-pre-wrap leading-relaxed" data-testid="text-brief-content">
                  {shown.content}
                </pre>
              </div>
            </div>
          ) : (
            <div className="text-center py-10">
              <ScrollText className="w-8 h-8 text-trident-text/20 mx-auto mb-2" />
              <p className="font-mono text-[10px] uppercase tracking-widest text-trident-text/40">
                NO BRIEF GENERATED YET
              </p>
              <p className="font-mono text-[9px] uppercase tracking-widest text-trident-text/25 mt-1">
                SELECT CLASSIFICATION & GENERATE
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Right: brief history */}
      <div className="w-52 flex-shrink-0 border-l border-trident-border overflow-y-auto">
        <div className="px-3 py-2.5 border-b border-trident-border font-mono text-[9px] uppercase tracking-widest text-trident-amber">
          BRIEF HISTORY
        </div>
        <div className="p-2 space-y-1.5">
          {briefs.length === 0 ? (
            <p className="font-mono text-[9px] uppercase tracking-widest text-trident-text/30 p-2 text-center">NONE</p>
          ) : (
            briefs.map((b) => (
              <button
                key={b.id}
                onClick={() => { setViewing(b); setDraft(null); }}
                className="w-full text-left border border-trident-border p-2 hover:border-trident-cyan/40 hover:bg-trident-cyan/5 transition-all"
                data-testid={`history-brief-${b.id}`}
              >
                <div className="font-mono text-[9px] uppercase tracking-wider text-trident-text/70 truncate">{b.title}</div>
                <div className="flex items-center gap-1 mt-1">
                  <span className={`text-[8px] font-mono ${b.isDraft ? "text-trident-amber" : "text-[#00ff41]"}`}>
                    {b.isDraft ? "DRAFT" : "PUBLISHED"}
                  </span>
                  <span className="text-trident-border">·</span>
                  <span className="text-[8px] font-mono text-trident-text/40">{(b.createdAt || "").slice(0, 10)}</span>
                </div>
              </button>
            ))
          )}
        </div>
      </div>
    </div>
  );
}

// ─── CHAT SUB-TAB ───
function ChatTab({ topic }: { topic: Topic }) {
  const { toast } = useToast();
  const [messages, setMessages] = useState<ChatMsg[]>([]);
  const [input, setInput] = useState("");
  const [sending, setSending] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, sending]);

  const send = async () => {
    const msg = input.trim();
    if (!msg || sending) return;
    setInput("");
    setMessages((m) => [...m, { role: "user", content: msg }]);
    setSending(true);
    try {
      const res = await fetch(`${API_BASE}/api/intel/topics/${encodeURIComponent(topic.name)}/chat`, {
        method: "POST",
        headers: { "Content-Type": "application/json", ...getAuthHeaders() },
        body: JSON.stringify({ message: msg }),
      });
      if (!res.ok) throw new Error((await res.json())?.error || "CHAT FAILED");
      const data = await res.json();
      setMessages((m) => [...m, { role: "assistant", content: data.response, docs: data.documents_used }]);
    } catch (e: any) {
      setMessages((m) => [...m, { role: "assistant", content: `[ERROR] ${e?.message || "CHAT FAILED"}` }]);
      toast({ title: "CHAT ERROR", description: e?.message, variant: "destructive" });
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="flex flex-col h-full">
      <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.length === 0 && (
          <div className="text-center py-10">
            <MessageSquare className="w-8 h-8 text-trident-text/20 mx-auto mb-2" />
            <p className="font-mono text-[10px] uppercase tracking-widest text-trident-text/40">
              INTERROGATE THE INTELLIGENCE
            </p>
            <p className="font-mono text-[9px] uppercase tracking-widest text-trident-text/25 mt-1">
              ASK ABOUT FILES IN {topic.name}
            </p>
          </div>
        )}
        {messages.map((m, i) => (
          <div key={i} className={m.role === "user" ? "flex justify-end" : "flex justify-start"} data-testid={`msg-${m.role}-${i}`}>
            <div className={`max-w-[80%] border p-3 ${
              m.role === "user"
                ? "border-trident-cyan/40 bg-trident-cyan/8"
                : "border-[#00ff41]/30 bg-[#00ff41]/5"
            }`}>
              {m.role === "assistant" && (
                <div className="font-mono text-[9px] uppercase tracking-widest text-[#00ff41] mb-1.5">
                  TRIDENT ANALYST:
                </div>
              )}
              <pre className="font-mono text-[11px] text-trident-text/85 whitespace-pre-wrap leading-relaxed">{m.content}</pre>
              {m.docs && m.docs.length > 0 && (
                <div className="mt-2 pt-2 border-t border-trident-border/40 font-mono text-[8px] uppercase tracking-widest text-trident-text/40">
                  CONTEXT: {m.docs.join(", ")}
                </div>
              )}
            </div>
          </div>
        ))}
        {sending && (
          <div className="flex justify-start">
            <div className="border border-[#00ff41]/30 bg-[#00ff41]/5 p-3 flex items-center gap-2">
              <Loader2 className="w-3.5 h-3.5 animate-spin text-[#00ff41]" />
              <span className="font-mono text-[10px] uppercase tracking-widest text-[#00ff41]/70">ANALYZING...</span>
            </div>
          </div>
        )}
      </div>

      <div className="border-t border-trident-border p-3 flex items-center gap-2">
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => { if (e.key === "Enter") send(); }}
          placeholder="ASK ABOUT THIS INTELLIGENCE..."
          disabled={sending}
          className="flex-1 bg-[#050a0e] border border-trident-border text-trident-text font-mono text-[11px] uppercase tracking-wider px-3 py-2 focus:border-trident-cyan outline-none placeholder:text-trident-text/25"
          data-testid="input-chat"
        />
        <button
          onClick={send}
          disabled={sending || !input.trim()}
          className="flex items-center gap-1.5 px-4 py-2 text-[10px] font-mono uppercase tracking-widest text-trident-cyan border border-trident-cyan/50 hover:bg-trident-cyan/10 disabled:opacity-40 transition-all"
          data-testid="button-send-chat"
        >
          <Send className="w-3.5 h-3.5" /> SEND
        </button>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════
// FEED PANEL
// ═══════════════════════════════════════════════════
function FeedPanel({ feed }: { feed: WebFeed }) {
  const { toast } = useToast();
  const qc = useQueryClient();
  const [brief, setBrief] = useState<{ content: string; title: string } | null>(null);
  const [viewing, setViewing] = useState<IntelBrief | null>(null);

  const { data: briefsData } = useQuery<{ briefs: IntelBrief[] }>({
    queryKey: ["/api/intel/feeds", feed.id, "briefs"],
    queryFn: async () => {
      const res = await fetch(`${API_BASE}/api/intel/feeds/${feed.id}/briefs`, { headers: getAuthHeaders() });
      if (!res.ok) throw new Error("feed briefs failed");
      return res.json();
    },
    staleTime: 0,
  });
  const briefs = briefsData?.briefs || [];

  const fetchAnalyze = useMutation({
    mutationFn: async () => {
      const res = await fetch(`${API_BASE}/api/intel/feeds/${feed.id}/fetch`, {
        method: "POST",
        headers: getAuthHeaders(),
      });
      if (!res.ok) throw new Error((await res.json())?.error || "FETCH FAILED");
      return res.json();
    },
    onSuccess: (d) => {
      setBrief({ content: d.content, title: d.title });
      setViewing(null);
      qc.invalidateQueries({ queryKey: ["/api/intel/feeds", feed.id, "briefs"] });
      qc.invalidateQueries({ queryKey: ["/api/intel/feeds"] });
      toast({ title: "FEED ANALYZED", description: `${d.fetched_length} CHARS FETCHED` });
    },
    onError: (e: any) => toast({ title: "FETCH FAILED", description: e?.message, variant: "destructive" }),
  });

  const remove = useMutation({
    mutationFn: async () => {
      const res = await fetch(`${API_BASE}/api/intel/feeds/${feed.id}`, {
        method: "DELETE",
        headers: getAuthHeaders(),
      });
      if (!res.ok) throw new Error("DELETE FAILED");
      return res.json();
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["/api/intel/feeds"] });
      toast({ title: "FEED REMOVED" });
    },
  });

  const shown = viewing ? { content: viewing.content, title: viewing.title } : brief;

  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center justify-between px-4 py-3 border-b border-trident-border">
        <div className="flex items-center gap-2 min-w-0">
          <Radio className="w-4 h-4 text-[#00ff41] flex-shrink-0" />
          <div className="min-w-0">
            <div className="font-mono text-sm uppercase tracking-widest text-[#00ff41] truncate">{feed.name}</div>
            <div className="font-mono text-[9px] text-trident-text/50 truncate">{feed.url}</div>
          </div>
        </div>
        <div className="flex items-center gap-2 flex-shrink-0">
          <span className="inline-block px-1.5 py-0.5 text-[8px] font-mono uppercase tracking-widest border border-trident-cyan/40 text-trident-cyan">
            {feed.category}
          </span>
          <span className="font-mono text-[9px] uppercase tracking-widest text-trident-text/40">
            <Clock className="w-2.5 h-2.5 inline mr-1" />{relTime(feed.lastFetched)}
          </span>
          <button
            onClick={() => remove.mutate()}
            className="text-trident-red/60 hover:text-trident-red transition-colors"
            data-testid="button-remove-feed"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      <div className="px-4 py-3 border-b border-trident-border">
        <button
          onClick={() => fetchAnalyze.mutate()}
          disabled={fetchAnalyze.isPending}
          className="w-full flex items-center justify-center gap-2 px-4 py-2 text-[11px] font-mono uppercase tracking-widest text-trident-amber border border-trident-amber/50 hover:bg-trident-amber/10 disabled:opacity-40 transition-all"
          data-testid="button-fetch-analyze"
        >
          {fetchAnalyze.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <RefreshCw className="w-4 h-4" />}
          {fetchAnalyze.isPending ? ">> FETCHING & ANALYZING SOURCE..." : "FETCH & ANALYZE"}
        </button>
      </div>

      <div className="flex flex-1 overflow-hidden">
        <div className="flex-1 overflow-y-auto p-4">
          {shown ? (
            <div>
              <div className="font-mono text-[11px] uppercase tracking-widest text-[#00ff41] mb-3">{shown.title}</div>
              <div className="border border-trident-border bg-[#050a0e]/60 p-4">
                <pre className="font-mono text-[11px] text-trident-text/85 whitespace-pre-wrap leading-relaxed" data-testid="text-feed-brief">
                  {shown.content}
                </pre>
              </div>
            </div>
          ) : (
            <div className="text-center py-10">
              <Globe className="w-8 h-8 text-trident-text/20 mx-auto mb-2" />
              <p className="font-mono text-[10px] uppercase tracking-widest text-trident-text/40">
                NO BRIEF YET — FETCH TO ANALYZE
              </p>
            </div>
          )}
        </div>

        <div className="w-52 flex-shrink-0 border-l border-trident-border overflow-y-auto">
          <div className="px-3 py-2.5 border-b border-trident-border font-mono text-[9px] uppercase tracking-widest text-[#00ff41]">
            FEED HISTORY
          </div>
          <div className="p-2 space-y-1.5">
            {briefs.length === 0 ? (
              <p className="font-mono text-[9px] uppercase tracking-widest text-trident-text/30 p-2 text-center">NONE</p>
            ) : (
              briefs.map((b) => (
                <button
                  key={b.id}
                  onClick={() => { setViewing(b); setBrief(null); }}
                  className="w-full text-left border border-trident-border p-2 hover:border-[#00ff41]/40 hover:bg-[#00ff41]/5 transition-all"
                  data-testid={`history-feed-brief-${b.id}`}
                >
                  <div className="font-mono text-[9px] uppercase tracking-wider text-trident-text/70 truncate">{b.title}</div>
                  <div className="text-[8px] font-mono text-trident-text/40 mt-1">{(b.createdAt || "").slice(0, 10)}</div>
                </button>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════
// MODALS
// ═══════════════════════════════════════════════════
function NewTopicModal({ onClose }: { onClose: () => void }) {
  const { toast } = useToast();
  const qc = useQueryClient();
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [classification, setClassification] = useState("UNCLASSIFIED");

  const create = useMutation({
    mutationFn: async () => {
      const res = await fetch(`${API_BASE}/api/intel/topics`, {
        method: "POST",
        headers: { "Content-Type": "application/json", ...getAuthHeaders() },
        body: JSON.stringify({ name, description, classification }),
      });
      if (!res.ok) throw new Error((await res.json())?.error || "CREATE FAILED");
      return res.json();
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["/api/intel/topics"] });
      toast({ title: "TOPIC CREATED", description: "NAS FOLDER PROVISIONED" });
      onClose();
    },
    onError: (e: any) => toast({ title: "CREATE FAILED", description: e?.message, variant: "destructive" }),
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70" onClick={onClose}>
      <div
        className="w-[440px] border border-trident-cyan/40 bg-[#0a1628]"
        style={{ boxShadow: "0 0 30px #00f0ff30" }}
        onClick={(e) => e.stopPropagation()}
        data-testid="modal-new-topic"
      >
        <div className="flex items-center justify-between px-4 py-3 border-b border-trident-border">
          <div className="flex items-center gap-2">
            <Folder className="w-4 h-4 text-trident-cyan" />
            <span className="font-mono text-xs uppercase tracking-widest text-trident-cyan">CREATE INTEL TOPIC</span>
          </div>
          <button onClick={onClose} className="text-trident-text/40 hover:text-trident-red"><X className="w-4 h-4" /></button>
        </div>
        <div className="p-4 space-y-3">
          <div>
            <label className="block font-mono text-[9px] uppercase tracking-widest text-trident-text/50 mb-1">TOPIC NAME</label>
            <input
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="E.G. UKRAINE-CONFLICT"
              className="w-full bg-[#050a0e] border border-trident-border text-trident-text font-mono text-[11px] uppercase tracking-wider px-3 py-2 focus:border-trident-cyan outline-none placeholder:text-trident-text/25"
              data-testid="input-topic-name"
            />
          </div>
          <div>
            <label className="block font-mono text-[9px] uppercase tracking-widest text-trident-text/50 mb-1">DESCRIPTION</label>
            <input
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="OPTIONAL"
              className="w-full bg-[#050a0e] border border-trident-border text-trident-text font-mono text-[11px] tracking-wider px-3 py-2 focus:border-trident-cyan outline-none placeholder:text-trident-text/25"
              data-testid="input-topic-description"
            />
          </div>
          <div>
            <label className="block font-mono text-[9px] uppercase tracking-widest text-trident-text/50 mb-1">CLASSIFICATION</label>
            <select
              value={classification}
              onChange={(e) => setClassification(e.target.value)}
              className="w-full bg-[#050a0e] border border-trident-border text-trident-cyan font-mono text-[11px] uppercase tracking-widest px-3 py-2 focus:border-trident-cyan outline-none"
              data-testid="select-topic-classification"
            >
              {CLASSIFICATIONS.map((c) => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>
        </div>
        <div className="flex items-center justify-end gap-2 px-4 py-3 border-t border-trident-border">
          <button onClick={onClose} className="px-4 py-1.5 text-[10px] font-mono uppercase tracking-widest text-trident-text/60 border border-trident-border hover:bg-white/5">CANCEL</button>
          <button
            onClick={() => create.mutate()}
            disabled={create.isPending || !name.trim()}
            className="flex items-center gap-1.5 px-4 py-1.5 text-[10px] font-mono uppercase tracking-widest text-trident-cyan border border-trident-cyan/50 hover:bg-trident-cyan/10 disabled:opacity-40"
            data-testid="button-create-topic-confirm"
          >
            {create.isPending ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Plus className="w-3.5 h-3.5" />}
            CREATE TOPIC
          </button>
        </div>
      </div>
    </div>
  );
}

function AddFeedModal({ onClose }: { onClose: () => void }) {
  const { toast } = useToast();
  const qc = useQueryClient();
  const [name, setName] = useState("");
  const [url, setUrl] = useState("");
  const [category, setCategory] = useState("GENERAL");

  const create = useMutation({
    mutationFn: async () => {
      const res = await fetch(`${API_BASE}/api/intel/feeds`, {
        method: "POST",
        headers: { "Content-Type": "application/json", ...getAuthHeaders() },
        body: JSON.stringify({ name, url, category }),
      });
      if (!res.ok) throw new Error((await res.json())?.error || "ADD FAILED");
      return res.json();
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["/api/intel/feeds"] });
      toast({ title: "FEED ADDED" });
      onClose();
    },
    onError: (e: any) => toast({ title: "ADD FAILED", description: e?.message, variant: "destructive" }),
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70" onClick={onClose}>
      <div
        className="w-[440px] border border-[#00ff41]/40 bg-[#0a1628]"
        style={{ boxShadow: "0 0 30px #00ff4130" }}
        onClick={(e) => e.stopPropagation()}
        data-testid="modal-add-feed"
      >
        <div className="flex items-center justify-between px-4 py-3 border-b border-trident-border">
          <div className="flex items-center gap-2">
            <Rss className="w-4 h-4 text-[#00ff41]" />
            <span className="font-mono text-xs uppercase tracking-widest text-[#00ff41]">ADD WEB INTEL FEED</span>
          </div>
          <button onClick={onClose} className="text-trident-text/40 hover:text-trident-red"><X className="w-4 h-4" /></button>
        </div>
        <div className="p-4 space-y-3">
          <div>
            <label className="block font-mono text-[9px] uppercase tracking-widest text-trident-text/50 mb-1">NAME</label>
            <input
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="E.G. DEFENSE NEWS"
              className="w-full bg-[#050a0e] border border-trident-border text-trident-text font-mono text-[11px] uppercase tracking-wider px-3 py-2 focus:border-[#00ff41] outline-none placeholder:text-trident-text/25"
              data-testid="input-feed-name"
            />
          </div>
          <div>
            <label className="block font-mono text-[9px] uppercase tracking-widest text-trident-text/50 mb-1">URL</label>
            <input
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              placeholder="https://..."
              className="w-full bg-[#050a0e] border border-trident-border text-trident-text font-mono text-[11px] tracking-wider px-3 py-2 focus:border-[#00ff41] outline-none placeholder:text-trident-text/25"
              data-testid="input-feed-url"
            />
          </div>
          <div>
            <label className="block font-mono text-[9px] uppercase tracking-widest text-trident-text/50 mb-1">CATEGORY</label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="w-full bg-[#050a0e] border border-trident-border text-[#00ff41] font-mono text-[11px] uppercase tracking-widest px-3 py-2 focus:border-[#00ff41] outline-none"
              data-testid="select-feed-category"
            >
              {FEED_CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>
        </div>
        <div className="flex items-center justify-end gap-2 px-4 py-3 border-t border-trident-border">
          <button onClick={onClose} className="px-4 py-1.5 text-[10px] font-mono uppercase tracking-widest text-trident-text/60 border border-trident-border hover:bg-white/5">CANCEL</button>
          <button
            onClick={() => create.mutate()}
            disabled={create.isPending || !name.trim() || !url.trim()}
            className="flex items-center gap-1.5 px-4 py-1.5 text-[10px] font-mono uppercase tracking-widest text-[#00ff41] border border-[#00ff41]/50 hover:bg-[#00ff41]/10 disabled:opacity-40"
            data-testid="button-add-feed-confirm"
          >
            {create.isPending ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Plus className="w-3.5 h-3.5" />}
            ADD FEED
          </button>
        </div>
      </div>
    </div>
  );
}
