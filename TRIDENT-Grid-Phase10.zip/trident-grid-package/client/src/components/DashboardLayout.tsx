import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { TridentLogo } from "./TridentLogo";
import { useAuth } from "@/hooks/use-auth";
import {
  MessageSquare,
  Box,
  Image,
  Mic,
  GalleryHorizontalEnd,
  Settings,
  LogOut,
  ChevronLeft,
  ChevronRight,
  Shield,
  Users,
  Wrench,
  TrendingUp,
  Network,
} from "lucide-react";

interface NavItem {
  label: string;
  path: string;
  icon: React.ComponentType<{ className?: string }>;
  adminOnly?: boolean;
}

const navItems: NavItem[] = [
  { label: "CHAT", path: "/dashboard", icon: MessageSquare },
  { label: "MODELS", path: "/dashboard/models", icon: Box },
  { label: "IMAGE GEN", path: "/dashboard/imagegen", icon: Image },
  { label: "VOICE", path: "/dashboard/voice", icon: Mic },
  { label: "GALLERY", path: "/dashboard/gallery", icon: GalleryHorizontalEnd },
  { label: "TOOLS", path: "/dashboard/tools", icon: Wrench },
  { label: "INTELLIGENCE", path: "/dashboard/intelligence", icon: TrendingUp },
  { label: "INTEL BRIEFS", path: "/intel-briefs", icon: Shield },
  { label: "GRID", path: "/grid", icon: Network },
  { label: "SETTINGS", path: "/dashboard/settings", icon: Settings },
  { label: "PERSONNEL", path: "/admin/users", icon: Users, adminOnly: true },
];

export function DashboardLayout({ children }: { children: React.ReactNode }) {
  const [collapsed, setCollapsed] = useState(false);
  const [location] = useLocation();
  const { user, logout } = useAuth();
  const [, setLocation] = useLocation();
  const [clock, setClock] = useState("");

  // Live clock
  useEffect(() => {
    const tick = () => {
      const now = new Date();
      setClock(
        now.toLocaleTimeString("en-US", {
          hour12: false,
          hour: "2-digit",
          minute: "2-digit",
          second: "2-digit",
          timeZone: "America/New_York",
        })
      );
    };
    tick();
    const interval = setInterval(tick, 1000);
    return () => clearInterval(interval);
  }, []);

  const handleLogout = () => {
    logout();
    setLocation("/login");
  };

  const roleBadgeColor = {
    admin: "text-trident-amber border-trident-amber/40 bg-trident-amber/10",
    power_user: "text-trident-cyan border-trident-cyan/40 bg-trident-cyan/10",
    user: "text-trident-green border-[#00ff41]/40 bg-[#00ff41]/10",
  };

  return (
    <div className="h-screen flex overflow-hidden" style={{ backgroundColor: "#050a0e" }}>
      {/* ═══════════ SIDEBAR ═══════════ */}
      <aside
        className={`relative flex flex-col border-r border-trident-border scanlines transition-all duration-300 ${
          collapsed ? "w-16" : "w-60"
        }`}
        style={{ backgroundColor: "#0a1628" }}
        data-testid="sidebar"
      >
        {/* Logo area */}
        <div className="flex items-center justify-between px-3 py-4 border-b border-trident-border">
          {!collapsed && <TridentLogo size="sm" showText={true} />}
          {collapsed && <TridentLogo size="sm" showText={false} />}
          <button
            onClick={() => setCollapsed(!collapsed)}
            className="text-trident-cyan/50 hover:text-trident-cyan transition-colors p-1"
            data-testid="button-collapse-sidebar"
          >
            {collapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
          </button>
        </div>

        {/* Nav items */}
        <nav className="flex-1 py-3 space-y-1 px-2 relative z-10">
          {navItems
            .filter((item) => !item.adminOnly || user?.role === "admin")
            .map((item) => {
              const isActive = location === item.path || 
                (item.path !== "/dashboard" && location.startsWith(item.path));
              const Icon = item.icon;

              return (
                <Link key={item.path} href={item.path}>
                  <div
                    className={`flex items-center gap-3 px-3 py-2.5 text-xs font-mono uppercase tracking-widest cursor-pointer transition-all group ${
                      isActive
                        ? "text-trident-cyan border-l-[3px] border-trident-amber bg-trident-cyan/8"
                        : "text-trident-text/60 hover:text-trident-cyan hover:bg-trident-cyan/5 border-l-2 border-transparent"
                    }`}
                    style={isActive ? { textShadow: "0 0 8px #00f0ff, 0 0 16px #00f0ff50" } : undefined}
                    data-testid={`nav-${item.label.toLowerCase().replace(/\s/g, "-")}`}
                  >
                    <Icon className={`w-4 h-4 flex-shrink-0 ${isActive ? "text-trident-cyan" : "text-trident-text/40 group-hover:text-trident-cyan"}`} />
                    {!collapsed && <span>{item.label}</span>}
                  </div>
                </Link>
              );
            })}
        </nav>

        {/* User info + Logout at bottom */}
        <div className="border-t border-trident-border p-3 relative z-10">
          {!collapsed && user && (
            <div className="mb-3">
              <div className="flex items-center gap-2">
                <Shield className="w-3 h-3 text-trident-cyan/60" />
                <span className="text-xs font-mono uppercase tracking-widest text-trident-text truncate">
                  {user.username}
                </span>
              </div>
              <span
                className={`inline-block mt-1 px-1.5 py-0.5 text-[9px] font-mono uppercase tracking-widest border ${
                  roleBadgeColor[user.role as keyof typeof roleBadgeColor] || roleBadgeColor.user
                }`}
              >
                {user.role}
              </span>
            </div>
          )}
          <button
            onClick={handleLogout}
            className="flex items-center gap-2 w-full px-2 py-2 text-xs font-mono uppercase tracking-widest text-trident-red/70 hover:text-trident-red hover:bg-trident-red/5 transition-all"
            data-testid="button-logout"
          >
            <LogOut className="w-4 h-4" />
            {!collapsed && "LOGOUT"}
          </button>
        </div>
      </aside>

      {/* ═══════════ MAIN CONTENT ═══════════ */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Top header bar */}
        <header
          className="flex items-center justify-between px-4 py-2.5 border-b border-trident-border scanlines relative"
          style={{ backgroundColor: "#0a1628" }}
          data-testid="header"
        >
          <div className="font-display text-xs tracking-[0.15em] text-trident-cyan text-glow-cyan relative z-10">
            TRIDENT SYSTEM
          </div>

          {/* Status strip */}
          <div className="flex items-center gap-3 font-mono text-[10px] uppercase tracking-widest relative z-10">
            <span className="text-[#00ff41] text-glow-green flex items-center gap-1.5">
              <span className="inline-block w-1.5 h-1.5 rounded-full bg-[#00ff41] animate-pulse" />
              SYSTEM ONLINE
            </span>
            <span className="text-trident-border">|</span>
            <span className="text-trident-text/70">
              USER: <span className="text-trident-cyan">{user?.username?.toUpperCase() || "UNKNOWN"}</span>
            </span>
            <span className="text-trident-border">|</span>
            <span className="text-trident-text/70">
              CLEARANCE: <span className="text-trident-amber">{user?.role?.toUpperCase() || "NONE"}</span>
            </span>
          </div>

          {/* Clock */}
          <div className="font-mono text-sm tracking-widest text-trident-cyan text-glow-cyan tabular-nums relative z-10" data-testid="text-clock">
            {clock}
          </div>
        </header>

        {/* Main content area */}
        <main className="flex-1 overflow-auto grid-bg p-4">
          {children}
        </main>

        {/* Attribution footer */}
        <footer className="border-t border-trident-border px-4 py-1.5 text-center" style={{ backgroundColor: "#0a1628" }}>
          <a
            href="https://www.perplexity.ai/computer"
            target="_blank"
            rel="noopener noreferrer"
            className="text-[9px] font-mono uppercase tracking-widest text-trident-border hover:text-trident-cyan/50 transition-colors"
          >
            Created with Perplexity Computer
          </a>
        </footer>
      </div>
    </div>
  );
}
