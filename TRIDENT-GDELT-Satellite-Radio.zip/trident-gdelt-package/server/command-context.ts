import * as fs from "fs";
import * as path from "path";
import { execSync } from "child_process";

async function safeFetch(url: string, ms = 4000): Promise<any> {
  try { const r = await fetch(url, { signal: AbortSignal.timeout(ms) }); return r.ok ? r.json() : null; }
  catch { return null; }
}

export function classifyIntent(msg: string): string[] {
  const m = msg.toLowerCase();
  const out: string[] = [];
  if (/flight|aircraft|plane|fly|overhead|airspace|callsign|aviation/.test(m)) out.push("flights");
  if (/weather|rain|wind|temp|forecast|storm|alert|humidity|noaa/.test(m)) out.push("weather");
  if (/market|stock|price|spy|btc|bitcoin|crypto|nasdaq|bond|gold|oil/.test(m)) out.push("markets");
  if (/geo|conflict|military|war|threat|attack|fatali|defense|geopolit/.test(m)) out.push("geo");
  if (/system|cpu|ram|memory|disk|service|health|uptime|load/.test(m)) out.push("system");
  if (/grid|worker|node|dispatch|compute/.test(m)) out.push("grid");
  if (/brief|report|summary|archive|yesterday|morning|s2|defense.*news|war.*rocks|foreign|intel.*feed|web.*intel|site|article|headline/.test(m)) out.push("briefs");
  if (out.length === 0) out.push("general");
  return out;
}

export async function fetchIntelContext(intents: string[], watchlistSymbols?: string[]): Promise<string> {
  const all = intents.includes("general");
  const parts: string[] = [];

  if (all || intents.includes("flights")) {
    // Live overhead aircraft
    const live = await safeFetch("http://localhost:5004/aircraft");
    if (live) {
      const ac = (live.aircraft || []).slice(0, 8);
      parts.push(ac.length > 0
        ? `LIVE AIRSPACE (${ac.length} overhead now): ` + ac.map((a: any) =>
            `${(a.callsign||"?").trim()} ${Math.round((a.altitude_m||0)*3.28084)}ft ${a.velocity_kts||Math.round((a.velocity_ms||0)*1.94384)}kts ${a.distance_nm}nm ${a.origin_country||""}`
          ).join(" | ")
        : "LIVE AIRSPACE: No aircraft overhead at this time");
    }
    // Recent flight history stats
    const stats = await safeFetch("http://localhost:5004/stats");
    if (stats) {
      parts.push(`AVIATION STATS: ${stats.today_count||0} flights today, ${stats.total_flights_recorded||0} total recorded. Max altitude: ${stats.max_altitude_ft||0}ft. Top callsigns: ${(stats.top_callsigns||[]).slice(0,5).map((c: any)=>c.callsign).join(", ")||"none"}`);
    }
    // Recent history (last 10)
    const hist = await safeFetch("http://localhost:5004/history?limit=10");
    if (hist?.flights?.length) {
      const recent = hist.flights.slice(0,5).map((f: any) =>
        `${(f.callsign||"?").trim()} ${Math.round((f.altitude_m||0)*3.28084)}ft seen ${f.last_seen?.slice(11,16)||"?"} UTC`
      ).join(" | ");
      parts.push(`RECENT FLIGHTS (last recorded): ${recent}`);
    }
  }

  if (all || intents.includes("weather")) {
    const d = await safeFetch("http://localhost:5005/current");
    if (d) parts.push(`WEATHER: ${d.condition} ${d.temperature_f}°F feels ${d.feels_like_f}°F wind ${d.wind_speed_mph}mph humidity ${d.humidity_pct}%`);
    const alerts = await safeFetch("http://localhost:5005/alerts");
    if (alerts?.alerts?.length) parts.push(`NOAA ALERTS (${alerts.alerts.length}): ${alerts.alerts[0].headline}`);
  }

  if (all || intents.includes("markets")) {
    // Fetch market overview (indices, crypto, commodities)
    const overview = await safeFetch("http://localhost:5002/market-overview");
    if (overview) {
      const idx = (overview.indices||[]).slice(0,4).map((i: any) => `${i.symbol} ${i.price} (${i.change_pct>0?'+':''}${i.change_pct}%)`).join(", ");
      const crypto = (overview.crypto||[]).slice(0,3).map((c: any) => `${c.symbol} $${c.price?.toLocaleString()} (${c.change_pct>0?'+':''}${c.change_pct}%)`).join(", ");
      const commodities = (overview.commodities||[]).slice(0,3).map((c: any) => `${c.symbol} ${c.price} (${c.change_pct>0?'+':''}${c.change_pct}%)`).join(", ");
      if (idx) parts.push(`MARKET INDICES: ${idx}`);
      if (crypto) parts.push(`CRYPTO: ${crypto}`);
      if (commodities) parts.push(`COMMODITIES: ${commodities}`);
    }
    // Fetch user's personal watchlist if symbols provided
    if (watchlistSymbols && watchlistSymbols.length > 0) {
      const symbols = watchlistSymbols.join(",");
      const quotes = await safeFetch(`http://localhost:5002/quotes?symbols=${encodeURIComponent(symbols)}`);
      if (quotes?.quotes?.length) {
        const watchlistStr = quotes.quotes.map((q: any) =>
          `${q.symbol} $${q.price} (${q.change_pct>0?'+':''}${q.change_pct}%)`
        ).join(", ");
        parts.push(`YOUR WATCHLIST: ${watchlistStr}`);
      }
    }
  }

  if (all || intents.includes("system")) {
    try {
      const mem = fs.readFileSync("/proc/meminfo","utf8");
      const total = parseInt((mem.match(/MemTotal:\s+(\d+)/)||[])[1]||"0")*1024;
      const avail = parseInt((mem.match(/MemAvailable:\s+(\d+)/)||[])[1]||"0")*1024;
      const pct = Math.round((1-avail/total)*100);
      const load = fs.readFileSync("/proc/loadavg","utf8").split(" ").slice(0,3).join("/");
      let gpu = "";
      try { const g = execSync("nvidia-smi --query-gpu=utilization.gpu,memory.used,memory.total,temperature.gpu --format=csv,noheader,nounits",{timeout:2000}).toString().trim().split(","); gpu = ` GPU:${g[0].trim()}% VRAM:${Math.round(+g[1]/1024*10)/10}/${Math.round(+g[2]/1024*10)/10}GB ${g[3].trim()}°C`; } catch {}
      parts.push(`SYSTEM: RAM ${pct}% load ${load}${gpu}`);
    } catch {}
  }

  if (all || intents.includes("grid")) {
    const d = await safeFetch("http://localhost:5007/nodes");
    if (d) {
      const on = (d.nodes||[]).filter((n: any) => n.status==="online");
      parts.push(`GRID: ${on.length}/${d.nodes?.length||0} nodes online${on.length ? ". "+on.map((n: any)=>`${n.name} cpu:${n.last_metrics?.cpu_pct||0}% score:${n.dispatch_score}`).join(", ") : ""}`);
    }
  }

  if (intents.includes("briefs") || all) {
    try {
      const base = "/mnt/trident-briefs";
      const summaries: string[] = [];

      // 1. Standard brief folders
      const briefDirs = ["weather","markets","geo-intel","aviation"];
      for (const d of briefDirs) {
        const p = path.join(base, d);
        if (fs.existsSync(p)) {
          const files = fs.readdirSync(p).filter(f=>f.endsWith(".md")).sort().reverse();
          if (files.length) {
            try {
              const content = fs.readFileSync(path.join(p, files[0]), "utf8");
              // Extract content between first and second separator lines
              const sep = "=".repeat(20);
              const firstSep = content.indexOf(sep);
              const secondSep = firstSep > -1 ? content.indexOf(sep, firstSep + sep.length) : -1;
              let body: string;
              if (firstSep > -1 && secondSep > -1) {
                // Content is between the two separators
                body = content.slice(firstSep + sep.length, secondSep).trim();
              } else if (firstSep > -1) {
                body = content.slice(firstSep + sep.length).trim();
              } else {
                // No separators — skip header lines (first 5 lines)
                body = content.split("\n").slice(5).join("\n").trim();
              }
              summaries.push(`--- ${d.toUpperCase()} BRIEF (${files[0]}) ---\n${body.slice(0, 600).trim()}`);
            } catch { summaries.push(`${d.toUpperCase()}: ${files[0]}`); }
          }
        }
      }

      // 2. Web intel archives — scan _web-intel subfolders
      const webIntelBase = path.join(base, "_web-intel");
      if (fs.existsSync(webIntelBase)) {
        const feedFolders = fs.readdirSync(webIntelBase).filter(f => {
          try { return fs.statSync(path.join(webIntelBase, f)).isDirectory(); } catch { return false; }
        });
        for (const feed of feedFolders) {
          const feedPath = path.join(webIntelBase, feed);
          const files = fs.readdirSync(feedPath).filter(f=>f.endsWith(".md")).sort().reverse();
          if (files.length) {
            try {
              const content = fs.readFileSync(path.join(feedPath, files[0]), "utf8");
              // Web intel archives: content after the first === separator
              const sep = "=".repeat(20);
              const firstSep = content.indexOf(sep);
              const secondSep = firstSep > -1 ? content.indexOf(sep, firstSep + sep.length) : -1;
              let body: string;
              if (firstSep > -1 && secondSep > -1) {
                body = content.slice(firstSep + sep.length, secondSep).trim();
              } else if (firstSep > -1) {
                body = content.slice(firstSep + sep.length).trim();
              } else {
                body = content.split("\n").slice(4).join("\n").trim();
              }
              const snippet = body.slice(0, 600).replace(/\n{3,}/g, "\n\n").trim();
              summaries.push(`--- WEB INTEL: ${feed.toUpperCase()} (${files[0]}) ---\n${snippet}`);
            } catch { summaries.push(`WEB INTEL: ${feed} — ${files[0]}`); }
          }
        }
      }

      if (summaries.length) parts.push("INTEL BRIEFS & WEB ARCHIVES:\n" + summaries.join("\n\n"));
    } catch {}
  }

  return parts.join("\n");
}

export async function shouldOffloadToGrid(): Promise<{offload:boolean,nodeUrl?:string}> {
  try {
    const g = execSync("nvidia-smi --query-gpu=utilization.gpu,memory.used,memory.total --format=csv,noheader,nounits",{timeout:2000}).toString().trim().split(",");
    if (+g[0] > 70 || +g[1]/+g[2]*100 > 80) {
      const nodes = await safeFetch("http://localhost:5007/nodes", 3000);
      const eligible = (nodes?.nodes||[]).filter((n:any)=>n.status==="online" && n.tags?.includes("OLLAMA")).sort((a:any,b:any)=>a.dispatch_score-b.dispatch_score);
      if (eligible.length) return { offload: true, nodeUrl: `http://${eligible[0].ip}:11434` };
    }
  } catch {}
  return { offload: false };
}

/**
 * Returns the best Ollama endpoint for background/batch work (brief generation,
 * summarization, etc). Unlike shouldOffloadToGrid (which only reacts to local
 * GPU overload for interactive COMMAND queries), this ALWAYS prefers an
 * available GPU worker node to keep the main TRIDENT server free for the UI,
 * voice, and real-time COMMAND traffic. Falls back to local Ollama if no
 * worker is online or reachable.
 */
export async function getBackgroundOllamaUrl(preferredModel?: string): Promise<{ url: string; node: string }> {
  try {
    const nodes = await safeFetch("http://localhost:5007/nodes", 3000);
    const eligible = (nodes?.nodes || [])
      .filter((n: any) => n.status === "online" && (n.tags || []).includes("OLLAMA"))
      .sort((a: any, b: any) => a.dispatch_score - b.dispatch_score);

    if (eligible.length > 0) {
      // Prefer a node that already has the requested model pulled
      let best = eligible[0];
      if (preferredModel) {
        const withModel = eligible.find((n: any) =>
          (n.capabilities?.ollama_models || []).some((m: string) => m.includes(preferredModel))
        );
        if (withModel) best = withModel;
      }
      return { url: `http://${best.ip}:11434`, node: best.name || best.node_id };
    }
  } catch {}
  return { url: "http://localhost:11434", node: "local" };
}
