import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { requireAuth, requireAdmin, generateToken } from "./middleware/auth";
import bcrypt from "bcryptjs";
import { z } from "zod";
import multer from "multer";
import http from "http";
import https from "https";
import * as fs from "fs";
import * as path from "path";
import crypto from "crypto";
import os from "os";
import dns from "dns";
import net from "net";
import { exec, execSync } from "child_process";
import { promisify } from "util";
import { startScheduler, scheduleTask, unscheduleTask, executeTask, setToolExecutor } from "./scheduler";
import type { ScheduledTask } from "@shared/schema";
import { classifyIntent, fetchIntelContext, shouldOffloadToGrid } from "./command-context";

const execAsync = promisify(exec);

// Validation schemas
const registerSchema = z.object({
  username: z.string().min(3).max(32),
  email: z.string().email(),
  password: z.string().min(8),
});

const loginSchema = z.object({
  email: z.string().email(),
  password: z.string(),
});

const updateUserSchema = z.object({
  role: z.enum(["admin", "power_user", "user"]).optional(),
  is_active: z.boolean().optional(),
});

const updateSettingsSchema = z.object({
  username: z.string().min(3).max(32).optional(),
  email: z.string().email().optional(),
  current_password: z.string().optional(),
  new_password: z.string().min(8).optional(),
});


// ═══════════════════════════════════════════════════
// OPSCENTER — SYSTEM VITALS HELPERS (Phase 11)
// ═══════════════════════════════════════════════════

const TRIDENT_SERVICES = [
  { name: "trident", label: "TRIDENT CORE", port: 5000 },
  { name: "ollama", label: "OLLAMA LLM", port: 11434 },
  { name: "trident-voice", label: "VOICE (WHISPER/PIPER)", port: 5001 },
  { name: "trident-markets", label: "MARKET INTELLIGENCE", port: 5002 },
  { name: "trident-geo", label: "GEO-INTELLIGENCE", port: 5003 },
  { name: "trident-flights", label: "FLIGHT INTELLIGENCE", port: 5004 },
  { name: "trident-weather", label: "WEATHER INTELLIGENCE", port: 5005 },
  { name: "trident-briefs", label: "BRIEF INTELLIGENCE", port: 5006 },
  { name: "trident-grid", label: "GRID COORDINATOR", port: 5007 },
  { name: "trident-imagegen", label: "IMAGE GENERATION", port: 7860 },
  { name: "nginx", label: "NGINX PROXY", port: 443 },
];

function getCpuPct(): number {
  try {
    const readStat = () =>
      fs.readFileSync("/proc/stat", "utf8").split("\n")[0].split(/\s+/).slice(1).map(Number);
    const stat1 = readStat();
    const start = Date.now();
    while (Date.now() - start < 100) {} // busy wait ~100ms
    const stat2 = readStat();
    const idle1 = stat1[3], idle2 = stat2[3];
    const total1 = stat1.reduce((a, b) => a + b, 0);
    const total2 = stat2.reduce((a, b) => a + b, 0);
    const idleDelta = idle2 - idle1;
    const totalDelta = total2 - total1;
    if (totalDelta <= 0) return 0;
    return Math.max(0, Math.min(100, Math.round((1 - idleDelta / totalDelta) * 100)));
  } catch { return 0; }
}

function getCpuCores(): number {
  try {
    const cpuinfo = fs.readFileSync("/proc/cpuinfo", "utf8");
    return (cpuinfo.match(/^processor\s*:/gm) || []).length || 1;
  } catch { return 1; }
}

function getMemInfo(): { used_gb: number; total_gb: number; pct: number; swap_used_gb: number; swap_total_gb: number } {
  try {
    const meminfo = fs.readFileSync("/proc/meminfo", "utf8");
    const get = (key: string) => {
      const m = meminfo.match(new RegExp(`${key}:\\s+(\\d+)`));
      return m ? parseInt(m[1], 10) * 1024 : 0; // kB to bytes
    };
    const total = get("MemTotal");
    const available = get("MemAvailable");
    const used = total - available;
    const swapTotal = get("SwapTotal");
    const swapFree = get("SwapFree");
    return {
      used_gb: Math.round((used / (1024 ** 3)) * 10) / 10,
      total_gb: Math.round((total / (1024 ** 3)) * 10) / 10,
      pct: total > 0 ? Math.round((used / total) * 100) : 0,
      swap_used_gb: Math.round(((swapTotal - swapFree) / (1024 ** 3)) * 10) / 10,
      swap_total_gb: Math.round((swapTotal / (1024 ** 3)) * 10) / 10,
    };
  } catch { return { used_gb: 0, total_gb: 0, pct: 0, swap_used_gb: 0, swap_total_gb: 0 }; }
}

function getGpuInfo(): { gpu_pct: number; gpu_vram_used_gb: number; gpu_vram_total_gb: number; gpu_temp_c: number; gpu_name: string } {
  try {
    const out = execSync(
      "nvidia-smi --query-gpu=utilization.gpu,memory.used,memory.total,temperature.gpu,name --format=csv,noheader,nounits",
      { timeout: 3000 }
    ).toString().trim();
    const parts = out.split(",").map((s) => s.trim());
    return {
      gpu_pct: parseFloat(parts[0]) || 0,
      gpu_vram_used_gb: Math.round((parseFloat(parts[1]) / 1024) * 10) / 10,
      gpu_vram_total_gb: Math.round((parseFloat(parts[2]) / 1024) * 10) / 10,
      gpu_temp_c: parseFloat(parts[3]) || 0,
      gpu_name: parts[4] || "Unknown",
    };
  } catch { return { gpu_pct: 0, gpu_vram_used_gb: 0, gpu_vram_total_gb: 0, gpu_temp_c: 0, gpu_name: "N/A" }; }
}

function getDiskInfo(mountPath: string): { used_gb: number; total_gb: number; pct: number; available: boolean } {
  try {
    const out = execSync(`df -B1 ${mountPath} | tail -1`, { timeout: 3000 }).toString().trim();
    const parts = out.split(/\s+/);
    const total = parseInt(parts[1], 10);
    const used = parseInt(parts[2], 10);
    if (!total || Number.isNaN(total)) return { used_gb: 0, total_gb: 0, pct: 0, available: false };
    return {
      used_gb: Math.round((used / (1024 ** 3)) * 10) / 10,
      total_gb: Math.round((total / (1024 ** 3)) * 10) / 10,
      pct: Math.round((used / total) * 100),
      available: true,
    };
  } catch { return { used_gb: 0, total_gb: 0, pct: 0, available: false }; }
}

function getNetStats(): { rx_bytes: number; tx_bytes: number } {
  try {
    const netdev = fs.readFileSync("/proc/net/dev", "utf8");
    const lines = netdev.split("\n");
    for (const iface of ["ens18", "eth0", "ens3", "enp0s3"]) {
      const line = lines.find((l) => l.trim().startsWith(iface + ":") || l.trim().startsWith(iface));
      if (line) {
        const parts = line.replace(/:/g, " ").trim().split(/\s+/);
        // parts[0] = iface, parts[1] = rx bytes, parts[9] = tx bytes
        return { rx_bytes: parseInt(parts[1], 10) || 0, tx_bytes: parseInt(parts[9], 10) || 0 };
      }
    }
  } catch { /* fall through */ }
  return { rx_bytes: 0, tx_bytes: 0 };
}

function getUptimeSeconds(): number {
  try {
    return Math.round(parseFloat(fs.readFileSync("/proc/uptime", "utf8").split(/\s+/)[0]) || 0);
  } catch { return 0; }
}

function getLoadAvg(): { l1: number; l5: number; l15: number } {
  try {
    const parts = fs.readFileSync("/proc/loadavg", "utf8").trim().split(/\s+/);
    return {
      l1: parseFloat(parts[0]) || 0,
      l5: parseFloat(parts[1]) || 0,
      l15: parseFloat(parts[2]) || 0,
    };
  } catch { return { l1: 0, l5: 0, l15: 0 }; }
}

// Estimate VRAM (GB) from Ollama model parameter count / size
function estimateVram(paramStr: string, sizeBytes: number): string {
  const m = /([\d.]+)\s*([BM])/i.exec(paramStr || "");
  if (m) {
    const val = parseFloat(m[1]);
    const billions = m[2].toUpperCase() === "B" ? val : val / 1000;
    // ~0.85 GB per billion params at Q4 quantization
    return `~${Math.max(1, Math.round(billions * 0.85))}GB`;
  }
  if (sizeBytes > 0) return `~${Math.round((sizeBytes / (1024 ** 3)) * 1.1)}GB`;
  return "—";
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {

  // ═══════════════════════════════════════════════════
  // AUTH ROUTES
  // ═══════════════════════════════════════════════════

  // POST /api/auth/register — Create new user
  app.post("/api/auth/register", async (req, res) => {
    try {
      const data = registerSchema.parse(req.body);
      data.email = data.email.toLowerCase().trim();

      // Check uniqueness
      const existingEmail = await storage.getUserByEmail(data.email);
      if (existingEmail) {
        return res.status(409).json({ error: "EMAIL ALREADY REGISTERED" });
      }
      const existingUsername = await storage.getUserByUsername(data.username);
      if (existingUsername) {
        return res.status(409).json({ error: "USERNAME ALREADY TAKEN" });
      }

      const password_hash = await bcrypt.hash(data.password, 12);

      const user = await storage.createUser({
        username: data.username,
        email: data.email,
        password_hash,
        role: "user",
        is_active: true,
      });

      const { password_hash: _, ...safeUser } = user;
      res.status(201).json({ message: "ACCESS GRANTED — AWAIT AUTHENTICATION", user: safeUser });
    } catch (err: any) {
      if (err.name === "ZodError") {
        return res.status(400).json({ error: "INVALID INPUT DATA", details: err.errors });
      }
      console.error("Registration error:", err);
      res.status(500).json({ error: "SYSTEM ERROR — REGISTRATION FAILED" });
    }
  });

  // POST /api/auth/login — Validate credentials, return JWT
  app.post("/api/auth/login", async (req, res) => {
    try {
      const data = loginSchema.parse(req.body);
      data.email = data.email.toLowerCase().trim();

      const user = await storage.getUserByEmail(data.email);
      if (!user) {
        return res.status(401).json({ error: "INVALID CREDENTIALS" });
      }

      if (!user.is_active) {
        return res.status(403).json({ error: "ACCOUNT DEACTIVATED — CONTACT ADMINISTRATOR" });
      }

      const valid = await bcrypt.compare(data.password, user.password_hash);
      if (!valid) {
        return res.status(401).json({ error: "INVALID CREDENTIALS" });
      }

      // Update last login
      await storage.updateUser(user.id, { last_login: new Date().toISOString() });

      const token = generateToken(user.id, user.role);
      const { password_hash: _, ...safeUser } = user;

      res.json({ token, user: safeUser });
    } catch (err: any) {
      if (err.name === "ZodError") {
        return res.status(400).json({ error: "INVALID INPUT DATA" });
      }
      console.error("Login error:", err);
      res.status(500).json({ error: "SYSTEM ERROR — AUTHENTICATION FAILED" });
    }
  });

  // POST /api/auth/logout — Invalidate session
  app.post("/api/auth/logout", requireAuth, async (req, res) => {
    // With JWT, logout is client-side (discard token). 
    // We respond affirmatively.
    res.json({ message: "SESSION TERMINATED" });
  });

  // GET /api/auth/me — Return current user
  app.get("/api/auth/me", requireAuth, async (req, res) => {
    res.json({ user: req.user });
  });

  // ═══════════════════════════════════════════════════
  // USER SETTINGS
  // ═══════════════════════════════════════════════════

  app.patch("/api/auth/settings", requireAuth, async (req, res) => {
    try {
      const data = updateSettingsSchema.parse(req.body);
      const userId = req.user!.id;
      const updateData: any = {};

      if (data.username) updateData.username = data.username;
      if (data.email) updateData.email = data.email;

      if (data.new_password) {
        if (!data.current_password) {
          return res.status(400).json({ error: "CURRENT PASSWORD REQUIRED" });
        }
        const user = await storage.getUser(userId);
        if (!user) return res.status(404).json({ error: "USER NOT FOUND" });
        const valid = await bcrypt.compare(data.current_password, user.password_hash);
        if (!valid) return res.status(401).json({ error: "CURRENT PASSWORD INVALID" });
        updateData.password_hash = await bcrypt.hash(data.new_password, 12);
      }

      const updated = await storage.updateUser(userId, updateData);
      if (!updated) return res.status(404).json({ error: "USER NOT FOUND" });

      const { password_hash: _, ...safeUser } = updated;
      res.json({ user: safeUser });
    } catch (err: any) {
      if (err.name === "ZodError") {
        return res.status(400).json({ error: "INVALID INPUT DATA", details: err.errors });
      }
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  // ═══════════════════════════════════════════════════
  // ADMIN ROUTES
  // ═══════════════════════════════════════════════════

  // GET /api/admin/users — List all users
  app.get("/api/admin/users", requireAdmin, async (req, res) => {
    const allUsers = await storage.getAllUsers();
    res.json({ users: allUsers });
  });

  // PATCH /api/admin/users/:id — Update user role/status
  app.patch("/api/admin/users/:id", requireAdmin, async (req, res) => {
    try {
      const userId = parseInt(String(req.params.id), 10);
      if (isNaN(userId)) return res.status(400).json({ error: "INVALID USER ID" });

      const data = updateUserSchema.parse(req.body);
      const updated = await storage.updateUser(userId, data);
      if (!updated) return res.status(404).json({ error: "USER NOT FOUND" });

      const { password_hash: _, ...safeUser } = updated;
      res.json({ user: safeUser });
    } catch (err: any) {
      if (err.name === "ZodError") {
        return res.status(400).json({ error: "INVALID INPUT DATA" });
      }
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  // DELETE /api/admin/users/:id — Delete user
  app.delete("/api/admin/users/:id", requireAdmin, async (req, res) => {
    const userId = parseInt(String(req.params.id), 10);
    if (isNaN(userId)) return res.status(400).json({ error: "INVALID USER ID" });

    // Prevent self-delete
    if (userId === req.user!.id) {
      return res.status(400).json({ error: "CANNOT DELETE OWN ACCOUNT" });
    }

    const deleted = await storage.deleteUser(userId);
    if (!deleted) return res.status(404).json({ error: "USER NOT FOUND" });

    res.json({ message: "USER ELIMINATED" });
  });

  // ═══════════════════════════════════════════════════
  // PHASE 2 — OLLAMA PROXY ROUTES
  // ═══════════════════════════════════════════════════

  const OLLAMA_BASE = "http://localhost:11434";

  // GET /api/ollama/status — Check if Ollama is reachable
  app.get("/api/ollama/status", requireAuth, async (_req, res) => {
    try {
      const response = await fetch(`${OLLAMA_BASE}/api/version`);
      if (response.ok) {
        const data = await response.json();
        res.json({ online: true, version: data.version || "unknown" });
      } else {
        res.json({ online: false, version: "" });
      }
    } catch {
      res.json({ online: false, version: "" });
    }
  });

  // GET /api/ollama/models — List installed models
  app.get("/api/ollama/models", requireAuth, async (_req, res) => {
    try {
      const response = await fetch(`${OLLAMA_BASE}/api/tags`);
      if (!response.ok) {
        return res.status(502).json({ error: "OLLAMA UNREACHABLE" });
      }
      const data = await response.json();
      const models = (data.models || []).map((m: any) => ({
        name: m.name,
        size: m.size,
        modified_at: m.modified_at,
        details: m.details || {},
      }));
      res.json({ models });
    } catch {
      res.status(502).json({ error: "NEURAL LINK SEVERED — OLLAMA OFFLINE" });
    }
  });

  // POST /api/ollama/pull — Pull a model with SSE progress
  app.post("/api/ollama/pull", requireAuth, async (req, res) => {
    const { model } = req.body;
    if (!model || typeof model !== "string") {
      return res.status(400).json({ error: "MODEL NAME REQUIRED" });
    }

    res.setHeader("Content-Type", "text/event-stream");
    res.setHeader("Cache-Control", "no-cache");
    res.setHeader("Connection", "keep-alive");
    res.flushHeaders();

    try {
      const response = await fetch(`${OLLAMA_BASE}/api/pull`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: model, stream: true }),
      });

      if (!response.ok || !response.body) {
        res.write(`data: {"error":"FAILED TO INITIATE PULL"}\n\n`);
        return res.end();
      }

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split("\n");
        buffer = lines.pop() || "";

        for (const line of lines) {
          if (!line.trim()) continue;
          try {
            const parsed = JSON.parse(line);
            res.write(`data: ${JSON.stringify({
              status: parsed.status || "",
              completed: parsed.completed || 0,
              total: parsed.total || 0,
            })}\n\n`);
          } catch {
            // skip malformed lines
          }
        }
      }

      res.write(`data: {"done":true}\n\n`);
      res.end();
    } catch {
      res.write(`data: {"error":"NEURAL LINK SEVERED — OLLAMA OFFLINE"}\n\n`);
      res.end();
    }
  });

  // DELETE /api/ollama/models/:name — Delete a model
  app.delete("/api/ollama/models/:name", requireAuth, async (req, res) => {
    const modelName = req.params.name;
    try {
      const response = await fetch(`${OLLAMA_BASE}/api/delete`, {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: modelName }),
      });
      if (response.ok) {
        res.json({ message: "MODEL PURGED" });
      } else {
        const err = await response.text();
        res.status(response.status).json({ error: err || "DELETE FAILED" });
      }
    } catch {
      res.status(502).json({ error: "NEURAL LINK SEVERED — OLLAMA OFFLINE" });
    }
  });

  // ═══════════════════════════════════════════════════
  // PHASE 2 — CHAT / STREAMING ROUTE
  // ═══════════════════════════════════════════════════

  const TOOL_DEFINITIONS: Record<string, any> = {
    proxmox_get_nodes: {
      type: "function",
      function: {
        name: "proxmox_get_nodes",
        description: "Get list of all Proxmox hypervisor nodes with their status, CPU and memory usage",
        parameters: { type: "object", properties: {} },
      },
    },
    proxmox_get_vms: {
      type: "function",
      function: {
        name: "proxmox_get_vms",
        description: "Get list of all virtual machines from Proxmox with their status, CPU and memory usage",
        parameters: {
          type: "object",
          properties: {
            node: { type: "string", description: "Proxmox node name (default: pve)" },
          },
        },
      },
    },
    proxmox_get_vm_status: {
      type: "function",
      function: {
        name: "proxmox_get_vm_status",
        description: "Get detailed status of a specific virtual machine",
        parameters: {
          type: "object",
          properties: {
            node: { type: "string", description: "Proxmox node name" },
            vmid: { type: "string", description: "Virtual machine ID" },
          },
          required: ["node", "vmid"],
        },
      },
    },
    proxmox_start_vm: {
      type: "function",
      function: {
        name: "proxmox_start_vm",
        description: "Start a virtual machine on Proxmox",
        parameters: {
          type: "object",
          properties: {
            node: { type: "string", description: "Proxmox node name" },
            vmid: { type: "string", description: "Virtual machine ID" },
          },
          required: ["node", "vmid"],
        },
      },
    },
    proxmox_stop_vm: {
      type: "function",
      function: {
        name: "proxmox_stop_vm",
        description: "Stop a virtual machine on Proxmox",
        parameters: {
          type: "object",
          properties: {
            node: { type: "string", description: "Proxmox node name" },
            vmid: { type: "string", description: "Virtual machine ID" },
          },
          required: ["node", "vmid"],
        },
      },
    },
    proxmox_get_storage: {
      type: "function",
      function: {
        name: "proxmox_get_storage",
        description: "Get storage pools with usage information from Proxmox",
        parameters: {
          type: "object",
          properties: {
            node: { type: "string", description: "Proxmox node name (default: pve)" },
          },
        },
      },
    },
    truenas_get_pools: {
      type: "function",
      function: {
        name: "truenas_get_pools",
        description: "Get list of ZFS storage pools from TrueNAS with status and usage",
        parameters: { type: "object", properties: {} },
      },
    },
    truenas_get_datasets: {
      type: "function",
      function: {
        name: "truenas_get_datasets",
        description: "Get all ZFS datasets from TrueNAS with used and available space",
        parameters: { type: "object", properties: {} },
      },
    },
    truenas_get_alerts: {
      type: "function",
      function: {
        name: "truenas_get_alerts",
        description: "Get active alerts from TrueNAS",
        parameters: { type: "object", properties: {} },
      },
    },
    truenas_get_system_info: {
      type: "function",
      function: {
        name: "truenas_get_system_info",
        description: "Get TrueNAS system information including hostname, version, and uptime",
        parameters: { type: "object", properties: {} },
      },
    },
    truenas_get_disks: {
      type: "function",
      function: {
        name: "truenas_get_disks",
        description: "Get disk list from TrueNAS with temperatures and status",
        parameters: { type: "object", properties: {} },
      },
    },
    truenas_dismiss_alert: {
      type: "function",
      function: {
        name: "truenas_dismiss_alert",
        description: "Dismiss an alert on TrueNAS by UUID",
        parameters: {
          type: "object",
          properties: {
            uuid: { type: "string", description: "Alert UUID to dismiss" },
          },
          required: ["uuid"],
        },
      },
    },
    network_ping: {
      type: "function",
      function: {
        name: "network_ping",
        description: "Ping a host and return packet loss and average RTT",
        parameters: {
          type: "object",
          properties: {
            host: { type: "string", description: "Host or IP to ping" },
            count: { type: "number", description: "Number of pings (default: 4)" },
          },
          required: ["host"],
        },
      },
    },
    network_dns_lookup: {
      type: "function",
      function: {
        name: "network_dns_lookup",
        description: "Perform DNS lookup for a hostname",
        parameters: {
          type: "object",
          properties: {
            hostname: { type: "string", description: "Hostname to resolve" },
          },
          required: ["hostname"],
        },
      },
    },
    network_port_check: {
      type: "function",
      function: {
        name: "network_port_check",
        description: "Check if a TCP port is open on a host",
        parameters: {
          type: "object",
          properties: {
            host: { type: "string", description: "Host or IP to check" },
            port: { type: "number", description: "Port number to check" },
            timeout: { type: "number", description: "Timeout in ms (default: 3000)" },
          },
          required: ["host", "port"],
        },
      },
    },
    network_get_local_hosts: {
      type: "function",
      function: {
        name: "network_get_local_hosts",
        description: "Read /etc/hosts file and return all entries",
        parameters: { type: "object", properties: {} },
      },
    },
    network_traceroute: {
      type: "function",
      function: {
        name: "network_traceroute",
        description: "Run traceroute to a host",
        parameters: {
          type: "object",
          properties: {
            host: { type: "string", description: "Host or IP to trace route to" },
          },
          required: ["host"],
        },
      },
    },
    system_get_metrics: {
      type: "function",
      function: {
        name: "system_get_metrics",
        description: "Get TRIDENT server metrics: CPU usage, memory, disk, uptime, load average",
        parameters: { type: "object", properties: {} },
      },
    },
    system_get_services: {
      type: "function",
      function: {
        name: "system_get_services",
        description: "Get status of TRIDENT services: trident, ollama, trident-voice, trident-imagegen",
        parameters: { type: "object", properties: {} },
      },
    },
    system_get_disk_usage: {
      type: "function",
      function: {
        name: "system_get_disk_usage",
        description: "Get disk usage for all mounted filesystems",
        parameters: { type: "object", properties: {} },
      },
    },
    system_run_command: {
      type: "function",
      function: {
        name: "system_run_command",
        description: "Run an approved system command (admin only). Allowed: df, free, top, ps, netstat, ss, ip, systemctl status",
        parameters: {
          type: "object",
          properties: {
            command: { type: "string", description: "Command to run (must be in whitelist)" },
          },
          required: ["command"],
        },
      },
    },
  };


  function parseToolCallName(name: string): { toolName: string; action: string } {
    const parts = name.split("_");
    const toolName = parts[0];
    const action = parts.slice(1).join("_");
    return { toolName, action };
  }



  const chatStreamSchema = z.object({
    conversationId: z.number(),
    message: z.string().min(1),
    model: z.string().min(1),
    temperature: z.number().min(0).max(2).optional(),
    max_tokens: z.number().min(1).max(65536).optional(),
    top_p: z.number().min(0).max(1).optional(),
    tools_enabled: z.boolean().optional(),
    available_tools: z.array(z.string()).optional(),
  });

  app.post("/api/chat/stream", requireAuth, async (req, res) => {
    try {
      const data = chatStreamSchema.parse(req.body);
      const userId = req.user!.id;

      // Validate ownership
      const conversation = await storage.getConversation(data.conversationId, userId);
      if (!conversation) {
        return res.status(404).json({ error: "CONVERSATION NOT FOUND" });
      }

      // Save user message
      const now = new Date().toISOString();
      await storage.addMessage({
        conversation_id: data.conversationId,
        role: "user",
        content: data.message,
        created_at: now,
      });

      // Update conversation timestamp
      await storage.updateConversation(data.conversationId, userId, { updated_at: now });

      // Build message history
      const dbMessages = await storage.getConversationMessages(data.conversationId);
      const ollamaMessages: { role: string; content: string }[] = [];

      // Add system prompt if exists
      const systemPrompt = conversation.system_prompt;
      if (systemPrompt) {
        ollamaMessages.push({ role: "system", content: systemPrompt });
      }

      for (const msg of dbMessages) {
        if (msg.role === "system") continue; // system prompt handled above
        ollamaMessages.push({ role: msg.role, content: msg.content });
      }

      // Set SSE headers
      res.setHeader("Content-Type", "text/event-stream");
      res.setHeader("Cache-Control", "no-cache");
      res.setHeader("Connection", "keep-alive");
      res.flushHeaders();

      // Build tool definitions if tools are enabled
      const activeToolDefs: any[] = [];
      if (data.tools_enabled && data.available_tools && data.available_tools.length > 0) {
        for (const toolKey of Object.keys(TOOL_DEFINITIONS)) {
          const toolPrefix = toolKey.split('_')[0];
          if (data.available_tools.includes(toolPrefix) || data.available_tools.includes(toolKey)) {
            activeToolDefs.push(TOOL_DEFINITIONS[toolKey]);
          }
        }
      }

      try {
        // If tools are active: use non-streaming first call to detect tool_calls reliably
        // (Ollama streaming chunks tool_calls across multiple lines which is hard to parse)
        if (activeToolDefs.length > 0) {
          const toolRes = await fetch(`${OLLAMA_BASE}/api/chat`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              model: data.model,
              messages: ollamaMessages,
              stream: false,
              tools: activeToolDefs,
              options: {
                temperature: data.temperature ?? 0.7,
                num_predict: data.max_tokens ?? 2048,
                top_p: data.top_p ?? 0.9,
              },
            }),
          });

          if (!toolRes.ok) {
            res.write(`data: {"error":"NEURAL LINK SEVERED — OLLAMA OFFLINE"}\n\n`);
            return res.end();
          }

          const toolJson = await toolRes.json();
          const toolMsg = toolJson.message;

          // Check if model wants to call a tool
          if (toolMsg?.tool_calls && toolMsg.tool_calls.length > 0) {
            for (const toolCall of toolMsg.tool_calls) {
              const fnName = toolCall.function?.name;
              const fnArgs = toolCall.function?.arguments || {};
              if (!fnName) continue;

              res.write(`data: ${JSON.stringify({ tool_call: fnName, args: fnArgs, done: false })}\n\n`);

              const { toolName, action } = parseToolCallName(fnName);
              let toolResult: any;
              try {
                toolResult = await executeTool(toolName, action, fnArgs, userId);
              } catch (e: any) {
                toolResult = { error: e.message, success: false };
              }

              res.write(`data: ${JSON.stringify({ tool_result: fnName, result: toolResult, done: false })}\n\n`);

              ollamaMessages.push({ role: "assistant", content: "", tool_calls: [toolCall] } as any);
              ollamaMessages.push({ role: "tool", content: JSON.stringify(toolResult) } as any);
            }

            // Stream the final response after tool execution
            const finalRes = await fetch(`${OLLAMA_BASE}/api/chat`, {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({
                model: data.model,
                messages: ollamaMessages,
                stream: true,
                options: { temperature: data.temperature ?? 0.7, num_predict: data.max_tokens ?? 2048 },
              }),
            });

            if (finalRes.ok && finalRes.body) {
              const fReader = finalRes.body.getReader();
              const fDecoder = new TextDecoder();
              let fBuffer = "";
              let fullContent = "";
              while (true) {
                const { done, value } = await fReader.read();
                if (done) break;
                fBuffer += fDecoder.decode(value, { stream: true });
                const fLines = fBuffer.split("\n");
                fBuffer = fLines.pop() || "";
                for (const fLine of fLines) {
                  if (!fLine.trim()) continue;
                  try {
                    const fParsed = JSON.parse(fLine);
                    if (fParsed.message?.content) {
                      fullContent += fParsed.message.content;
                      res.write(`data: ${JSON.stringify({ token: fParsed.message.content, done: false })}\n\n`);
                    }
                    if (fParsed.done) {
                      const savedMsg = await storage.addMessage({
                        conversation_id: data.conversationId,
                        role: "assistant",
                        content: fullContent,
                        created_at: new Date().toISOString(),
                      });
                      res.write(`data: ${JSON.stringify({ done: true, messageId: savedMsg.id })}\n\n`);
                    }
                  } catch {}
                }
              }
            }
            return res.end();
          }

          // No tool call — stream the regular response
          if (toolMsg?.content) {
            const savedMsg = await storage.addMessage({
              conversation_id: data.conversationId,
              role: "assistant",
              content: toolMsg.content,
              created_at: new Date().toISOString(),
            });
            // Stream it token by token for smooth UX
            for (const char of toolMsg.content) {
              res.write(`data: ${JSON.stringify({ token: char, done: false })}\n\n`);
            }
            res.write(`data: ${JSON.stringify({ done: true, messageId: savedMsg.id })}\n\n`);
            return res.end();
          }
        }

        // No tools or tools disabled — use regular streaming
        const ollamaRes = await fetch(`${OLLAMA_BASE}/api/chat`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            model: data.model,
            messages: ollamaMessages,
            stream: true,
            options: {
              temperature: data.temperature ?? 0.7,
              num_predict: data.max_tokens ?? 2048,
              top_p: data.top_p ?? 0.9,
            },
          }),
        });

        if (!ollamaRes.ok || !ollamaRes.body) {
          res.write(`data: {"error":"NEURAL LINK SEVERED — OLLAMA OFFLINE"}\n\n`);
          return res.end();
        }

        const reader = ollamaRes.body.getReader();
        const decoder = new TextDecoder();
        let buffer = "";
        let fullContent = "";

        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          buffer += decoder.decode(value, { stream: true });
          const lines = buffer.split("\n");
          buffer = lines.pop() || "";

          for (const line of lines) {
            if (!line.trim()) continue;
            try {
              const parsed = JSON.parse(line);

              // Handle tool calls from Ollama
              if (parsed.message?.tool_calls && parsed.message.tool_calls.length > 0) {
                for (const toolCall of parsed.message.tool_calls) {
                  const fnName = toolCall.function?.name;
                  const fnArgs = toolCall.function?.arguments || {};
                  if (!fnName) continue;

                  // Send tool call notification to client
                  res.write(`data: ${JSON.stringify({ tool_call: fnName, args: fnArgs, done: false })}\n\n`);

                  // Parse tool name and action
                  const { toolName, action } = parseToolCallName(fnName);

                  // Execute the tool
                  let toolResult: any;
                  try {
                    toolResult = await executeTool(toolName, action, fnArgs, userId);
                  } catch (e: any) {
                    toolResult = { error: e.message, success: false };
                  }

                  // Send tool result to client
                  res.write(`data: ${JSON.stringify({ tool_result: fnName, result: toolResult, done: false })}\n\n`);

                  // Add tool call + result to message history and re-query Ollama
                  ollamaMessages.push({ role: "assistant", content: "", tool_calls: [toolCall] } as any);
                  ollamaMessages.push({ role: "tool", content: JSON.stringify(toolResult) } as any);

                  // Continue conversation with tool result
                  const followupRes = await fetch(`${OLLAMA_BASE}/api/chat`, {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({
                      model: data.model,
                      messages: ollamaMessages,
                      stream: true,
                      options: { temperature: data.temperature ?? 0.7, num_predict: data.max_tokens ?? 2048 },
                    }),
                  });

                  if (followupRes.ok && followupRes.body) {
                    const followupReader = followupRes.body.getReader();
                    let followupBuffer = "";
                    while (true) {
                      const { done: fDone, value: fValue } = await followupReader.read();
                      if (fDone) break;
                      followupBuffer += decoder.decode(fValue, { stream: true });
                      const fLines = followupBuffer.split("\n");
                      followupBuffer = fLines.pop() || "";
                      for (const fLine of fLines) {
                        if (!fLine.trim()) continue;
                        try {
                          const fParsed = JSON.parse(fLine);
                          if (fParsed.message?.content) {
                            fullContent += fParsed.message.content;
                            res.write(`data: ${JSON.stringify({ token: fParsed.message.content, done: false })}\n\n`);
                          }
                        } catch {}
                      }
                    }
                  }
                }
                continue;
              }

              if (parsed.message?.content) {
                const token = parsed.message.content;
                fullContent += token;
                res.write(`data: ${JSON.stringify({ token, done: false })}\n\n`);
              }
              if (parsed.done) {
                // Save assistant message
                const savedMsg = await storage.addMessage({
                  conversation_id: data.conversationId,
                  role: "assistant",
                  content: fullContent,
                  created_at: new Date().toISOString(),
                });
                res.write(`data: ${JSON.stringify({ done: true, messageId: savedMsg.id })}\n\n`);
              }
            } catch {
              // skip malformed
            }
          }
        }

        // If we haven't sent done yet (e.g. buffer remaining)
        if (buffer.trim()) {
          try {
            const parsed = JSON.parse(buffer);
            if (parsed.message?.content) {
              fullContent += parsed.message.content;
              res.write(`data: ${JSON.stringify({ token: parsed.message.content, done: false })}\n\n`);
            }
          } catch {}
        }

        res.end();
      } catch (fetchErr) {
        res.write(`data: {"error":"NEURAL LINK SEVERED — OLLAMA OFFLINE"}\n\n`);
        res.end();
      }
    } catch (err: any) {
      if (err.name === "ZodError") {
        return res.status(400).json({ error: "INVALID INPUT DATA", details: err.errors });
      }
      console.error("Chat stream error:", err);
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  // ═══════════════════════════════════════════════════
  // PHASE 2 — CONVERSATION ROUTES
  // ═══════════════════════════════════════════════════

  const createConversationSchema = z.object({
    title: z.string().optional(),
    model: z.string().min(1),
    system_prompt: z.string().optional(),
  });

  const updateConversationSchema = z.object({
    title: z.string().optional(),
    model: z.string().optional(),
    system_prompt: z.string().optional(),
  });

  // GET /api/conversations — List user's conversations
  app.get("/api/conversations", requireAuth, async (req, res) => {
    const userId = req.user!.id;
    const convs = await storage.getUserConversations(userId);
    res.json({ conversations: convs });
  });

  // POST /api/conversations — Create new conversation
  app.post("/api/conversations", requireAuth, async (req, res) => {
    try {
      const data = createConversationSchema.parse(req.body);
      const now = new Date().toISOString();
      const conv = await storage.createConversation({
        user_id: req.user!.id,
        title: data.title || "NEW CONVERSATION",
        model: data.model,
        system_prompt: data.system_prompt || "",
        created_at: now,
        updated_at: now,
      });
      res.status(201).json(conv);
    } catch (err: any) {
      if (err.name === "ZodError") {
        return res.status(400).json({ error: "INVALID INPUT DATA", details: err.errors });
      }
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  // GET /api/conversations/:id — Get conversation + messages
  app.get("/api/conversations/:id", requireAuth, async (req, res) => {
    const convId = parseInt(String(req.params.id), 10);
    if (isNaN(convId)) return res.status(400).json({ error: "INVALID CONVERSATION ID" });

    const conv = await storage.getConversation(convId, req.user!.id);
    if (!conv) return res.status(404).json({ error: "CONVERSATION NOT FOUND" });

    const msgs = await storage.getConversationMessages(convId);
    res.json({ conversation: conv, messages: msgs });
  });

  // PATCH /api/conversations/:id — Update conversation
  app.patch("/api/conversations/:id", requireAuth, async (req, res) => {
    try {
      const convId = parseInt(String(req.params.id), 10);
      if (isNaN(convId)) return res.status(400).json({ error: "INVALID CONVERSATION ID" });

      const data = updateConversationSchema.parse(req.body);
      const updated = await storage.updateConversation(convId, req.user!.id, {
        ...data,
        updated_at: new Date().toISOString(),
      });
      if (!updated) return res.status(404).json({ error: "CONVERSATION NOT FOUND" });
      res.json(updated);
    } catch (err: any) {
      if (err.name === "ZodError") {
        return res.status(400).json({ error: "INVALID INPUT DATA" });
      }
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  // DELETE /api/conversations/:id — Delete conversation + messages
  app.delete("/api/conversations/:id", requireAuth, async (req, res) => {
    const convId = parseInt(String(req.params.id), 10);
    if (isNaN(convId)) return res.status(400).json({ error: "INVALID CONVERSATION ID" });

    const deleted = await storage.deleteConversation(convId, req.user!.id);
    if (!deleted) return res.status(404).json({ error: "CONVERSATION NOT FOUND" });
    res.json({ message: "CONVERSATION PURGED" });
  });

  // ═══════════════════════════════════════════════════
  // PHASE 2 — MODEL CONFIG ROUTES
  // ═══════════════════════════════════════════════════

  const modelConfigSchema = z.object({
    temperature: z.number().min(0).max(2).optional(),
    max_tokens: z.number().min(256).max(65536).optional(),
    top_p: z.number().min(0).max(1).optional(),
    system_prompt: z.string().optional(),
  });

  // GET /api/model-configs/:modelName
  app.get("/api/model-configs/:modelName", requireAuth, async (req, res) => {
    const config = await storage.getModelConfig(req.user!.id, String(req.params.modelName));
    res.json(config || { temperature: 0.7, max_tokens: 2048, top_p: 0.9, system_prompt: "" });
  });

  // PUT /api/model-configs/:modelName
  app.put("/api/model-configs/:modelName", requireAuth, async (req, res) => {
    try {
      const data = modelConfigSchema.parse(req.body);
      const config = await storage.upsertModelConfig(req.user!.id, String(req.params.modelName), data);
      res.json(config);
    } catch (err: any) {
      if (err.name === "ZodError") {
        return res.status(400).json({ error: "INVALID INPUT DATA", details: err.errors });
      }
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  // ═══════════════════════════════════════════════════
  // PHASE 3 — VOICE PROXY ROUTES
  // ═══════════════════════════════════════════════════

  const VOICE_SERVICE_BASE = "http://127.0.0.1:5001";
  const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 25 * 1024 * 1024 } });

  // Helper: proxy request to voice service using Node http module
  function proxyToVoice(
    path: string,
    method: string,
    body: Buffer | string | null,
    contentType: string
  ): Promise<{ statusCode: number; headers: http.IncomingHttpHeaders; body: Buffer }> {
    return new Promise((resolve, reject) => {
      const options = {
        hostname: "127.0.0.1",
        port: 5001,
        path,
        method,
        headers: {
          "Content-Type": contentType,
          ...(body ? { "Content-Length": Buffer.byteLength(body) } : {}),
        },
      };

      const req = http.request(options, (res) => {
        const chunks: Buffer[] = [];
        res.on("data", (chunk: Buffer) => chunks.push(chunk));
        res.on("end", () => {
          resolve({
            statusCode: res.statusCode || 500,
            headers: res.headers,
            body: Buffer.concat(chunks),
          });
        });
      });

      req.on("error", reject);
      req.setTimeout(30000, () => {
        req.destroy();
        reject(new Error("Voice service timeout"));
      });

      if (body) req.write(body);
      req.end();
    });
  }

  // POST /api/voice/stt — Speech-to-text proxy
  app.post("/api/voice/stt", requireAuth, upload.single("audio"), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: "NO AUDIO DATA RECEIVED" });
      }

      const result = await proxyToVoice("/stt", "POST", req.file.buffer, "application/octet-stream");
      const json = JSON.parse(result.body.toString());
      res.status(result.statusCode).json(json);
    } catch {
      res.status(503).json({ error: "VOICE PROCESSING UNIT OFFLINE" });
    }
  });

  // POST /api/voice/tts — Text-to-speech proxy
  app.post("/api/voice/tts", requireAuth, async (req, res) => {
    try {
      const { text, voice } = req.body;
      if (!text || typeof text !== "string") {
        return res.status(400).json({ error: "TEXT PAYLOAD REQUIRED" });
      }

      const payload = JSON.stringify({ text, voice: voice || "lessac" });
      const result = await proxyToVoice("/tts", "POST", payload, "application/json");

      if (result.statusCode === 200) {
        res.setHeader("Content-Type", "audio/wav");
        res.setHeader("Content-Length", result.body.length);
        res.status(200).end(result.body);
      } else {
        const json = JSON.parse(result.body.toString());
        res.status(result.statusCode).json(json);
      }
    } catch {
      res.status(503).json({ error: "VOICE SYNTHESIS UNIT OFFLINE" });
    }
  });

  // GET /api/voice/status — Check if voice service is online via TCP probe
  app.get("/api/voice/status", requireAuth, async (_req, res) => {
    const net = await import("net");
    const socket = new net.Socket();
    let resolved = false;
    const done = (online: boolean) => {
      if (resolved) return;
      resolved = true;
      socket.destroy();
      res.json({ online, voices: online ? ["lessac", "amy"] : [] });
    };
    socket.setTimeout(2000);
    socket.connect(5001, "127.0.0.1", () => done(true));
    socket.on("error", () => done(false));
    socket.on("timeout", () => done(false));
  });

  // GET /api/voice/voices — Available voice profiles
  app.get("/api/voice/voices", requireAuth, async (_req, res) => {
    res.json([
      {
        id: "lessac",
        name: "LESSAC (NEUTRAL)",
        description: "Clear, professional neutral American English voice",
      },
      {
        id: "amy",
        name: "AMY (NEUTRAL)",
        description: "Warm, natural American English female voice",
      },
    ]);
  });

  // ═══════════════════════════════════════════════════
  // PHASE 4 — IMAGE GENERATION ROUTES
  // ═══════════════════════════════════════════════════

  const SD_PORT = 7860;
  const SD_HOST = "127.0.0.1";
  const IMAGE_UPLOAD_DIR = "/opt/trident/uploads/images";

  // Helper: proxy request to Stable Diffusion API
  function proxyToSD(
    sdPath: string,
    method: string,
    body: string | null,
    timeoutMs: number = 300000
  ): Promise<{ statusCode: number; body: string }> {
    return new Promise((resolve, reject) => {
      const options: http.RequestOptions = {
        hostname: SD_HOST,
        port: SD_PORT,
        path: sdPath,
        method,
        headers: {
          "Content-Type": "application/json",
          ...(body ? { "Content-Length": Buffer.byteLength(body) } : {}),
        },
      };

      const req = http.request(options, (res) => {
        const chunks: Buffer[] = [];
        res.on("data", (chunk: Buffer) => chunks.push(chunk));
        res.on("end", () => {
          resolve({
            statusCode: res.statusCode || 500,
            body: Buffer.concat(chunks).toString("utf-8"),
          });
        });
      });

      req.on("error", reject);
      req.setTimeout(timeoutMs, () => {
        req.destroy();
        reject(new Error("SD API timeout"));
      });

      if (body) req.write(body);
      req.end();
    });
  }

  // GET /api/imagegen/status — TCP probe to port 7860
  app.get("/api/imagegen/status", requireAuth, async (_req, res) => {
    const net = await import("net");
    const socket = new net.Socket();
    let resolved = false;
    const done = (online: boolean) => {
      if (resolved) return;
      resolved = true;
      socket.destroy();

      if (!online) {
        return res.json({ online: false, backend: "offline" });
      }

      // Detect backend type by querying models endpoint
      proxyToSD("/sdapi/v1/sd-models", "GET", null, 5000)
        .then((result) => {
          let backend: string = "automatic1111";
          try {
            const models = JSON.parse(result.body);
            if (Array.isArray(models) && models.length > 0 && models[0].hash === "diffusers-cpu") {
              backend = "diffusers";
            }
          } catch {
            // default to automatic1111
          }
          res.json({ online: true, backend });
        })
        .catch(() => {
          res.json({ online: true, backend: "automatic1111" });
        });
    };
    socket.setTimeout(2000);
    socket.connect(SD_PORT, SD_HOST, () => done(true));
    socket.on("error", () => done(false));
    socket.on("timeout", () => done(false));
  });

  // GET /api/imagegen/models — List available SD models
  app.get("/api/imagegen/models", requireAuth, async (_req, res) => {
    try {
      const result = await proxyToSD("/sdapi/v1/sd-models", "GET", null, 10000);
      const models = JSON.parse(result.body);
      res.json(models);
    } catch {
      res.status(503).json({ error: "VISUAL SYNTHESIS ENGINE OFFLINE" });
    }
  });

  // POST /api/imagegen/generate — Generate an image
  app.post("/api/imagegen/generate", requireAuth, async (req, res) => {
    try {
      const { prompt, negative_prompt, width, height, steps, cfg_scale, seed, model } = req.body;
      if (!prompt || typeof prompt !== "string" || prompt.trim().length === 0) {
        return res.status(400).json({ error: "VISUAL DIRECTIVE REQUIRED" });
      }

      const sdPayload = JSON.stringify({
        prompt: prompt.trim(),
        negative_prompt: negative_prompt || "",
        width: width || 512,
        height: height || 512,
        steps: steps || 20,
        cfg_scale: cfg_scale || 7,
        seed: seed ?? -1,
        sampler_name: "DPM++ 2M Karras",
      });

      const startTime = Date.now();
      const result = await proxyToSD("/sdapi/v1/txt2img", "POST", sdPayload, 300000);

      if (result.statusCode !== 200) {
        return res.status(result.statusCode).json({ error: "GENERATION FAILED", details: result.body });
      }

      const sdResponse = JSON.parse(result.body);
      if (!sdResponse.images || sdResponse.images.length === 0) {
        return res.status(500).json({ error: "NO IMAGE DATA RETURNED" });
      }

      // Parse info for actual seed
      let actualSeed = -1;
      try {
        const info = JSON.parse(sdResponse.info || "{}");
        actualSeed = info.seed ?? info.all_seeds?.[0] ?? -1;
      } catch {
        // ignore
      }

      // Save image to disk
      const userId = req.user!.id;
      const userDir = path.join(IMAGE_UPLOAD_DIR, String(userId));
      fs.mkdirSync(userDir, { recursive: true });

      const timestamp = Date.now();
      const filename = `${timestamp}_${crypto.randomBytes(4).toString("hex")}.png`;
      const imagePath = path.join(userDir, filename);
      const imageBuffer = Buffer.from(sdResponse.images[0], "base64");
      fs.writeFileSync(imagePath, imageBuffer);

      // Save record to database
      const now = new Date().toISOString();
      const record = await storage.createGeneratedImage({
        user_id: userId,
        prompt: prompt.trim(),
        negative_prompt: negative_prompt || "",
        model: model || "stable-diffusion",
        width: width || 512,
        height: height || 512,
        steps: steps || 20,
        cfg_scale: cfg_scale || 7.0,
        seed: seed ?? -1,
        actual_seed: actualSeed,
        image_path: imagePath,
        thumbnail_path: imagePath,
        created_at: now,
        is_favorite: 0,
      });

      const elapsed = Date.now() - startTime;
      res.json({
        id: record.id,
        imageUrl: `/api/imagegen/image/${record.id}`,
        seed: actualSeed,
        width: record.width,
        height: record.height,
        elapsed_ms: elapsed,
      });
    } catch (err: any) {
      if (err.message === "SD API timeout") {
        return res.status(504).json({ error: "GENERATION TIMEOUT — IMAGE TOOK TOO LONG" });
      }
      res.status(503).json({ error: "VISUAL SYNTHESIS ENGINE OFFLINE" });
    }
  });

  // GET /api/imagegen/image/:id — Serve image file
  app.get("/api/imagegen/image/:id", requireAuth, async (req, res) => {
    try {
      const imageId = parseInt(String(req.params.id), 10);
      if (isNaN(imageId)) return res.status(400).json({ error: "INVALID IMAGE ID" });

      const image = await storage.getImage(imageId, req.user!.id);
      if (!image) return res.status(404).json({ error: "IMAGE NOT FOUND" });

      if (!fs.existsSync(image.image_path)) {
        return res.status(404).json({ error: "IMAGE FILE MISSING FROM DISK" });
      }

      res.setHeader("Content-Type", "image/png");
      res.setHeader("Cache-Control", "max-age=31536000, immutable");
      const fileBuffer = fs.readFileSync(image.image_path);
      res.send(fileBuffer);
    } catch {
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  // GET /api/imagegen/gallery — Paginated gallery
  app.get("/api/imagegen/gallery", requireAuth, async (req, res) => {
    try {
      const page = Math.max(1, parseInt(String(req.query.page || "1"), 10));
      const limit = Math.min(50, Math.max(1, parseInt(String(req.query.limit || "20"), 10)));
      const offset = (page - 1) * limit;

      const total = await storage.getUserImageCount(req.user!.id);
      const images = await storage.getUserImages(req.user!.id, limit, offset);
      const pages = Math.ceil(total / limit);

      res.json({
        images: images.map((img) => ({
          id: img.id,
          prompt: img.prompt,
          negative_prompt: img.negative_prompt,
          width: img.width,
          height: img.height,
          steps: img.steps,
          cfg_scale: img.cfg_scale,
          seed: img.seed,
          actual_seed: img.actual_seed,
          model: img.model,
          created_at: img.created_at,
          is_favorite: img.is_favorite,
          imageUrl: `/api/imagegen/image/${img.id}`,
        })),
        total,
        page,
        pages,
      });
    } catch {
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  // DELETE /api/imagegen/image/:id — Delete image
  app.delete("/api/imagegen/image/:id", requireAuth, async (req, res) => {
    try {
      const imageId = parseInt(String(req.params.id), 10);
      if (isNaN(imageId)) return res.status(400).json({ error: "INVALID IMAGE ID" });

      const image = await storage.getImage(imageId, req.user!.id);
      if (!image) return res.status(404).json({ error: "IMAGE NOT FOUND" });

      // Delete file from disk
      try {
        if (fs.existsSync(image.image_path)) fs.unlinkSync(image.image_path);
        if (image.thumbnail_path && image.thumbnail_path !== image.image_path && fs.existsSync(image.thumbnail_path)) {
          fs.unlinkSync(image.thumbnail_path);
        }
      } catch {
        // ignore file deletion errors
      }

      await storage.deleteImage(imageId, req.user!.id);
      res.json({ message: "IMAGE PURGED" });
    } catch {
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  // PATCH /api/imagegen/image/:id/favorite — Toggle favorite
  app.patch("/api/imagegen/image/:id/favorite", requireAuth, async (req, res) => {
    try {
      const imageId = parseInt(String(req.params.id), 10);
      if (isNaN(imageId)) return res.status(400).json({ error: "INVALID IMAGE ID" });

      const updated = await storage.toggleFavorite(imageId, req.user!.id);
      if (!updated) return res.status(404).json({ error: "IMAGE NOT FOUND" });

      res.json({
        id: updated.id,
        is_favorite: updated.is_favorite,
      });
    } catch {
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  // ═══════════════════════════════════════════════════
  // PHASE 5 — FILE UPLOAD ROUTES
  // ═══════════════════════════════════════════════════

  // NAS mount point — all persistent data lives here
  const NAS_BASE = "/mnt/trident-briefs";
  const FILE_UPLOAD_DIR = `${NAS_BASE}/uploads`;
  const MAX_FILE_SIZE = 50 * 1024 * 1024; // 50MB

  const ACCEPTED_MIMES = new Set([
    "application/pdf",
    "text/plain",
    "text/markdown",
    "text/csv",
    "application/json",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    "image/jpeg",
    "image/png",
    "image/gif",
    "image/webp",
  ]);

  const fileUpload = multer({
    storage: multer.memoryStorage(),
    limits: { fileSize: MAX_FILE_SIZE },
  });

  // Helper: extract text from uploaded file
  async function extractTextFromFile(filePath: string, mimeType: string): Promise<string> {
    if (mimeType.startsWith("text/") || mimeType === "application/json") {
      return fs.readFileSync(filePath, "utf-8").slice(0, 50000);
    }
    if (mimeType === "application/pdf") {
      try {
        // eslint-disable-next-line @typescript-eslint/no-var-requires
        const pdfParse = require("pdf-parse");
        const buffer = fs.readFileSync(filePath);
        const data = await pdfParse(buffer);
        return data.text.slice(0, 50000);
      } catch {
        return "[PDF EXTRACTION FAILED]";
      }
    }
    if (mimeType.startsWith("image/")) {
      return `[IMAGE FILE: ${path.basename(filePath)}]`;
    }
    if (mimeType === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' || filePath.endsWith('.docx')) {
      try {
        const mammoth = require('mammoth');
        const result = await mammoth.extractRawText({ path: filePath });
        return result.value.slice(0, 50000);
      } catch (e) { return '[DOCX EXTRACTION FAILED: ' + String(e) + ']'; }
    }
    return `[BINARY FILE: ${path.basename(filePath)} — content not extractable as text]`;
  }

  // POST /api/files/upload/:conversationId — Upload file to conversation
  app.post("/api/files/upload/:conversationId", requireAuth, fileUpload.single("file"), async (req, res) => {
    try {
      const convId = parseInt(String(req.params.conversationId), 10);
      if (isNaN(convId)) return res.status(400).json({ error: "INVALID CONVERSATION ID" });

      const userId = req.user!.id;

      // Validate conversation ownership
      const conv = await storage.getConversation(convId, userId);
      if (!conv) return res.status(404).json({ error: "CONVERSATION NOT FOUND" });

      if (!req.file) {
        return res.status(400).json({ error: "NO FILE RECEIVED" });
      }

      const mimeType = req.file.mimetype;
      if (!ACCEPTED_MIMES.has(mimeType)) {
        return res.status(400).json({ error: `UNSUPPORTED FILE TYPE: ${mimeType}` });
      }

      // Create upload directory
      const userDir = path.join(FILE_UPLOAD_DIR, String(userId));
      fs.mkdirSync(userDir, { recursive: true });

      // Generate stored filename
      const ext = path.extname(req.file.originalname) || ".bin";
      const storedFilename = `${crypto.randomUUID()}${ext}`;
      const filePath = path.join(userDir, storedFilename);

      // Write file to disk
      fs.writeFileSync(filePath, req.file.buffer);

      // Create DB record
      const now = new Date().toISOString();
      const record = await storage.addConversationFile({
        conversation_id: convId,
        user_id: userId,
        filename: req.file.originalname,
        stored_filename: storedFilename,
        file_path: filePath,
        mime_type: mimeType,
        file_size: req.file.size,
        extracted_text: null,
        extraction_status: "pending",
        created_at: now,
      });

      // Trigger async text extraction (don't await)
      extractTextFromFile(filePath, mimeType)
        .then((text) => {
          storage.updateFileExtraction(record.id, text, "done");
        })
        .catch(() => {
          storage.updateFileExtraction(record.id, "", "failed");
        });

      res.status(201).json({
        id: record.id,
        filename: record.filename,
        mime_type: record.mime_type,
        file_size: record.file_size,
        extraction_status: "pending",
      });
    } catch (err: any) {
      console.error("File upload error:", err);
      if (err.code === "LIMIT_FILE_SIZE") {
        return res.status(413).json({ error: "FILE TOO LARGE — MAX 50MB" });
      }
      res.status(500).json({ error: "FILE UPLOAD FAILED" });
    }
  });

  // GET /api/files/content/:fileId — Get extracted text content (must be before /:conversationId)
  app.get("/api/files/content/:fileId", requireAuth, async (req, res) => {
    try {
      const fileId = parseInt(String(req.params.fileId), 10);
      if (isNaN(fileId)) return res.status(400).json({ error: "INVALID FILE ID" });

      const userId = req.user!.id;
      const file = await storage.getConversationFile(fileId, userId);
      if (!file) return res.status(404).json({ error: "FILE NOT FOUND" });

      res.json({
        id: file.id,
        filename: file.filename,
        extraction_status: file.extraction_status,
        extracted_text: file.extracted_text || "",
      });
    } catch {
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  // GET /api/files/:conversationId — List files for a conversation
  app.get("/api/files/:conversationId", requireAuth, async (req, res) => {
    try {
      const convId = parseInt(String(req.params.conversationId), 10);
      if (isNaN(convId)) return res.status(400).json({ error: "INVALID CONVERSATION ID" });

      const userId = req.user!.id;

      // Validate conversation ownership
      const conv = await storage.getConversation(convId, userId);
      if (!conv) return res.status(404).json({ error: "CONVERSATION NOT FOUND" });

      const files = await storage.getConversationFiles(convId);

      // Strip file_path for security
      const safeFiles = files.map(({ file_path, ...rest }) => rest);
      res.json({ files: safeFiles });
    } catch {
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  // DELETE /api/files/:fileId — Delete a file
  app.delete("/api/files/:fileId", requireAuth, async (req, res) => {
    try {
      const fileId = parseInt(String(req.params.fileId), 10);
      if (isNaN(fileId)) return res.status(400).json({ error: "INVALID FILE ID" });

      const userId = req.user!.id;
      const file = await storage.getConversationFile(fileId, userId);
      if (!file) return res.status(404).json({ error: "FILE NOT FOUND" });

      // Delete from disk
      try {
        if (fs.existsSync(file.file_path)) fs.unlinkSync(file.file_path);
      } catch {
        // ignore disk errors
      }

      await storage.deleteConversationFile(fileId, userId);
      res.json({ message: "FILE PURGED" });
    } catch {
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  // ═══════════════════════════════════════════════════
  // PHASE 6 — ADMIN STATS, EXPORT, API KEYS
  // ═══════════════════════════════════════════════════

  // GET /api/admin/stats — System-wide statistics (admin only)
  app.get("/api/admin/stats", requireAdmin, async (_req, res) => {
    try {
      const stats = await storage.getSystemStats();
      const mem = process.memoryUsage();
      res.json({
        users: { total: stats.userCount, active: stats.activeUserCount, admins: stats.adminCount },
        conversations: { total: stats.conversationCount, totalMessages: stats.messageCount },
        images: { total: stats.imageCount, totalSize: stats.imageTotalSize },
        files: { total: stats.fileCount, totalSize: stats.fileTotalSize },
        system: {
          uptime: process.uptime(),
          nodeVersion: process.version,
          platform: process.platform,
          memoryUsed: mem.heapUsed,
          memoryTotal: mem.heapTotal,
        },
      });
    } catch {
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  // GET /api/admin/user-stats/:userId — Per-user usage (admin only)
  app.get("/api/admin/user-stats/:userId", requireAdmin, async (req, res) => {
    try {
      const userId = parseInt(String(req.params.userId), 10);
      if (isNaN(userId)) return res.status(400).json({ error: "INVALID USER ID" });
      const stats = await storage.getUserStats(userId);
      res.json(stats);
    } catch {
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  // GET /api/conversations/:id/export — Export conversation
  app.get("/api/conversations/:id/export", requireAuth, async (req, res) => {
    try {
      const convId = parseInt(String(req.params.id), 10);
      if (isNaN(convId)) return res.status(400).json({ error: "INVALID CONVERSATION ID" });

      const userId = req.user!.id;
      const conv = await storage.getConversation(convId, userId);
      if (!conv) return res.status(404).json({ error: "CONVERSATION NOT FOUND" });

      const msgs = await storage.getConversationMessages(convId);
      const format = String(req.query.format || "json");

      if (format === "markdown") {
        let md = `# ${conv.title}\n\n`;
        md += `**Model:** ${conv.model}\n`;
        md += `**Created:** ${conv.created_at}\n`;
        md += `**Messages:** ${msgs.length}\n\n---\n\n`;
        for (const msg of msgs) {
          const role = msg.role === "user" ? "🟠 **User**" : "🔵 **Assistant**";
          md += `${role} *(${msg.created_at})*\n\n${msg.content}\n\n---\n\n`;
        }
        res.setHeader("Content-Type", "text/markdown; charset=utf-8");
        res.setHeader("Content-Disposition", `attachment; filename="${conv.title.replace(/[^a-zA-Z0-9]/g, "_")}.md"`);
        return res.send(md);
      }

      // Default: JSON
      const data = { conversation: conv, messages: msgs };
      res.setHeader("Content-Type", "application/json; charset=utf-8");
      res.setHeader("Content-Disposition", `attachment; filename="${conv.title.replace(/[^a-zA-Z0-9]/g, "_")}.json"`);
      return res.json(data);
    } catch {
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  // GET /api/keys — List user's API keys
  app.get("/api/keys", requireAuth, async (req, res) => {
    try {
      const keys = await storage.getUserApiKeys(req.user!.id);
      res.json({
        keys: keys.map((k) => ({
          id: k.id,
          name: k.name,
          key_prefix: k.key_prefix,
          created_at: k.created_at,
          last_used: k.last_used,
        })),
      });
    } catch {
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  // POST /api/keys — Generate new API key
  app.post("/api/keys", requireAuth, async (req, res) => {
    try {
      const { name } = req.body;
      if (!name || typeof name !== "string" || name.trim().length === 0) {
        return res.status(400).json({ error: "KEY NAME REQUIRED" });
      }

      const rawKey = "trident_" + crypto.randomBytes(32).toString("hex");
      const keyHash = crypto.createHash("sha256").update(rawKey).digest("hex");
      const keyPrefix = rawKey.slice(0, 16) + "...";

      await storage.createApiKey({
        user_id: req.user!.id,
        key_hash: keyHash,
        key_prefix: keyPrefix,
        name: name.trim(),
        created_at: new Date().toISOString(),
      });

      res.status(201).json({
        key: rawKey,
        prefix: keyPrefix,
        name: name.trim(),
        message: "KEY GENERATED — STORE SECURELY. THIS WILL NOT BE SHOWN AGAIN.",
      });
    } catch {
      res.status(500).json({ error: "KEY GENERATION FAILED" });
    }
  });

  // DELETE /api/keys/:id — Deactivate API key
  app.delete("/api/keys/:id", requireAuth, async (req, res) => {
    try {
      const keyId = parseInt(String(req.params.id), 10);
      if (isNaN(keyId)) return res.status(400).json({ error: "INVALID KEY ID" });

      const deleted = await storage.deactivateApiKey(keyId, req.user!.id);
      if (!deleted) return res.status(404).json({ error: "KEY NOT FOUND" });

      res.json({ message: "KEY REVOKED" });
    } catch {
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  // ═══════════════════════════════════════════════════
  // PHASE 8 — TOOL CONFIGURATION ROUTES
  // ═══════════════════════════════════════════════════

  // GET /api/tools/configs — list user's tool configs
  app.get("/api/tools/configs", requireAuth, async (req, res) => {
    try {
      const configs = await storage.getAllToolConfigs(req.user!.id);
      res.json({ configs });
    } catch {
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  // POST /api/tools/configs — save/update a tool config
  app.post("/api/tools/configs", requireAuth, async (req, res) => {
    try {
      const { tool_name, config, is_enabled } = req.body;
      if (!tool_name || !config) {
        return res.status(400).json({ error: "TOOL NAME AND CONFIG REQUIRED" });
      }
      const configStr = typeof config === "string" ? config : JSON.stringify(config);
      const enabled = is_enabled !== undefined ? (is_enabled ? 1 : 0) : 1;
      const saved = await storage.upsertToolConfig(req.user!.id, tool_name, configStr, enabled);
      res.json(saved);
    } catch {
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  // DELETE /api/tools/configs/:toolName — remove a tool config
  app.delete("/api/tools/configs/:toolName", requireAuth, async (req, res) => {
    try {
      const toolName = String(req.params.toolName);
      const deleted = await storage.deleteToolConfig(req.user!.id, toolName);
      if (!deleted) return res.status(404).json({ error: "TOOL CONFIG NOT FOUND" });
      res.json({ message: "TOOL CONFIG PURGED" });
    } catch {
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  // ═══════════════════════════════════════════════════
  // PHASE 8 — TOOL EXECUTION ENGINE
  // ═══════════════════════════════════════════════════

  // Helper: make HTTPS request to self-signed cert hosts
  function httpsRequest(url: string, options: https.RequestOptions): Promise<any> {
    return new Promise((resolve, reject) => {
      const req = https.request(url, { ...options, rejectUnauthorized: false }, (res) => {
        let data = "";
        res.on("data", (chunk) => (data += chunk));
        res.on("end", () => {
          try {
            resolve(JSON.parse(data));
          } catch {
            resolve(data);
          }
        });
      });
      req.on("error", reject);
      req.setTimeout(15000, () => {
        req.destroy();
        reject(new Error("Request timeout"));
      });
      if (options.method === "POST" || options.method === "DELETE") {
        // For POST/DELETE without body
      }
      req.end();
    });
  }

  function httpsPost(url: string, options: https.RequestOptions, body?: string): Promise<any> {
    return new Promise((resolve, reject) => {
      const req = https.request(url, { ...options, rejectUnauthorized: false, method: "POST" }, (res) => {
        let data = "";
        res.on("data", (chunk) => (data += chunk));
        res.on("end", () => {
          try {
            resolve(JSON.parse(data));
          } catch {
            resolve(data);
          }
        });
      });
      req.on("error", reject);
      req.setTimeout(15000, () => {
        req.destroy();
        reject(new Error("Request timeout"));
      });
      if (body) req.write(body);
      req.end();
    });
  }

  function httpsDelete(url: string, options: https.RequestOptions): Promise<any> {
    return new Promise((resolve, reject) => {
      const req = https.request(url, { ...options, rejectUnauthorized: false, method: "DELETE" }, (res) => {
        let data = "";
        res.on("data", (chunk) => (data += chunk));
        res.on("end", () => {
          try {
            resolve(JSON.parse(data));
          } catch {
            resolve(data);
          }
        });
      });
      req.on("error", reject);
      req.setTimeout(15000, () => {
        req.destroy();
        reject(new Error("Request timeout"));
      });
      req.end();
    });
  }

  // Core tool execution function — shared between API route and scheduler
  async function executeTool(toolName: string, action: string, params: any, userId: number): Promise<any> {
    try {
      switch (toolName) {
        case "proxmox":
          return await executeProxmoxTool(action, params, userId);
        case "truenas":
          return await executeTrueNASTool(action, params, userId);
        case "network":
          return await executeNetworkTool(action, params);
        case "system":
          return await executeSystemTool(action, params, userId);
        default:
          return { error: `Unknown tool: ${toolName}`, success: false };
      }
    } catch (err: any) {
      return { error: err.message || String(err), success: false };
    }
  }

  // Register tool executor with scheduler
  setToolExecutor(executeTool);

  // ─── PROXMOX TOOL ───
  async function executeProxmoxTool(action: string, params: any, userId: number): Promise<any> {
    const config = await storage.getToolConfig(userId, "proxmox");
    if (!config) return { error: "Proxmox not configured", success: false };
    
    const cfg = JSON.parse(config.config);
    const host = cfg.host;
    const port = cfg.port || 8006;
    const baseUrl = `https://${host}:${port}`;
    const headers = {
      Authorization: `PVEAPIToken=${cfg.token_id}=${cfg.token_secret}`,
    };

    switch (action) {
      case "get_nodes": {
        const result = await httpsRequest(`${baseUrl}/api2/json/nodes`, { headers });
        return { success: true, data: result?.data || result };
      }
      case "get_vms": {
        const node = params?.node || "pve";
        const result = await httpsRequest(`${baseUrl}/api2/json/nodes/${node}/qemu`, { headers });
        return { success: true, data: result?.data || result };
      }
      case "get_vm_status": {
        if (!params?.node || !params?.vmid) return { error: "node and vmid required", success: false };
        const result = await httpsRequest(`${baseUrl}/api2/json/nodes/${params.node}/qemu/${params.vmid}/status/current`, { headers });
        return { success: true, data: result?.data || result };
      }
      case "start_vm": {
        if (!params?.node || !params?.vmid) return { error: "node and vmid required", success: false };
        const result = await httpsPost(`${baseUrl}/api2/json/nodes/${params.node}/qemu/${params.vmid}/status/start`, { headers });
        return { success: true, data: result?.data || result };
      }
      case "stop_vm": {
        if (!params?.node || !params?.vmid) return { error: "node and vmid required", success: false };
        const result = await httpsPost(`${baseUrl}/api2/json/nodes/${params.node}/qemu/${params.vmid}/status/stop`, { headers });
        return { success: true, data: result?.data || result };
      }
      case "get_storage": {
        const node = params?.node || "pve";
        const result = await httpsRequest(`${baseUrl}/api2/json/nodes/${node}/storage`, { headers });
        return { success: true, data: result?.data || result };
      }
      default:
        return { error: `Unknown proxmox action: ${action}`, success: false };
    }
  }

  // ─── TRUENAS TOOL ───
  async function executeTrueNASTool(action: string, params: any, userId: number): Promise<any> {
    const config = await storage.getToolConfig(userId, "truenas");
    if (!config) return { error: "TrueNAS not configured", success: false };
    
    const cfg = JSON.parse(config.config);
    const host = cfg.host;
    const baseUrl = `https://${host}`;
    const headers = {
      Authorization: `Bearer ${cfg.api_key}`,
    };

    switch (action) {
      case "get_pools": {
        const result = await httpsRequest(`${baseUrl}/api/v2.0/pool`, { headers });
        return { success: true, data: result };
      }
      case "get_datasets": {
        const result = await httpsRequest(`${baseUrl}/api/v2.0/pool/dataset`, { headers });
        return { success: true, data: result };
      }
      case "get_alerts": {
        const result = await httpsRequest(`${baseUrl}/api/v2.0/alert/list`, { headers });
        return { success: true, data: result };
      }
      case "get_system_info": {
        const result = await httpsRequest(`${baseUrl}/api/v2.0/system/info`, { headers });
        return { success: true, data: result };
      }
      case "get_disks": {
        const result = await httpsRequest(`${baseUrl}/api/v2.0/disk`, { headers });
        return { success: true, data: result };
      }
      case "dismiss_alert": {
        if (!params?.uuid) return { error: "uuid required", success: false };
        const result = await httpsDelete(`${baseUrl}/api/v2.0/alert/dismiss/${params.uuid}`, { headers });
        return { success: true, data: result };
      }
      default:
        return { error: `Unknown truenas action: ${action}`, success: false };
    }
  }

  // ─── NETWORK TOOL ───
  async function executeNetworkTool(action: string, params: any): Promise<any> {
    switch (action) {
      case "ping": {
        if (!params?.host) return { error: "host required", success: false };
        const count = params.count || 4;
        try {
          const { stdout } = await execAsync(`ping -c ${count} ${params.host}`, { timeout: 10000 });
          // Parse packet loss and avg RTT
          const lossMatch = stdout.match(/(\d+\.?\d*)% packet loss/);
          const rttMatch = stdout.match(/rtt min\/avg\/max\/mdev = [\d.]+\/([\d.]+)\//);
          return {
            success: true,
            data: {
              host: params.host,
              packet_loss: lossMatch ? parseFloat(lossMatch[1]) : null,
              avg_rtt_ms: rttMatch ? parseFloat(rttMatch[1]) : null,
              raw: stdout,
            },
          };
        } catch (err: any) {
          return { success: false, error: err.message, data: { raw: err.stdout || err.stderr || "" } };
        }
      }
      case "dns_lookup": {
        if (!params?.hostname) return { error: "hostname required", success: false };
        return new Promise((resolve) => {
          dns.lookup(params.hostname, { all: true }, (err, addresses) => {
            if (err) {
              resolve({ success: false, error: err.message });
            } else {
              resolve({ success: true, data: { hostname: params.hostname, addresses } });
            }
          });
        });
      }
      case "port_check": {
        if (!params?.host || !params?.port) return { error: "host and port required", success: false };
        const timeout = params.timeout || 3000;
        return new Promise((resolve) => {
          const socket = new net.Socket();
          let resolved = false;
          socket.setTimeout(timeout);
          socket.on("connect", () => {
            resolved = true;
            socket.destroy();
            resolve({ success: true, data: { host: params.host, port: params.port, status: "open" } });
          });
          socket.on("timeout", () => {
            if (!resolved) {
              resolved = true;
              socket.destroy();
              resolve({ success: true, data: { host: params.host, port: params.port, status: "closed", reason: "timeout" } });
            }
          });
          socket.on("error", (err: any) => {
            if (!resolved) {
              resolved = true;
              socket.destroy();
              resolve({ success: true, data: { host: params.host, port: params.port, status: "closed", reason: err.message } });
            }
          });
          socket.connect(params.port, params.host);
        });
      }
      case "get_local_hosts": {
        try {
          const hostsContent = fs.readFileSync("/etc/hosts", "utf-8");
          const entries = hostsContent.split("\n")
            .filter((l) => l.trim() && !l.trim().startsWith("#"))
            .map((l) => {
              const parts = l.trim().split(/\s+/);
              return { ip: parts[0], hostnames: parts.slice(1) };
            });
          return { success: true, data: { entries } };
        } catch (err: any) {
          return { success: false, error: err.message };
        }
      }
      case "traceroute": {
        if (!params?.host) return { error: "host required", success: false };
        try {
          const { stdout } = await execAsync(`traceroute -m 15 ${params.host}`, { timeout: 30000 });
          return { success: true, data: { host: params.host, raw: stdout } };
        } catch (err: any) {
          return { success: false, error: err.message, data: { raw: err.stdout || err.stderr || "" } };
        }
      }
      default:
        return { error: `Unknown network action: ${action}`, success: false };
    }
  }

  // ─── SYSTEM TOOL ───
  const ALLOWED_COMMANDS = ["df", "free", "top", "ps", "netstat", "ss", "ip", "systemctl status"];

  async function executeSystemTool(action: string, params: any, userId: number): Promise<any> {
    switch (action) {
      case "get_metrics": {
        const cpus = os.cpus();
        const totalIdle = cpus.reduce((acc, cpu) => acc + cpu.times.idle, 0);
        const totalTick = cpus.reduce((acc, cpu) => acc + Object.values(cpu.times).reduce((a, b) => a + b, 0), 0);
        const cpuUsage = ((1 - totalIdle / totalTick) * 100).toFixed(1);
        
        const totalMem = os.totalmem();
        const freeMem = os.freemem();
        const usedMem = totalMem - freeMem;
        
        let diskUsage = "";
        try {
          const { stdout } = await execAsync("df -h /", { timeout: 5000 });
          diskUsage = stdout;
        } catch { /* ignore */ }
        
        return {
          success: true,
          data: {
            cpu_usage_pct: parseFloat(cpuUsage),
            memory: {
              total_bytes: totalMem,
              used_bytes: usedMem,
              free_bytes: freeMem,
              used_pct: ((usedMem / totalMem) * 100).toFixed(1),
            },
            disk_root: diskUsage.trim(),
            uptime_seconds: os.uptime(),
            load_average: os.loadavg(),
            hostname: os.hostname(),
            platform: os.platform(),
            arch: os.arch(),
          },
        };
      }
      case "get_services": {
        const services = ["trident", "ollama", "trident-voice", "trident-imagegen"];
        const results: Record<string, string> = {};
        for (const svc of services) {
          try {
            const { stdout } = await execAsync(`systemctl is-active ${svc}`, { timeout: 5000 });
            results[svc] = stdout.trim();
          } catch {
            results[svc] = "inactive";
          }
        }
        return { success: true, data: { services: results } };
      }
      case "get_disk_usage": {
        try {
          const { stdout } = await execAsync("df -h", { timeout: 5000 });
          const lines = stdout.trim().split("\n");
          const header = lines[0];
          const entries = lines.slice(1).map((line) => {
            const parts = line.trim().split(/\s+/);
            return {
              filesystem: parts[0],
              size: parts[1],
              used: parts[2],
              available: parts[3],
              use_pct: parts[4],
              mounted_on: parts[5],
            };
          });
          return { success: true, data: { entries } };
        } catch (err: any) {
          return { success: false, error: err.message };
        }
      }
      case "run_command": {
        // Admin only
        const user = await storage.getUser(userId);
        if (!user || user.role !== "admin") {
          return { error: "ADMIN CLEARANCE REQUIRED", success: false };
        }
        if (!params?.command) return { error: "command required", success: false };
        
        const cmd = params.command.trim();
        const isAllowed = ALLOWED_COMMANDS.some((allowed) => cmd.startsWith(allowed));
        if (!isAllowed) {
          return { error: `Command not in whitelist. Allowed: ${ALLOWED_COMMANDS.join(", ")}`, success: false };
        }
        
        try {
          const { stdout, stderr } = await execAsync(cmd, { timeout: 10000 });
          return { success: true, data: { stdout: stdout.trim(), stderr: stderr.trim() } };
        } catch (err: any) {
          return { success: false, error: err.message, data: { stdout: err.stdout || "", stderr: err.stderr || "" } };
        }
      }
      default:
        return { error: `Unknown system action: ${action}`, success: false };
    }
  }

  // POST /api/tools/execute — Execute a tool action
  app.post("/api/tools/execute", requireAuth, async (req, res) => {
    try {
      const { tool_name, action, params } = req.body;
      if (!tool_name || !action) {
        return res.status(400).json({ error: "TOOL NAME AND ACTION REQUIRED" });
      }
      const result = await executeTool(tool_name, action, params || {}, req.user!.id);
      res.json(result);
    } catch (err: any) {
      res.status(500).json({ error: err.message || "TOOL EXECUTION FAILED", success: false });
    }
  });

  // ═══════════════════════════════════════════════════
  // PHASE 8 — OLLAMA TOOL CALLING DEFINITIONS
  // ═══════════════════════════════════════════════════

  // ═══════════════════════════════════════════════════
  // PHASE 8 — SCHEDULED TASKS ROUTES
  // ═══════════════════════════════════════════════════

  // GET /api/tasks/runs/recent — recent runs across all tasks (must be before :id routes)
  app.get("/api/tasks/runs/recent", requireAuth, async (req, res) => {
    try {
      const runs = await storage.getRecentTaskRuns(req.user!.id, 50);
      res.json({ runs });
    } catch {
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  // GET /api/tasks — list user's scheduled tasks
  app.get("/api/tasks", requireAuth, async (req, res) => {
    try {
      const tasks = await storage.getUserScheduledTasks(req.user!.id);
      res.json({ tasks });
    } catch {
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  // POST /api/tasks — create a new scheduled task
  app.post("/api/tasks", requireAuth, async (req, res) => {
    try {
      const { name, description, tool_name, tool_action, tool_params, schedule_cron, alert_condition } = req.body;
      if (!name || !tool_name || !tool_action || !schedule_cron) {
        return res.status(400).json({ error: "MISSING REQUIRED FIELDS" });
      }
      const now = new Date().toISOString();
      const task = await storage.createScheduledTask({
        user_id: req.user!.id,
        name,
        description: description || "",
        tool_name,
        tool_action,
        tool_params: typeof tool_params === "string" ? tool_params : JSON.stringify(tool_params || {}),
        schedule_cron,
        is_active: 1,
        alert_condition: alert_condition ? (typeof alert_condition === "string" ? alert_condition : JSON.stringify(alert_condition)) : null,
        created_at: now,
      });
      // Schedule it
      await scheduleTask(task);
      res.status(201).json(task);
    } catch {
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  // PATCH /api/tasks/:id — update task
  app.patch("/api/tasks/:id", requireAuth, async (req, res) => {
    try {
      const taskId = parseInt(String(req.params.id), 10);
      if (isNaN(taskId)) return res.status(400).json({ error: "INVALID TASK ID" });

      const existing = await storage.getScheduledTask(taskId, req.user!.id);
      if (!existing) return res.status(404).json({ error: "TASK NOT FOUND" });

      const updates: any = {};
      if (req.body.name !== undefined) updates.name = req.body.name;
      if (req.body.description !== undefined) updates.description = req.body.description;
      if (req.body.tool_name !== undefined) updates.tool_name = req.body.tool_name;
      if (req.body.tool_action !== undefined) updates.tool_action = req.body.tool_action;
      if (req.body.tool_params !== undefined) updates.tool_params = typeof req.body.tool_params === "string" ? req.body.tool_params : JSON.stringify(req.body.tool_params);
      if (req.body.schedule_cron !== undefined) updates.schedule_cron = req.body.schedule_cron;
      if (req.body.is_active !== undefined) updates.is_active = req.body.is_active ? 1 : 0;
      if (req.body.alert_condition !== undefined) updates.alert_condition = req.body.alert_condition ? (typeof req.body.alert_condition === "string" ? req.body.alert_condition : JSON.stringify(req.body.alert_condition)) : null;

      const updated = await storage.updateScheduledTask(taskId, req.user!.id, updates);
      if (!updated) return res.status(404).json({ error: "TASK NOT FOUND" });

      // Reschedule
      if (updated.is_active) {
        await scheduleTask(updated);
      } else {
        unscheduleTask(updated.id);
      }

      res.json(updated);
    } catch {
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  // DELETE /api/tasks/:id — delete task
  app.delete("/api/tasks/:id", requireAuth, async (req, res) => {
    try {
      const taskId = parseInt(String(req.params.id), 10);
      if (isNaN(taskId)) return res.status(400).json({ error: "INVALID TASK ID" });

      unscheduleTask(taskId);
      const deleted = await storage.deleteScheduledTask(taskId, req.user!.id);
      if (!deleted) return res.status(404).json({ error: "TASK NOT FOUND" });

      res.json({ message: "TASK PURGED" });
    } catch {
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  // GET /api/tasks/:id/runs — get run history
  app.get("/api/tasks/:id/runs", requireAuth, async (req, res) => {
    try {
      const taskId = parseInt(String(req.params.id), 10);
      if (isNaN(taskId)) return res.status(400).json({ error: "INVALID TASK ID" });

      const runs = await storage.getTaskRuns(taskId, req.user!.id, 20);
      res.json({ runs });
    } catch {
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  // POST /api/tasks/:id/run — manually trigger a task run
  app.post("/api/tasks/:id/run", requireAuth, async (req, res) => {
    try {
      const taskId = parseInt(String(req.params.id), 10);
      if (isNaN(taskId)) return res.status(400).json({ error: "INVALID TASK ID" });

      const task = await storage.getScheduledTask(taskId, req.user!.id);
      if (!task) return res.status(404).json({ error: "TASK NOT FOUND" });

      const result = await executeTask(task);
      res.json(result);
    } catch {
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  // ═══════════════════════════════════════════════════
  // SYSTEM CONFIG — Hardware acceleration (GPU/CPU toggle)
  // ═══════════════════════════════════════════════════

  // GET /api/system/config — get all system config + detected GPU info
  app.get("/api/system/config", requireAdmin, async (_req, res) => {
    try {
      const config = await storage.getAllSystemConfig();
      
      // Detect if GPU is available via nvidia-smi
      const { exec } = await import("child_process");
      const gpuInfo = await new Promise<{ available: boolean; name: string; vram: string; driver: string }>((resolve) => {
        exec("nvidia-smi --query-gpu=name,memory.total,driver_version --format=csv,noheader,nounits", { timeout: 5000 }, (err, stdout) => {
          if (err || !stdout.trim()) {
            resolve({ available: false, name: "NONE", vram: "0", driver: "N/A" });
          } else {
            const parts = stdout.trim().split(", ");
            resolve({
              available: true,
              name: parts[0] || "Unknown GPU",
              vram: parts[1] ? `${Math.round(parseInt(parts[1]) / 1024)}GB` : "Unknown",
              driver: parts[2] || "Unknown",
            });
          }
        });
      });

      res.json({
        config,
        gpu: gpuInfo,
        defaults: {
          ollama_device: "auto",
          whisper_device: "cpu",
          imagegen_backend: "cpu",
        }
      });
    } catch {
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  // POST /api/system/config — update a config value and apply it
  app.post("/api/system/config", requireAdmin, async (req, res) => {
    try {
      const { key, value } = req.body as { key: string; value: string };
      if (!key || value === undefined) return res.status(400).json({ error: "MISSING KEY OR VALUE" });

      await storage.setSystemConfig(key, value);

      // Apply the change immediately based on the key
      const { exec } = await import("child_process");
      let applied = false;
      let message = "";

      if (key === "whisper_device") {
        // Patch voice service and restart
        const device = value === "gpu" ? "cuda" : "cpu";
        exec(`sed -i "s/device='cpu'/device='${device}'/g; s/device='cuda'/device='${device}'/g" /opt/trident-voice/voice_service.py && systemctl restart trident-voice`, 
          { timeout: 10000 }, (err) => {
          if (err) console.error("[GPU] Voice service restart failed:", err.message);
        });
        applied = true;
        message = `Voice STT switched to ${device.toUpperCase()}`;
      }

      if (key === "imagegen_backend") {
        if (value === "gpu") {
          exec("systemctl stop trident-imagegen && bash /opt/trident/scripts/setup-imagegen.sh && systemctl start trident-imagegen",
            { timeout: 600000 }, (err) => {
            if (err) console.error("[GPU] Image gen GPU setup failed:", err.message);
          });
          message = "Image generation switching to GPU (A1111) — this takes 5-10 minutes on first run";
        } else {
          exec("systemctl stop trident-imagegen && /opt/trident-imagegen/venv/bin/python3 /opt/trident-imagegen/imagegen_service.py &",
            { timeout: 10000 }, (err) => {
            if (err) console.error("[GPU] Image gen CPU restart failed:", err.message);
          });
          message = "Image generation switched to CPU";
        }
        applied = true;
      }

      if (key === "ollama_device") {
        // Ollama auto-detects GPU — just restart it
        exec("systemctl restart ollama", { timeout: 15000 }, (err) => {
          if (err) console.error("[GPU] Ollama restart failed:", err.message);
        });
        applied = true;
        message = "Ollama restarting — will auto-detect GPU";
      }

      res.json({ success: true, applied, message: message || `Config ${key} updated` });
    } catch {
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  // GET /api/system/gpu-status — live GPU stats
  app.get("/api/system/gpu-status", requireAuth, async (_req, res) => {
    try {
      const { exec } = await import("child_process");
      const stats = await new Promise<any>((resolve) => {
        exec("nvidia-smi --query-gpu=name,temperature.gpu,utilization.gpu,memory.used,memory.total,power.draw --format=csv,noheader,nounits", 
          { timeout: 5000 }, (err, stdout) => {
          if (err || !stdout.trim()) {
            resolve({ available: false });
          } else {
            const [name, temp, util, memUsed, memTotal, power] = stdout.trim().split(", ");
            resolve({
              available: true,
              name: name?.trim(),
              temperature: parseInt(temp) || 0,
              utilization: parseInt(util) || 0,
              memory_used_mb: parseInt(memUsed) || 0,
              memory_total_mb: parseInt(memTotal) || 0,
              memory_used_pct: Math.round((parseInt(memUsed) / parseInt(memTotal)) * 100) || 0,
              power_draw_w: parseFloat(power) || 0,
            });
          }
        });
      });
      res.json(stats);
    } catch {
      res.json({ available: false });
    }
  });


  // ═══════════════════════════════════════════════════
  // INTELLIGENCE — Markets & Daily Brief (Phase 1)
  // ═══════════════════════════════════════════════════
  const MARKET_BASE = "http://localhost:5002";

  // Helper: proxy a GET request to the Python market service with timeout
  async function proxyMarkets(reqPath: string): Promise<any> {
    const res = await fetch(`${MARKET_BASE}${reqPath}`, {
      signal: AbortSignal.timeout(30000),
    });
    if (!res.ok) throw new Error(`Market service error: ${res.status}`);
    return res.json();
  }

  // GET /api/markets/status — TCP probe to market service on port 5002
  app.get("/api/markets/status", requireAuth, async (_req, res) => {
    const online = await new Promise<boolean>((resolve) => {
      const socket = new net.Socket();
      let done = false;
      const finish = (val: boolean) => {
        if (done) return;
        done = true;
        socket.destroy();
        resolve(val);
      };
      socket.setTimeout(2000);
      socket.once("connect", () => finish(true));
      socket.once("timeout", () => finish(false));
      socket.once("error", () => finish(false));
      socket.connect(5002, "127.0.0.1");
    });
    res.json({ online, service: "TRIDENT Markets", port: 5002 });
  });

  // GET /api/markets/overview — indices, commodities, crypto, bonds, fx
  app.get("/api/markets/overview", requireAuth, async (_req, res) => {
    try {
      res.json(await proxyMarkets("/market-overview"));
    } catch (e: any) {
      res.status(502).json({ error: e?.message || "MARKET SERVICE OFFLINE" });
    }
  });

  // GET /api/markets/quote/:symbol
  app.get("/api/markets/quote/:symbol", requireAuth, async (req, res) => {
    try {
      const symbol = encodeURIComponent(String(req.params.symbol));
      res.json(await proxyMarkets(`/quote/${symbol}`));
    } catch (e: any) {
      res.status(502).json({ error: e?.message || "MARKET SERVICE OFFLINE" });
    }
  });

  // GET /api/markets/history/:symbol?period=&interval=
  app.get("/api/markets/history/:symbol", requireAuth, async (req, res) => {
    try {
      const symbol = encodeURIComponent(String(req.params.symbol));
      const period = encodeURIComponent(String(req.query.period || "1mo"));
      const interval = encodeURIComponent(String(req.query.interval || "1d"));
      res.json(await proxyMarkets(`/history/${symbol}?period=${period}&interval=${interval}`));
    } catch (e: any) {
      res.status(502).json({ error: e?.message || "MARKET SERVICE OFFLINE" });
    }
  });

  // GET /api/markets/quotes?symbols=
  app.get("/api/markets/quotes", requireAuth, async (req, res) => {
    try {
      const symbols = encodeURIComponent(String(req.query.symbols || ""));
      res.json(await proxyMarkets(`/quotes${symbols ? `?symbols=${symbols}` : ""}`));
    } catch (e: any) {
      res.status(502).json({ error: e?.message || "MARKET SERVICE OFFLINE" });
    }
  });

  // GET /api/markets/news?symbol=
  app.get("/api/markets/news", requireAuth, async (req, res) => {
    try {
      const symbol = String(req.query.symbol || "");
      res.json(await proxyMarkets(`/news${symbol ? `?symbol=${encodeURIComponent(symbol)}` : ""}`));
    } catch (e: any) {
      res.status(502).json({ error: e?.message || "MARKET SERVICE OFFLINE", news: [] });
    }
  });

  // GET /api/markets/macro — FRED indicators
  app.get("/api/markets/macro", requireAuth, async (_req, res) => {
    try {
      res.json(await proxyMarkets("/macro"));
    } catch (e: any) {
      res.status(502).json({ error: e?.message || "MARKET SERVICE OFFLINE", indicators: [] });
    }
  });

  // ─────────── Watchlist ───────────
  const DEFAULT_WATCHLIST: { symbol: string; name: string; category: string }[] = [
    { symbol: "SPY", name: "S&P 500 ETF", category: "index" },
    { symbol: "QQQ", name: "Nasdaq 100 ETF", category: "index" },
    { symbol: "BTC-USD", name: "Bitcoin", category: "crypto" },
    { symbol: "GLD", name: "Gold ETF", category: "commodity" },
    { symbol: "CL=F", name: "Crude Oil", category: "commodity" },
  ];

  // GET /api/markets/watchlist — user's watchlist (auto-seeds defaults if empty)
  app.get("/api/markets/watchlist", requireAuth, async (req, res) => {
    try {
      const userId = req.user!.id;
      let items = await storage.getWatchlist(userId);
      if (items.length === 0) {
        const now = new Date().toISOString();
        for (let i = 0; i < DEFAULT_WATCHLIST.length; i++) {
          const d = DEFAULT_WATCHLIST[i];
          await storage.addWatchlistItem({
            user_id: userId,
            symbol: d.symbol,
            name: d.name,
            category: d.category,
            display_order: i,
            created_at: now,
          });
        }
        items = await storage.getWatchlist(userId);
      }
      res.json({ watchlist: items });
    } catch {
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  const addWatchlistSchema = z.object({
    symbol: z.string().min(1).max(20),
    name: z.string().max(80).optional(),
    category: z.enum(["stock", "crypto", "commodity", "index", "fx"]).optional(),
  });

  // POST /api/markets/watchlist — add symbol
  app.post("/api/markets/watchlist", requireAuth, async (req, res) => {
    try {
      const userId = req.user!.id;
      const data = addWatchlistSchema.parse(req.body);
      const existing = await storage.getWatchlist(userId);
      const symbol = data.symbol.trim().toUpperCase();
      if (existing.some((w) => w.symbol.toUpperCase() === symbol)) {
        return res.status(409).json({ error: "SYMBOL ALREADY TRACKED" });
      }
      const item = await storage.addWatchlistItem({
        user_id: userId,
        symbol,
        name: data.name || "",
        category: data.category || "stock",
        display_order: existing.length,
        created_at: new Date().toISOString(),
      });
      res.json({ item });
    } catch (e: any) {
      if (e?.issues) return res.status(400).json({ error: "INVALID INPUT" });
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  // DELETE /api/markets/watchlist/:id
  app.delete("/api/markets/watchlist/:id", requireAuth, async (req, res) => {
    try {
      const id = parseInt(String(req.params.id), 10);
      const ok = await storage.removeWatchlistItem(id, req.user!.id);
      if (!ok) return res.status(404).json({ error: "NOT FOUND" });
      res.json({ success: true });
    } catch {
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  // ─────────── Daily Brief ───────────
  // GET /api/markets/brief — today's brief (or latest)
  app.get("/api/markets/brief", requireAuth, async (req, res) => {
    try {
      const userId = req.user!.id;
      const today = new Date().toISOString().slice(0, 10);
      let brief = await storage.getTodayBrief(userId, today);
      if (!brief) brief = await storage.getLatestBrief(userId);
      res.json({ brief: brief || null, today });
    } catch {
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  // GET /api/markets/briefs — list last 30 briefs
  app.get("/api/markets/briefs", requireAuth, async (req, res) => {
    try {
      const briefs = await storage.listBriefs(req.user!.id, 30);
      res.json({ briefs });
    } catch {
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  // POST /api/markets/brief/generate — generate a new brief via TRIDENT LLM
  app.post("/api/markets/brief/generate", requireAuth, async (req, res) => {
    try {
      const userId = req.user!.id;
      const today = new Date().toISOString().slice(0, 10);

      // Determine model from system config
      const configuredModel =
        (await storage.getSystemConfig("default_model")) ||
        (await storage.getSystemConfig("brief_model")) ||
        "llama3.2:latest";

      // Gather real-time data from the market service (best-effort)
      let overview: any = {};
      let macro: any = { indicators: [] };
      let news: any = { news: [] };
      try { overview = await proxyMarkets("/market-overview"); } catch { /* offline */ }
      try { macro = await proxyMarkets("/macro"); } catch { /* offline */ }
      try { news = await proxyMarkets("/news"); } catch { /* offline */ }

      const fmtOverview = Object.entries(overview || {})
        .map(([cat, arr]: [string, any]) =>
          `${cat.toUpperCase()}: ` +
          (Array.isArray(arr)
            ? arr.map((q: any) => `${q.symbol} ${q.price} (${q.change_pct >= 0 ? "+" : ""}${q.change_pct}%)`).join(", ")
            : ""))
        .join("\n") || "No market data available (service offline).";

      const fmtMacro = (macro.indicators || [])
        .map((m: any) => `${m.label}: ${m.value} (as of ${m.date}, prev ${m.prev_value})`)
        .join("\n") || "No macro data available.";

      const fmtNews = (news.news || [])
        .slice(0, 12)
        .map((n: any) => `- ${n.title} (${n.publisher})`)
        .join("\n") || "No headlines available.";

      const prompt = `You are TRIDENT, a tactical financial intelligence system. Generate a concise daily market brief based on the following real-time data.

MARKET OVERVIEW (as of ${today}):
${fmtOverview}

MACRO INDICATORS:
${fmtMacro}

RECENT NEWS HEADLINES:
${fmtNews}

Generate a structured brief with these sections:
1. MARKET SUMMARY — 2-3 sentences on overall market conditions
2. KEY MOVERS — Notable price movements and why
3. MACRO WATCH — Relevant economic data points
4. RISK FACTORS — Current threats to markets
5. TACTICAL OUTLOOK — Short-term view (1-5 days)

Keep it under 500 words. Use military/tactical language. Be direct and data-driven.`;

      // Call Ollama (non-streaming) for a complete brief
      const ollamaRes = await fetch(`${OLLAMA_BASE}/api/chat`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: configuredModel,
          messages: [{ role: "user", content: prompt }],
          stream: false,
          options: { temperature: 0.5, num_predict: 1024 },
        }),
        signal: AbortSignal.timeout(180000),
      });

      if (!ollamaRes.ok) {
        return res.status(502).json({ error: "LLM UNAVAILABLE — ensure Ollama is running" });
      }
      const ollamaData: any = await ollamaRes.json();
      const content: string = ollamaData?.message?.content?.trim() || "";
      if (!content) {
        return res.status(502).json({ error: "LLM RETURNED EMPTY BRIEF" });
      }

      const now = new Date().toISOString();
      const brief = await storage.createBrief({
        user_id: userId,
        date: today,
        content,
        model_used: configuredModel,
        created_at: now,
      });

      // Save to NAS markets folder
      try {
        const dir = "/mnt/trident-briefs/markets";
        fs.mkdirSync(dir, { recursive: true });
        fs.writeFileSync(path.join(dir, `market-brief-${today}.md`),
          `TRIDENT MARKET BRIEF \u2014 ${today}\nModel: ${brief.model_used}\n${'='.repeat(60)}\n\n${brief.content}\n\n${'='.repeat(60)}\nGENERATED BY TRIDENT // CLASSIFICATION: UNCLASSIFIED`,
          "utf8");
      } catch { /* NAS unavailable — brief still saved to SQLite */ }

      try { await storage.logOpsEvent("brief_generated", `Market brief generated (${brief.model_used})`, { type: "MARKET", topic: "DAILY BRIEF", model: brief.model_used }, userId); } catch { /* non-fatal */ }
      res.json({ id: brief.id, content: brief.content, date: brief.date, model_used: brief.model_used });
    } catch (e: any) {
      res.status(500).json({ error: e?.message || "BRIEF GENERATION FAILED" });
    }
  });

  // ═══════════════════════════════════════════════════
  // GEO-INTELLIGENCE (Phase 2) — proxies Python geo service on port 5003
  // ═══════════════════════════════════════════════════
  const GEO_BASE = "http://localhost:5003";

  // Helper: proxy a GET request to the Python geo service with timeout
  async function proxyGeo(reqPath: string): Promise<any> {
    const geoRes = await fetch(`${GEO_BASE}${reqPath}`, {
      signal: AbortSignal.timeout(20000),
    });
    if (!geoRes.ok) throw new Error(`Geo service error: ${geoRes.status}`);
    return geoRes.json();
  }

  // GET /api/geo/status — TCP probe to geo service on port 5003
  app.get("/api/geo/status", requireAuth, async (_req, res) => {
    const online = await new Promise<boolean>((resolve) => {
      const socket = new net.Socket();
      let done = false;
      const finish = (val: boolean) => {
        if (done) return;
        done = true;
        socket.destroy();
        resolve(val);
      };
      socket.setTimeout(2000);
      socket.once("connect", () => finish(true));
      socket.once("timeout", () => finish(false));
      socket.once("error", () => finish(false));
      socket.connect(5003, "127.0.0.1");
    });
    res.json({ online, service: "TRIDENT Geo-Intelligence", port: 5003 });
  });

  // GET /api/geo/events — recent ACLED conflict events
  app.get("/api/geo/events", requireAuth, async (_req, res) => {
    try {
      res.json(await proxyGeo("/acled/events"));
    } catch (e: any) {
      res.status(502).json({ error: e?.message || "GEO SERVICE OFFLINE", events: [], count: 0 });
    }
  });

  // GET /api/geo/summary — ACLED conflict stats by country
  app.get("/api/geo/summary", requireAuth, async (_req, res) => {
    try {
      res.json(await proxyGeo("/acled/summary"));
    } catch (e: any) {
      res.status(502).json({ error: e?.message || "GEO SERVICE OFFLINE", summary: [] });
    }
  });

  // GET /api/geo/threat-summary — aggregated threat data for dashboard
  app.get("/api/geo/threat-summary", requireAuth, async (_req, res) => {
    try {
      res.json(await proxyGeo("/threat-summary"));
    } catch (e: any) {
      res.status(502).json({ error: e?.message || "GEO SERVICE OFFLINE", acled: {} });
    }
  });

  // GET /api/geo/news/military — military/defense RSS feeds
  app.get("/api/geo/news/military", requireAuth, async (_req, res) => {
    try {
      res.json(await proxyGeo("/news/military"));
    } catch (e: any) {
      res.status(502).json({ error: e?.message || "GEO SERVICE OFFLINE", articles: [] });
    }
  });

  // GET /api/geo/news/geopolitical — geopolitical RSS feeds
  app.get("/api/geo/news/geopolitical", requireAuth, async (_req, res) => {
    try {
      res.json(await proxyGeo("/news/geopolitical"));
    } catch (e: any) {
      res.status(502).json({ error: e?.message || "GEO SERVICE OFFLINE", articles: [] });
    }
  });

  // GET /api/geo/brief — today's geo brief (or latest)
  app.get("/api/geo/brief", requireAuth, async (req, res) => {
    try {
      const userId = req.user!.id;
      const today = new Date().toISOString().slice(0, 10);
      let brief = await storage.getTodayGeoBrief(userId, today);
      if (!brief) brief = await storage.getLatestGeoBrief(userId);
      res.json({ brief: brief || null, today });
    } catch {
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  // GET /api/geo/briefs — list user's last 20 geo briefs
  app.get("/api/geo/briefs", requireAuth, async (req, res) => {
    try {
      const briefs = await storage.listGeoBriefs(req.user!.id, 20);
      res.json({ briefs });
    } catch {
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  // POST /api/geo/brief/generate — generate a geo-intel brief via TRIDENT LLM
  app.post("/api/geo/brief/generate", requireAuth, async (req, res) => {
    try {
      const userId = req.user!.id;
      const today = new Date().toISOString().slice(0, 10);

      const configuredModel =
        (await storage.getSystemConfig("default_model")) ||
        (await storage.getSystemConfig("brief_model")) ||
        "llama3.2:latest";

      // Gather real-time geo data (best-effort)
      let threat: any = { acled: {} };
      let mil: any = { articles: [] };
      try { threat = await proxyGeo("/threat-summary"); } catch { /* offline */ }
      try { mil = await proxyGeo("/news/military"); } catch { /* offline */ }

      const acled = threat?.acled || {};
      const totalEvents = acled?.total_events_7d ?? 0;
      const totalFatalities = acled?.total_fatalities_7d ?? 0;
      const hotspotsList =
        (acled?.top_hotspots || [])
          .map((h: any) => `${h.country} (${h.events} events)`)
          .join(", ") || "No conflict data available (service offline or ACLED not configured).";
      const topHeadlines =
        (mil?.articles || [])
          .slice(0, 5)
          .map((a: any) => `- ${a.title} (${a.source})`)
          .join("\n") || "No military headlines available.";

      const prompt = `You are TRIDENT, a military intelligence analyst with TOP SECRET clearance.
Generate a classified geo-intelligence brief based on real conflict data.

CONFLICT DATA (last 7 days):
Total events: ${totalEvents}
Total fatalities: ${totalFatalities}
Top conflict zones: ${hotspotsList}

RECENT MILITARY HEADLINES:
${topHeadlines}

Generate a structured brief:
1. THREAT ASSESSMENT — Overall global threat level and key concerns
2. ACTIVE CONFLICT ZONES — Top 3 hotspots with brief analysis
3. EMERGING THREATS — Situations to monitor
4. STRATEGIC IMPLICATIONS — Impact on global stability
5. TACTICAL RECOMMENDATIONS — Suggested monitoring priorities

Classification: TOP SECRET // TRIDENT
Keep under 400 words. Use military/intelligence language.`;

      const ollamaRes = await fetch(`${OLLAMA_BASE}/api/chat`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: configuredModel,
          messages: [{ role: "user", content: prompt }],
          stream: false,
          options: { temperature: 0.5, num_predict: 1024 },
        }),
        signal: AbortSignal.timeout(180000),
      });

      if (!ollamaRes.ok) {
        return res.status(502).json({ error: "LLM UNAVAILABLE — ensure Ollama is running" });
      }
      const ollamaData: any = await ollamaRes.json();
      const content: string = ollamaData?.message?.content?.trim() || "";
      if (!content) {
        return res.status(502).json({ error: "LLM RETURNED EMPTY BRIEF" });
      }

      const now = new Date().toISOString();
      const brief = await storage.createGeoBrief({
        user_id: userId,
        date: today,
        content,
        model_used: configuredModel,
        region_focus: "GLOBAL",
        created_at: now,
      });

      // Save to NAS geo-intel folder
      try {
        const dir = "/mnt/trident-briefs/geo-intel";
        fs.mkdirSync(dir, { recursive: true });
        fs.writeFileSync(path.join(dir, `geo-brief-${today}.md`),
          `TRIDENT GEO-INTEL BRIEF \u2014 ${today}\nModel: ${brief.model_used}\nRegion: GLOBAL\n${'='.repeat(60)}\n\n${brief.content}\n\n${'='.repeat(60)}\nGENERATED BY TRIDENT // CLASSIFICATION: TOP SECRET // GEO-INTELLIGENCE`,
          "utf8");
      } catch { /* NAS unavailable — brief still saved to SQLite */ }

      try { await storage.logOpsEvent("brief_generated", `Geo-intel brief generated (${brief.model_used})`, { type: "GEO-INTEL", topic: (brief as any).region_focus || "GLOBAL", model: brief.model_used }, userId); } catch { /* non-fatal */ }
      res.json({ id: brief.id, content: brief.content, date: brief.date, model_used: brief.model_used });
    } catch (e: any) {
      res.status(500).json({ error: e?.message || "GEO BRIEF GENERATION FAILED" });
    }
  });

  // ═══════════════════════════════════════════════════
  // FLIGHT INTELLIGENCE (Phase 6) — proxies Python flight service on port 5004
  // Primary source: OpenSky Network. Fallback: local dump1090 SDR.
  // ═══════════════════════════════════════════════════
  const FLIGHT_BASE = "http://localhost:5004";

  // Helper: proxy a GET request to the Python flight service with timeout
  async function proxyFlights(reqPath: string): Promise<any> {
    const flightRes = await fetch(`${FLIGHT_BASE}${String(reqPath)}`, {
      signal: AbortSignal.timeout(20000),
    });
    if (!flightRes.ok) throw new Error(`Flight service error: ${flightRes.status}`);
    return flightRes.json();
  }

  // GET /api/flights/status — TCP probe to flight service on port 5004
  app.get("/api/flights/status", requireAuth, async (_req, res) => {
    const online = await new Promise<boolean>((resolve) => {
      const socket = new net.Socket();
      let done = false;
      const finish = (val: boolean) => {
        if (done) return;
        done = true;
        socket.destroy();
        resolve(val);
      };
      socket.setTimeout(2000);
      socket.once("connect", () => finish(true));
      socket.once("timeout", () => finish(false));
      socket.once("error", () => finish(false));
      socket.connect(5004, "127.0.0.1");
    });
    res.json({ online, service: "TRIDENT Flight Intelligence", port: 5004 });
  });

  // GET /api/flights/live — live aircraft overhead (proxy /aircraft)
  app.get("/api/flights/live", requireAuth, async (_req, res) => {
    try {
      res.json(await proxyFlights("/aircraft"));
    } catch (e: any) {
      res.status(502).json({ error: e?.message || "FLIGHT SERVICE OFFLINE", aircraft: [], count: 0, source: "offline" });
    }
  });

  // GET /api/flights/history — recorded flight log (proxy /history)
  app.get("/api/flights/history", requireAuth, async (req, res) => {
    try {
      const limit = String(req.query.limit ?? "50");
      const offset = String(req.query.offset ?? "0");
      const date = String(req.query.date ?? "");
      const qs = new URLSearchParams({ limit, offset });
      if (date) qs.set("date", date);
      res.json(await proxyFlights(`/history?${qs.toString()}`));
    } catch (e: any) {
      res.status(502).json({ error: e?.message || "FLIGHT SERVICE OFFLINE", flights: [], total: 0 });
    }
  });

  // GET /api/flights/stats — aggregate stats (proxy /stats)
  app.get("/api/flights/stats", requireAuth, async (_req, res) => {
    try {
      res.json(await proxyFlights("/stats"));
    } catch (e: any) {
      res.status(502).json({ error: e?.message || "FLIGHT SERVICE OFFLINE" });
    }
  });

  // GET /api/flights/health — service health + data source (proxy /health)
  app.get("/api/flights/health", requireAuth, async (_req, res) => {
    try {
      res.json(await proxyFlights("/health"));
    } catch (e: any) {
      res.status(502).json({ error: e?.message || "FLIGHT SERVICE OFFLINE", status: "offline", data_source: "offline" });
    }
  });

  // POST /api/flights/brief/generate — generate aviation brief via LLM, save to NAS aviation folder
  app.post("/api/flights/brief/generate", requireAuth, async (req, res) => {
    try {
      const hours = String(req.body?.hours ?? "24");
      const date = String(req.body?.date ?? "");
      const qs = date ? `?date=${encodeURIComponent(date)}` : `?hours=${encodeURIComponent(hours)}`;
      const flightRes = await fetch(`${FLIGHT_BASE}/brief/data${qs}`, { signal: AbortSignal.timeout(15000) });
      if (!flightRes.ok) throw new Error("Flight service unavailable");
      const flightData: any = await flightRes.json();
      const stats = flightData.stats || {};
      const flights: any[] = flightData.flights || [];
      const period = date ? `DATE: ${date}` : `LAST ${hours} HOURS`;
      const today = new Date().toLocaleDateString("en-US", { weekday: "long", year: "numeric", month: "long", day: "numeric", timeZone: "America/New_York" });
      const now = new Date().toLocaleString("en-US", { timeZone: "America/New_York" });
      const manifest = flights.slice(0, 20).map((f: any) =>
        `  ${((f.callsign || "UNKNOWN") as string).padEnd(10)} | ${String(Math.round((f.altitude_m || 0) * 3.28084)).padStart(6)} FT | ${String(Math.round((f.velocity_ms || 0) * 1.94384)).padStart(4)} KTS | ${String(f.distance_nm || 0).padStart(5)} NM | ${f.origin_country || "Unknown"}`
      ).join("\n");
      const closest = stats.closest_approach;
      const closestStr = closest
        ? `${((closest.callsign || "UNKNOWN") as string).trim()} at ${stats.closest_distance_nm} NM, ${Math.round((closest.altitude_m || 0) * 3.28084)} FT`
        : "None recorded";
      const prompt = `You are TRIDENT, a military aviation intelligence analyst. Generate a professional aviation activity brief for the airspace over Denton, NC (Davidson County) \u2014 monitoring radius 25 nautical miles.\n\nPERIOD: ${period}\nGENERATED: ${now}\n\nAVIATION STATISTICS:\n- Total aircraft recorded: ${stats.total_flights}\n- Maximum altitude observed: ${stats.max_altitude_ft} ft\n- Maximum speed observed: ${stats.max_speed_kts} kts\n- Closest approach to Denton: ${closestStr}\n- Top origin countries: ${(stats.top_countries || []).map((c: any) => `${c.country} (${c.count})`).join(", ") || "N/A"}\n- Most active callsigns: ${(stats.top_callsigns || []).slice(0, 5).map((c: any) => `${c.callsign} (${c.count}x)`).join(", ") || "N/A"}\n\nFLIGHT MANIFEST (sample \u2014 ${flights.length} total):\n  CALLSIGN   |    ALT    | SPEED | DIST  | COUNTRY\n${manifest || "  No flights recorded in this period"}\n\nGenerate a structured aviation brief with:\n1. EXECUTIVE SUMMARY \u2014 overall activity level and notable observations\n2. TRAFFIC ANALYSIS \u2014 volume, patterns, altitude distribution\n3. NOTABLE AIRCRAFT \u2014 any unusual callsigns, squawk codes, or flight patterns\n4. CLOSEST APPROACHES \u2014 aircraft that came within 10nm of Denton\n5. COUNTRY OF ORIGIN BREAKDOWN \u2014 fleet composition analysis\n6. AIRSPACE ASSESSMENT \u2014 overall airspace characterization\n\nClassification: UNCLASSIFIED // AVIATION INTELLIGENCE\nLocation: Denton, NC \u2014 Davidson County Airspace\nKeep under 500 words. Use military/aviation language.`;
      const model = (await storage.getSystemConfig("defaultModel")) || "llama3.2";
      const ollamaRes = await fetch("http://localhost:11434/api/generate", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ model, prompt, stream: false }),
        signal: AbortSignal.timeout(120000)
      });
      if (!ollamaRes.ok) throw new Error("Ollama unavailable");
      const ollamaData: any = await ollamaRes.json();
      const content: string = ollamaData.response || "Brief generation failed.";
      const dateStr = new Date().toISOString().slice(0, 10);
      const briefText = `TRIDENT AVIATION BRIEF \u2014 ${today}\nPeriod: ${period}\nGenerated: ${now}\nLocation: Denton, NC \u2014 Davidson County Airspace (25nm radius)\n${'='.repeat(60)}\n\n${content}\n\n${'='.repeat(60)}\nFULL MANIFEST: ${stats.total_flights} aircraft recorded\n${manifest}\n${'='.repeat(60)}\nGENERATED BY TRIDENT // ${model.toUpperCase()}\nCLASSIFICATION: UNCLASSIFIED // AVIATION INTELLIGENCE`;
      let savedPath: string | null = null;
      try {
        const dir = "/mnt/trident-briefs/aviation";
        fs.mkdirSync(dir, { recursive: true });
        const fname = date ? `aviation-brief-${date}.md` : `aviation-brief-${dateStr}-${hours}h.md`;
        fs.writeFileSync(path.join(dir, fname), briefText, "utf8");
        savedPath = `aviation\\${fname}`;
      } catch { /* NAS unavailable */ }
      try { await storage.logOpsEvent("brief_generated", `Aviation brief generated (${model})`, { type: "AVIATION", topic: `${hours}H REPORT`, model }, req.user?.id); } catch { /* non-fatal */ }
      res.json({ content, date: dateStr, period, model_used: model, saved_to_nas: !!savedPath, nas_path: savedPath, stats });
    } catch (e: any) {
      res.status(500).json({ error: e?.message || "Aviation brief generation failed" });
    }
  });

  // GET /api/flights/storage — DB storage info (proxy /storage)
  app.get("/api/flights/storage", requireAuth, async (_req, res) => {
    try {
      res.json(await proxyFlights("/storage"));
    } catch (e: any) {
      res.status(502).json({ error: e?.message || "FLIGHT SERVICE OFFLINE", db_size_mb: 0, total_records: 0 });
    }
  });

  // GET /api/flights/export/csv — stream CSV export from flight service
  app.get("/api/flights/export/csv", requireAuth, async (req, res) => {
    try {
      const date = String(req.query.date ?? "");
      const qs = date ? `?date=${encodeURIComponent(date)}` : "";
      const upstream = await fetch(`${FLIGHT_BASE}/export/csv${qs}`, {
        signal: AbortSignal.timeout(30000),
      });
      if (!upstream.ok) throw new Error(`Flight service error: ${upstream.status}`);
      const body = await upstream.text();
      const fname = `trident-flights-${date || new Date().toISOString().slice(0, 10)}.csv`;
      res.setHeader("Content-Type", "text/csv");
      res.setHeader("Content-Disposition", `attachment; filename="${fname}"`);
      res.send(body);
    } catch (e: any) {
      res.status(502).json({ error: e?.message || "FLIGHT SERVICE OFFLINE" });
    }
  });

  // GET /api/flights/export/json — stream JSON export from flight service
  app.get("/api/flights/export/json", requireAuth, async (req, res) => {
    try {
      const date = String(req.query.date ?? "");
      const qs = date ? `?date=${encodeURIComponent(date)}` : "";
      const upstream = await fetch(`${FLIGHT_BASE}/export/json${qs}`, {
        signal: AbortSignal.timeout(30000),
      });
      if (!upstream.ok) throw new Error(`Flight service error: ${upstream.status}`);
      const body = await upstream.text();
      const fname = `trident-flights-${date || new Date().toISOString().slice(0, 10)}.json`;
      res.setHeader("Content-Type", "application/json");
      res.setHeader("Content-Disposition", `attachment; filename="${fname}"`);
      res.send(body);
    } catch (e: any) {
      res.status(502).json({ error: e?.message || "FLIGHT SERVICE OFFLINE" });
    }
  });

  // DELETE /api/flights/clear — clear flight history (admin only, safety-gated)
  app.delete("/api/flights/clear", requireAuth, requireAdmin, async (req, res) => {
    try {
      const date = String(req.query.date ?? "");
      const before = String(req.query.before ?? "");
      const qs = new URLSearchParams();
      if (date) qs.set("date", date);
      if (before) qs.set("before", before);
      const url = `${FLIGHT_BASE}/clear${qs.toString() ? `?${qs.toString()}` : ""}`;
      const upstream = await fetch(url, {
        method: "DELETE",
        headers: { "X-Trident-Confirm": "CLEAR" },
        signal: AbortSignal.timeout(30000),
      });
      const data = await upstream.json().catch(() => ({}));
      res.status(upstream.ok ? 200 : upstream.status).json(data);
    } catch (e: any) {
      res.status(502).json({ error: e?.message || "FLIGHT SERVICE OFFLINE", deleted: 0 });
    }
  });

  // ═══════════════════════════════════════════════════
  // WEATHER INTELLIGENCE (Phase 7) — proxy to Python weather service on port 5005
  // ═══════════════════════════════════════════════════
  const WEATHER_BASE = "http://localhost:5005";

  // Helper: proxy a GET request to the Python weather service with timeout
  async function proxyWeather(reqPath: string): Promise<any> {
    const weatherRes = await fetch(`${WEATHER_BASE}${String(reqPath)}`, {
      signal: AbortSignal.timeout(20000),
    });
    if (!weatherRes.ok) throw new Error(`Weather service error: ${weatherRes.status}`);
    return weatherRes.json();
  }

  // GET /api/weather/status — TCP probe to weather service on port 5005
  app.get("/api/weather/status", requireAuth, async (_req, res) => {
    const online = await new Promise<boolean>((resolve) => {
      const socket = new net.Socket();
      let done = false;
      const finish = (val: boolean) => {
        if (done) return;
        done = true;
        socket.destroy();
        resolve(val);
      };
      socket.setTimeout(2000);
      socket.once("connect", () => finish(true));
      socket.once("timeout", () => finish(false));
      socket.once("error", () => finish(false));
      socket.connect(5005, "127.0.0.1");
    });
    res.json({ online, service: "TRIDENT Weather Intelligence", port: 5005 });
  });

  // GET /api/weather/current — current conditions (proxy /current)
  app.get("/api/weather/current", requireAuth, async (_req, res) => {
    try {
      res.json(await proxyWeather("/current"));
    } catch (e: any) {
      res.status(502).json({ error: e?.message || "WEATHER SERVICE OFFLINE" });
    }
  });

  // GET /api/weather/forecast — 7-day forecast (proxy /forecast)
  app.get("/api/weather/forecast", requireAuth, async (_req, res) => {
    try {
      res.json(await proxyWeather("/forecast"));
    } catch (e: any) {
      res.status(502).json({ error: e?.message || "WEATHER SERVICE OFFLINE" });
    }
  });

  // GET /api/weather/alerts — NOAA alerts (proxy /alerts)
  app.get("/api/weather/alerts", requireAuth, async (_req, res) => {
    try {
      res.json(await proxyWeather("/alerts"));
    } catch (e: any) {
      res.status(502).json({ error: e?.message || "WEATHER SERVICE OFFLINE", alerts: [], count: 0 });
    }
  });

  // GET /api/weather/radar-tiles — radar tile URL templates (proxy /radar-tiles)
  app.get("/api/weather/radar-tiles", requireAuth, async (_req, res) => {
    try {
      res.json(await proxyWeather("/radar-tiles"));
    } catch (e: any) {
      res.status(502).json({ error: e?.message || "WEATHER SERVICE OFFLINE" });
    }
  });

  // GET /api/weather/satellite-tiles — satellite tile URL templates (proxy /satellite-tiles)
  app.get("/api/weather/satellite-tiles", requireAuth, async (_req, res) => {
    try {
      res.json(await proxyWeather("/satellite-tiles"));
    } catch (e: any) {
      res.status(502).json({ error: e?.message || "WEATHER SERVICE OFFLINE" });
    }
  });

  // GET /api/weather/astronomy — sunrise/sunset (proxy /astronomy)
  app.get("/api/weather/astronomy", requireAuth, async (_req, res) => {
    try {
      res.json(await proxyWeather("/astronomy"));
    } catch (e: any) {
      res.status(502).json({ error: e?.message || "WEATHER SERVICE OFFLINE" });
    }
  });

  // POST /api/weather/brief/generate — generate daily weather brief via LLM, save to NAS \briefs\weather
  app.post("/api/weather/brief/generate", requireAuth, async (req, res) => {
    try {
      // Fetch current conditions + forecast + alerts
      const [current, forecast, alerts, astronomy] = await Promise.allSettled([
        proxyWeather("/current"),
        proxyWeather("/forecast"),
        proxyWeather("/alerts"),
        proxyWeather("/astronomy")
      ]);
      const cur = current.status === "fulfilled" ? current.value : {};
      const fcast = forecast.status === "fulfilled" ? forecast.value : {};
      const alrt = alerts.status === "fulfilled" ? alerts.value : { alerts: [] };
      const astro = astronomy.status === "fulfilled" ? astronomy.value : {};

      // Build prompt context
      const today = new Date().toLocaleDateString("en-US", { weekday: "long", year: "numeric", month: "long", day: "numeric", timeZone: "America/New_York" });
      const daily = fcast?.daily || {};
      const day0 = {
        high: daily.temperature_2m_max?.[0] ?? "N/A",
        low: daily.temperature_2m_min?.[0] ?? "N/A",
        precip: daily.precipitation_probability_max?.[0] ?? 0,
        wind: daily.wind_speed_10m_max?.[0] ?? 0,
        code: daily.weather_code?.[0] ?? 0,
      };
      const alertList = (alrt.alerts || []).map((a: any) => `- ${a.event}: ${a.headline}`).join("\n") || "None";

      const prompt = `You are TRIDENT, a tactical intelligence system. Generate a professional daily weather brief for Denton, NC (Davidson County) for ${today}.

CURRENT CONDITIONS:
- Temperature: ${cur.temperature_f}°F (Feels like ${cur.feels_like_f}°F)
- Condition: ${cur.condition}
- Humidity: ${cur.humidity_pct}%
- Wind: ${cur.wind_speed_mph} MPH ${cur.wind_direction_deg ? 'from ' + cur.wind_direction_deg + '°' : ''}, Gusts ${cur.wind_gust_mph} MPH
- Visibility: ${cur.visibility_m ? (cur.visibility_m / 1000).toFixed(1) + ' km' : 'N/A'}
- Pressure: ${cur.surface_pressure_hpa} hPa

DAY FORECAST:
- High: ${day0.high}°F | Low: ${day0.low}°F
- Precipitation Probability: ${day0.precip}%
- Max Wind: ${day0.wind} MPH

SUNRISE/SUNSET:
- Sunrise: ${astro.sunrise || 'N/A'}
- Sunset: ${astro.sunset || 'N/A'}

ACTIVE NOAA ALERTS:
${alertList}

Generate a structured weather brief with:
1. EXECUTIVE SUMMARY — one paragraph overview
2. CURRENT CONDITIONS — key metrics
3. TODAY'S FORECAST — what to expect
4. HAZARDS & ALERTS — any active warnings
5. OPERATIONAL IMPACT — how weather affects outdoor operations
6. OUTLOOK — next 3 days summary

Classification: UNCLASSIFIED // WEATHER INTELLIGENCE
Format professionally. Keep under 500 words.`;

      // Get system config for model
      const model = (await storage.getSystemConfig("defaultModel")) || "llama3.2";

      // Call Ollama
      const ollamaRes = await fetch(`http://localhost:11434/api/generate`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ model, prompt, stream: false }),
        signal: AbortSignal.timeout(120000)
      });
      if (!ollamaRes.ok) throw new Error("Ollama unavailable");
      const ollamaData = await ollamaRes.json();
      const briefContent = ollamaData.response || "Brief generation failed.";

      // Save to NAS share \\192.168.0.20\briefs\weather
      const dateStr = new Date().toISOString().slice(0, 10);
      const briefText = `TRIDENT WEATHER BRIEF — ${today}\nGenerated: ${new Date().toLocaleString("en-US", { timeZone: "America/New_York" })}\nLocation: Denton, NC — Davidson County\n${'='.repeat(60)}\n\n${briefContent}\n\n${'='.repeat(60)}\nGENERATED BY TRIDENT // ${model.toUpperCase()}\nCLASSIFICATION: UNCLASSIFIED // WEATHER INTELLIGENCE`;

      // Try to write to NAS (mounted at /mnt/trident-briefs or via SMB path)
      const nasPaths = [
        "/mnt/trident-briefs/weather",
        "/opt/trident/briefs/weather"
      ];
      let saved = false;
      for (const dir of nasPaths) {
        try {
          fs.mkdirSync(dir, { recursive: true });
          const filePath = path.join(dir, `weather-brief-${dateStr}.md`);
          fs.writeFileSync(filePath, briefText, "utf8");
          saved = true;
          break;
        } catch { /* try next path */ }
      }

      res.json({
        content: briefContent,
        date: dateStr,
        model_used: model,
        saved_to_nas: saved,
        nas_path: saved ? `briefs\\weather\\weather-brief-${dateStr}.md` : null
      });
      try { await storage.logOpsEvent("brief_generated", `Weather brief generated (${model})`, { type: "WEATHER", topic: "DAVIDSON COUNTY", model }, req.user?.id); } catch { /* non-fatal */ }
    } catch (e: any) {
      res.status(500).json({ error: e?.message || "Brief generation failed" });
    }
  });

  // ═══════════════════════════════════════════════════
  // SECURITY BRIEF INTELLIGENCE (Phase 9) — proxies Python brief service on port 5006
  // NAS folder analysis + web intel feeds. All LLM calls go through Ollama here.
  // ═══════════════════════════════════════════════════
  const BRIEFS_BASE = "http://localhost:5006";
  const INTEL_NAS_BASE = "/mnt/trident-briefs";

  // Helper: proxy a GET request to the Python brief service with timeout
  async function proxyBriefs(reqPath: string): Promise<any> {
    const r = await fetch(`${BRIEFS_BASE}${reqPath}`, {
      signal: AbortSignal.timeout(60000),
    });
    if (!r.ok) throw new Error(`Brief service error: ${r.status}`);
    return r.json();
  }

  // Helper: proxy a POST/DELETE request to the Python brief service
  async function proxyBriefsMethod(reqPath: string, method: string, body?: any): Promise<any> {
    const r = await fetch(`${BRIEFS_BASE}${reqPath}`, {
      method,
      headers: body ? { "Content-Type": "application/json" } : {},
      body: body ? JSON.stringify(body) : undefined,
      signal: AbortSignal.timeout(60000),
    });
    if (!r.ok) throw new Error(`Brief service error: ${r.status}`);
    return r.json();
  }

  // Helper: slugify a topic/feed name into a safe folder name
  function intelSlug(name: string): string {
    return String(name).trim().toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-+|-+$/g, "")
      .slice(0, 64) || "topic";
  }

  // Helper: run an Ollama chat completion, return trimmed content
  async function intelOllamaChat(model: string, prompt: string, numPredict = 1536): Promise<string> {
    const r = await fetch(`${OLLAMA_BASE}/api/chat`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        model,
        messages: [{ role: "user", content: prompt }],
        stream: false,
        options: { temperature: 0.4, num_predict: numPredict },
      }),
      signal: AbortSignal.timeout(240000),
    });
    if (!r.ok) throw new Error("LLM UNAVAILABLE — ensure Ollama is running");
    const data: any = await r.json();
    return data?.message?.content?.trim() || "";
  }

  async function intelModel(): Promise<string> {
    return (
      (await storage.getSystemConfig("default_model")) ||
      (await storage.getSystemConfig("brief_model")) ||
      "llama3.2:latest"
    );
  }

  // GET /api/intel/status — TCP probe port 5006
  app.get("/api/intel/status", requireAuth, async (_req, res) => {
    const online = await new Promise<boolean>((resolve) => {
      const socket = new net.Socket();
      let done = false;
      const finish = (val: boolean) => {
        if (done) return;
        done = true;
        socket.destroy();
        resolve(val);
      };
      socket.setTimeout(2000);
      socket.once("connect", () => finish(true));
      socket.once("timeout", () => finish(false));
      socket.once("error", () => finish(false));
      socket.connect(5006, "127.0.0.1");
    });
    res.json({ online, service: "TRIDENT Brief Intelligence", port: 5006 });
  });

  // GET /api/intel/topics — list NAS topic folders merged with DB metadata
  app.get("/api/intel/topics", requireAuth, async (req, res) => {
    try {
      const userId = req.user!.id;
      let nasTopics: any[] = [];
      try {
        const data = await proxyBriefs("/topics");
        nasTopics = data?.topics || [];
      } catch { /* brief service offline — fall back to DB only */ }

      const dbTopics = await storage.listIntelTopics(userId);
      const byName: Record<string, any> = {};
      for (const t of dbTopics) {
        byName[t.name] = {
          name: t.name,
          description: t.description,
          classification: t.classification,
          file_count: 0,
          files: [],
          brief_count: 0,
          total_size_kb: 0,
        };
      }
      for (const nt of nasTopics) {
        byName[nt.name] = { ...(byName[nt.name] || {}), ...nt };
        if (!byName[nt.name].classification) byName[nt.name].classification = "UNCLASSIFIED";
      }
      res.json({ topics: Object.values(byName), count: Object.keys(byName).length });
    } catch (e: any) {
      res.status(500).json({ error: e?.message || "FAILED TO LIST TOPICS" });
    }
  });

  // POST /api/intel/topics — create topic (NAS folder + DB record)
  app.post("/api/intel/topics", requireAuth, async (req, res) => {
    try {
      const userId = req.user!.id;
      const name = intelSlug(String(req.body?.name || ""));
      if (!name || name === "topic") {
        return res.status(400).json({ error: "INVALID TOPIC NAME" });
      }
      const description = String(req.body?.description || "");
      const classification = String(req.body?.classification || "UNCLASSIFIED");

      const existing = await storage.getIntelTopicByName(userId, name);
      if (existing) return res.status(409).json({ error: "TOPIC ALREADY EXISTS" });

      // Create folder on NAS (best-effort via brief service, then direct fs fallback)
      let folderOk = false;
      try {
        const r = await proxyBriefsMethod(`/topic/${encodeURIComponent(name)}/mkdir`, "POST", {});
        folderOk = !!r?.ok;
      } catch { /* service offline */ }
      if (!folderOk) {
        try {
          fs.mkdirSync(path.join(INTEL_NAS_BASE, name, "_briefs"), { recursive: true });
          folderOk = true;
        } catch { /* NAS unavailable — DB record still created */ }
      }

      const now = new Date().toISOString();
      const topic = await storage.createIntelTopic({
        name,
        description,
        classification,
        userId,
        createdAt: now,
        updatedAt: now,
      });
      res.json({ ...topic, folder_created: folderOk });
    } catch (e: any) {
      res.status(500).json({ error: e?.message || "FAILED TO CREATE TOPIC" });
    }
  });

  // DELETE /api/intel/topics/:name — delete topic folder + DB record
  app.delete("/api/intel/topics/:name", requireAuth, async (req, res) => {
    try {
      const userId = req.user!.id;
      const name = intelSlug(String(req.params.name));
      try {
        await proxyBriefsMethod(`/topic/${encodeURIComponent(name)}`, "DELETE");
      } catch {
        try { fs.rmSync(path.join(INTEL_NAS_BASE, name), { recursive: true, force: true }); }
        catch { /* NAS unavailable */ }
      }
      const ok = await storage.deleteIntelTopic(userId, name);
      res.json({ ok });
    } catch (e: any) {
      res.status(500).json({ error: e?.message || "FAILED TO DELETE TOPIC" });
    }
  });

  // GET /api/intel/topics/:name/extract — extract text from all files in folder
  app.get("/api/intel/topics/:name/extract", requireAuth, async (req, res) => {
    try {
      const name = intelSlug(String(req.params.name));
      res.json(await proxyBriefs(`/topic/${encodeURIComponent(name)}/extract`));
    } catch (e: any) {
      res.status(502).json({ error: e?.message || "BRIEF SERVICE OFFLINE" });
    }
  });

  // GET /api/intel/topics/:name/briefs — list briefs for topic (from SQLite)
  app.get("/api/intel/topics/:name/briefs", requireAuth, async (req, res) => {
    try {
      const userId = req.user!.id;
      const name = intelSlug(String(req.params.name));
      const briefs = await storage.listIntelBriefsByTopic(userId, name);
      res.json({ topic: name, briefs });
    } catch (e: any) {
      res.status(500).json({ error: e?.message || "FAILED TO LIST BRIEFS" });
    }
  });

  // GET /api/intel/briefs/:id — get a specific brief
  app.get("/api/intel/briefs/:id", requireAuth, async (req, res) => {
    try {
      const userId = req.user!.id;
      const id = parseInt(String(req.params.id), 10);
      const brief = await storage.getIntelBrief(id, userId);
      if (!brief) return res.status(404).json({ error: "BRIEF NOT FOUND" });
      res.json(brief);
    } catch (e: any) {
      res.status(500).json({ error: e?.message || "FAILED TO GET BRIEF" });
    }
  });

  // POST /api/intel/topics/:name/brief/generate — generate a security brief via LLM
  app.post("/api/intel/topics/:name/brief/generate", requireAuth, async (req, res) => {
    try {
      const userId = req.user!.id;
      const name = intelSlug(String(req.params.name));
      const classification = String(req.body?.classification || "UNCLASSIFIED");
      const focus = String(req.body?.focus || "").trim();

      // Fetch extracted docs from brief service
      const extracted = await proxyBriefs(`/topic/${encodeURIComponent(name)}/extract`);
      const documents: any[] = extracted?.documents || [];
      if (documents.length === 0) {
        return res.status(400).json({ error: "NO DOCUMENTS FOUND IN TOPIC FOLDER" });
      }

      // Build document summaries (truncate each doc to keep prompt bounded)
      const perDocLimit = Math.max(800, Math.floor(20000 / documents.length));
      const documentSummaries = documents
        .map((d, i) => `--- DOCUMENT ${i + 1}: ${d.name} (${d.ext}, ${d.text_length} chars) ---\n${String(d.text || "").slice(0, perDocLimit)}`)
        .join("\n\n");

      const dateStr = new Date().toISOString().slice(0, 10);
      const focusLine = focus ? `\nANALYTICAL FOCUS: ${focus}\n` : "";

      const prompt = `You are TRIDENT, a classified intelligence analyst. Generate a comprehensive security intelligence brief based on the following source documents.

TOPIC: ${name}
CLASSIFICATION: ${classification}
ANALYST: TRIDENT SYSTEM
DATE: ${dateStr}
DOCUMENT COUNT: ${documents.length}${focusLine}

SOURCE DOCUMENTS:
${documentSummaries}

Generate a structured intelligence brief:
1. EXECUTIVE SUMMARY — 2-3 sentences overview
2. KEY FINDINGS — bullet points of most important information
3. ENTITIES OF INTEREST — people, organizations, locations mentioned
4. TIMELINE OF EVENTS — chronological sequence if applicable
5. CORRELATION ANALYSIS — connections and patterns across documents
6. THREAT ASSESSMENT — potential risks or concerns identified
7. INTELLIGENCE GAPS — what information is missing or unclear
8. RECOMMENDATIONS — suggested follow-up actions

Classification: ${classification} // TRIDENT INTEL
Format professionally with clear sections.`;

      const content = await intelOllamaChat(await intelModel(), prompt, 2048);
      if (!content) return res.status(502).json({ error: "LLM RETURNED EMPTY BRIEF" });

      const model = await intelModel();
      const now = new Date().toISOString();
      const briefName = `brief-${dateStr}-${Date.now().toString().slice(-5)}.md`;
      const title = `${name.toUpperCase()} INTEL BRIEF — ${dateStr}`;
      const mdBody = `# ${title}\nCLASSIFICATION: ${classification} // TRIDENT INTEL\nMODEL: ${model}\nDOCUMENTS ANALYZED: ${documents.length}\n${"=".repeat(60)}\n\n${content}\n\n${"=".repeat(60)}\nGENERATED BY TRIDENT // CLASSIFICATION: ${classification} // BRIEF INTELLIGENCE`;

      // Save .md to NAS topic/_briefs/ (best-effort)
      let nasPath: string | null = null;
      try {
        const r = await proxyBriefsMethod(`/topic/${encodeURIComponent(name)}/brief/save`, "POST", { name: briefName, content: mdBody });
        if (r?.ok) nasPath = r.path || `${name}/_briefs/${briefName}`;
      } catch { /* service offline */ }
      if (!nasPath) {
        try {
          const dir = path.join(INTEL_NAS_BASE, name, "_briefs");
          fs.mkdirSync(dir, { recursive: true });
          fs.writeFileSync(path.join(dir, briefName), mdBody, "utf8");
          nasPath = `${name}/_briefs/${briefName}`;
        } catch { /* NAS unavailable */ }
      }

      const brief = await storage.createIntelBrief({
        topicName: name,
        title,
        content,
        classification,
        modelUsed: model,
        userId,
        isDraft: 1,
        nasPath,
        createdAt: now,
      });

      try { await storage.logOpsEvent("brief_generated", `Intel brief generated: ${title}`, { type: "INTEL", topic: name || title, model }, userId); } catch { /* non-fatal */ }
      res.json({ id: brief.id, content: brief.content, title: brief.title, classification, model_used: model, is_draft: true, nas_path: nasPath });
    } catch (e: any) {
      res.status(500).json({ error: e?.message || "BRIEF GENERATION FAILED" });
    }
  });

  // POST /api/intel/briefs/:id/publish — publish draft brief (is_draft = 0)
  app.post("/api/intel/briefs/:id/publish", requireAuth, async (req, res) => {
    try {
      const userId = req.user!.id;
      const id = parseInt(String(req.params.id), 10);
      const brief = await storage.publishIntelBrief(id, userId);
      if (!brief) return res.status(404).json({ error: "BRIEF NOT FOUND" });
      res.json({ id: brief.id, is_draft: brief.isDraft, nas_path: brief.nasPath });
    } catch (e: any) {
      res.status(500).json({ error: e?.message || "FAILED TO PUBLISH BRIEF" });
    }
  });

  // POST /api/intel/topics/:name/chat — ask a question about topic documents
  app.post("/api/intel/topics/:name/chat", requireAuth, async (req, res) => {
    try {
      const name = intelSlug(String(req.params.name));
      const message = String(req.body?.message || "").trim();
      if (!message) return res.status(400).json({ error: "NO MESSAGE PROVIDED" });

      const extracted = await proxyBriefs(`/topic/${encodeURIComponent(name)}/extract`);
      const documents: any[] = extracted?.documents || [];
      if (documents.length === 0) {
        return res.status(400).json({ error: "NO DOCUMENTS FOUND IN TOPIC FOLDER" });
      }

      const perDocLimit = Math.max(600, Math.floor(16000 / documents.length));
      const documentContext = documents
        .map((d, i) => `--- DOCUMENT ${i + 1}: ${d.name} ---\n${String(d.text || "").slice(0, perDocLimit)}`)
        .join("\n\n");

      const prompt = `You are TRIDENT, a classified intelligence analyst. Answer questions about the following intelligence documents.

TOPIC: ${name}
DOCUMENTS:
${documentContext}

USER QUESTION: ${message}

Answer concisely and accurately based only on the provided documents. 
If the answer is not in the documents, say so clearly.`;

      const response = await intelOllamaChat(await intelModel(), prompt, 1024);
      res.json({
        response: response || "[NO RESPONSE]",
        documents_used: documents.map((d) => d.name),
      });
    } catch (e: any) {
      res.status(500).json({ error: e?.message || "CHAT FAILED" });
    }
  });

  // GET /api/intel/feeds — list web feeds (from SQLite)
  app.get("/api/intel/feeds", requireAuth, async (req, res) => {
    try {
      const userId = req.user!.id;
      const feeds = await storage.listWebFeeds(userId);
      res.json({ feeds });
    } catch (e: any) {
      res.status(500).json({ error: e?.message || "FAILED TO LIST FEEDS" });
    }
  });

  // POST /api/intel/feeds — add a web feed
  app.post("/api/intel/feeds", requireAuth, async (req, res) => {
    try {
      const userId = req.user!.id;
      const name = String(req.body?.name || "").trim();
      const url = String(req.body?.url || "").trim();
      const category = String(req.body?.category || "GENERAL");
      // Poll interval in hours; 0 / "never" disables auto-poll
      let pollIntervalHours = 6;
      if (req.body?.pollIntervalHours !== undefined && req.body?.pollIntervalHours !== null) {
        const parsed = parseInt(String(req.body.pollIntervalHours), 10);
        if (!isNaN(parsed)) pollIntervalHours = parsed;
      }
      if (!name || !url) return res.status(400).json({ error: "NAME AND URL REQUIRED" });
      const now = new Date().toISOString();
      const feed = await storage.createWebFeed({
        name, url, category, userId, lastFetched: null, isActive: 1, createdAt: now,
        pollIntervalHours, lastArchived: null, archiveCount: 0,
      });

      // Kick off an immediate first fetch-and-archive (best-effort, non-blocking)
      (async () => {
        try {
          const r = await proxyBriefsMethod(`/feed/fetch-and-archive`, "POST", { url, name });
          if (r?.archived_file) {
            await storage.updateWebFeedArchived(feed.id, userId, new Date().toISOString());
          }
        } catch { /* brief service offline — archive will happen on demand or via poller */ }
      })();

      res.json(feed);
    } catch (e: any) {
      res.status(500).json({ error: e?.message || "FAILED TO ADD FEED" });
    }
  });

  // GET /api/intel/feeds/poll-status — active background poll threads (Phase 9 archive)
  // NOTE: registered BEFORE /api/intel/feeds/:id so "poll-status" is not captured as :id
  app.get("/api/intel/feeds/poll-status", requireAuth, async (_req, res) => {
    try {
      const data = await proxyBriefs(`/feeds/poll-status`);
      res.json(data);
    } catch (e: any) {
      res.status(503).json({ active_polls: [], count: 0, error: e?.message || "BRIEF SERVICE OFFLINE" });
    }
  });

  // DELETE /api/intel/feeds/:id — remove feed
  app.delete("/api/intel/feeds/:id", requireAuth, async (req, res) => {
    try {
      const userId = req.user!.id;
      const id = parseInt(String(req.params.id), 10);
      const ok = await storage.deleteWebFeed(id, userId);
      res.json({ ok });
    } catch (e: any) {
      res.status(500).json({ error: e?.message || "FAILED TO DELETE FEED" });
    }
  });

  // POST /api/intel/feeds/:id/fetch — fetch and generate a brief for one feed
  app.post("/api/intel/feeds/:id/fetch", requireAuth, async (req, res) => {
    try {
      const userId = req.user!.id;
      const id = parseInt(String(req.params.id), 10);
      const feed = await storage.getWebFeed(id, userId);
      if (!feed) return res.status(404).json({ error: "FEED NOT FOUND" });

      // Fetch URL content via brief service
      const fetched = await proxyBriefs(`/feed/fetch?url=${encodeURIComponent(feed.url)}`);
      const rawContent = String(fetched?.content || "").slice(0, 24000);
      if (!rawContent) return res.status(502).json({ error: "NO CONTENT FETCHED FROM FEED" });

      const dateStr = new Date().toISOString().slice(0, 10);
      const prompt = `You are TRIDENT, a classified intelligence analyst. Generate a comprehensive security intelligence brief based on the following web source.

SOURCE: ${feed.name}
URL: ${feed.url}
CATEGORY: ${feed.category}
DATE: ${dateStr}

SOURCE CONTENT:
${rawContent}

Generate a structured intelligence brief:
1. EXECUTIVE SUMMARY — 2-3 sentences overview
2. KEY FINDINGS — bullet points of most important information
3. ENTITIES OF INTEREST — people, organizations, locations mentioned
4. THREAT ASSESSMENT — potential risks or concerns identified
5. RECOMMENDATIONS — suggested follow-up actions

Classification: UNCLASSIFIED // TRIDENT INTEL
Format professionally with clear sections.`;

      const content = await intelOllamaChat(await intelModel(), prompt, 1536);
      if (!content) return res.status(502).json({ error: "LLM RETURNED EMPTY BRIEF" });

      const model = await intelModel();
      const now = new Date().toISOString();
      const feedSlug = intelSlug(feed.name);
      const briefName = `${feedSlug}-brief-${dateStr}.md`;
      const title = `${feed.name.toUpperCase()} WEB INTEL — ${dateStr}`;
      const mdBody = `# ${title}\nSOURCE: ${feed.url}\nCATEGORY: ${feed.category}\nMODEL: ${model}\n${"=".repeat(60)}\n\n${content}\n\n${"=".repeat(60)}\nGENERATED BY TRIDENT // WEB INTELLIGENCE`;

      // Save to NAS _web-intel folder (best-effort)
      let nasPath: string | null = null;
      try {
        const r = await proxyBriefsMethod(`/web-intel/save`, "POST", { name: briefName, content: mdBody });
        if (r?.ok) nasPath = r.path || `_web-intel/${briefName}`;
      } catch { /* service offline */ }
      if (!nasPath) {
        try {
          const dir = path.join(INTEL_NAS_BASE, "_web-intel");
          fs.mkdirSync(dir, { recursive: true });
          fs.writeFileSync(path.join(dir, briefName), mdBody, "utf8");
          nasPath = `_web-intel/${briefName}`;
        } catch { /* NAS unavailable */ }
      }

      const brief = await storage.createIntelBrief({
        topicName: `_web:${feedSlug}`,
        title,
        content,
        classification: "UNCLASSIFIED",
        modelUsed: model,
        userId,
        isDraft: 0,
        nasPath,
        createdAt: now,
      });
      await storage.updateWebFeedFetched(id, userId, now);

      res.json({ id: brief.id, content: brief.content, title, model_used: model, nas_path: nasPath, fetched_length: rawContent.length });
    } catch (e: any) {
      res.status(500).json({ error: e?.message || "FEED FETCH FAILED" });
    }
  });

  // GET /api/intel/feeds/:id/briefs — list past briefs generated for a feed
  app.get("/api/intel/feeds/:id/briefs", requireAuth, async (req, res) => {
    try {
      const userId = req.user!.id;
      const id = parseInt(String(req.params.id), 10);
      const feed = await storage.getWebFeed(id, userId);
      if (!feed) return res.status(404).json({ error: "FEED NOT FOUND" });
      const briefs = await storage.listIntelBriefsByTopic(userId, `_web:${intelSlug(feed.name)}`);
      res.json({ feed: feed.name, briefs });
    } catch (e: any) {
      res.status(500).json({ error: e?.message || "FAILED TO LIST FEED BRIEFS" });
    }
  });

  // ── Phase 9 — WEB ARCHIVE ──────────────────────────────────────────
  // Match the Python get_feed_archive_dir() sanitization exactly:
  //   safe_name = each char kept if alnum or in "-_", else replaced with "-", lowercased.
  const safeName = (name: string) => name.toLowerCase().replace(/[^a-z0-9-_]/g, "-");

  // POST /api/intel/feeds/:id/fetch-and-archive — fetch URL, archive to NAS, return content
  app.post("/api/intel/feeds/:id/fetch-and-archive", requireAuth, async (req, res) => {
    try {
      const userId = req.user!.id;
      const id = parseInt(String(req.params.id), 10);
      const feed = await storage.getWebFeed(id, userId);
      if (!feed) return res.status(404).json({ error: "FEED NOT FOUND" });

      const result = await proxyBriefsMethod(`/feed/fetch-and-archive`, "POST", {
        url: feed.url,
        name: feed.name,
      });
      if (result?.error) return res.status(502).json({ error: result.error });

      const now = new Date().toISOString();
      await storage.updateWebFeedArchived(id, userId, now);

      res.json({
        content: result.content,
        archived_file: result.archived_file,
        archived_path: result.archived_path,
        length: result.length,
        fetched_at: result.fetched_at || now,
      });
    } catch (e: any) {
      res.status(500).json({ error: e?.message || "FETCH & ARCHIVE FAILED" });
    }
  });

  // GET /api/intel/feeds/:id/archive/latest — most recent archived copy
  // NOTE: registered before /:id/archive/:filename so "latest" isn't captured as :filename
  app.get("/api/intel/feeds/:id/archive/latest", requireAuth, async (req, res) => {
    try {
      const userId = req.user!.id;
      const id = parseInt(String(req.params.id), 10);
      const feed = await storage.getWebFeed(id, userId);
      if (!feed) return res.status(404).json({ error: "FEED NOT FOUND" });
      const data = await proxyBriefs(`/feed/archive/${encodeURIComponent(safeName(feed.name))}/latest`);
      res.json(data);
    } catch (e: any) {
      res.status(503).json({ error: e?.message || "BRIEF SERVICE OFFLINE", content: null });
    }
  });

  // GET /api/intel/feeds/:id/archive/:filename — content of a specific archived file
  app.get("/api/intel/feeds/:id/archive/:filename", requireAuth, async (req, res) => {
    try {
      const userId = req.user!.id;
      const id = parseInt(String(req.params.id), 10);
      const filename = String(req.params.filename);
      const feed = await storage.getWebFeed(id, userId);
      if (!feed) return res.status(404).json({ error: "FEED NOT FOUND" });
      const data = await proxyBriefs(
        `/feed/archive/${encodeURIComponent(safeName(feed.name))}/${encodeURIComponent(filename)}`
      );
      res.json(data);
    } catch (e: any) {
      res.status(503).json({ error: e?.message || "BRIEF SERVICE OFFLINE" });
    }
  });

  // GET /api/intel/feeds/:id/archive — list archived copies for a feed
  app.get("/api/intel/feeds/:id/archive", requireAuth, async (req, res) => {
    try {
      const userId = req.user!.id;
      const id = parseInt(String(req.params.id), 10);
      const feed = await storage.getWebFeed(id, userId);
      if (!feed) return res.status(404).json({ error: "FEED NOT FOUND" });
      const data = await proxyBriefs(`/feed/archive/${encodeURIComponent(safeName(feed.name))}`);
      res.json(data);
    } catch (e: any) {
      res.status(503).json({ files: [], count: 0, error: e?.message || "BRIEF SERVICE OFFLINE" });
    }
  });

  // ═══════════════════════════════════════════════════
  // TRIDENT GRID — DISTRIBUTED COMPUTE (Phase 10)
  // ═══════════════════════════════════════════════════
  const GRID_BASE = "http://localhost:5007";

  // Helper: proxy a GET request to the grid coordinator with timeout
  async function proxyGrid(reqPath: string): Promise<any> {
    const r = await fetch(`${GRID_BASE}${reqPath}`, {
      signal: AbortSignal.timeout(30000),
    });
    if (!r.ok) throw new Error(`Grid coordinator error: ${r.status}`);
    return r.json();
  }

  // Helper: proxy a POST/DELETE request to the grid coordinator
  async function proxyGridMethod(reqPath: string, method: string, body?: any): Promise<any> {
    const r = await fetch(`${GRID_BASE}${reqPath}`, {
      method,
      headers: body ? { "Content-Type": "application/json" } : {},
      body: body ? JSON.stringify(body) : undefined,
      signal: AbortSignal.timeout(30000),
    });
    if (!r.ok) throw new Error(`Grid coordinator error: ${r.status}`);
    return r.json();
  }

  // GET /api/grid/status — TCP probe port 5007 + health
  app.get("/api/grid/status", requireAuth, async (_req, res) => {
    const online = await new Promise<boolean>((resolve) => {
      const socket = new net.Socket();
      let done = false;
      const finish = (val: boolean) => {
        if (done) return;
        done = true;
        socket.destroy();
        resolve(val);
      };
      socket.setTimeout(2000);
      socket.once("connect", () => finish(true));
      socket.once("timeout", () => finish(false));
      socket.once("error", () => finish(false));
      socket.connect(5007, "127.0.0.1");
    });
    let health: any = null;
    if (online) {
      try {
        health = await proxyGrid("/health");
      } catch { /* coordinator up but health unavailable */ }
    }
    res.json({ online, service: "TRIDENT GRID Coordinator", port: 5007, health });
  });

  // GET /api/grid/nodes — list all registered nodes (proxy)
  app.get("/api/grid/nodes", requireAuth, async (_req, res) => {
    try {
      const data = await proxyGrid("/nodes");
      res.json(data);
    } catch (e: any) {
      res.status(503).json({ nodes: [], count: 0, error: e?.message || "GRID COORDINATOR OFFLINE" });
    }
  });

  // DELETE /api/grid/nodes/:nodeId — remove a node (admin)
  app.delete("/api/grid/nodes/:nodeId", requireAuth, requireAdmin, async (req, res) => {
    try {
      const nodeId = String(req.params.nodeId);
      const data = await proxyGridMethod(`/nodes/${encodeURIComponent(nodeId)}`, "DELETE");
      res.json(data);
    } catch (e: any) {
      res.status(503).json({ error: e?.message || "GRID COORDINATOR OFFLINE" });
    }
  });

  // GET /api/grid/jobs — list recent jobs
  app.get("/api/grid/jobs", requireAuth, async (req, res) => {
    try {
      const limit = parseInt(String(req.query.limit || "50"), 10);
      const data = await proxyGrid(`/jobs?limit=${limit}`);
      res.json(data);
    } catch (e: any) {
      res.status(503).json({ jobs: [], total: 0, error: e?.message || "GRID COORDINATOR OFFLINE" });
    }
  });

  // POST /api/grid/jobs/submit — submit a job to the grid
  app.post("/api/grid/jobs/submit", requireAuth, async (req, res) => {
    try {
      const data = await proxyGridMethod("/jobs/submit", "POST", req.body || {});
      res.json(data);
    } catch (e: any) {
      res.status(503).json({ error: e?.message || "GRID COORDINATOR OFFLINE" });
    }
  });

  // GET /api/grid/dispatch/test — test dispatch for a job type
  app.get("/api/grid/dispatch/test", requireAuth, async (req, res) => {
    try {
      const type = String(req.query.type || "llm");
      const model = req.query.model ? String(req.query.model) : undefined;
      const data = await proxyGridMethod("/dispatch/test", "POST", { type, model });
      res.json(data);
    } catch (e: any) {
      res.status(503).json({ best_node: null, error: e?.message || "GRID COORDINATOR OFFLINE" });
    }
  });

  // GET /api/grid/install.sh — PUBLIC: serve the worker install script (no auth — runs on fresh servers)
  app.get("/api/grid/install.sh", (req, res) => {
    try {
      const coordinatorUrl = `http://192.168.0.7:5007`;
      const scriptPaths = [path.join(process.cwd(), "scripts/trident-worker-install.sh"), "/opt/trident/scripts/trident-worker-install.sh"];
      let rawScript = "";
      for (const sp of scriptPaths) { try { rawScript = fs.readFileSync(sp, "utf8"); break; } catch {} }
      if (!rawScript) throw new Error("install.sh not found");
      const script = rawScript.replace("${TRIDENT_COORDINATOR:-http://192.168.0.7:5007}", coordinatorUrl);
      res.setHeader("Content-Type", "text/x-shellscript");
      res.send(script);
    } catch (e: any) {
      res.status(500).send(`# TRIDENT GRID installer unavailable: ${e?.message || "error"}\n`);
    }
  });

  // GET /api/grid/worker-agent — serve the raw worker agent Python file
  app.get("/api/grid/worker-agent", (req, res) => {
    try {
      const agentPaths = [path.join(process.cwd(), "scripts/trident-worker-agent.py"), "/opt/trident/scripts/trident-worker-agent.py"];
      let agent = "";
      for (const ap of agentPaths) { try { agent = fs.readFileSync(ap, "utf8"); break; } catch {} }
      if (!agent) throw new Error("worker agent not found");
      res.setHeader("Content-Type", "text/x-python");
      res.send(agent);
    } catch (e: any) {
      res.status(500).send(`# TRIDENT GRID worker agent unavailable: ${e?.message || "error"}\n`);
    }
  });


  // ═══════════════════════════════════════════════════
  // OPSCENTER ROUTES (Phase 11)
  // ═══════════════════════════════════════════════════

  // GET /api/ops/vitals — live system metrics
  app.get("/api/ops/vitals", requireAuth, async (_req, res) => {
    try {
      const mem = getMemInfo();
      const gpu = getGpuInfo();
      const diskRoot = getDiskInfo("/");
      const diskOpt = getDiskInfo("/opt");
      const diskNas = getDiskInfo("/mnt/trident-briefs");
      const net = getNetStats();
      const load = getLoadAvg();
      res.json({
        cpu_pct: getCpuPct(),
        cpu_cores: getCpuCores(),
        ram_used_gb: mem.used_gb,
        ram_total_gb: mem.total_gb,
        ram_pct: mem.pct,
        swap_used_gb: mem.swap_used_gb,
        swap_total_gb: mem.swap_total_gb,
        gpu_pct: gpu.gpu_pct,
        gpu_vram_used_gb: gpu.gpu_vram_used_gb,
        gpu_vram_total_gb: gpu.gpu_vram_total_gb,
        gpu_temp_c: gpu.gpu_temp_c,
        gpu_name: gpu.gpu_name,
        disk_root_used_gb: diskRoot.used_gb,
        disk_root_total_gb: diskRoot.total_gb,
        disk_root_pct: diskRoot.pct,
        disk_opt_used_gb: diskOpt.used_gb,
        disk_opt_total_gb: diskOpt.total_gb,
        disk_opt_pct: diskOpt.pct,
        disk_nas_used_gb: diskNas.used_gb,
        disk_nas_total_gb: diskNas.total_gb,
        disk_nas_pct: diskNas.pct,
        disk_nas_available: diskNas.available,
        uptime_seconds: getUptimeSeconds(),
        load_avg_1: load.l1,
        load_avg_5: load.l5,
        load_avg_15: load.l15,
        net_rx_bytes: net.rx_bytes,
        net_tx_bytes: net.tx_bytes,
        timestamp: new Date().toISOString(),
      });
    } catch (e: any) {
      res.status(500).json({ error: e?.message || "VITALS UNAVAILABLE" });
    }
  });

  // GET /api/ops/services — status of all TRIDENT systemd services
  app.get("/api/ops/services", requireAuth, async (_req, res) => {
    const services = TRIDENT_SERVICES.map((svc) => {
      let active = false;
      let status = "unknown";
      let memory_mb: number | undefined = undefined;
      try {
        status = execSync(`systemctl is-active ${svc.name}`, { timeout: 3000 }).toString().trim();
      } catch (e: any) {
        // is-active exits non-zero when not active; stdout still holds the state
        status = (e?.stdout ? e.stdout.toString().trim() : "inactive") || "inactive";
      }
      active = status === "active";
      try {
        const memOut = execSync(`systemctl show ${svc.name} --property=MemoryCurrent`, { timeout: 3000 })
          .toString().trim();
        const m = /MemoryCurrent=(\d+)/.exec(memOut);
        if (m && m[1] !== "18446744073709551615") {
          memory_mb = Math.round((parseInt(m[1], 10) / (1024 * 1024)) * 10) / 10;
        }
      } catch { /* memory unavailable */ }
      return { name: svc.name, label: svc.label, port: svc.port, active, status, memory_mb };
    });
    res.json({ services });
  });

  // POST /api/ops/services/:name/restart — restart a service (admin only)
  app.post("/api/ops/services/:name/restart", requireAdmin, async (req, res) => {
    const name = String(req.params.name);
    const allowed = TRIDENT_SERVICES.some((s) => s.name === name);
    if (!allowed) {
      return res.status(400).json({ error: "SERVICE NOT IN ALLOWED LIST" });
    }
    try {
      execSync(`systemctl restart ${name}`, { timeout: 15000 });
      await storage.logOpsEvent(
        "service_restarted",
        `Service ${name} restarted`,
        { service: name },
        req.user?.id
      );
      res.json({ ok: true, service: name, restarted_at: new Date().toISOString() });
    } catch (e: any) {
      res.status(500).json({ error: e?.message || `RESTART FAILED FOR ${name}` });
    }
  });

  // GET /api/ops/nas — NAS folder breakdown
  app.get("/api/ops/nas", requireAuth, async (_req, res) => {
    const base = "/mnt/trident-briefs";
    try {
      if (!fs.existsSync(base)) {
        return res.json({ folders: [], total_size_mb: 0, available: false });
      }
      const entries = fs.readdirSync(base, { withFileTypes: true }).filter((d) => d.isDirectory());
      let totalBytes = 0;
      const folders = entries.map((d) => {
        const dirPath = path.join(base, d.name);
        let fileCount = 0;
        let sizeBytes = 0;
        let lastModified: string | null = null;
        try {
          const walk = (p: string) => {
            for (const f of fs.readdirSync(p, { withFileTypes: true })) {
              const fp = path.join(p, f.name);
              if (f.isDirectory()) { walk(fp); continue; }
              try {
                const st = fs.statSync(fp);
                fileCount += 1;
                sizeBytes += st.size;
                const mt = st.mtime.toISOString();
                if (!lastModified || mt > lastModified) lastModified = mt;
              } catch { /* skip */ }
            }
          };
          walk(dirPath);
        } catch { /* unreadable folder */ }
        totalBytes += sizeBytes;
        return {
          name: d.name,
          file_count: fileCount,
          size_mb: Math.round((sizeBytes / (1024 * 1024)) * 100) / 100,
          last_modified: lastModified,
        };
      });
      res.json({
        folders,
        total_size_mb: Math.round((totalBytes / (1024 * 1024)) * 100) / 100,
        available: true,
      });
    } catch (e: any) {
      res.json({ folders: [], total_size_mb: 0, available: false, error: e?.message });
    }
  });

  // GET /api/ops/ollama — Ollama model info with VRAM estimate
  app.get("/api/ops/ollama", requireAuth, async (_req, res) => {
    try {
      const r = await fetch("http://localhost:11434/api/tags");
      if (!r.ok) throw new Error("OLLAMA UNAVAILABLE");
      const data: any = await r.json();
      const models = (data?.models || []).map((m: any) => {
        const params = m?.details?.parameter_size || "";
        const sizeBytes = m?.size || 0;
        return {
          name: m?.name || "unknown",
          size_gb: Math.round((sizeBytes / (1024 ** 3)) * 10) / 10,
          params: params || "—",
          est_vram: estimateVram(params, sizeBytes),
          family: m?.details?.family || "",
        };
      });
      res.json({ models, available: true });
    } catch (e: any) {
      res.json({ models: [], available: false, error: e?.message || "OLLAMA OFFLINE" });
    }
  });

  // GET /api/ops/brief-log — recent brief activity across all types
  app.get("/api/ops/brief-log", requireAuth, async (req, res) => {
    try {
      const userId = req.user!.id;
      const entries: any[] = [];
      try {
        const daily = await storage.listBriefs(userId, 50);
        for (const b of daily) {
          entries.push({ id: `market-${b.id}`, type: "MARKET", topic: "DAILY BRIEF", date: b.date, model_used: b.model_used, created_at: b.created_at });
        }
      } catch { /* skip */ }
      try {
        const geo = await storage.listGeoBriefs(userId, 50);
        for (const b of geo) {
          entries.push({ id: `geo-${b.id}`, type: "GEO-INTEL", topic: (b as any).region_focus || "GLOBAL", date: b.date, model_used: b.model_used, created_at: b.created_at });
        }
      } catch { /* skip */ }
      try {
        const ops = await storage.getOpsEvents(80);
        for (const e of ops.filter((x) => x.eventType === "brief_generated")) {
          let meta: any = {};
          try { meta = JSON.parse(e.metadata || "{}"); } catch { /* ignore */ }
          if (meta.type && ["AVIATION", "WEATHER", "INTEL"].includes(meta.type)) {
            entries.push({
              id: `ops-${e.id}`,
              type: meta.type,
              topic: meta.topic || "—",
              date: e.createdAt.slice(0, 10),
              model_used: meta.model || "—",
              created_at: e.createdAt,
            });
          }
        }
      } catch { /* skip */ }
      entries.sort((a, b) => (b.created_at || "").localeCompare(a.created_at || ""));
      res.json({ entries: entries.slice(0, 50) });
    } catch (e: any) {
      res.status(500).json({ error: e?.message || "BRIEF LOG UNAVAILABLE", entries: [] });
    }
  });

  // GET /api/ops/grid-summary — grid nodes + recent jobs summary
  app.get("/api/ops/grid-summary", requireAuth, async (_req, res) => {
    try {
      const [nodesR, jobsR] = await Promise.all([
        fetch("http://localhost:5007/nodes").catch(() => null),
        fetch("http://localhost:5007/jobs?limit=10").catch(() => null),
      ]);
      const nodes = nodesR && nodesR.ok ? await nodesR.json() : { nodes: [] };
      const jobs = jobsR && jobsR.ok ? await jobsR.json() : { jobs: [] };
      res.json({ nodes: (nodes as any)?.nodes || [], jobs: (jobs as any)?.jobs || [], available: true });
    } catch (e: any) {
      res.json({ nodes: [], jobs: [], available: false, error: e?.message });
    }
  });

  // ═══════════════════════════════════════
  // TRIDENT COMMAND (Phase 12)
  // ═══════════════════════════════════════

  app.get("/api/command/status", requireAuth, async (_req, res) => {
    const [ollama, grid] = await Promise.allSettled([
      fetch("http://localhost:11434/api/version", { signal: AbortSignal.timeout(2000) }),
      fetch("http://localhost:5007/health", { signal: AbortSignal.timeout(2000) }),
    ]);
    // Voice: TCP probe on port 5001 (same as /api/voice/status)
    const voiceOnline = await new Promise<boolean>(resolve => {
      const s = net.createConnection({ port: 5001, host: "127.0.0.1" });
      s.setTimeout(2000);
      s.on("connect", () => { s.destroy(); resolve(true); });
      s.on("error", () => resolve(false));
      s.on("timeout", () => { s.destroy(); resolve(false); });
    });
    res.json({
      ollama: ollama.status === "fulfilled" && (ollama.value as Response).ok,
      voice: voiceOnline,
      grid: grid.status === "fulfilled" && (grid.value as Response).ok,
    });
  });

  app.post("/api/command/query", requireAuth, async (req, res) => {
    const { message, history = [], model } = req.body;
    if (!message) return res.status(400).json({ error: "Message required" });
    try {
      const intents = classifyIntent(String(message));
      const context = await fetchIntelContext(intents);
      const { offload, nodeUrl } = await shouldOffloadToGrid();
      const ollamaUrl = offload && nodeUrl ? nodeUrl : "http://localhost:11434";
      const configuredModel = model || (await storage.getSystemConfig("defaultModel")) || "llama3.2";

      const systemPrompt = `You are TRIDENT COMMAND, a tactical military intelligence AI. You have real-time access to all TRIDENT intelligence modules.

LIVE INTELLIGENCE DATA:
${context || "No live data — services may be offline."}

Be concise, precise, military in tone. Cite actual numbers from the data above. Keep responses under 200 words unless a full brief is requested.`;

      const messages = [
        { role: "system", content: systemPrompt },
        ...(history as any[]).slice(-10),
        { role: "user", content: message }
      ];

      res.setHeader("Content-Type", "text/event-stream");
      res.setHeader("Cache-Control", "no-cache");
      res.setHeader("Connection", "keep-alive");
      res.flushHeaders();

      res.write(`data: ${JSON.stringify({ type: "meta", intents, offloaded: offload })}\n\n`);

      const ollamaRes = await fetch(`${ollamaUrl}/api/chat`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ model: configuredModel, messages, stream: true }),
        signal: AbortSignal.timeout(120000)
      });

      if (!ollamaRes.ok || !ollamaRes.body) {
        res.write(`data: ${JSON.stringify({ type: "error", error: "LLM unavailable" })}\n\n`);
        return res.end();
      }

      let full = "";
      const reader = ollamaRes.body.getReader();
      const dec = new TextDecoder();
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        for (const line of dec.decode(value, { stream: true }).split("\n").filter(l => l.trim())) {
          try {
            const d = JSON.parse(line);
            const token = d?.message?.content || "";
            if (token) { full += token; res.write(`data: ${JSON.stringify({ type: "token", token })}\n\n`); }
            if (d.done) res.write(`data: ${JSON.stringify({ type: "done", full_response: full, model: configuredModel, offloaded: offload })}\n\n`);
          } catch {}
        }
      }
      res.end();
    } catch (e: any) {
      res.write(`data: ${JSON.stringify({ type: "error", error: e?.message })}\n\n`);
      res.end();
    }
  });

  app.post("/api/command/tts", requireAuth, async (req, res) => {
    const { text, voice = "lessac" } = req.body;
    try {
      const r = await fetch("http://localhost:5001/tts", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text: String(text).slice(0, 500), voice }),
        signal: AbortSignal.timeout(30000)
      });
      if (!r.ok) throw new Error("TTS unavailable");
      res.setHeader("Content-Type", "audio/wav");
      res.send(Buffer.from(await r.arrayBuffer()));
    } catch (e: any) { res.status(503).json({ error: e?.message }); }
  });

  app.post("/api/command/brief/surface", requireAuth, async (req, res) => {
    const { type, date } = req.body;
    try {
      const dir = path.join("/mnt/trident-briefs", String(type || "weather"));
      if (!fs.existsSync(dir)) return res.json({ error: "Not found", content: null });
      let files = fs.readdirSync(dir).filter(f => f.endsWith(".md")).sort().reverse();
      if (date) files = files.filter(f => f.includes(String(date)));
      if (!files.length) return res.json({ error: "No briefs", content: null });
      res.json({ filename: files[0], content: fs.readFileSync(path.join(dir, files[0]), "utf8"), type, total: files.length });
    } catch (e: any) { res.status(500).json({ error: e?.message }); }
  });

  app.get("/api/command/sessions", requireAuth, async (req, res) => {
    const sessions = await storage.listCommandSessions(req.user!.id, 20);
    res.json({ sessions });
  });
  app.post("/api/command/sessions", requireAuth, async (req, res) => {
    const session = await storage.createCommandSession({ userId: req.user!.id, title: String(req.body.title || "COMMAND SESSION"), messages: "[]" });
    res.json(session);
  });
  app.patch("/api/command/sessions/:id", requireAuth, async (req, res) => {
    await storage.updateCommandSession(parseInt(String(req.params.id)), String(req.body.messages || "[]"));
    res.json({ ok: true });
  });
  app.delete("/api/command/sessions/:id", requireAuth, async (req, res) => {
    await storage.deleteCommandSession(parseInt(String(req.params.id)));
    res.json({ ok: true });
  });

  // Start the scheduler
  startScheduler(storage).catch((err) => console.error("[SCHEDULER] Start failed:", err));

  return httpServer;
}
