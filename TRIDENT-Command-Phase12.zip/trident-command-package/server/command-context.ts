import * as fs from "fs";
import * as path from "path";
import { execSync } from "child_process";

async function safeFetch(url: string, ms = 4000): Promise<any> {
  try { const r = await fetch(url, { signal: AbortSignal.timeout(ms) }); return r.ok ? r.json() : null; }
  catch { return null; }
}

export function classifyIntent(msg: string): string[] {
  const m = msg.toLowerCase();
  const out: string[] = [];
  if (/flight|aircraft|plane|fly|overhead|airspace|callsign|aviation/.test(m)) out.push("flights");
  if (/weather|rain|wind|temp|forecast|storm|alert|humidity|noaa/.test(m)) out.push("weather");
  if (/market|stock|price|spy|btc|bitcoin|crypto|nasdaq|bond|gold|oil/.test(m)) out.push("markets");
  if (/geo|conflict|military|war|threat|attack|fatali|defense|geopolit/.test(m)) out.push("geo");
  if (/system|cpu|ram|memory|disk|service|health|uptime|load/.test(m)) out.push("system");
  if (/grid|worker|node|dispatch|compute/.test(m)) out.push("grid");
  if (/brief|report|summary|archive|yesterday|morning/.test(m)) out.push("briefs");
  if (out.length === 0) out.push("general");
  return out;
}

export async function fetchIntelContext(intents: string[]): Promise<string> {
  const all = intents.includes("general");
  const parts: string[] = [];

  if (all || intents.includes("flights")) {
    const d = await safeFetch("http://localhost:5004/aircraft");
    if (d) {
      const ac = (d.aircraft || []).slice(0, 5);
      parts.push(ac.length > 0
        ? `AIRSPACE (${ac.length} overhead): ` + ac.map((a: any) => `${(a.callsign||"?").trim()} ${Math.round((a.altitude_m||0)*3.28084)}ft ${a.distance_nm}nm`).join(" | ")
        : "AIRSPACE: No aircraft overhead");
    }
  }

  if (all || intents.includes("weather")) {
    const d = await safeFetch("http://localhost:5005/current");
    if (d) parts.push(`WEATHER: ${d.condition} ${d.temperature_f}°F feels ${d.feels_like_f}°F wind ${d.wind_speed_mph}mph humidity ${d.humidity_pct}%`);
    const alerts = await safeFetch("http://localhost:5005/alerts");
    if (alerts?.alerts?.length) parts.push(`NOAA ALERTS (${alerts.alerts.length}): ${alerts.alerts[0].headline}`);
  }

  if (all || intents.includes("markets")) {
    const d = await safeFetch("http://localhost:5002/market-overview");
    if (d) {
      const idx = (d.indices||[]).slice(0,3).map((i: any) => `${i.symbol} ${i.price} (${i.change_pct>0?'+':''}${i.change_pct}%)`).join(", ");
      if (idx) parts.push(`MARKETS: ${idx}`);
    }
  }

  if (all || intents.includes("system")) {
    try {
      const mem = fs.readFileSync("/proc/meminfo","utf8");
      const total = parseInt((mem.match(/MemTotal:\s+(\d+)/)||[])[1]||"0")*1024;
      const avail = parseInt((mem.match(/MemAvailable:\s+(\d+)/)||[])[1]||"0")*1024;
      const pct = Math.round((1-avail/total)*100);
      const load = fs.readFileSync("/proc/loadavg","utf8").split(" ").slice(0,3).join("/");
      let gpu = "";
      try { const g = execSync("nvidia-smi --query-gpu=utilization.gpu,memory.used,memory.total,temperature.gpu --format=csv,noheader,nounits",{timeout:2000}).toString().trim().split(","); gpu = ` GPU:${g[0].trim()}% VRAM:${Math.round(+g[1]/1024*10)/10}/${Math.round(+g[2]/1024*10)/10}GB ${g[3].trim()}°C`; } catch {}
      parts.push(`SYSTEM: RAM ${pct}% load ${load}${gpu}`);
    } catch {}
  }

  if (all || intents.includes("grid")) {
    const d = await safeFetch("http://localhost:5007/nodes");
    if (d) {
      const on = (d.nodes||[]).filter((n: any) => n.status==="online");
      parts.push(`GRID: ${on.length}/${d.nodes?.length||0} nodes online${on.length ? ". "+on.map((n: any)=>`${n.name} cpu:${n.last_metrics?.cpu_pct||0}% score:${n.dispatch_score}`).join(", ") : ""}`);
    }
  }

  if (intents.includes("briefs")) {
    try {
      const base = "/mnt/trident-briefs";
      const dirs = ["weather","markets","geo-intel","aviation"];
      const found: string[] = [];
      for (const d of dirs) {
        const p = path.join(base, d);
        if (fs.existsSync(p)) {
          const files = fs.readdirSync(p).filter(f=>f.endsWith(".md")).sort().reverse();
          if (files.length) found.push(`${d.toUpperCase()}: ${files[0]}`);
        }
      }
      if (found.length) parts.push("RECENT BRIEFS: "+found.join(" | "));
    } catch {}
  }

  return parts.join("\n");
}

export async function shouldOffloadToGrid(): Promise<{offload:boolean,nodeUrl?:string}> {
  try {
    const g = execSync("nvidia-smi --query-gpu=utilization.gpu,memory.used,memory.total --format=csv,noheader,nounits",{timeout:2000}).toString().trim().split(",");
    if (+g[0] > 70 || +g[1]/+g[2]*100 > 80) {
      const nodes = await safeFetch("http://localhost:5007/nodes", 3000);
      const eligible = (nodes?.nodes||[]).filter((n:any)=>n.status==="online" && n.tags?.includes("OLLAMA")).sort((a:any,b:any)=>a.dispatch_score-b.dispatch_score);
      if (eligible.length) return { offload: true, nodeUrl: `http://${eligible[0].ip}:11434` };
    }
  } catch {}
  return { offload: false };
}
