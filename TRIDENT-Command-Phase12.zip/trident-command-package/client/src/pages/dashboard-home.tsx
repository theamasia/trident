import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { getAuthHeaders, useAuth } from "@/hooks/use-auth";
import { useEffect, useState } from "react";
import {
  TrendingUp, TrendingDown, Cloud, Wind, Thermometer,
  AlertTriangle, Shield, Activity, Plane, BarChart2,
  Globe, Map, FileText, Cpu, Network
} from "lucide-react";

function apiGet(url: string) {
  return fetch(url, { headers: getAuthHeaders() }).then(r => r.json());
}

const CLEARANCE_COLOR: Record<string, string> = {
  admin: "#ff6b00",
  user: "#00f0ff",
};

const INTEL_SHORTCUTS = [
  { label: "MARKETS", icon: BarChart2, tab: "MARKETS", path: "/intelligence" },
  { label: "GEO-INTEL", icon: Globe, tab: "GEO-INTEL", path: "/intelligence" },
  { label: "FLIGHTS", icon: Plane, tab: "FLIGHTS", path: "/intelligence" },
  { label: "WEATHER", icon: Cloud, tab: "WEATHER", path: "/intelligence" },
  { label: "BRIEFS", icon: FileText, tab: null, path: "/intel-briefs" },
  { label: "OPSCENTER", icon: Cpu, tab: null, path: "/opscenter" },
  { label: "GRID", icon: Network, tab: null, path: "/grid" },
  { label: "COMMAND", icon: Activity, tab: null, path: "/command" },
];

function Clock() {
  const [t, setT] = useState("");
  useEffect(() => {
    const tick = () => setT(new Date().toLocaleTimeString("en-US", { hour12: false, hour: "2-digit", minute: "2-digit", second: "2-digit", timeZone: "America/New_York" }));
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, []);
  return <span>{t} EST</span>;
}

export default function DashboardHome() {
  const { user } = useAuth();
  const [, navigate] = useLocation();
  const [greeting, setGreeting] = useState("");

  useEffect(() => {
    const h = new Date().getHours();
    if (h < 12) setGreeting("GOOD MORNING");
    else if (h < 17) setGreeting("GOOD AFTERNOON");
    else setGreeting("GOOD EVENING");
  }, []);

  const { data: weather } = useQuery({
    queryKey: ["/api/weather/current"],
    queryFn: () => apiGet("/api/weather/current"),
    staleTime: 0,
    refetchInterval: 300000,
  });

  const { data: alerts } = useQuery({
    queryKey: ["/api/weather/alerts"],
    queryFn: () => apiGet("/api/weather/alerts"),
    staleTime: 0,
    refetchInterval: 300000,
  });

  const { data: forecast } = useQuery({
    queryKey: ["/api/weather/forecast"],
    queryFn: () => apiGet("/api/weather/forecast"),
    staleTime: 0,
    refetchInterval: 1800000,
  });

  const activeAlerts = alerts?.alerts || [];
  const daily = forecast?.daily || {};
  const days = (daily.time || []).slice(0, 5);

  const wmoCondition: Record<number, string> = {
    0: "CLR", 1: "MCLR", 2: "PCT", 3: "OVC",
    45: "FOG", 51: "DRZ", 61: "RAIN", 63: "RAIN", 65: "HVYRAIN",
    71: "SNOW", 73: "SNOW", 75: "HVYSNOW",
    80: "SHWR", 81: "SHWR", 82: "HVYSHWR",
    95: "TSTM", 96: "TSTM", 99: "HVYTSTM"
  };

  const alertSeverityColor: Record<string, string> = {
    Extreme: "#ff2244",
    Severe: "#ff6b00",
    Moderate: "#00f0ff",
    Minor: "#00ff41",
  };

  return (
    <div className="min-h-screen bg-[#050a0e] text-[#a0b4c0] font-mono flex flex-col">
      {/* Top bar */}
      <div className="flex items-center justify-between px-6 py-3 border-b border-[#1a2a3a]">
        <div className="flex items-center gap-3">
          <div className="text-[#00f0ff] text-xs tracking-[0.3em] uppercase">TRIDENT SYSTEM</div>
          <span className="text-[#1a2a3a]">|</span>
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-[#00ff41] animate-pulse inline-block" />
            <span className="text-[#00ff41] text-[10px] tracking-widest uppercase">SYSTEM ONLINE</span>
          </div>
        </div>
        <div className="text-[#00f0ff] text-xs tracking-widest font-[Orbitron,monospace]">
          <Clock />
        </div>
      </div>

      <div className="flex-1 flex flex-col items-center justify-start px-6 py-10 gap-8 max-w-5xl mx-auto w-full">

        {/* Welcome block */}
        <div className="w-full text-center space-y-3">
          <div className="text-[10px] tracking-[0.4em] uppercase text-[#a0b4c0]/60">{greeting}, OPERATOR</div>
          <h1 className="text-4xl md:text-5xl font-[Orbitron,monospace] tracking-widest text-[#00f0ff] uppercase">
            {user?.username?.toUpperCase() || user?.email?.split("@")[0]?.toUpperCase() || "ANALYST"}
          </h1>
          <div className="flex items-center justify-center gap-4 text-[10px] tracking-widest uppercase">
            <div className="flex items-center gap-1.5">
              <Shield className="w-3 h-3" style={{ color: CLEARANCE_COLOR[user?.role || "user"] }} />
              <span style={{ color: CLEARANCE_COLOR[user?.role || "user"] }}>
                CLEARANCE: {(user?.role || "USER").toUpperCase()}
              </span>
            </div>
            <span className="text-[#1a2a3a]">|</span>
            <span className="text-[#a0b4c0]/50">TACTICAL NEURAL INTERFACE SYSTEM</span>
          </div>
          {/* Thin cyan divider */}
          <div className="w-48 h-px bg-gradient-to-r from-transparent via-[#00f0ff] to-transparent mx-auto mt-2" />
        </div>

        {/* Weather section */}
        <div className="w-full space-y-3">
          <div className="text-[9px] tracking-[0.35em] uppercase text-[#a0b4c0]/50">
            WEATHER INTELLIGENCE // DENTON, NC — DAVIDSON COUNTY
          </div>

          {/* Active alerts */}
          {activeAlerts.length > 0 && (
            <div className="space-y-2">
              {activeAlerts.slice(0, 3).map((alert: any, i: number) => (
                <div
                  key={i}
                  className="flex items-start gap-3 border px-4 py-3"
                  style={{ borderColor: alertSeverityColor[alert.severity] || "#ff6b00", background: `${alertSeverityColor[alert.severity] || "#ff6b00"}10` }}
                >
                  <AlertTriangle className="w-4 h-4 mt-0.5 shrink-0" style={{ color: alertSeverityColor[alert.severity] || "#ff6b00" }} />
                  <div>
                    <div className="text-[10px] uppercase tracking-widest" style={{ color: alertSeverityColor[alert.severity] || "#ff6b00" }}>
                      {alert.severity?.toUpperCase()} — {alert.event?.toUpperCase()}
                    </div>
                    <div className="text-[10px] text-[#a0b4c0]/80 mt-0.5">{alert.headline}</div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Current conditions */}
          {weather && (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <div className="border border-[#1a2a3a] bg-[#050a0e]/80 px-4 py-3 space-y-1">
                <div className="text-[9px] tracking-widest uppercase text-[#a0b4c0]/50 flex items-center gap-1">
                  <Thermometer className="w-3 h-3" /> TEMPERATURE
                </div>
                <div className="text-2xl font-[Orbitron] text-[#00f0ff]">{weather.temperature_f}°F</div>
                <div className="text-[9px] text-[#a0b4c0]/50">FEELS {weather.feels_like_f}°F</div>
              </div>
              <div className="border border-[#1a2a3a] bg-[#050a0e]/80 px-4 py-3 space-y-1">
                <div className="text-[9px] tracking-widest uppercase text-[#a0b4c0]/50 flex items-center gap-1">
                  <Cloud className="w-3 h-3" /> CONDITION
                </div>
                <div className="text-lg font-[Orbitron] text-[#00f0ff] leading-tight">{weather.condition}</div>
                <div className="text-[9px] text-[#a0b4c0]/50">HUMIDITY {weather.humidity_pct}%</div>
              </div>
              <div className="border border-[#1a2a3a] bg-[#050a0e]/80 px-4 py-3 space-y-1">
                <div className="text-[9px] tracking-widest uppercase text-[#a0b4c0]/50 flex items-center gap-1">
                  <Wind className="w-3 h-3" /> WIND
                </div>
                <div className="text-2xl font-[Orbitron] text-[#00f0ff]">{weather.wind_speed_mph} <span className="text-sm">MPH</span></div>
                <div className="text-[9px] text-[#a0b4c0]/50">GUSTS {weather.wind_gust_mph} MPH</div>
              </div>
              <div className="border border-[#1a2a3a] bg-[#050a0e]/80 px-4 py-3 space-y-1">
                <div className="text-[9px] tracking-widest uppercase text-[#a0b4c0]/50">PRESSURE</div>
                <div className="text-2xl font-[Orbitron] text-[#00f0ff]">{weather.surface_pressure_hpa}</div>
                <div className="text-[9px] text-[#a0b4c0]/50">HPA // VIS {weather.visibility_m ? Math.round(weather.visibility_m/1000) : "?"}KM</div>
              </div>
            </div>
          )}

          {/* 5-day forecast strip */}
          {days.length > 0 && (
            <div className="grid grid-cols-5 gap-2">
              {days.map((day: string, i: number) => {
                const code = daily.weather_code?.[i] ?? 0;
                const high = daily.temperature_2m_max?.[i];
                const low = daily.temperature_2m_min?.[i];
                const precip = daily.precipitation_probability_max?.[i] ?? 0;
                const isToday = i === 0;
                return (
                  <div key={day} className={`border px-3 py-2 text-center space-y-1 ${isToday ? "border-[#00f0ff]/40" : "border-[#1a2a3a]"}`}>
                    <div className="text-[9px] tracking-widest uppercase text-[#a0b4c0]/50">
                      {isToday ? "TODAY" : new Date(day + "T12:00:00").toLocaleDateString("en-US", { weekday: "short" }).toUpperCase()}
                    </div>
                    <div className="text-[10px] text-[#00f0ff] font-[Orbitron]">{wmoCondition[code] || "—"}</div>
                    <div className="text-[10px]">
                      <span className="text-[#ff6b00]">{Math.round(high ?? 0)}°</span>
                      <span className="text-[#a0b4c0]/40"> / </span>
                      <span className="text-[#a0b4c0]">{Math.round(low ?? 0)}°</span>
                    </div>
                    <div className="text-[9px] text-[#a0b4c0]/50">{precip}% RAIN</div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Intel shortcuts */}
        <div className="w-full space-y-3">
          <div className="text-[9px] tracking-[0.35em] uppercase text-[#a0b4c0]/50">INTELLIGENCE MODULES</div>
          <div className="grid grid-cols-4 md:grid-cols-8 gap-2">
            {INTEL_SHORTCUTS.map(({ label, icon: Icon, path }) => (
              <button
                key={label}
                onClick={() => navigate(path)}
                className="border border-[#1a2a3a] hover:border-[#00f0ff]/50 hover:bg-[#00f0ff]/5 transition-all px-3 py-4 flex flex-col items-center gap-2 group"
              >
                <Icon className="w-5 h-5 text-[#a0b4c0]/50 group-hover:text-[#00f0ff] transition-colors" />
                <span className="text-[8px] tracking-widest uppercase text-[#a0b4c0]/50 group-hover:text-[#00f0ff] transition-colors">{label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Footer */}
        <div className="text-[8px] tracking-[0.3em] uppercase text-[#a0b4c0]/20 text-center pb-4">
          TRIDENT // TACTICAL NEURAL INTERFACE SYSTEM // CLASSIFICATION: {(user?.role || "USER").toUpperCase()}
        </div>
      </div>
    </div>
  );
}
