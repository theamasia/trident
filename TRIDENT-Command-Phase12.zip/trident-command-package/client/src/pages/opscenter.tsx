import { useState, useRef, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { getAuthHeaders } from "@/hooks/use-auth";
import { useAuth } from "@/hooks/use-auth";
import { useLocation } from "wouter";
import {
  Activity,
  HardDrive,
  Server,
  Boxes,
  Network,
  RotateCw,
  Gauge,
} from "lucide-react";

const API_BASE = "__PORT_5000__".startsWith("__") ? "" : "__PORT_5000__";

// ─── Types ──────────────────────────────────────────────────────────
interface Vitals {
  cpu_pct: number; cpu_cores: number;
  ram_used_gb: number; ram_total_gb: number; ram_pct: number;
  swap_used_gb: number; swap_total_gb: number;
  gpu_pct: number; gpu_vram_used_gb: number; gpu_vram_total_gb: number; gpu_temp_c: number; gpu_name: string;
  disk_root_used_gb: number; disk_root_total_gb: number; disk_root_pct: number;
  disk_opt_used_gb: number; disk_opt_total_gb: number; disk_opt_pct: number;
  disk_nas_used_gb: number; disk_nas_total_gb: number; disk_nas_pct: number; disk_nas_available: boolean;
  uptime_seconds: number; load_avg_1: number; load_avg_5: number; load_avg_15: number;
  net_rx_bytes: number; net_tx_bytes: number; timestamp: string;
}
interface SvcItem { name: string; label: string; port: number; active: boolean; status: string; memory_mb?: number; }
interface BriefEntry { id: string; type: string; topic: string; date: string; model_used: string; created_at: string; }
interface NasFolder { name: string; file_count: number; size_mb: number; last_modified: string | null; }
interface OllamaModel { name: string; size_gb: number; params: string; est_vram: string; family: string; }
interface GridNode { node_id?: string; name?: string; ip?: string; status?: string; last_metrics?: { cpu_pct?: number; ram_pct?: number }; score?: number; jobs_completed?: number; }

// ─── Helpers ────────────────────────────────────────────────────────
const barColor = (pct: number) =>
  pct >= 80 ? "#ff2244" : pct >= 60 ? "#ff6b00" : "#00ff41";

function fmtUptime(sec: number): string {
  if (!sec) return "—";
  const d = Math.floor(sec / 86400);
  const h = Math.floor((sec % 86400) / 3600);
  const m = Math.floor((sec % 3600) / 60);
  return `${d}D ${h}H ${m}M`;
}
function fmtBytesRate(bytesPerSec: number): string {
  if (bytesPerSec < 1024) return `${Math.round(bytesPerSec)} B/s`;
  if (bytesPerSec < 1024 * 1024) return `${(bytesPerSec / 1024).toFixed(1)} KB/s`;
  return `${(bytesPerSec / (1024 * 1024)).toFixed(2)} MB/s`;
}
function fmtSize(mb: number): string {
  if (!mb) return "—";
  if (mb < 1) return `${Math.round(mb * 1024)} KB`;
  if (mb < 1024) return `${mb.toFixed(1)} MB`;
  return `${(mb / 1024).toFixed(2)} GB`;
}
function fmtTime(iso: string | null): string {
  if (!iso) return "—";
  try {
    return new Date(iso + (iso.endsWith("Z") ? "" : "Z")).toLocaleTimeString("en-US", { hour12: false, timeZone: "America/New_York" });
  } catch { return "—"; }
}

// ─── Gauge component ────────────────────────────────────────────────
function Gauge2({ label, pct, value, sub }: { label: string; pct: number; value: string; sub: string }) {
  const color = barColor(pct);
  return (
    <div className="border border-trident-border bg-[#0a1628]/40 p-3" data-testid={`gauge-${label.toLowerCase().replace(/\s|\//g, "-")}`}>
      <div className="flex items-center justify-between mb-1.5">
        <span className="text-[10px] font-mono uppercase tracking-widest text-trident-text/60">{label}</span>
        <span className="text-[11px] font-mono tabular-nums" style={{ color }}>{pct}%</span>
      </div>
      <div className="h-2 w-full bg-[#050a0e] border border-trident-border/50 overflow-hidden">
        <div
          className="h-full transition-all duration-500"
          style={{ width: `${Math.min(100, pct)}%`, backgroundColor: color, boxShadow: `0 0 8px ${color}` }}
        />
      </div>
      <div className="mt-1.5 text-[11px] font-mono text-trident-cyan tabular-nums">{value}</div>
      <div className="text-[9px] font-mono uppercase tracking-wider text-trident-text/40">{sub}</div>
    </div>
  );
}

export default function OpsCenter() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const isAdmin = user?.role === "admin";
  const [briefFilter, setBriefFilter] = useState<string>("ALL");
  const [confirmRestart, setConfirmRestart] = useState<string | null>(null);

  // Net rate calc — keep previous reading
  const prevNet = useRef<{ rx: number; tx: number; ts: number } | null>(null);
  const [netRate, setNetRate] = useState<{ rx: number; tx: number }>({ rx: 0, tx: 0 });

  // ── Queries ──
  const { data: vitals, isLoading: vitalsLoading } = useQuery<Vitals>({
    queryKey: ["/api/ops/vitals"],
    queryFn: async () => {
      const res = await fetch(`${API_BASE}/api/ops/vitals`, { headers: getAuthHeaders() });
      if (!res.ok) throw new Error("VITALS FETCH FAILED");
      return res.json();
    },
    staleTime: 0,
    refetchInterval: 5000,
  });

  const { data: servicesData } = useQuery<{ services: SvcItem[] }>({
    queryKey: ["/api/ops/services"],
    queryFn: async () => {
      const res = await fetch(`${API_BASE}/api/ops/services`, { headers: getAuthHeaders() });
      if (!res.ok) throw new Error("SERVICES FETCH FAILED");
      return res.json();
    },
    staleTime: 0,
    refetchInterval: 15000,
  });

  const { data: briefData } = useQuery<{ entries: BriefEntry[] }>({
    queryKey: ["/api/ops/brief-log"],
    queryFn: async () => {
      const res = await fetch(`${API_BASE}/api/ops/brief-log`, { headers: getAuthHeaders() });
      if (!res.ok) throw new Error("BRIEF LOG FETCH FAILED");
      return res.json();
    },
    staleTime: 0,
    refetchInterval: 30000,
  });

  const { data: nasData } = useQuery<{ folders: NasFolder[]; total_size_mb: number; available: boolean }>({
    queryKey: ["/api/ops/nas"],
    queryFn: async () => {
      const res = await fetch(`${API_BASE}/api/ops/nas`, { headers: getAuthHeaders() });
      if (!res.ok) throw new Error("NAS FETCH FAILED");
      return res.json();
    },
    staleTime: 0,
    refetchInterval: 60000,
  });

  const { data: ollamaData } = useQuery<{ models: OllamaModel[]; available: boolean }>({
    queryKey: ["/api/ops/ollama"],
    queryFn: async () => {
      const res = await fetch(`${API_BASE}/api/ops/ollama`, { headers: getAuthHeaders() });
      if (!res.ok) throw new Error("OLLAMA FETCH FAILED");
      return res.json();
    },
    staleTime: 0,
    refetchInterval: 60000,
  });

  const { data: gridData } = useQuery<{ nodes: GridNode[]; jobs: any[]; available: boolean }>({
    queryKey: ["/api/ops/grid-summary"],
    queryFn: async () => {
      const res = await fetch(`${API_BASE}/api/ops/grid-summary`, { headers: getAuthHeaders() });
      if (!res.ok) throw new Error("GRID FETCH FAILED");
      return res.json();
    },
    staleTime: 0,
    refetchInterval: 10000,
  });

  // ── Restart mutation ──
  const restartMutation = useMutation({
    mutationFn: async (name: string) => {
      const res = await fetch(`${API_BASE}/api/ops/services/${name}/restart`, {
        method: "POST",
        headers: { ...getAuthHeaders(), "Content-Type": "application/json" },
      });
      if (!res.ok) throw new Error("RESTART FAILED");
      return res.json();
    },
    onSettled: () => {
      setConfirmRestart(null);
      queryClient.invalidateQueries({ queryKey: ["/api/ops/services"] });
    },
  });

  // ── Net rate effect ──
  useEffect(() => {
    if (!vitals) return;
    const now = Date.now();
    if (prevNet.current) {
      const dt = (now - prevNet.current.ts) / 1000;
      if (dt > 0) {
        setNetRate({
          rx: Math.max(0, (vitals.net_rx_bytes - prevNet.current.rx) / dt),
          tx: Math.max(0, (vitals.net_tx_bytes - prevNet.current.tx) / dt),
        });
      }
    }
    prevNet.current = { rx: vitals.net_rx_bytes, tx: vitals.net_tx_bytes, ts: now };
  }, [vitals]);

  const v = vitals;
  const services = servicesData?.services || [];
  const onlineCount = services.filter((s) => s.active).length;
  const briefEntries = (briefData?.entries || []).filter((e) => briefFilter === "ALL" || e.type.startsWith(briefFilter));
  const folders = nasData?.folders || [];
  const nasPct = v?.disk_nas_pct ?? 0;
  const models = ollamaData?.models || [];
  const gridNodes = gridData?.nodes || [];
  const gridOnline = gridNodes.filter((n) => n.status === "online").length;

  const statusDot = (s: SvcItem) => {
    if (s.status === "activating") return "#ff6b00";
    return s.active ? "#00ff41" : "#ff2244";
  };
  const statusText = (s: SvcItem) => {
    if (s.status === "activating") return "STARTING";
    return s.active ? "ONLINE" : "OFFLINE";
  };

  const BRIEF_FILTERS = ["ALL", "MARKET", "AVIATION", "WEATHER", "GEO", "INTEL"];

  return (
    <div className="max-w-7xl mx-auto space-y-6" data-testid="page-opscenter">
      {/* ═══════════ HEADER ═══════════ */}
      <div className="flex items-center justify-between border-b border-trident-border pb-4">
        <div>
          <div className="flex items-center gap-3">
            <Activity className="w-6 h-6 text-trident-cyan" style={{ filter: "drop-shadow(0 0 8px #00f0ff)" }} />
            <h1 className="font-display text-xl tracking-[0.15em] text-trident-cyan text-glow-cyan">OPSCENTER</h1>
          </div>
          <p className="mt-1 text-[10px] font-mono uppercase tracking-widest text-trident-text/50">
            TACTICAL OPERATIONS CENTER // SYSTEM STATUS
          </p>
        </div>
        <div className="text-right font-mono text-[10px] uppercase tracking-widest text-trident-text/60">
          <div>NODE: <span className="text-trident-cyan">192.168.0.7</span></div>
          <div>UPTIME: <span className="text-[#00ff41]">{fmtUptime(v?.uptime_seconds ?? 0)}</span></div>
        </div>
      </div>

      {/* ═══════════ SECTION 1 — SYSTEM VITALS ═══════════ */}
      <section>
        <div className="flex items-center gap-2 mb-3">
          <Gauge className="w-4 h-4 text-trident-amber" />
          <h2 className="font-mono text-xs uppercase tracking-widest text-trident-amber">SYSTEM VITALS</h2>
          <span className="text-[9px] font-mono text-trident-text/30">// REFRESH 5s</span>
        </div>
        {vitalsLoading && !v ? (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {Array.from({ length: 8 }).map((_, i) => (
              <div key={i} className="border border-trident-border bg-[#0a1628]/40 p-3 h-[92px] animate-pulse" />
            ))}
          </div>
        ) : (
          <div className="space-y-3">
            {/* Row 1 — Compute */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <Gauge2 label="CPU" pct={v?.cpu_pct ?? 0} value={`LOAD: ${(v?.load_avg_1 ?? 0).toFixed(2)}`} sub={`${v?.cpu_cores ?? 0} CORES`} />
              <Gauge2 label="RAM" pct={v?.ram_pct ?? 0} value={`${v?.ram_used_gb ?? 0}/${v?.ram_total_gb ?? 0} GB`} sub={`SWAP: ${v?.swap_used_gb ?? 0}GB`} />
              <Gauge2 label="GPU" pct={v?.gpu_pct ?? 0} value={v?.gpu_name || "N/A"} sub={`${v?.gpu_temp_c ?? 0}°C`} />
              <Gauge2
                label="GPU VRAM"
                pct={v && v.gpu_vram_total_gb ? Math.round((v.gpu_vram_used_gb / v.gpu_vram_total_gb) * 100) : 0}
                value={`${v?.gpu_vram_used_gb ?? 0}/${v?.gpu_vram_total_gb ?? 0} GB`}
                sub={v?.gpu_name || "GPU"}
              />
            </div>
            {/* Row 2 — Storage & Network */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <Gauge2 label="DISK /" pct={v?.disk_root_pct ?? 0} value={`${v?.disk_root_used_gb ?? 0}/${v?.disk_root_total_gb ?? 0} GB`} sub="ROOT VOLUME" />
              <Gauge2 label="DISK /opt" pct={v?.disk_opt_pct ?? 0} value={`${v?.disk_opt_used_gb ?? 0}/${v?.disk_opt_total_gb ?? 0} GB`} sub="APP VOLUME" />
              {v?.disk_nas_available ? (
                <Gauge2 label="NAS BRIEFS" pct={nasPct} value={`${v?.disk_nas_used_gb ?? 0}/${v?.disk_nas_total_gb ?? 0} GB`} sub="CIFS 192.168.0.20" />
              ) : (
                <div className="border border-trident-red/40 bg-trident-red/5 p-3" data-testid="gauge-nas-offline">
                  <div className="text-[10px] font-mono uppercase tracking-widest text-trident-red/70 mb-1.5">NAS BRIEFS</div>
                  <div className="text-[11px] font-mono text-trident-red">MOUNT UNAVAILABLE</div>
                  <div className="text-[9px] font-mono uppercase tracking-wider text-trident-text/40">CIFS 192.168.0.20</div>
                </div>
              )}
              <div className="border border-trident-border bg-[#0a1628]/40 p-3" data-testid="gauge-network">
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-[10px] font-mono uppercase tracking-widest text-trident-text/60">NETWORK</span>
                  <Network className="w-3 h-3 text-trident-cyan/50" />
                </div>
                <div className="text-[11px] font-mono text-[#00ff41] tabular-nums">↓ {fmtBytesRate(netRate.rx)}</div>
                <div className="text-[11px] font-mono text-trident-amber tabular-nums">↑ {fmtBytesRate(netRate.tx)}</div>
                <div className="text-[9px] font-mono uppercase tracking-wider text-trident-text/40 mt-0.5">
                  LOAD 5M: {(v?.load_avg_5 ?? 0).toFixed(2)} / 15M: {(v?.load_avg_15 ?? 0).toFixed(2)}
                </div>
              </div>
            </div>
          </div>
        )}
      </section>

      {/* ═══════════ SECTION 2 — SERVICE STATUS BOARD ═══════════ */}
      <section>
        <div className="flex items-center gap-2 mb-3">
          <Server className="w-4 h-4 text-trident-amber" />
          <h2 className="font-mono text-xs uppercase tracking-widest text-trident-amber">SERVICE STATUS BOARD</h2>
          <span className="text-[9px] font-mono text-trident-text/30">// REFRESH 15s</span>
          <span className="ml-auto text-[10px] font-mono uppercase tracking-widest text-[#00ff41]">
            {onlineCount}/{services.length || 11} ONLINE
          </span>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {services.map((s) => (
            <div key={s.name} className="border border-trident-border bg-[#0a1628]/40 p-3 flex flex-col gap-2" data-testid={`card-service-${s.name}`}>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="inline-block w-2 h-2 rounded-full" style={{ backgroundColor: statusDot(s), boxShadow: `0 0 6px ${statusDot(s)}` }} />
                  <span className="text-[10px] font-mono uppercase tracking-widest" style={{ color: statusDot(s) }}>{statusText(s)}</span>
                </div>
                <span className="text-[10px] font-mono text-trident-text/40 tabular-nums">:{s.port}</span>
              </div>
              <div className="text-[11px] font-mono uppercase tracking-wider text-trident-cyan truncate">{s.label}</div>
              <div className="text-[10px] font-mono text-trident-text/50 tabular-nums">
                MEM: {s.memory_mb != null ? `${s.memory_mb} MB` : "—"}
              </div>
              {isAdmin && (
                confirmRestart === s.name ? (
                  <div className="flex items-center gap-2 mt-1">
                    <span className="text-[9px] font-mono uppercase text-trident-amber flex-1">CONFIRM RESTART {s.name}?</span>
                    <button
                      onClick={() => setConfirmRestart(null)}
                      className="text-[9px] font-mono uppercase tracking-wider px-2 py-1 border border-trident-border text-trident-text/60 hover:text-trident-text"
                      data-testid={`button-cancel-restart-${s.name}`}
                    >CANCEL</button>
                    <button
                      onClick={() => restartMutation.mutate(s.name)}
                      disabled={restartMutation.isPending}
                      className="text-[9px] font-mono uppercase tracking-wider px-2 py-1 border border-trident-red/50 text-trident-red hover:bg-trident-red/10"
                      data-testid={`button-confirm-restart-${s.name}`}
                    >
                      {restartMutation.isPending && restartMutation.variables === s.name ? "RESTARTING..." : "CONFIRM RESTART"}
                    </button>
                  </div>
                ) : (
                  <button
                    onClick={() => setConfirmRestart(s.name)}
                    className="mt-1 flex items-center justify-center gap-1.5 text-[9px] font-mono uppercase tracking-widest px-2 py-1.5 border border-trident-amber/40 text-trident-amber hover:bg-trident-amber/10 transition-colors"
                    data-testid={`button-restart-${s.name}`}
                  >
                    <RotateCw className="w-3 h-3" /> RESTART
                  </button>
                )
              )}
            </div>
          ))}
          {services.length === 0 && (
            <div className="col-span-full text-center py-6 text-[10px] font-mono uppercase tracking-widest text-trident-text/40">
              QUERYING SYSTEMD UNITS...
            </div>
          )}
        </div>
      </section>

      {/* ═══════════ SECTION 3 — BRIEF ACTIVITY LOG ═══════════ */}
      <section>
        <div className="flex items-center gap-2 mb-3 flex-wrap">
          <Activity className="w-4 h-4 text-trident-amber" />
          <h2 className="font-mono text-xs uppercase tracking-widest text-trident-amber">BRIEF ACTIVITY LOG</h2>
          <span className="text-[9px] font-mono text-trident-text/30">// REFRESH 30s</span>
          <div className="ml-auto flex items-center gap-1">
            {BRIEF_FILTERS.map((f) => (
              <button
                key={f}
                onClick={() => setBriefFilter(f)}
                className={`text-[9px] font-mono uppercase tracking-wider px-2 py-1 border transition-colors ${
                  briefFilter === f
                    ? "border-trident-cyan text-trident-cyan bg-trident-cyan/10"
                    : "border-trident-border text-trident-text/50 hover:text-trident-cyan"
                }`}
                data-testid={`filter-brief-${f.toLowerCase()}`}
              >{f}</button>
            ))}
          </div>
        </div>
        <div className="border border-trident-border bg-[#0a1628]/40 overflow-x-auto">
          <table className="w-full text-[10px] font-mono">
            <thead>
              <tr className="border-b border-trident-border text-trident-text/40 uppercase tracking-widest">
                <th className="text-left px-3 py-2">TIME</th>
                <th className="text-left px-3 py-2">TYPE</th>
                <th className="text-left px-3 py-2">TOPIC/SOURCE</th>
                <th className="text-left px-3 py-2">MODEL</th>
                <th className="text-left px-3 py-2">STATUS</th>
              </tr>
            </thead>
            <tbody>
              {briefEntries.map((e) => (
                <tr key={e.id} className="border-b border-trident-border/40 hover:bg-trident-cyan/5" data-testid={`row-brief-${e.id}`}>
                  <td className="px-3 py-1.5 text-trident-text/70 tabular-nums">{fmtTime(e.created_at)}</td>
                  <td className="px-3 py-1.5 text-trident-cyan uppercase">{e.type}</td>
                  <td className="px-3 py-1.5 text-trident-text/80 uppercase">{e.topic}</td>
                  <td className="px-3 py-1.5 text-trident-amber">{e.model_used}</td>
                  <td className="px-3 py-1.5 text-[#00ff41]">✓ SAVED</td>
                </tr>
              ))}
              {briefEntries.length === 0 && (
                <tr><td colSpan={5} className="px-3 py-6 text-center text-trident-text/40 uppercase tracking-widest">NO BRIEF ACTIVITY RECORDED</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </section>

      {/* ═══════════ SECTION 4 — NAS STORAGE MONITOR ═══════════ */}
      <section>
        <div className="flex items-center gap-2 mb-3">
          <HardDrive className="w-4 h-4 text-trident-amber" />
          <h2 className="font-mono text-xs uppercase tracking-widest text-trident-amber">NAS STORAGE MONITOR</h2>
          <span className="text-[9px] font-mono text-trident-text/30">// REFRESH 60s</span>
        </div>
        <div className="border border-trident-border bg-[#0a1628]/40 p-3 space-y-3">
          {!nasData?.available ? (
            <div className="text-center py-4 text-[10px] font-mono uppercase tracking-widest text-trident-red/70">
              NAS MOUNT /mnt/trident-briefs UNAVAILABLE
            </div>
          ) : (
            <>
              <div className="overflow-x-auto">
                <table className="w-full text-[10px] font-mono">
                  <thead>
                    <tr className="border-b border-trident-border text-trident-text/40 uppercase tracking-widest">
                      <th className="text-left px-2 py-1.5">FOLDER</th>
                      <th className="text-right px-2 py-1.5">FILES</th>
                      <th className="text-right px-2 py-1.5">SIZE</th>
                      <th className="text-right px-2 py-1.5">LAST WRITE</th>
                    </tr>
                  </thead>
                  <tbody>
                    {folders.map((f) => (
                      <tr key={f.name} className="border-b border-trident-border/40" data-testid={`row-nas-${f.name}`}>
                        <td className="px-2 py-1.5 text-trident-cyan">{f.name}/</td>
                        <td className="px-2 py-1.5 text-right text-trident-text/80 tabular-nums">{f.file_count || "—"}</td>
                        <td className="px-2 py-1.5 text-right text-trident-text/80 tabular-nums">{fmtSize(f.size_mb)}</td>
                        <td className="px-2 py-1.5 text-right text-trident-text/60 tabular-nums">{fmtTime(f.last_modified)}</td>
                      </tr>
                    ))}
                    {folders.length === 0 && (
                      <tr><td colSpan={4} className="px-2 py-4 text-center text-trident-text/40 uppercase">NO FOLDERS FOUND</td></tr>
                    )}
                  </tbody>
                </table>
              </div>
              <div>
                <div className="flex items-center justify-between mb-1 text-[10px] font-mono uppercase tracking-widest">
                  <span className="text-trident-text/50">TOTAL NAS USAGE</span>
                  <span className="text-trident-cyan tabular-nums">
                    {v?.disk_nas_used_gb ?? 0} GB / {v?.disk_nas_total_gb ?? 0} GB
                  </span>
                </div>
                <div className="h-2.5 w-full bg-[#050a0e] border border-trident-border/50 overflow-hidden">
                  <div className="h-full transition-all duration-500" style={{ width: `${Math.min(100, nasPct)}%`, backgroundColor: barColor(nasPct), boxShadow: `0 0 8px ${barColor(nasPct)}` }} />
                </div>
              </div>
            </>
          )}
        </div>
      </section>

      {/* ═══════════ SECTION 5 — OLLAMA MODEL MANAGER ═══════════ */}
      <section>
        <div className="flex items-center gap-2 mb-3">
          <Boxes className="w-4 h-4 text-trident-amber" />
          <h2 className="font-mono text-xs uppercase tracking-widest text-trident-amber">OLLAMA MODEL MANAGER</h2>
          <span className="text-[9px] font-mono text-trident-text/30">// REFRESH 60s</span>
        </div>
        <div className="border border-trident-border bg-[#0a1628]/40 p-3">
          {!ollamaData?.available ? (
            <div className="text-center py-4 text-[10px] font-mono uppercase tracking-widest text-trident-red/70">OLLAMA SERVICE OFFLINE</div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-[10px] font-mono">
                <thead>
                  <tr className="border-b border-trident-border text-trident-text/40 uppercase tracking-widest">
                    <th className="text-left px-2 py-1.5">MODEL</th>
                    <th className="text-right px-2 py-1.5">SIZE</th>
                    <th className="text-right px-2 py-1.5">PARAMS</th>
                    <th className="text-right px-2 py-1.5">EST. VRAM</th>
                    <th className="text-right px-2 py-1.5">STATUS</th>
                  </tr>
                </thead>
                <tbody>
                  {models.map((m) => (
                    <tr key={m.name} className="border-b border-trident-border/40" data-testid={`row-model-${m.name}`}>
                      <td className="px-2 py-1.5 text-trident-cyan">{m.name}</td>
                      <td className="px-2 py-1.5 text-right text-trident-text/80 tabular-nums">{m.size_gb}GB</td>
                      <td className="px-2 py-1.5 text-right text-trident-text/80">{m.params}</td>
                      <td className="px-2 py-1.5 text-right text-trident-amber">{m.est_vram}</td>
                      <td className="px-2 py-1.5 text-right text-[#00ff41]">● AVAILABLE</td>
                    </tr>
                  ))}
                  {models.length === 0 && (
                    <tr><td colSpan={5} className="px-2 py-4 text-center text-trident-text/40 uppercase">NO MODELS INSTALLED</td></tr>
                  )}
                </tbody>
              </table>
            </div>
          )}
          <div className="mt-2 text-[9px] font-mono uppercase tracking-wider text-trident-text/40">
            CPU/GPU TOGGLE AVAILABLE IN SETTINGS
          </div>
        </div>
      </section>

      {/* ═══════════ SECTION 6 — GRID SUMMARY ═══════════ */}
      <section>
        <div className="flex items-center gap-2 mb-3">
          <Network className="w-4 h-4 text-trident-amber" />
          <h2 className="font-mono text-xs uppercase tracking-widest text-trident-amber">GRID SUMMARY</h2>
          <span className="text-[9px] font-mono text-trident-text/30">// REFRESH 10s</span>
        </div>
        <div className="border border-trident-border bg-[#0a1628]/40 p-3 space-y-2">
          <div className="text-[10px] font-mono uppercase tracking-widest text-trident-text/50">
            WORKER NODES ({gridOnline}/{gridNodes.length} ONLINE)
          </div>
          {gridNodes.map((n, i) => (
            <div key={n.node_id || i} className="flex items-center gap-3 text-[10px] font-mono flex-wrap" data-testid={`row-grid-${n.node_id || i}`}>
              <span className="inline-block w-2 h-2 rounded-full" style={{ backgroundColor: n.status === "online" ? "#00ff41" : "#ff2244", boxShadow: `0 0 6px ${n.status === "online" ? "#00ff41" : "#ff2244"}` }} />
              <span className="text-trident-cyan uppercase">{n.name || n.node_id}</span>
              <span className="text-trident-text/60">{n.ip}</span>
              <span className="text-trident-text/70">CPU:{Math.round(n.last_metrics?.cpu_pct ?? 0)}%</span>
              <span className="text-trident-text/70">RAM:{Math.round(n.last_metrics?.ram_pct ?? 0)}%</span>
              <span className="text-trident-amber">SCORE:{(n.score ?? 0).toFixed(1)}</span>
              <span className="text-trident-text/70">JOBS:{n.jobs_completed ?? 0}</span>
            </div>
          ))}
          {gridNodes.length === 0 && (
            <div className="text-[10px] font-mono uppercase tracking-widest text-trident-text/40 py-2">NO WORKER NODES REGISTERED</div>
          )}
          <button
            onClick={() => setLocation("/grid")}
            className="mt-1 text-[10px] font-mono uppercase tracking-widest text-trident-cyan hover:text-glow-cyan transition-colors"
            data-testid="link-full-grid"
          >
            → VIEW FULL GRID
          </button>
        </div>
      </section>
    </div>
  );
}
