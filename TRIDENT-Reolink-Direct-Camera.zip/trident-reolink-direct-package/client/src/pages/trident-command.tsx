import { useState, useRef, useEffect, useCallback } from "react";
import { useQuery } from "@tanstack/react-query";
import { getAuthHeaders } from "@/hooks/use-auth";
import {
  Terminal, Radio, Cpu, Network, Plus, Trash2, Volume2, Mic,
  Send, Zap, Radar, Cloud, TrendingUp, Server, Activity, FileText,
  Shield, Globe, Newspaper, Plane, HardDrive, ClipboardList, Router,
} from "lucide-react";

const API_BASE = "__PORT_5000__".startsWith("__") ? "" : "__PORT_5000__";

const QUICK = [
  { label: "FLIGHTS OVERHEAD", q: "What aircraft are currently overhead Denton NC?", icon: Radar },
  { label: "MILITARY AIRCRAFT", q: "Any military aircraft detected today?", icon: Shield },
  { label: "WEATHER STATUS", q: "Current weather and any NOAA alerts for Davidson County?", icon: Cloud },
  { label: "MARKET OVERVIEW", q: "Quick market overview — indices and crypto.", icon: TrendingUp },
  { label: "GEO-INTEL BRIEF", q: "Summarize the latest geopolitical intelligence brief.", icon: Globe },
  { label: "GRID HEALTH", q: "Is the TRIDENT GRID healthy? Worker node status?", icon: Network },
  { label: "NETWORK STATUS", q: "What's the status of the core network switches and WAN connections?", icon: Router },
  { label: "PROXMOX STATUS", q: "What's the status of the Proxmox cluster? How many hosts and VMs are online?", icon: Server },
  { label: "SECURITY STATUS", q: "What's the status of the security cameras at Command Station Alpha1? Any active alarms or recent detections?", icon: Shield },
  { label: "SYSTEM STATUS", q: "TRIDENT system health — CPU, RAM, GPU status.", icon: Server },
  { label: "TODAY'S BRIEFS", q: "What briefs have been generated and saved to NAS today?", icon: FileText },
  { label: "WEB INTEL SUMMARY", q: "Summarize the latest web intelligence findings.", icon: Newspaper },
  { label: "AVIATION HISTORY", q: "Show aviation flight history stats for today.", icon: Plane },
  { label: "NAS STORAGE", q: "What is the current NAS storage usage and capacity?", icon: HardDrive },
  { label: "FULL SITREP", q: "Give me a full situation report across all TRIDENT modules.", icon: ClipboardList },
];

const INTENT_LABEL: Record<string, string> = {
  flights: "FLIGHTS", weather: "WEATHER", markets: "MARKETS", geo: "GEO-INTEL",
  system: "SYSTEM", grid: "GRID", network: "NETWORK", security: "SECURITY", briefs: "BRIEFS", general: "ALL-SOURCE",
};

interface Msg { role: "user" | "assistant"; content: string; ts: string; meta?: any; }
interface Session { id: number; title: string; messages: string; updatedAt: string; }

export default function TridentCommand() {
  const authHeaders = getAuthHeaders();
  const [messages, setMessages] = useState<Msg[]>([]);
  const [input, setInput] = useState("");
  const [streaming, setStreaming] = useState(false);
  const [currentResponse, setCurrentResponse] = useState("");
  const [currentMeta, setCurrentMeta] = useState<any>(null);
  const currentMetaRef = useRef<any>(null);
  const [autoTts, setAutoTts] = useState(true);
  const [voiceMode, setVoiceMode] = useState(true);
  const [selectedModel, setSelectedModel] = useState("");
  const [models, setModels] = useState<any[]>([]);
  const [recording, setRecording] = useState(false);
  const [transcribing, setTranscribing] = useState(false);
  const [recorder, setRecorder] = useState<MediaRecorder | null>(null);
  const [playingIdx, setPlayingIdx] = useState<number | null>(null);
  const feedRef = useRef<HTMLDivElement>(null);

  // System status
  const { data: status } = useQuery<{ ollama: boolean; voice: boolean; grid: boolean }>({
    queryKey: ["/api/command/status"],
    queryFn: async () => {
      const res = await fetch(`${API_BASE}/api/command/status`, { headers: getAuthHeaders() });
      if (!res.ok) throw new Error("status failed");
      return res.json();
    },
    refetchInterval: 15000,
    staleTime: 0,
  });

  // Sessions
  const { data: sessionsData, refetch: refetchSessions } = useQuery<{ sessions: Session[] }>({
    queryKey: ["/api/command/sessions"],
    queryFn: async () => {
      const res = await fetch(`${API_BASE}/api/command/sessions`, { headers: getAuthHeaders() });
      if (!res.ok) throw new Error("sessions failed");
      return res.json();
    },
    staleTime: 0,
  });

  // Models
  useEffect(() => {
    (async () => {
      try {
        const res = await fetch(`${API_BASE}/api/ollama/models`, { headers: authHeaders });
        if (res.ok) {
          const data = await res.json();
          setModels(data.models || []);
          if (data.models?.length > 0) setSelectedModel(data.models[0].name);
        }
      } catch {}
    })();
  }, []);

  useEffect(() => {
    feedRef.current?.scrollTo({ top: feedRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, currentResponse]);

  const playTTS = useCallback(async (text: string, idx?: number) => {
    try {
      if (idx !== undefined) setPlayingIdx(idx);
      const r = await fetch(`${API_BASE}/api/command/tts`, {
        method: "POST",
        headers: { ...getAuthHeaders(), "Content-Type": "application/json" },
        body: JSON.stringify({ text: text.slice(0, 500) }),
      });
      if (!r.ok) throw new Error("tts");
      const blob = await r.blob();
      const audio = new Audio(URL.createObjectURL(blob));
      audio.onended = () => setPlayingIdx(null);
      await audio.play();
    } catch { setPlayingIdx(null); }
  }, []);

  const sendMessage = useCallback(async (text: string) => {
    if (!text.trim() || streaming) return;
    const userMsg: Msg = { role: "user", content: text, ts: new Date().toISOString() };
    const priorMessages = messages;
    setMessages(prev => [...prev, userMsg]);
    setInput("");
    setStreaming(true);
    setCurrentResponse("");
    setCurrentMeta(null);
    currentMetaRef.current = null;

    try {
      const res = await fetch(`${API_BASE}/api/command/query`, {
        method: "POST",
        headers: { ...getAuthHeaders(), "Content-Type": "application/json" },
        body: JSON.stringify({
          message: text,
          history: priorMessages.map(m => ({ role: m.role, content: m.content })),
          model: selectedModel || undefined,
        }),
      });
      if (!res.body) throw new Error("no stream");
      const reader = res.body.getReader();
      const dec = new TextDecoder();
      let full = "";
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        for (const line of dec.decode(value, { stream: true }).split("\n")) {
          if (!line.startsWith("data: ")) continue;
          try {
            const d = JSON.parse(line.slice(6));
            if (d.type === "meta") { setCurrentMeta(d); currentMetaRef.current = d; }
            if (d.type === "token") { full += d.token; setCurrentResponse(full); }
            if (d.type === "error") { full = full || `[ERROR] ${d.error || "LLM unavailable"}`; }
            if (d.type === "done") { /* handled below */ }
          } catch {}
        }
      }
      const assistantMsg: Msg = { role: "assistant", content: full || "[NO RESPONSE]", meta: currentMetaRef.current, ts: new Date().toISOString() };
      setMessages(prev => [...prev, assistantMsg]);
      setCurrentResponse("");
      setStreaming(false);
      if (autoTts && full) playTTS(full);
    } catch (e) {
      setMessages(prev => [...prev, { role: "assistant", content: "[COMMS LINK FAILURE] Unable to reach intelligence core.", ts: new Date().toISOString() }]);
      setCurrentResponse("");
      setStreaming(false);
    }
  }, [messages, streaming, selectedModel, autoTts, playTTS]);

  // Voice PTT
  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mr = new MediaRecorder(stream);
      const chunks: Blob[] = [];
      mr.ondataavailable = e => chunks.push(e.data);
      mr.onstop = async () => {
        stream.getTracks().forEach(t => t.stop());
        setTranscribing(true);
        const blob = new Blob(chunks, { type: "audio/webm" });
        const fd = new FormData();
        fd.append("audio", blob, "recording.webm");
        try {
          const r = await fetch(`${API_BASE}/api/voice/stt`, { method: "POST", headers: getAuthHeaders(), body: fd });
          const d = await r.json();
          const txt = d.transcript || d.text || "";
          if (txt) { setInput(txt); if (voiceMode) sendMessage(txt); }
        } catch {}
        setTranscribing(false);
      };
      mr.start();
      setRecorder(mr);
      setRecording(true);
    } catch {}
  };

  const stopRecording = () => {
    recorder?.stop();
    setRecording(false);
  };

  const newSession = async () => {
    setMessages([]);
    setCurrentResponse("");
    try {
      await fetch(`${API_BASE}/api/command/sessions`, {
        method: "POST",
        headers: { ...getAuthHeaders(), "Content-Type": "application/json" },
        body: JSON.stringify({ title: "COMMAND SESSION" }),
      });
      refetchSessions();
    } catch {}
  };

  const loadSession = (s: Session) => {
    try {
      const msgs = JSON.parse(s.messages || "[]");
      setMessages(Array.isArray(msgs) ? msgs : []);
      setCurrentResponse("");
    } catch { setMessages([]); }
  };

  const deleteSession = async (id: number, e: React.MouseEvent) => {
    e.stopPropagation();
    try {
      await fetch(`${API_BASE}/api/command/sessions/${id}`, { method: "DELETE", headers: getAuthHeaders() });
      refetchSessions();
    } catch {}
  };

  const StatusDot = ({ ok, label, icon: Icon }: { ok?: boolean; label: string; icon: any }) => (
    <div className="flex items-center gap-2 px-2 py-1.5">
      <Icon className={`w-3.5 h-3.5 ${ok ? "text-[#00ff41]" : "text-trident-red/60"}`} />
      <span className="text-[10px] font-mono uppercase tracking-widest text-trident-text/60 flex-1">{label}</span>
      <span className={`inline-block w-1.5 h-1.5 rounded-full ${ok ? "bg-[#00ff41] animate-pulse" : "bg-trident-red/60"}`}
        style={ok ? { boxShadow: "0 0 6px #00ff41" } : undefined} />
    </div>
  );

  return (
    <div className="h-full flex gap-3">
      {/* ═══════ LEFT COLUMN ═══════ */}
      <div className="w-[280px] flex-shrink-0 flex flex-col gap-3 overflow-y-auto" data-testid="command-sidebar">
        {/* Header */}
        <div className="border border-trident-amber/40 bg-trident-amber/5 px-3 py-3" style={{ boxShadow: "0 0 20px rgba(255,176,0,0.1)" }}>
          <div className="flex items-center gap-2">
            <Terminal className="w-5 h-5 text-trident-amber" style={{ filter: "drop-shadow(0 0 6px #ffb000)" }} />
            <div className="font-display text-sm tracking-[0.2em] text-trident-amber" style={{ textShadow: "0 0 10px #ffb00080" }}>
              COMMAND
            </div>
          </div>
          <div className="text-[9px] font-mono uppercase tracking-widest text-trident-text/40 mt-1">
            ALL-SOURCE INTELLIGENCE
          </div>
        </div>

        {/* Status strip */}
        <div className="border border-trident-border bg-[#0a1628]/60">
          <div className="px-2 py-1.5 border-b border-trident-border text-[9px] font-mono uppercase tracking-widest text-trident-cyan/60">
            SUBSYSTEMS
          </div>
          <StatusDot ok={status?.ollama} label="OLLAMA CORE" icon={Cpu} />
          <StatusDot ok={status?.voice} label="VOICE UNIT" icon={Radio} />
          <StatusDot ok={status?.grid} label="TRIDENT GRID" icon={Network} />
        </div>

        {/* Sessions */}
        <div className="border border-trident-border bg-[#0a1628]/60">
          <div className="px-2 py-1.5 border-b border-trident-border flex items-center justify-between">
            <span className="text-[9px] font-mono uppercase tracking-widest text-trident-cyan/60">SESSIONS</span>
            <button onClick={newSession} data-testid="button-new-session"
              className="flex items-center gap-1 text-[9px] font-mono uppercase tracking-widest text-trident-amber hover:text-trident-amber/80 transition-colors">
              <Plus className="w-3 h-3" /> NEW
            </button>
          </div>
          <div className="max-h-[180px] overflow-y-auto">
            {(sessionsData?.sessions || []).length === 0 && (
              <div className="px-2 py-3 text-[9px] font-mono uppercase tracking-widest text-trident-text/30">NO SESSIONS</div>
            )}
            {(sessionsData?.sessions || []).map(s => (
              <div key={s.id} onClick={() => loadSession(s)} data-testid={`session-${s.id}`}
                className="group flex items-center gap-2 px-2 py-2 border-b border-trident-border/40 cursor-pointer hover:bg-trident-cyan/5 transition-colors">
                <FileText className="w-3 h-3 text-trident-text/30 flex-shrink-0" />
                <span className="text-[10px] font-mono text-trident-text/70 truncate flex-1">{s.title}</span>
                <button onClick={(e) => deleteSession(s.id, e)} data-testid={`delete-session-${s.id}`}
                  className="opacity-0 group-hover:opacity-100 text-trident-red/60 hover:text-trident-red transition-all">
                  <Trash2 className="w-3 h-3" />
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Quick commands */}
        <div className="border border-trident-border bg-[#0a1628]/60 flex-1">
          <div className="px-2 py-1.5 border-b border-trident-border text-[9px] font-mono uppercase tracking-widest text-trident-cyan/60">
            QUICK QUERIES
          </div>
          <div className="p-2 space-y-1.5">
            {QUICK.map(q => {
              const Icon = q.icon;
              return (
                <button key={q.label} onClick={() => sendMessage(q.q)} disabled={streaming}
                  data-testid={`quick-${q.label.toLowerCase().replace(/[^a-z]/g, "-")}`}
                  className="w-full flex items-center gap-2 px-2 py-2 border border-trident-border hover:border-trident-amber/50 hover:bg-trident-amber/5 disabled:opacity-40 disabled:cursor-not-allowed transition-all text-left group">
                  <Icon className="w-3.5 h-3.5 text-trident-cyan/60 group-hover:text-trident-amber flex-shrink-0" />
                  <span className="text-[9px] font-mono uppercase tracking-widest text-trident-text/70 group-hover:text-trident-text">{q.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* ═══════ RIGHT COLUMN ═══════ */}
      <div className="flex-1 flex flex-col border border-trident-border bg-[#0a1628]/40 overflow-hidden">
        {/* Header bar */}
        <div className="flex items-center justify-between px-4 py-2.5 border-b border-trident-border scanlines" style={{ backgroundColor: "#0a1628" }}>
          <div className="flex items-center gap-2 relative z-10">
            <Zap className="w-4 h-4 text-trident-amber" />
            <span className="font-display text-xs tracking-[0.15em] text-trident-amber">TRIDENT COMMAND</span>
            <span className="text-[9px] font-mono uppercase tracking-widest text-trident-text/40 ml-2">
              MODEL: <span className="text-trident-cyan">{selectedModel || "AUTO"}</span>
            </span>
          </div>
          <div className="flex items-center gap-3 relative z-10">
            {models.length > 0 && (
              <select value={selectedModel} onChange={e => setSelectedModel(e.target.value)} data-testid="select-model"
                className="bg-[#050a0e] border border-trident-border text-[10px] font-mono uppercase tracking-widest text-trident-text/70 px-2 py-1 outline-none focus:border-trident-cyan">
                {models.map(m => <option key={m.name} value={m.name}>{m.name}</option>)}
              </select>
            )}
            <button onClick={() => setAutoTts(!autoTts)} data-testid="toggle-tts"
              className={`px-2 py-1 text-[9px] font-mono uppercase tracking-widest border transition-all ${autoTts ? "text-trident-amber border-trident-amber/50 bg-trident-amber/10" : "text-trident-text/50 border-trident-border hover:text-trident-text"}`}>
              AUTO-TTS {autoTts ? "ON" : "OFF"}
            </button>
            <button onClick={() => setVoiceMode(!voiceMode)} data-testid="toggle-voice"
              className={`px-2 py-1 text-[9px] font-mono uppercase tracking-widest border transition-all ${voiceMode ? "text-[#00ff41] border-[#00ff41]/50 bg-[#00ff41]/10" : "text-trident-text/50 border-trident-border hover:text-trident-text"}`}>
              VOICE MODE {voiceMode ? "ON" : "OFF"}
            </button>
          </div>
        </div>

        {/* Message feed */}
        <div ref={feedRef} className="flex-1 overflow-y-auto p-4 space-y-4 grid-bg" data-testid="message-feed">
          {messages.length === 0 && !streaming && (
            <div className="h-full flex flex-col items-center justify-center text-center">
              <Terminal className="w-12 h-12 text-trident-amber/30 mb-4" />
              <div className="font-display text-sm tracking-[0.2em] text-trident-text/40 mb-2">TRIDENT COMMAND ONLINE</div>
              <div className="text-[10px] font-mono uppercase tracking-widest text-trident-text/30 max-w-md">
                Real-time access to airspace, weather, markets, grid, and system telemetry.
                Issue a query or select a quick command.
              </div>
            </div>
          )}

          {messages.map((m, i) => (
            m.role === "user" ? (
              <div key={i} className="flex justify-end" data-testid={`msg-user-${i}`}>
                <div className="max-w-[75%] border border-trident-border bg-[#050a0e] px-3 py-2">
                  <div className="text-[8px] font-mono uppercase tracking-widest text-trident-cyan/40 mb-1">
                    OPERATOR · {new Date(m.ts).toLocaleTimeString("en-US", { hour12: false })}
                  </div>
                  <div className="text-xs text-trident-text/90" style={{ fontFamily: "'JetBrains Mono', monospace" }}>{m.content}</div>
                </div>
              </div>
            ) : (
              <div key={i} className="flex justify-start" data-testid={`msg-assistant-${i}`}>
                <div className="max-w-[80%]">
                  <div className="flex items-center gap-1.5 mb-1.5 flex-wrap">
                    <span className="text-[8px] font-mono uppercase tracking-widest text-trident-amber">TRIDENT COMMAND</span>
                    {m.meta?.intents?.map((it: string) => (
                      <span key={it} className="px-1.5 py-0.5 text-[8px] font-mono uppercase tracking-widest text-trident-amber border border-trident-amber/40 bg-trident-amber/5">
                        {INTENT_LABEL[it] || it.toUpperCase()}
                      </span>
                    ))}
                    <span className={`px-1.5 py-0.5 text-[8px] font-mono uppercase tracking-widest border ${m.meta?.offloaded ? "text-trident-cyan border-trident-cyan/40 bg-trident-cyan/5" : "text-trident-text/50 border-trident-border"}`}>
                      {m.meta?.offloaded ? "WORKER" : "LOCAL"}
                    </span>
                  </div>
                  <div className="border-l-2 border-trident-amber/40 pl-3 py-1 text-xs text-trident-text/90 whitespace-pre-wrap leading-relaxed" style={{ fontFamily: "'JetBrains Mono', monospace" }}>
                    {m.content}
                  </div>
                  <button onClick={() => playTTS(m.content, i)} data-testid={`play-tts-${i}`}
                    className={`mt-1.5 ml-3 flex items-center gap-1 text-[8px] font-mono uppercase tracking-widest transition-colors ${playingIdx === i ? "text-trident-amber" : "text-trident-text/40 hover:text-trident-cyan"}`}>
                    <Volume2 className="w-3 h-3" /> {playingIdx === i ? "PLAYING..." : "PLAY"}
                  </button>
                </div>
              </div>
            )
          ))}

          {streaming && (
            <div className="flex justify-start" data-testid="msg-streaming">
              <div className="max-w-[80%]">
                <div className="flex items-center gap-1.5 mb-1.5 flex-wrap">
                  <span className="text-[8px] font-mono uppercase tracking-widest text-trident-amber">TRIDENT COMMAND</span>
                  {currentMeta?.intents?.map((it: string) => (
                    <span key={it} className="px-1.5 py-0.5 text-[8px] font-mono uppercase tracking-widest text-trident-amber border border-trident-amber/40 bg-trident-amber/5">
                      {INTENT_LABEL[it] || it.toUpperCase()}
                    </span>
                  ))}
                  {currentMeta && (
                    <span className={`px-1.5 py-0.5 text-[8px] font-mono uppercase tracking-widest border ${currentMeta.offloaded ? "text-trident-cyan border-trident-cyan/40 bg-trident-cyan/5" : "text-trident-text/50 border-trident-border"}`}>
                      {currentMeta.offloaded ? "WORKER" : "LOCAL"}
                    </span>
                  )}
                </div>
                {currentResponse ? (
                  <div className="border-l-2 border-trident-amber/40 pl-3 py-1 text-xs text-trident-text/90 whitespace-pre-wrap leading-relaxed" style={{ fontFamily: "'JetBrains Mono', monospace" }}>
                    {currentResponse}<span className="inline-block w-2 h-3.5 bg-trident-amber/70 animate-pulse ml-0.5 align-middle" />
                  </div>
                ) : (
                  <div className="flex items-center gap-2 pl-3 text-[10px] font-mono uppercase tracking-widest text-trident-amber/70 animate-pulse">
                    <Activity className="w-3.5 h-3.5" /> &gt;&gt; PROCESSING INTELLIGENCE...
                  </div>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Input area */}
        <div className="border-t border-trident-border p-3 flex items-center gap-2" style={{ backgroundColor: "#0a1628" }}>
          <button
            onMouseDown={startRecording} onMouseUp={stopRecording} onMouseLeave={() => recording && stopRecording()}
            onTouchStart={startRecording} onTouchEnd={stopRecording}
            disabled={transcribing} data-testid="button-ptt"
            className={`flex items-center gap-1.5 px-3 py-2.5 border font-mono text-[9px] uppercase tracking-widest transition-all flex-shrink-0 ${recording ? "text-trident-red border-trident-red bg-trident-red/10 animate-pulse" : transcribing ? "text-trident-amber border-trident-amber/50" : "text-trident-text/60 border-trident-border hover:text-trident-cyan hover:border-trident-cyan/50"}`}>
            <Mic className="w-3.5 h-3.5" /> {recording ? "REC..." : transcribing ? "..." : "HOLD"}
          </button>
          <input
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={e => { if (e.key === "Enter") sendMessage(input); }}
            placeholder="ENTER TACTICAL QUERY..."
            data-testid="input-query"
            className="flex-1 bg-[#050a0e] border border-trident-border px-3 py-2.5 text-xs text-trident-text placeholder:text-trident-text/30 outline-none focus:border-trident-cyan/60 uppercase tracking-wide"
            style={{ fontFamily: "'JetBrains Mono', monospace" }}
          />
          <button onClick={() => sendMessage(input)} disabled={streaming || !input.trim()} data-testid="button-send"
            className="flex items-center gap-1.5 px-4 py-2.5 border border-trident-amber/50 bg-trident-amber/10 text-trident-amber font-mono text-[10px] uppercase tracking-widest hover:bg-trident-amber/20 disabled:opacity-30 disabled:cursor-not-allowed transition-all flex-shrink-0">
            <Send className="w-3.5 h-3.5" /> SEND
          </button>
        </div>
      </div>
    </div>
  );
}
