import {
  type User,
  type InsertUser,
  type SafeUser,
  type Session,
  type InsertSession,
  type Conversation,
  type InsertConversation,
  type Message,
  type InsertMessage,
  type ModelConfig,
  type InsertModelConfig,
  type VoiceSession,
  type InsertVoiceSession,
  type GeneratedImage,
  type InsertGeneratedImage,
  type ConversationFile,
  type InsertConversationFile,
  type ApiKey,
  type InsertApiKey,
  type ToolConfig,
  type InsertToolConfig,
  type ScheduledTask,
  type InsertScheduledTask,
  type TaskRun,
  type InsertTaskRun,
  type MarketWatchlist,
  type InsertMarketWatchlist,
  type DailyBrief,
  type InsertDailyBrief,
  type GeoBrief,
  type InsertGeoBrief,
  users,
  sessions,
  conversations,
  messages,
  modelConfigs,
  voiceSessions,
  generatedImages,
  conversationFiles,
  apiKeys,
  toolConfigs,
  scheduledTasks,
  taskRuns,
  systemConfig,
  marketWatchlist,
  dailyBriefs,
  geoBriefs,
} from "@shared/schema";
import { drizzle } from "drizzle-orm/better-sqlite3";
import Database from "better-sqlite3";
import { eq, and, desc, sql } from "drizzle-orm";

const sqlite = new Database("data.db");
sqlite.pragma("journal_mode = WAL");

export const db = drizzle(sqlite);

// Strip password_hash from user for frontend delivery
function toSafeUser(user: User): SafeUser {
  const { password_hash, ...safe } = user;
  return safe;
}

export interface IStorage {
  // User CRUD
  getUser(id: number): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, data: Partial<Pick<User, "username" | "email" | "password_hash" | "role" | "is_active" | "last_login">>): Promise<User | undefined>;
  deleteUser(id: number): Promise<boolean>;
  getAllUsers(): Promise<SafeUser[]>;

  // Session CRUD
  createSession(session: InsertSession): Promise<Session>;
  getSessionByTokenHash(tokenHash: string): Promise<Session | undefined>;
  deleteSession(tokenHash: string): Promise<boolean>;
  deleteUserSessions(userId: number): Promise<boolean>;

  // Conversations
  createConversation(data: InsertConversation): Promise<Conversation>;
  getConversation(id: number, userId: number): Promise<Conversation | undefined>;
  getUserConversations(userId: number): Promise<Conversation[]>;
  updateConversation(id: number, userId: number, data: Partial<Pick<Conversation, "title" | "model" | "system_prompt" | "updated_at">>): Promise<Conversation | undefined>;
  deleteConversation(id: number, userId: number): Promise<boolean>;

  // Messages
  addMessage(data: InsertMessage): Promise<Message>;
  getConversationMessages(conversationId: number): Promise<Message[]>;
  deleteConversationMessages(conversationId: number): Promise<boolean>;

  // Model configs
  getModelConfig(userId: number, modelName: string): Promise<ModelConfig | undefined>;
  upsertModelConfig(userId: number, modelName: string, data: Partial<Pick<ModelConfig, "temperature" | "max_tokens" | "top_p" | "system_prompt">>): Promise<ModelConfig>;

  // Voice sessions — Phase 3
  createVoiceSession(data: InsertVoiceSession): Promise<VoiceSession>;
  getVoiceSession(id: number, userId: number): Promise<VoiceSession | undefined>;
  getUserVoiceSessions(userId: number): Promise<VoiceSession[]>;
  updateVoiceSession(id: number, userId: number, data: Partial<Pick<VoiceSession, "duration_seconds" | "message_count" | "conversation_id">>): Promise<VoiceSession | undefined>;

  // Generated images — Phase 4
  createGeneratedImage(data: InsertGeneratedImage): Promise<GeneratedImage>;
  getUserImages(userId: number, limit?: number, offset?: number): Promise<GeneratedImage[]>;
  getImage(id: number, userId: number): Promise<GeneratedImage | undefined>;
  deleteImage(id: number, userId: number): Promise<boolean>;
  toggleFavorite(id: number, userId: number): Promise<GeneratedImage | undefined>;
  getUserImageCount(userId: number): Promise<number>;

  // Conversation files — Phase 5
  addConversationFile(data: InsertConversationFile): Promise<ConversationFile>;
  getConversationFiles(conversationId: number): Promise<ConversationFile[]>;
  getConversationFile(id: number, userId: number): Promise<ConversationFile | undefined>;
  deleteConversationFile(id: number, userId: number): Promise<boolean>;
  updateFileExtraction(id: number, extractedText: string, status: string): Promise<ConversationFile | undefined>;

  // System stats — Phase 6
  getSystemStats(): Promise<{
    userCount: number;
    activeUserCount: number;
    adminCount: number;
    conversationCount: number;
    messageCount: number;
    imageCount: number;
    imageTotalSize: number;
    fileCount: number;
    fileTotalSize: number;
  }>;

  // Per-user stats — Phase 6
  getUserStats(userId: number): Promise<{
    conversations: number;
    messages: number;
    images: number;
    files: number;
    storageBytes: number;
  }>;

  // API keys — Phase 6
  createApiKey(data: InsertApiKey): Promise<ApiKey>;
  getUserApiKeys(userId: number): Promise<ApiKey[]>;
  getApiKeyByHash(keyHash: string): Promise<ApiKey | undefined>;
  deactivateApiKey(id: number, userId: number): Promise<boolean>;

  // Tool configs — Phase 8
  getToolConfig(userId: number, toolName: string): Promise<ToolConfig | undefined>;
  getAllToolConfigs(userId: number): Promise<ToolConfig[]>;
  upsertToolConfig(userId: number, toolName: string, config: string, isEnabled: number): Promise<ToolConfig>;
  deleteToolConfig(userId: number, toolName: string): Promise<boolean>;

  // Scheduled tasks — Phase 8
  createScheduledTask(data: InsertScheduledTask): Promise<ScheduledTask>;
  getScheduledTask(id: number, userId: number): Promise<ScheduledTask | undefined>;
  getUserScheduledTasks(userId: number): Promise<ScheduledTask[]>;
  getAllActiveScheduledTasks(): Promise<ScheduledTask[]>;
  updateScheduledTask(id: number, userId: number, data: Partial<Pick<ScheduledTask, "name" | "description" | "tool_name" | "tool_action" | "tool_params" | "schedule_cron" | "is_active" | "alert_condition" | "last_run" | "last_result">>): Promise<ScheduledTask | undefined>;
  deleteScheduledTask(id: number, userId: number): Promise<boolean>;

  // Task runs — Phase 8
  createTaskRun(data: InsertTaskRun): Promise<TaskRun>;
  getTaskRuns(taskId: number, userId: number, limit?: number): Promise<TaskRun[]>;
  getRecentTaskRuns(userId: number, limit?: number): Promise<TaskRun[]>;
  updateTaskRun(id: number, data: Partial<Pick<TaskRun, "completed_at" | "status" | "result" | "alert_triggered" | "error">>): Promise<TaskRun | undefined>;
  // System config
  getSystemConfig(key: string): Promise<string | undefined>;
  setSystemConfig(key: string, value: string): Promise<void>;
  getAllSystemConfig(): Promise<Record<string, string>>;

  // Intelligence — Markets (Phase 1)
  getWatchlist(userId: number): Promise<MarketWatchlist[]>;
  addWatchlistItem(data: InsertMarketWatchlist): Promise<MarketWatchlist>;
  removeWatchlistItem(id: number, userId: number): Promise<boolean>;
  getTodayBrief(userId: number, date: string): Promise<DailyBrief | undefined>;
  getLatestBrief(userId: number): Promise<DailyBrief | undefined>;
  createBrief(data: InsertDailyBrief): Promise<DailyBrief>;
  listBriefs(userId: number, limit?: number): Promise<DailyBrief[]>;
  getTodayGeoBrief(userId: number, date: string): Promise<GeoBrief | undefined>;
  getLatestGeoBrief(userId: number): Promise<GeoBrief | undefined>;
  createGeoBrief(data: InsertGeoBrief): Promise<GeoBrief>;
  listGeoBriefs(userId: number, limit?: number): Promise<GeoBrief[]>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    return db.select().from(users).where(eq(users.id, id)).get();
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return db.select().from(users).where(eq(users.email, email)).get();
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return db.select().from(users).where(eq(users.username, username)).get();
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const now = new Date().toISOString();
    return db.insert(users).values({ ...insertUser, created_at: now }).returning().get();
  }

  async updateUser(
    id: number,
    data: Partial<Pick<User, "username" | "email" | "password_hash" | "role" | "is_active" | "last_login">>
  ): Promise<User | undefined> {
    return db.update(users).set(data).where(eq(users.id, id)).returning().get();
  }

  async deleteUser(id: number): Promise<boolean> {
    const result = db.delete(users).where(eq(users.id, id)).run();
    return result.changes > 0;
  }

  async getAllUsers(): Promise<SafeUser[]> {
    const allUsers = db.select().from(users).all();
    return allUsers.map(toSafeUser);
  }

  // Sessions
  async createSession(session: InsertSession): Promise<Session> {
    const now = new Date().toISOString();
    return db.insert(sessions).values({ ...session, created_at: now }).returning().get();
  }

  async getSessionByTokenHash(tokenHash: string): Promise<Session | undefined> {
    return db.select().from(sessions).where(eq(sessions.token_hash, tokenHash)).get();
  }

  async deleteSession(tokenHash: string): Promise<boolean> {
    const result = db.delete(sessions).where(eq(sessions.token_hash, tokenHash)).run();
    return result.changes > 0;
  }

  async deleteUserSessions(userId: number): Promise<boolean> {
    const result = db.delete(sessions).where(eq(sessions.user_id, userId)).run();
    return result.changes >= 0;
  }

  // ═══════════════════════════════════════════════════
  // CONVERSATIONS — Phase 2
  // ═══════════════════════════════════════════════════
  async createConversation(data: InsertConversation): Promise<Conversation> {
    return db.insert(conversations).values(data).returning().get();
  }

  async getConversation(id: number, userId: number): Promise<Conversation | undefined> {
    return db.select().from(conversations).where(and(eq(conversations.id, id), eq(conversations.user_id, userId))).get();
  }

  async getUserConversations(userId: number): Promise<Conversation[]> {
    return db.select().from(conversations).where(eq(conversations.user_id, userId)).orderBy(desc(conversations.updated_at)).all();
  }

  async updateConversation(
    id: number,
    userId: number,
    data: Partial<Pick<Conversation, "title" | "model" | "system_prompt" | "updated_at">>
  ): Promise<Conversation | undefined> {
    return db.update(conversations).set(data).where(and(eq(conversations.id, id), eq(conversations.user_id, userId))).returning().get();
  }

  async deleteConversation(id: number, userId: number): Promise<boolean> {
    // Delete messages first
    db.delete(messages).where(eq(messages.conversation_id, id)).run();
    const result = db.delete(conversations).where(and(eq(conversations.id, id), eq(conversations.user_id, userId))).run();
    return result.changes > 0;
  }

  // ═══════════════════════════════════════════════════
  // MESSAGES — Phase 2
  // ═══════════════════════════════════════════════════
  async addMessage(data: InsertMessage): Promise<Message> {
    return db.insert(messages).values(data).returning().get();
  }

  async getConversationMessages(conversationId: number): Promise<Message[]> {
    return db.select().from(messages).where(eq(messages.conversation_id, conversationId)).all();
  }

  async deleteConversationMessages(conversationId: number): Promise<boolean> {
    const result = db.delete(messages).where(eq(messages.conversation_id, conversationId)).run();
    return result.changes >= 0;
  }

  // ═══════════════════════════════════════════════════
  // MODEL CONFIGS — Phase 2
  // ═══════════════════════════════════════════════════
  async getModelConfig(userId: number, modelName: string): Promise<ModelConfig | undefined> {
    return db.select().from(modelConfigs).where(and(eq(modelConfigs.user_id, userId), eq(modelConfigs.model_name, modelName))).get();
  }

  async upsertModelConfig(
    userId: number,
    modelName: string,
    data: Partial<Pick<ModelConfig, "temperature" | "max_tokens" | "top_p" | "system_prompt">>
  ): Promise<ModelConfig> {
    const now = new Date().toISOString();
    const existing = await this.getModelConfig(userId, modelName);
    if (existing) {
      return db.update(modelConfigs).set({ ...data, updated_at: now }).where(eq(modelConfigs.id, existing.id)).returning().get();
    }
    return db.insert(modelConfigs).values({
      user_id: userId,
      model_name: modelName,
      temperature: data.temperature ?? 0.7,
      max_tokens: data.max_tokens ?? 2048,
      top_p: data.top_p ?? 0.9,
      system_prompt: data.system_prompt ?? "",
      updated_at: now,
    }).returning().get();
  }

  // ═══════════════════════════════════════════════════
  // VOICE SESSIONS — Phase 3
  // ═══════════════════════════════════════════════════
  async createVoiceSession(data: InsertVoiceSession): Promise<VoiceSession> {
    return db.insert(voiceSessions).values(data).returning().get();
  }

  async getVoiceSession(id: number, userId: number): Promise<VoiceSession | undefined> {
    return db.select().from(voiceSessions).where(and(eq(voiceSessions.id, id), eq(voiceSessions.user_id, userId))).get();
  }

  async getUserVoiceSessions(userId: number): Promise<VoiceSession[]> {
    return db.select().from(voiceSessions).where(eq(voiceSessions.user_id, userId)).orderBy(desc(voiceSessions.created_at)).all();
  }

  async updateVoiceSession(
    id: number,
    userId: number,
    data: Partial<Pick<VoiceSession, "duration_seconds" | "message_count" | "conversation_id">>
  ): Promise<VoiceSession | undefined> {
    return db.update(voiceSessions).set(data).where(and(eq(voiceSessions.id, id), eq(voiceSessions.user_id, userId))).returning().get();
  }

  // ═══════════════════════════════════════════════════
  // GENERATED IMAGES — Phase 4
  // ═══════════════════════════════════════════════════
  async createGeneratedImage(data: InsertGeneratedImage): Promise<GeneratedImage> {
    return db.insert(generatedImages).values(data).returning().get();
  }

  async getUserImages(userId: number, limit: number = 20, offset: number = 0): Promise<GeneratedImage[]> {
    return db.select().from(generatedImages)
      .where(eq(generatedImages.user_id, userId))
      .orderBy(desc(generatedImages.created_at))
      .limit(limit)
      .offset(offset)
      .all();
  }

  async getImage(id: number, userId: number): Promise<GeneratedImage | undefined> {
    return db.select().from(generatedImages)
      .where(and(eq(generatedImages.id, id), eq(generatedImages.user_id, userId)))
      .get();
  }

  async deleteImage(id: number, userId: number): Promise<boolean> {
    const result = db.delete(generatedImages)
      .where(and(eq(generatedImages.id, id), eq(generatedImages.user_id, userId)))
      .run();
    return result.changes > 0;
  }

  async toggleFavorite(id: number, userId: number): Promise<GeneratedImage | undefined> {
    const image = await this.getImage(id, userId);
    if (!image) return undefined;
    const newVal = image.is_favorite === 1 ? 0 : 1;
    return db.update(generatedImages)
      .set({ is_favorite: newVal })
      .where(and(eq(generatedImages.id, id), eq(generatedImages.user_id, userId)))
      .returning()
      .get();
  }

  async getUserImageCount(userId: number): Promise<number> {
    const result = db.select({ count: sql<number>`count(*)` })
      .from(generatedImages)
      .where(eq(generatedImages.user_id, userId))
      .get();
    return result?.count ?? 0;
  }

  // ═══════════════════════════════════════════════════
  // CONVERSATION FILES — Phase 5
  // ═══════════════════════════════════════════════════
  async addConversationFile(data: InsertConversationFile): Promise<ConversationFile> {
    return db.insert(conversationFiles).values(data).returning().get();
  }

  async getConversationFiles(conversationId: number): Promise<ConversationFile[]> {
    return db.select().from(conversationFiles)
      .where(eq(conversationFiles.conversation_id, conversationId))
      .orderBy(desc(conversationFiles.created_at))
      .all();
  }

  async getConversationFile(id: number, userId: number): Promise<ConversationFile | undefined> {
    return db.select().from(conversationFiles)
      .where(and(eq(conversationFiles.id, id), eq(conversationFiles.user_id, userId)))
      .get();
  }

  async deleteConversationFile(id: number, userId: number): Promise<boolean> {
    const result = db.delete(conversationFiles)
      .where(and(eq(conversationFiles.id, id), eq(conversationFiles.user_id, userId)))
      .run();
    return result.changes > 0;
  }

  async updateFileExtraction(id: number, extractedText: string, status: string): Promise<ConversationFile | undefined> {
    return db.update(conversationFiles)
      .set({ extracted_text: extractedText, extraction_status: status })
      .where(eq(conversationFiles.id, id))
      .returning()
      .get();
  }

  // ═══════════════════════════════════════════════════
  // SYSTEM STATS — Phase 6
  // ═══════════════════════════════════════════════════
  async getSystemStats() {
    const userCount = db.select({ count: sql<number>`count(*)` }).from(users).get()?.count ?? 0;
    const activeUserCount = db.select({ count: sql<number>`count(*)` }).from(users).where(eq(users.is_active, true)).get()?.count ?? 0;
    const adminCount = db.select({ count: sql<number>`count(*)` }).from(users).where(eq(users.role, "admin")).get()?.count ?? 0;
    const conversationCount = db.select({ count: sql<number>`count(*)` }).from(conversations).get()?.count ?? 0;
    const messageCount = db.select({ count: sql<number>`count(*)` }).from(messages).get()?.count ?? 0;
    const imageCount = db.select({ count: sql<number>`count(*)` }).from(generatedImages).get()?.count ?? 0;
    const fileCount = db.select({ count: sql<number>`count(*)` }).from(conversationFiles).get()?.count ?? 0;

    // Sum file sizes — generated_images doesn't have file_size, so estimate 0
    const imageTotalSize = 0; // images table has no file_size column
    const fileTotalSize = db.select({ total: sql<number>`coalesce(sum(file_size), 0)` }).from(conversationFiles).get()?.total ?? 0;

    return { userCount, activeUserCount, adminCount, conversationCount, messageCount, imageCount, imageTotalSize, fileCount, fileTotalSize };
  }

  async getUserStats(userId: number) {
    const convCount = db.select({ count: sql<number>`count(*)` }).from(conversations).where(eq(conversations.user_id, userId)).get()?.count ?? 0;
    const msgCount = db.select({ count: sql<number>`count(*)` })
      .from(messages)
      .where(
        sql`${messages.conversation_id} IN (SELECT id FROM conversations WHERE user_id = ${userId})`
      ).get()?.count ?? 0;
    const imgCount = db.select({ count: sql<number>`count(*)` }).from(generatedImages).where(eq(generatedImages.user_id, userId)).get()?.count ?? 0;
    const fCount = db.select({ count: sql<number>`count(*)` }).from(conversationFiles).where(eq(conversationFiles.user_id, userId)).get()?.count ?? 0;
    const storageBytes = db.select({ total: sql<number>`coalesce(sum(file_size), 0)` }).from(conversationFiles).where(eq(conversationFiles.user_id, userId)).get()?.total ?? 0;

    return { conversations: convCount, messages: msgCount, images: imgCount, files: fCount, storageBytes };
  }

  // ═══════════════════════════════════════════════════
  // API KEYS — Phase 6
  // ═══════════════════════════════════════════════════
  async createApiKey(data: InsertApiKey): Promise<ApiKey> {
    return db.insert(apiKeys).values(data).returning().get();
  }

  async getUserApiKeys(userId: number): Promise<ApiKey[]> {
    return db.select().from(apiKeys)
      .where(and(eq(apiKeys.user_id, userId), eq(apiKeys.is_active, 1)))
      .orderBy(desc(apiKeys.created_at))
      .all();
  }

  async getApiKeyByHash(keyHash: string): Promise<ApiKey | undefined> {
    return db.select().from(apiKeys)
      .where(and(eq(apiKeys.key_hash, keyHash), eq(apiKeys.is_active, 1)))
      .get();
  }

  async deactivateApiKey(id: number, userId: number): Promise<boolean> {
    const result = db.update(apiKeys)
      .set({ is_active: 0 })
      .where(and(eq(apiKeys.id, id), eq(apiKeys.user_id, userId)))
      .run();
    return result.changes > 0;
  }

  // ═══════════════════════════════════════════════════
  // TOOL CONFIGS — Phase 8
  // ═══════════════════════════════════════════════════
  async getToolConfig(userId: number, toolName: string): Promise<ToolConfig | undefined> {
    return db.select().from(toolConfigs)
      .where(and(eq(toolConfigs.user_id, userId), eq(toolConfigs.tool_name, toolName)))
      .get();
  }

  async getAllToolConfigs(userId: number): Promise<ToolConfig[]> {
    return db.select().from(toolConfigs)
      .where(eq(toolConfigs.user_id, userId))
      .all();
  }

  async upsertToolConfig(userId: number, toolName: string, config: string, isEnabled: number): Promise<ToolConfig> {
    const now = new Date().toISOString();
    const existing = await this.getToolConfig(userId, toolName);
    if (existing) {
      return db.update(toolConfigs)
        .set({ config, is_enabled: isEnabled, updated_at: now })
        .where(eq(toolConfigs.id, existing.id))
        .returning()
        .get();
    }
    return db.insert(toolConfigs).values({
      user_id: userId,
      tool_name: toolName,
      config,
      is_enabled: isEnabled,
      created_at: now,
      updated_at: now,
    }).returning().get();
  }

  async deleteToolConfig(userId: number, toolName: string): Promise<boolean> {
    const result = db.delete(toolConfigs)
      .where(and(eq(toolConfigs.user_id, userId), eq(toolConfigs.tool_name, toolName)))
      .run();
    return result.changes > 0;
  }

  // ═══════════════════════════════════════════════════
  // SCHEDULED TASKS — Phase 8
  // ═══════════════════════════════════════════════════
  async createScheduledTask(data: InsertScheduledTask): Promise<ScheduledTask> {
    return db.insert(scheduledTasks).values(data).returning().get();
  }

  async getScheduledTask(id: number, userId: number): Promise<ScheduledTask | undefined> {
    return db.select().from(scheduledTasks)
      .where(and(eq(scheduledTasks.id, id), eq(scheduledTasks.user_id, userId)))
      .get();
  }

  async getUserScheduledTasks(userId: number): Promise<ScheduledTask[]> {
    return db.select().from(scheduledTasks)
      .where(eq(scheduledTasks.user_id, userId))
      .orderBy(desc(scheduledTasks.created_at))
      .all();
  }

  async getAllActiveScheduledTasks(): Promise<ScheduledTask[]> {
    return db.select().from(scheduledTasks)
      .where(eq(scheduledTasks.is_active, 1))
      .all();
  }

  async updateScheduledTask(
    id: number,
    userId: number,
    data: Partial<Pick<ScheduledTask, "name" | "description" | "tool_name" | "tool_action" | "tool_params" | "schedule_cron" | "is_active" | "alert_condition" | "last_run" | "last_result">>
  ): Promise<ScheduledTask | undefined> {
    return db.update(scheduledTasks)
      .set(data)
      .where(and(eq(scheduledTasks.id, id), eq(scheduledTasks.user_id, userId)))
      .returning()
      .get();
  }

  async deleteScheduledTask(id: number, userId: number): Promise<boolean> {
    // Delete runs first
    db.delete(taskRuns).where(eq(taskRuns.task_id, id)).run();
    const result = db.delete(scheduledTasks)
      .where(and(eq(scheduledTasks.id, id), eq(scheduledTasks.user_id, userId)))
      .run();
    return result.changes > 0;
  }

  // ═══════════════════════════════════════════════════
  // TASK RUNS — Phase 8
  // ═══════════════════════════════════════════════════
  async createTaskRun(data: InsertTaskRun): Promise<TaskRun> {
    return db.insert(taskRuns).values(data).returning().get();
  }

  async getTaskRuns(taskId: number, userId: number, limit: number = 20): Promise<TaskRun[]> {
    return db.select().from(taskRuns)
      .where(and(eq(taskRuns.task_id, taskId), eq(taskRuns.user_id, userId)))
      .orderBy(desc(taskRuns.started_at))
      .limit(limit)
      .all();
  }

  async getRecentTaskRuns(userId: number, limit: number = 50): Promise<TaskRun[]> {
    return db.select().from(taskRuns)
      .where(eq(taskRuns.user_id, userId))
      .orderBy(desc(taskRuns.started_at))
      .limit(limit)
      .all();
  }

  async getSystemConfig(key: string): Promise<string | undefined> {
    const row = db.select().from(systemConfig).where(eq(systemConfig.key, key)).get();
    return row?.value;
  }

  async setSystemConfig(key: string, value: string): Promise<void> {
    const existing = db.select().from(systemConfig).where(eq(systemConfig.key, key)).get();
    if (existing) {
      db.update(systemConfig).set({ value, updated_at: new Date().toISOString() }).where(eq(systemConfig.key, key)).run();
    } else {
      db.insert(systemConfig).values({ key, value, updated_at: new Date().toISOString() }).run();
    }
  }

  async getAllSystemConfig(): Promise<Record<string, string>> {
    const rows = db.select().from(systemConfig).all();
    return Object.fromEntries(rows.map(r => [r.key, r.value]));
  }

  // ═══════════ Intelligence — Markets (Phase 1) ═══════════
  async getWatchlist(userId: number): Promise<MarketWatchlist[]> {
    return db.select().from(marketWatchlist)
      .where(eq(marketWatchlist.user_id, userId))
      .orderBy(marketWatchlist.display_order, marketWatchlist.id)
      .all();
  }

  async addWatchlistItem(data: InsertMarketWatchlist): Promise<MarketWatchlist> {
    return db.insert(marketWatchlist).values(data).returning().get();
  }

  async removeWatchlistItem(id: number, userId: number): Promise<boolean> {
    const res = db.delete(marketWatchlist)
      .where(and(eq(marketWatchlist.id, id), eq(marketWatchlist.user_id, userId)))
      .run();
    return res.changes > 0;
  }

  async getTodayBrief(userId: number, date: string): Promise<DailyBrief | undefined> {
    return db.select().from(dailyBriefs)
      .where(and(eq(dailyBriefs.user_id, userId), eq(dailyBriefs.date, date)))
      .orderBy(desc(dailyBriefs.id))
      .get();
  }

  async getLatestBrief(userId: number): Promise<DailyBrief | undefined> {
    return db.select().from(dailyBriefs)
      .where(eq(dailyBriefs.user_id, userId))
      .orderBy(desc(dailyBriefs.id))
      .get();
  }

  async createBrief(data: InsertDailyBrief): Promise<DailyBrief> {
    return db.insert(dailyBriefs).values(data).returning().get();
  }

  async listBriefs(userId: number, limit: number = 30): Promise<DailyBrief[]> {
    return db.select().from(dailyBriefs)
      .where(eq(dailyBriefs.user_id, userId))
      .orderBy(desc(dailyBriefs.id))
      .limit(limit)
      .all();
  }

  async getTodayGeoBrief(userId: number, date: string): Promise<GeoBrief | undefined> {
    return db.select().from(geoBriefs)
      .where(and(eq(geoBriefs.user_id, userId), eq(geoBriefs.date, date)))
      .orderBy(desc(geoBriefs.id))
      .get();
  }

  async getLatestGeoBrief(userId: number): Promise<GeoBrief | undefined> {
    return db.select().from(geoBriefs)
      .where(eq(geoBriefs.user_id, userId))
      .orderBy(desc(geoBriefs.id))
      .get();
  }

  async createGeoBrief(data: InsertGeoBrief): Promise<GeoBrief> {
    return db.insert(geoBriefs).values(data).returning().get();
  }

  async listGeoBriefs(userId: number, limit: number = 20): Promise<GeoBrief[]> {
    return db.select().from(geoBriefs)
      .where(eq(geoBriefs.user_id, userId))
      .orderBy(desc(geoBriefs.id))
      .limit(limit)
      .all();
  }

  async updateTaskRun(
    id: number,
    data: Partial<Pick<TaskRun, "completed_at" | "status" | "result" | "alert_triggered" | "error">>
  ): Promise<TaskRun | undefined> {
    return db.update(taskRuns)
      .set(data)
      .where(eq(taskRuns.id, id))
      .returning()
      .get();
  }
}

export const storage = new DatabaseStorage();
