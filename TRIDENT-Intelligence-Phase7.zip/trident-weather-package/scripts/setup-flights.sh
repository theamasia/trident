#!/usr/bin/env bash
#
# TRIDENT Flight Intelligence Service — installer
# Installs the Python flight service (OpenSky / dump1090) as a systemd unit on port 5004.
#
set -euo pipefail

SERVICE_NAME="trident-flights"
INSTALL_DIR="/opt/trident-flights"
VENV_DIR="${INSTALL_DIR}/venv"
CONFIG_ENV="/etc/trident/config.env"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PORT=5004

echo "[ TRIDENT ] ═══ Flight Intelligence Service Setup ═══"

# ── 1. Directories ──
echo "[ TRIDENT ] Creating ${INSTALL_DIR} ..."
sudo mkdir -p "${INSTALL_DIR}"
sudo mkdir -p "$(dirname "${CONFIG_ENV}")"

# ── 2. Python venv + dependencies ──
echo "[ TRIDENT ] Building virtualenv at ${VENV_DIR} ..."
sudo python3 -m venv "${VENV_DIR}"
sudo "${VENV_DIR}/bin/pip" install --upgrade pip
sudo "${VENV_DIR}/bin/pip" install flask flask-cors requests

# ── 3. Deploy service code ──
echo "[ TRIDENT ] Copying flight_service.py ..."
sudo cp "${SCRIPT_DIR}/flight_service.py" "${INSTALL_DIR}/flight_service.py"

# ── 4. Ensure config env exists ──
if [ ! -f "${CONFIG_ENV}" ]; then
  echo "[ TRIDENT ] Creating ${CONFIG_ENV} ..."
  sudo tee "${CONFIG_ENV}" > /dev/null <<'ENVEOF'
# TRIDENT Flight Intelligence config
# OpenSky Network credentials (optional — anonymous works at 10s rate limit)
OPENSKY_USER=
OPENSKY_PASS=
# Local SDR dump1090 (optional — set to switch to real-time local ADS-B)
# e.g. DUMP1090_URL=http://192.168.0.50/data/aircraft.json
DUMP1090_URL=
# Flight history database path
FLIGHT_DB_PATH=/opt/trident-flights/flights.db
ENVEOF
else
  echo "[ TRIDENT ] ${CONFIG_ENV} already exists — leaving untouched."
fi

# ── 5. systemd unit ──
echo "[ TRIDENT ] Installing systemd unit ${SERVICE_NAME} ..."
sudo tee "/etc/systemd/system/${SERVICE_NAME}.service" > /dev/null <<EOF
[Unit]
Description=TRIDENT Flight Intelligence Service (port ${PORT})
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
WorkingDirectory=${INSTALL_DIR}
EnvironmentFile=${CONFIG_ENV}
ExecStart=${VENV_DIR}/bin/python ${INSTALL_DIR}/flight_service.py
Restart=always
RestartSec=5
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
EOF

# ── 6. Enable + start ──
echo "[ TRIDENT ] Reloading systemd and starting service ..."
sudo systemctl daemon-reload
sudo systemctl enable "${SERVICE_NAME}"
sudo systemctl restart "${SERVICE_NAME}"

# ── 7. Health check ──
echo "[ TRIDENT ] Waiting for service to come online ..."
sleep 3
echo "[ TRIDENT ] Health check:"
curl -fsS "http://127.0.0.1:${PORT}/health" && echo "" || {
  echo "[ TRIDENT ] Health check FAILED — inspect: sudo journalctl -u ${SERVICE_NAME} -n 50"
  exit 1
}

echo "[ TRIDENT ] ═══ Flight Intelligence Service installed on port ${PORT} ═══"
