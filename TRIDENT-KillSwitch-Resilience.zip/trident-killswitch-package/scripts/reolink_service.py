#!/usr/bin/env python3
"""
TRIDENT Reolink NVR Detection Event Service
Polls a Reolink standalone NVR (hardware model N6MB01, Hi3536-family chipset) for
channel/camera status and AI/motion detection events. Feeds "Command Station Alpha1".
Runs on port 5012.

DETECTION EVENT ANALYSIS ONLY for this phase — no live video streaming or recording
playback. That is planned for a later phase.

Credentials are read exclusively from environment variables (REOLINK_USER /
REOLINK_PASS), normally injected via /etc/trident/config.env through systemd's
EnvironmentFile directive. Never hardcode or log credentials.
"""
import os, time, json, threading, datetime
import requests
from flask import Flask, jsonify, request as flask_request
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

NVR_HOST = os.environ.get("REOLINK_HOST", "192.168.8.199")
NVR_SCHEME = os.environ.get("REOLINK_SCHEME", "http")  # configurable in case a future NVR is HTTPS-only
NVR_USER = os.environ.get("REOLINK_USER", "")
NVR_PASS = os.environ.get("REOLINK_PASS", "")
BASE_URL = f"{NVR_SCHEME}://{NVR_HOST}/cgi-bin/api.cgi"
STATION_LABEL = os.environ.get("REOLINK_STATION_LABEL", "COMMAND STATION ALPHA1")

STATE = {
    "status": "offline",
    "last_success": None,
    "last_error": None,
    "channels": [],
    "ai_states": {},   # channel -> {people, vehicle, dog_cat, alarm states}
    "recent_events": [],  # flattened list across channels
}
LOCK = threading.Lock()
TOKEN = {"value": None, "expires_at": 0}
MAX_EVENTS_CACHE = 300

def login():
    if not NVR_USER or not NVR_PASS:
        raise Exception("REOLINK_USER / REOLINK_PASS not configured in /etc/trident/config.env")
    body = [{"cmd": "Login", "action": 0, "param": {"User": {"userName": NVR_USER, "password": NVR_PASS}}}]
    res = requests.post(BASE_URL, json=body, timeout=10)
    res.raise_for_status()
    data = res.json()
    if not data or data[0].get("code") != 0:
        raise Exception(f"Reolink login failed: code={data[0].get('code') if data else 'no-response'}")
    token_info = data[0]["value"]["Token"]
    TOKEN["value"] = token_info["name"]
    TOKEN["expires_at"] = time.time() + token_info.get("leaseTime", 3600) - 60
    return TOKEN["value"]

def get_token():
    if not TOKEN["value"] or time.time() > TOKEN["expires_at"]:
        return login()
    return TOKEN["value"]

def call_api(cmd, param=None, retry=True):
    token = get_token()
    body = [{"cmd": cmd, "action": 0, "param": param or {}}]
    res = requests.post(f"{BASE_URL}?token={token}", json=body, timeout=15)
    res.raise_for_status()
    data = res.json()
    if data and data[0].get("code") != 0 and retry:
        # possible expired token — force re-login and retry once
        TOKEN["value"] = None
        return call_api(cmd, param, retry=False)
    return data[0] if data else {}

def poll_channels():
    result = call_api("GetChannelstatus")
    statuses = result.get("value", {}).get("status", [])
    channels = []
    for s in statuses:
        channels.append({
            "channel": s.get("channel"),
            "name": s.get("name", f"Channel {s.get('channel')}"),
            "online": bool(s.get("online")),
        })
    return channels

def poll_ai_state(channel):
    result = call_api("GetAiState", {"channel": channel})
    val = result.get("value", {}).get("State", {})
    state = {}
    for key in ("people", "vehicle", "dog_cat", "face"):
        if key in val:
            state[key] = {
                "supported": val[key].get("support", 0) == 1,
                "alarm_state": val[key].get("alarm_state", 0) == 1,
            }
    return state

def poll_recent_events(channel, hours_back=24):
    """
    Historical detection events via cmd=Search. Reolink's File entries don't always
    tag AI type (people/vehicle/pet) distinctly across firmware versions — we surface
    whatever 'type' field is present as a best-effort label. Correlating recordings
    with GetAiState alarm timestamps for richer AI-type tagging is a future enhancement.
    """
    now = datetime.datetime.utcnow()
    start = now - datetime.timedelta(hours=hours_back)
    param = {
        "Search": {
            "channel": channel,
            "onlyStatus": 0,
            "streamType": "sub",
            "StartTime": {"year": start.year, "mon": start.month, "day": start.day, "hour": start.hour, "min": start.minute, "sec": start.second},
            "EndTime": {"year": now.year, "mon": now.month, "day": now.day, "hour": now.hour, "min": now.minute, "sec": now.second},
        }
    }
    result = call_api("Search", param)
    files = result.get("value", {}).get("SearchResult", {}).get("File", []) or []
    events = []
    for f in files:
        st = f.get("StartTime", {})
        et = f.get("EndTime", {})
        try:
            start_dt = datetime.datetime(st.get("year",1970), st.get("mon",1), st.get("day",1), st.get("hour",0), st.get("min",0), st.get("sec",0))
            end_dt = datetime.datetime(et.get("year",1970), et.get("mon",1), et.get("day",1), et.get("hour",0), et.get("min",0), et.get("sec",0))
        except Exception:
            continue
        events.append({
            "channel": channel,
            "type": f.get("type", "unknown"),
            "start": start_dt.isoformat() + "Z",
            "end": end_dt.isoformat() + "Z",
            "duration_sec": max(0, int((end_dt - start_dt).total_seconds())),
            "size_bytes": f.get("size"),
            "name": f.get("name"),
        })
    return events

def poll_loop():
    while True:
        try:
            channels = poll_channels()
            ai_states = {}
            all_events = []
            for ch in channels:
                if not ch["online"]:
                    continue
                chan_num = ch["channel"]
                try:
                    ai_states[chan_num] = poll_ai_state(chan_num)
                except Exception as e:
                    print(f"[ TRIDENT REOLINK ] AI state error ch{chan_num}: {e}", flush=True)
                try:
                    events = poll_recent_events(chan_num, hours_back=24)
                    all_events.extend(events)
                except Exception as e:
                    print(f"[ TRIDENT REOLINK ] Event search error ch{chan_num}: {e}", flush=True)

            all_events.sort(key=lambda e: e["start"], reverse=True)

            with LOCK:
                STATE["channels"] = channels
                STATE["ai_states"] = ai_states
                STATE["recent_events"] = all_events[:MAX_EVENTS_CACHE]
                STATE["last_success"] = time.time()
                STATE["last_error"] = None
                STATE["status"] = "live"
        except Exception as e:
            with LOCK:
                STATE["last_error"] = str(e)
                STATE["status"] = "offline"
            print(f"[ TRIDENT REOLINK ] Poll error: {e}", flush=True)
        time.sleep(30)  # detection events don't need sub-10s polling; 30s is reasonable

@app.route("/health")
def health():
    with LOCK:
        age = time.time() - STATE["last_success"] if STATE["last_success"] else None
        status = STATE["status"]
        if status == "live" and age and age > 120:
            status = "stale"
        return jsonify({
            "service": "TRIDENT Reolink Detection",
            "nvr_host": NVR_HOST,
            "station_label": STATION_LABEL,
            "status": status,
            "last_error": STATE["last_error"],
            "last_success_age_sec": age,
        })

@app.route("/channels")
def channels():
    with LOCK:
        return jsonify({"channels": STATE["channels"], "ai_states": STATE["ai_states"]})

@app.route("/events")
def events():
    channel = flask_request.args.get("channel", type=int)
    event_type = flask_request.args.get("type")
    limit = flask_request.args.get("limit", default=100, type=int)
    with LOCK:
        results = STATE["recent_events"]
        if channel is not None:
            results = [e for e in results if e["channel"] == channel]
        if event_type:
            results = [e for e in results if event_type.lower() in (e.get("type") or "").lower()]
        return jsonify({"events": results[:limit], "count": len(results), "station_label": STATION_LABEL})

@app.route("/summary")
def summary():
    """Compact summary for COMMAND queries"""
    with LOCK:
        online_channels = [c for c in STATE["channels"] if c["online"]]
        events_last_hour = [e for e in STATE["recent_events"] if e["start"] >= (datetime.datetime.utcnow() - datetime.timedelta(hours=1)).isoformat()]
        active_alarms = []
        for chan_num, state in STATE["ai_states"].items():
            for kind, info in state.items():
                if info.get("alarm_state"):
                    chan_name = next((c["name"] for c in STATE["channels"] if c["channel"] == chan_num), f"Channel {chan_num}")
                    active_alarms.append(f"{chan_name}: {kind} detected")
        return jsonify({
            "status": STATE["status"],
            "station_label": STATION_LABEL,
            "cameras_online": len(online_channels),
            "cameras_total": len(STATE["channels"]),
            "events_24h": len(STATE["recent_events"]),
            "events_last_hour": len(events_last_hour),
            "active_alarms": active_alarms,
            "last_error": STATE["last_error"],
        })

if __name__ == "__main__":
    threading.Thread(target=poll_loop, daemon=True).start()
    print(f"[ TRIDENT ] Reolink Detection Service starting on port 5012, NVR: {NVR_HOST}")
    app.run(host="127.0.0.1", port=5012, debug=False)
