#!/usr/bin/env bash
#
# TRIDENT Reolink NVR Detection Event Service — installer
# Installs the Python Reolink AI/motion detection service (channel status + AI alarm
# state + historical detection events via the local Reolink CGI API on a standalone
# NVR, hardware model N6MB01) as a systemd unit on port 5012. Polls the NVR at
# 192.168.8.199 by default. Feeds "Command Station Alpha1".
#
# DETECTION EVENT ANALYSIS ONLY for this phase — no live video streaming or
# recording playback (planned for a later phase).
#
set -euo pipefail

echo "[ SETUP ] Before starting, ensure /etc/trident/config.env contains:"
echo "  REOLINK_HOST=192.168.8.199"
echo "  REOLINK_SCHEME=http"
echo "  REOLINK_USER=<view-only NVR account username>"
echo "  REOLINK_PASS=<view-only NVR account password>"
echo "  REOLINK_STATION_LABEL=COMMAND STATION ALPHA1"

SERVICE_NAME="trident-reolink"
INSTALL_DIR="/opt/trident-reolink"
VENV_DIR="${INSTALL_DIR}/venv"
CONFIG_ENV="/etc/trident/config.env"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PORT=5012

echo "[ TRIDENT ] ═══ Reolink Detection Event Service Setup ═══"

# ── 1. Directories ──
echo "[ TRIDENT ] Creating ${INSTALL_DIR} ..."
sudo mkdir -p "${INSTALL_DIR}"
sudo mkdir -p "$(dirname "${CONFIG_ENV}")"

# ── 2. Python venv + dependencies ──
echo "[ TRIDENT ] Building virtualenv at ${VENV_DIR} ..."
sudo python3 -m venv "${VENV_DIR}"
sudo "${VENV_DIR}/bin/pip" install --upgrade pip
sudo "${VENV_DIR}/bin/pip" install flask flask-cors requests

# ── 3. Deploy service code ──
echo "[ TRIDENT ] Copying reolink_service.py ..."
sudo cp "${SCRIPT_DIR}/reolink_service.py" "${INSTALL_DIR}/reolink_service.py"

# ── 4. Ensure config env exists ──
if [ ! -f "${CONFIG_ENV}" ]; then
  echo "[ TRIDENT ] Creating ${CONFIG_ENV} ..."
  sudo tee "${CONFIG_ENV}" > /dev/null <<'ENVEOF'
# TRIDENT Reolink NVR Detection Event config
# Standalone Reolink NVR (hardware model N6MB01, Hi3536-family chipset) feeding
# "Command Station Alpha1". REOLINK_USER / REOLINK_PASS must be a dedicated
# VIEW-ONLY local NVR account — this service only performs read/search operations,
# never configuration changes.
REOLINK_HOST=192.168.8.199
REOLINK_SCHEME=http
REOLINK_USER=
REOLINK_PASS=
REOLINK_STATION_LABEL=COMMAND STATION ALPHA1
ENVEOF
  echo "[ TRIDENT ] >>> EDIT ${CONFIG_ENV} NOW to set REOLINK_USER and REOLINK_PASS before starting the service. <<<"
else
  echo "[ TRIDENT ] ${CONFIG_ENV} already exists — leaving untouched."
  echo "[ TRIDENT ] Ensure it contains REOLINK_HOST, REOLINK_SCHEME, REOLINK_USER, REOLINK_PASS, REOLINK_STATION_LABEL (see reminder above)."
fi

# ── 5. systemd unit ──
echo "[ TRIDENT ] Installing systemd unit ${SERVICE_NAME} ..."
sudo tee "/etc/systemd/system/${SERVICE_NAME}.service" > /dev/null <<EOF
[Unit]
Description=TRIDENT Reolink NVR Detection Event Service (port ${PORT})
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
WorkingDirectory=${INSTALL_DIR}
EnvironmentFile=${CONFIG_ENV}
ExecStart=${VENV_DIR}/bin/python ${INSTALL_DIR}/reolink_service.py
Restart=always
RestartSec=5
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
EOF

# ── 6. Enable + start ──
echo "[ TRIDENT ] Reloading systemd and starting service ..."
sudo systemctl daemon-reload
sudo systemctl enable "${SERVICE_NAME}"
sudo systemctl restart "${SERVICE_NAME}"

# ── 7. Health check ──
echo "[ TRIDENT ] Waiting for service to come online ..."
sleep 3
echo "[ TRIDENT ] Health check:"
curl -fsS "http://127.0.0.1:${PORT}/health" && echo "" || {
  echo "[ TRIDENT ] Health check FAILED — inspect: sudo journalctl -u ${SERVICE_NAME} -n 50"
  exit 1
}

echo "[ TRIDENT ] ═══ Reolink Detection Event Service installed on port ${PORT} ═══"
echo "[ TRIDENT ] NOTE: Status will report 'offline' until REOLINK_USER/REOLINK_PASS are set in ${CONFIG_ENV}"
echo "[ TRIDENT ] and the NVR at \$REOLINK_HOST is reachable on the local network."
echo "[ TRIDENT ] Edit ${CONFIG_ENV} to point at a different NVR without touching code."
