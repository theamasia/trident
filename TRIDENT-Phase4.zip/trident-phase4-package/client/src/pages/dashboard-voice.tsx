import { useState, useRef, useCallback, useEffect } from "react";
import { useAuth, getAuthHeaders } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import {
  Mic,
  MicOff,
  Settings2,
  Volume2,
  Play,
  Send,
  Loader2,
  Wifi,
  WifiOff,
  ChevronDown,
} from "lucide-react";

// ═══════════════════════════════════════════════════
// Types
// ═══════════════════════════════════════════════════

type VoiceState = "IDLE" | "RECORDING" | "TRANSCRIBING" | "THINKING" | "SPEAKING";

interface VoiceEntry {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: string;
  audioUrl?: string;
}

interface VoiceProfile {
  id: string;
  name: string;
  description: string;
}

interface OllamaModel {
  name: string;
  size: number;
  modified_at: string;
}

// ═══════════════════════════════════════════════════
// API Base for deployment compatibility
// ═══════════════════════════════════════════════════
const API_BASE = "__PORT_5000__".startsWith("__") ? "" : "__PORT_5000__";

// ═══════════════════════════════════════════════════
// Component
// ═══════════════════════════════════════════════════

export default function DashboardVoice() {
  const { token } = useAuth();

  // State
  const [voiceState, setVoiceState] = useState<VoiceState>("IDLE");
  const [entries, setEntries] = useState<VoiceEntry[]>([]);
  const [selectedVoice, setSelectedVoice] = useState("lessac");
  const [autoRespond, setAutoRespond] = useState(true);
  const [selectedModel, setSelectedModel] = useState("");
  const [textInput, setTextInput] = useState("");
  const [showSettings, setShowSettings] = useState(false);

  // Refs
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<BlobPart[]>([]);
  const audioStreamRef = useRef<MediaStream | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const animFrameRef = useRef<number>(0);
  const scrollRef = useRef<HTMLDivElement | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const currentAudioRef = useRef<HTMLAudioElement | null>(null);

  // ═══════════════════════════════════════════════════
  // Queries
  // ═══════════════════════════════════════════════════

  const { data: voiceStatus } = useQuery<{ online: boolean; voices: string[] }>({
    queryKey: ["/api/voice/status"],
    refetchInterval: 15000,
    queryFn: async () => {
      const res = await fetch("/api/voice/status", { headers: getAuthHeaders() });
      if (!res.ok) throw new Error("Failed");
      return res.json();
    },
  });

  const { data: voicesData } = useQuery<VoiceProfile[]>({
    queryKey: ["/api/voice/voices"],
    queryFn: async () => {
      const res = await fetch("/api/voice/voices", { headers: getAuthHeaders() });
      if (!res.ok) throw new Error("Failed");
      return res.json();
    },
  });

  const { data: modelsData } = useQuery<{ models: OllamaModel[] }>({
    queryKey: ["/api/ollama/models"],
    queryFn: async () => {
      const res = await fetch("/api/ollama/models", { headers: getAuthHeaders() });
      if (!res.ok) throw new Error("Failed");
      return res.json();
    },
  });

  // Set default model
  useEffect(() => {
    if (modelsData?.models?.length && !selectedModel) {
      setSelectedModel(modelsData.models[0].name);
    }
  }, [modelsData, selectedModel]);

  // Auto-scroll conversation log
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [entries]);

  const isOnline = voiceStatus?.online ?? false;
  const voices = voicesData ?? [];
  const models = modelsData?.models ?? [];

  // ═══════════════════════════════════════════════════
  // Waveform Visualization
  // ═══════════════════════════════════════════════════

  const startWaveform = useCallback((stream: MediaStream) => {
    const audioCtx = new AudioContext();
    audioContextRef.current = audioCtx;
    const source = audioCtx.createMediaStreamSource(stream);
    const analyser = audioCtx.createAnalyser();
    analyser.fftSize = 128;
    source.connect(analyser);
    analyserRef.current = analyser;

    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const bufferLength = analyser.frequencyBinCount;
    const dataArray = new Uint8Array(bufferLength);

    const draw = () => {
      animFrameRef.current = requestAnimationFrame(draw);
      analyser.getByteFrequencyData(dataArray);

      ctx.fillStyle = "#050a0e";
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      const barWidth = (canvas.width / bufferLength) * 0.8;
      const gap = (canvas.width / bufferLength) * 0.2;
      let x = 0;

      for (let i = 0; i < bufferLength; i++) {
        const barHeight = (dataArray[i] / 255) * canvas.height * 0.9;
        const gradient = ctx.createLinearGradient(0, canvas.height, 0, canvas.height - barHeight);
        gradient.addColorStop(0, "rgba(0, 240, 255, 0.3)");
        gradient.addColorStop(1, "rgba(0, 240, 255, 0.9)");
        ctx.fillStyle = gradient;
        ctx.fillRect(x, canvas.height - barHeight, barWidth, barHeight);

        // Glow effect
        ctx.shadowColor = "#00f0ff";
        ctx.shadowBlur = 4;
        ctx.fillRect(x, canvas.height - barHeight, barWidth, 2);
        ctx.shadowBlur = 0;

        x += barWidth + gap;
      }
    };

    draw();
  }, []);

  const stopWaveform = useCallback(() => {
    if (animFrameRef.current) {
      cancelAnimationFrame(animFrameRef.current);
    }
    if (audioContextRef.current) {
      audioContextRef.current.close();
      audioContextRef.current = null;
    }
    analyserRef.current = null;

    // Clear canvas
    const canvas = canvasRef.current;
    if (canvas) {
      const ctx = canvas.getContext("2d");
      if (ctx) {
        ctx.fillStyle = "#050a0e";
        ctx.fillRect(0, 0, canvas.width, canvas.height);
      }
    }
  }, []);

  // ═══════════════════════════════════════════════════
  // TTS Playback
  // ═══════════════════════════════════════════════════

  const playTTS = useCallback(async (text: string, voice: string): Promise<string | undefined> => {
    try {
      setVoiceState("SPEAKING");
      const res = await fetch(`${API_BASE}/api/voice/tts`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...getAuthHeaders(),
        },
        body: JSON.stringify({ text, voice }),
      });

      if (!res.ok) {
        setVoiceState("IDLE");
        return undefined;
      }

      const audioBlob = await res.blob();
      const audioUrl = URL.createObjectURL(audioBlob);
      const audio = new Audio(audioUrl);
      currentAudioRef.current = audio;

      return new Promise((resolve) => {
        audio.onended = () => {
          setVoiceState("IDLE");
          currentAudioRef.current = null;
          resolve(audioUrl);
        };
        audio.onerror = () => {
          setVoiceState("IDLE");
          currentAudioRef.current = null;
          resolve(audioUrl);
        };
        audio.play().catch(() => {
          setVoiceState("IDLE");
          currentAudioRef.current = null;
          resolve(audioUrl);
        });
      });
    } catch {
      setVoiceState("IDLE");
      return undefined;
    }
  }, []);

  const replayAudio = useCallback((audioUrl: string) => {
    const audio = new Audio(audioUrl);
    setVoiceState("SPEAKING");
    currentAudioRef.current = audio;
    audio.onended = () => {
      setVoiceState("IDLE");
      currentAudioRef.current = null;
    };
    audio.play().catch(() => {
      setVoiceState("IDLE");
    });
  }, []);

  // ═══════════════════════════════════════════════════
  // LLM Chat + TTS (Auto-respond flow)
  // ═══════════════════════════════════════════════════

  const sendToLLM = useCallback(async (transcript: string) => {
    if (!selectedModel) return;

    setVoiceState("THINKING");

    try {
      // Create a conversation for voice
      const convRes = await apiRequest("POST", "/api/conversations", {
        title: "VOICE SESSION",
        model: selectedModel,
        system_prompt: "You are TRIDENT, a tactical AI assistant. Keep responses concise and direct. Respond in 1-3 sentences unless more detail is explicitly requested.",
      });
      const conv = await convRes.json();

      // Stream chat
      const chatRes = await fetch(`${API_BASE}/api/chat/stream`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...getAuthHeaders(),
        },
        body: JSON.stringify({
          conversationId: conv.id,
          message: transcript,
          model: selectedModel,
        }),
      });

      if (!chatRes.ok || !chatRes.body) {
        throw new Error("Chat stream failed");
      }

      const reader = chatRes.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";
      let fullContent = "";

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split("\n");
        buffer = lines.pop() || "";

        for (const line of lines) {
          if (!line.startsWith("data: ")) continue;
          const jsonStr = line.slice(6).trim();
          if (!jsonStr) continue;
          try {
            const parsed = JSON.parse(jsonStr);
            if (parsed.token) {
              fullContent += parsed.token;
            }
          } catch {
            // skip malformed
          }
        }
      }

      // Add assistant entry
      const entryId = `trident-${Date.now()}`;
      const newEntry: VoiceEntry = {
        id: entryId,
        role: "assistant",
        content: fullContent || "...",
        timestamp: new Date().toLocaleTimeString("en-US", { hour12: false }),
      };

      setEntries((prev) => [...prev, newEntry]);

      // Speak the response via TTS
      const audioUrl = await playTTS(fullContent, selectedVoice);
      if (audioUrl) {
        setEntries((prev) =>
          prev.map((e) => (e.id === entryId ? { ...e, audioUrl } : e))
        );
      }
    } catch (err) {
      const errorEntry: VoiceEntry = {
        id: `error-${Date.now()}`,
        role: "assistant",
        content: ">> NEURAL LINK ERROR — COULD NOT PROCESS REQUEST",
        timestamp: new Date().toLocaleTimeString("en-US", { hour12: false }),
      };
      setEntries((prev) => [...prev, errorEntry]);
      setVoiceState("IDLE");
    }
  }, [selectedModel, selectedVoice, playTTS]);

  // ═══════════════════════════════════════════════════
  // STT Processing
  // ═══════════════════════════════════════════════════

  const processAudio = useCallback(async (blob: Blob) => {
    setVoiceState("TRANSCRIBING");

    try {
      const formData = new FormData();
      formData.append("audio", blob, "recording.webm");

      const res = await fetch(`${API_BASE}/api/voice/stt`, {
        method: "POST",
        headers: getAuthHeaders(),
        body: formData,
      });

      const data = await res.json();

      if (data.error) {
        throw new Error(data.error);
      }

      const transcript = data.transcript || "";
      if (!transcript.trim()) {
        setVoiceState("IDLE");
        return;
      }

      // Add user entry
      const userEntry: VoiceEntry = {
        id: `user-${Date.now()}`,
        role: "user",
        content: transcript,
        timestamp: new Date().toLocaleTimeString("en-US", { hour12: false }),
      };
      setEntries((prev) => [...prev, userEntry]);

      // Auto-respond if enabled
      if (autoRespond) {
        await sendToLLM(transcript);
      } else {
        setVoiceState("IDLE");
      }
    } catch {
      setVoiceState("IDLE");
      const errorEntry: VoiceEntry = {
        id: `error-${Date.now()}`,
        role: "assistant",
        content: ">> VOICE PROCESSING UNIT OFFLINE — RUN scripts/setup-voice.sh",
        timestamp: new Date().toLocaleTimeString("en-US", { hour12: false }),
      };
      setEntries((prev) => [...prev, errorEntry]);
    }
  }, [autoRespond, sendToLLM]);

  // ═══════════════════════════════════════════════════
  // Recording (Push-to-Talk)
  // ═══════════════════════════════════════════════════

  const startRecording = useCallback(async () => {
    if (voiceState !== "IDLE") return;

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      audioStreamRef.current = stream;

      const mediaRecorder = new MediaRecorder(stream, {
        mimeType: MediaRecorder.isTypeSupported("audio/webm;codecs=opus")
          ? "audio/webm;codecs=opus"
          : "audio/webm",
      });

      chunksRef.current = [];
      mediaRecorder.ondataavailable = (e) => {
        if (e.data.size > 0) chunksRef.current.push(e.data);
      };
      mediaRecorder.onstop = () => {
        const blob = new Blob(chunksRef.current, { type: "audio/webm" });
        stopWaveform();
        if (audioStreamRef.current) {
          audioStreamRef.current.getTracks().forEach((t) => t.stop());
          audioStreamRef.current = null;
        }
        processAudio(blob);
      };

      mediaRecorderRef.current = mediaRecorder;
      mediaRecorder.start();
      setVoiceState("RECORDING");
      startWaveform(stream);
    } catch {
      // Microphone access denied or unavailable
      setVoiceState("IDLE");
    }
  }, [voiceState, startWaveform, stopWaveform, processAudio]);

  const stopRecording = useCallback(() => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== "inactive") {
      mediaRecorderRef.current.stop();
    }
  }, []);

  // ═══════════════════════════════════════════════════
  // Text Input (fallback)
  // ═══════════════════════════════════════════════════

  const handleTextSubmit = useCallback(async () => {
    if (!textInput.trim()) return;

    const userEntry: VoiceEntry = {
      id: `user-${Date.now()}`,
      role: "user",
      content: textInput.trim(),
      timestamp: new Date().toLocaleTimeString("en-US", { hour12: false }),
    };
    setEntries((prev) => [...prev, userEntry]);
    const msg = textInput.trim();
    setTextInput("");

    if (autoRespond) {
      await sendToLLM(msg);
    }
  }, [textInput, autoRespond, sendToLLM]);

  // ═══════════════════════════════════════════════════
  // Status bar label
  // ═══════════════════════════════════════════════════

  const stateLabel: Record<VoiceState, string> = {
    IDLE: "IDLE",
    RECORDING: "● RECORDING",
    TRANSCRIBING: ">> TRANSCRIBING...",
    THINKING: ">> PROCESSING...",
    SPEAKING: "◈ RESPONSE ACTIVE",
  };

  const stateColor: Record<VoiceState, string> = {
    IDLE: "text-trident-text/50",
    RECORDING: "text-red-500",
    TRANSCRIBING: "text-trident-amber",
    THINKING: "text-trident-amber",
    SPEAKING: "text-trident-green",
  };

  // ═══════════════════════════════════════════════════
  // PTT Button classes
  // ═══════════════════════════════════════════════════

  const getPttClasses = () => {
    const base =
      "w-[120px] h-[120px] rounded-full border-2 flex flex-col items-center justify-center cursor-pointer select-none transition-all duration-200";
    switch (voiceState) {
      case "RECORDING":
        return `${base} border-red-500 bg-red-500/10 animate-pulse-recording`;
      case "TRANSCRIBING":
      case "THINKING":
        return `${base} border-trident-amber bg-trident-amber/5 cursor-wait`;
      case "SPEAKING":
        return `${base} border-trident-green bg-trident-green/5`;
      default:
        return `${base} border-trident-cyan/40 bg-trident-cyan/5 hover:border-trident-cyan hover:bg-trident-cyan/10`;
    }
  };

  const getPttLabel = () => {
    switch (voiceState) {
      case "RECORDING":
        return "● TRANSMITTING";
      case "TRANSCRIBING":
        return ">> PROCESSING";
      case "THINKING":
        return ">> THINKING";
      case "SPEAKING":
        return "◈ RESPONSE ACTIVE";
      default:
        return "HOLD TO TRANSMIT";
    }
  };

  // ═══════════════════════════════════════════════════
  // Render
  // ═══════════════════════════════════════════════════

  return (
    <div className="h-full flex flex-col" data-testid="voice-page">
      {/* ─── STATUS BAR ─── */}
      <div className="trident-panel scanlines p-3 mb-3 flex items-center justify-between">
        <h1
          className="font-display text-sm tracking-[0.15em] text-trident-cyan text-glow-cyan flex items-center gap-2"
          data-testid="text-voice-title"
        >
          <Mic className="w-4 h-4" />
          VOICE INTERFACE
        </h1>

        <div className="flex items-center gap-4">
          <span className={`font-mono text-[10px] tracking-widest uppercase ${stateColor[voiceState]}`} data-testid="text-voice-state">
            {stateLabel[voiceState]}
          </span>

          <div className="flex items-center gap-1.5" data-testid="status-voice-service">
            {isOnline ? (
              <Wifi className="w-3 h-3 text-trident-green" />
            ) : (
              <WifiOff className="w-3 h-3 text-red-500" />
            )}
            <span className={`font-mono text-[10px] uppercase ${isOnline ? "text-trident-green" : "text-red-500"}`}>
              {isOnline ? "ONLINE" : "OFFLINE"}
            </span>
          </div>

          <button
            className="text-trident-text/50 hover:text-trident-cyan transition-colors"
            onClick={() => setShowSettings((s) => !s)}
            data-testid="button-settings"
          >
            <Settings2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* ─── MAIN LAYOUT ─── */}
      <div className="flex-1 flex gap-3 min-h-0">
        {/* ─── LEFT CONTROLS PANEL ─── */}
        <div className="w-[300px] shrink-0 flex flex-col gap-3">
          {/* PTT Button */}
          <div className="trident-panel p-6 flex flex-col items-center">
            <div
              className={getPttClasses()}
              onMouseDown={(e) => {
                e.preventDefault();
                if (voiceState === "IDLE") startRecording();
              }}
              onMouseUp={(e) => {
                e.preventDefault();
                if (voiceState === "RECORDING") stopRecording();
              }}
              onMouseLeave={() => {
                if (voiceState === "RECORDING") stopRecording();
              }}
              onTouchStart={(e) => {
                e.preventDefault();
                if (voiceState === "IDLE") startRecording();
              }}
              onTouchEnd={(e) => {
                e.preventDefault();
                if (voiceState === "RECORDING") stopRecording();
              }}
              data-testid="button-ptt"
            >
              {voiceState === "RECORDING" ? (
                <Mic className="w-8 h-8 text-red-500" />
              ) : voiceState === "TRANSCRIBING" || voiceState === "THINKING" ? (
                <Loader2 className="w-8 h-8 text-trident-amber animate-spin" />
              ) : voiceState === "SPEAKING" ? (
                <Volume2 className="w-8 h-8 text-trident-green" />
              ) : (
                <Mic className="w-8 h-8 text-trident-cyan/60" />
              )}
              <span className="font-mono text-[9px] mt-2 tracking-wider text-center uppercase">
                {getPttLabel()}
              </span>
            </div>
          </div>

          {/* Waveform */}
          <div className="trident-panel p-3">
            <div className="font-mono text-[9px] text-trident-text/40 uppercase tracking-widest mb-2">
              AUDIO WAVEFORM
            </div>
            <canvas
              ref={canvasRef}
              width={264}
              height={60}
              className="w-full rounded-sm"
              style={{ backgroundColor: "#050a0e" }}
              data-testid="canvas-waveform"
            />
          </div>

          {/* Voice Select */}
          <div className="trident-panel p-3">
            <label className="font-mono text-[9px] text-trident-text/40 uppercase tracking-widest block mb-2">
              VOICE PROFILE
            </label>
            <div className="relative">
              <select
                value={selectedVoice}
                onChange={(e) => setSelectedVoice(e.target.value)}
                className="trident-input w-full py-1.5 px-2 text-[11px] appearance-none pr-6"
                data-testid="select-voice"
              >
                {voices.map((v) => (
                  <option key={v.id} value={v.id}>
                    {v.name}
                  </option>
                ))}
                {voices.length === 0 && (
                  <>
                    <option value="lessac">LESSAC (NEUTRAL)</option>
                    <option value="amy">AMY (NEUTRAL)</option>
                  </>
                )}
              </select>
              <ChevronDown className="w-3 h-3 absolute right-2 top-1/2 -translate-y-1/2 text-trident-text/30 pointer-events-none" />
            </div>
          </div>

          {/* Auto-respond toggle */}
          <div className="trident-panel p-3">
            <div className="flex items-center justify-between">
              <label className="font-mono text-[9px] text-trident-text/40 uppercase tracking-widest">
                AUTO-RESPOND
              </label>
              <button
                onClick={() => setAutoRespond((a) => !a)}
                className={`w-10 h-5 rounded-full border transition-all duration-200 relative ${
                  autoRespond
                    ? "border-trident-cyan bg-trident-cyan/20"
                    : "border-trident-border bg-trident-surface"
                }`}
                data-testid="button-auto-respond"
              >
                <div
                  className={`w-3.5 h-3.5 rounded-full absolute top-[2px] transition-all duration-200 ${
                    autoRespond
                      ? "left-[22px] bg-trident-cyan"
                      : "left-[2px] bg-trident-text/30"
                  }`}
                />
              </button>
            </div>
            <p className="font-mono text-[8px] text-trident-text/25 mt-1 uppercase">
              {autoRespond
                ? "TRANSCRIPT → LLM → TTS (FULL AUTO)"
                : "TRANSCRIPT ONLY — MANUAL MODE"}
            </p>
          </div>

          {/* Model selector (visible when settings open or always) */}
          {showSettings && (
            <div className="trident-panel p-3">
              <label className="font-mono text-[9px] text-trident-text/40 uppercase tracking-widest block mb-2">
                LLM MODEL
              </label>
              <div className="relative">
                <select
                  value={selectedModel}
                  onChange={(e) => setSelectedModel(e.target.value)}
                  className="trident-input w-full py-1.5 px-2 text-[11px] appearance-none pr-6"
                  data-testid="select-model"
                >
                  {models.map((m) => (
                    <option key={m.name} value={m.name}>
                      {m.name.toUpperCase()}
                    </option>
                  ))}
                  {models.length === 0 && (
                    <option value="">NO MODELS AVAILABLE</option>
                  )}
                </select>
                <ChevronDown className="w-3 h-3 absolute right-2 top-1/2 -translate-y-1/2 text-trident-text/30 pointer-events-none" />
              </div>
            </div>
          )}

          {/* Voice service status */}
          <div className="trident-panel p-3">
            <div className="font-mono text-[9px] text-trident-text/40 uppercase tracking-widest mb-1">
              VOICE SERVICE
            </div>
            {isOnline ? (
              <div className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-trident-green animate-pulse" />
                <span className="font-mono text-[10px] text-trident-green">
                  PROCESSING UNIT ONLINE
                </span>
              </div>
            ) : (
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-red-500" />
                  <span className="font-mono text-[10px] text-red-500">
                    PROCESSING UNIT OFFLINE
                  </span>
                </div>
                <p className="font-mono text-[8px] text-trident-text/25 uppercase">
                  RUN scripts/setup-voice.sh ON SERVER
                </p>
              </div>
            )}
          </div>
        </div>

        {/* ─── RIGHT CONVERSATION LOG ─── */}
        <div className="flex-1 flex flex-col trident-panel min-h-0">
          {/* Header */}
          <div className="scanlines p-3 border-b border-trident-border shrink-0">
            <div className="font-mono text-[9px] text-trident-text/40 uppercase tracking-widest">
              TRANSCRIPT / CONVERSATION LOG
            </div>
          </div>

          {/* Messages */}
          <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-3 min-h-0">
            {entries.length === 0 && (
              <div className="flex items-center justify-center h-full">
                <div className="text-center space-y-3">
                  <Mic className="w-10 h-10 mx-auto text-trident-cyan/15" />
                  <div className="font-mono text-[11px] text-trident-text/25 cursor-blink">
                    &gt;&gt; AWAITING VOICE INPUT
                  </div>
                  <p className="font-mono text-[9px] text-trident-text/15 uppercase max-w-[260px]">
                    HOLD THE TRANSMIT BUTTON OR TYPE BELOW TO BEGIN
                  </p>
                </div>
              </div>
            )}

            {entries.map((entry) => (
              <div
                key={entry.id}
                className={`flex ${entry.role === "user" ? "justify-end" : "justify-start"}`}
                data-testid={`entry-${entry.role}-${entry.id}`}
              >
                <div
                  className={`max-w-[80%] ${
                    entry.role === "user"
                      ? "bg-trident-amber/5 border border-trident-amber/20"
                      : "bg-trident-cyan/5 border border-trident-cyan/20"
                  } p-3 rounded-sm`}
                >
                  <div className="flex items-center gap-2 mb-1">
                    <span
                      className={`font-mono text-[8px] uppercase tracking-widest font-bold ${
                        entry.role === "user" ? "text-trident-amber/70" : "text-trident-cyan/70"
                      }`}
                    >
                      {entry.role === "user" ? "OPERATOR" : "TRIDENT"}
                    </span>
                    <span className="font-mono text-[7px] text-trident-text/20">
                      {entry.timestamp}
                    </span>
                  </div>
                  <p
                    className={`font-mono text-[11px] leading-relaxed ${
                      entry.role === "user" ? "text-trident-amber/90" : "text-trident-cyan/90"
                    }`}
                  >
                    {entry.content}
                  </p>
                  {entry.role === "assistant" && entry.audioUrl && (
                    <button
                      onClick={() => replayAudio(entry.audioUrl!)}
                      className="mt-2 flex items-center gap-1 font-mono text-[8px] text-trident-green/60 hover:text-trident-green transition-colors uppercase tracking-widest"
                      data-testid={`button-replay-${entry.id}`}
                    >
                      <Play className="w-3 h-3" /> REPLAY
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>

          {/* Text input fallback */}
          <div className="p-3 border-t border-trident-border shrink-0">
            <div className="flex gap-2">
              <input
                type="text"
                value={textInput}
                onChange={(e) => setTextInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter" && !e.shiftKey) {
                    e.preventDefault();
                    handleTextSubmit();
                  }
                }}
                placeholder="TYPE MESSAGE — ALTERNATIVE TO VOICE INPUT"
                className="trident-input flex-1 py-2 px-3 text-[11px]"
                disabled={voiceState !== "IDLE"}
                data-testid="input-text-message"
              />
              <button
                onClick={handleTextSubmit}
                disabled={voiceState !== "IDLE" || !textInput.trim()}
                className="trident-btn trident-btn-primary px-3 py-2 text-[10px] flex items-center gap-1.5 disabled:opacity-30 disabled:cursor-not-allowed"
                data-testid="button-send-text"
              >
                <Send className="w-3 h-3" />
                TRANSMIT
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* ─── Custom CSS for recording pulse ─── */}
      <style>{`
        @keyframes pulseRecording {
          0%, 100% {
            box-shadow: 0 0 5px rgba(255, 34, 68, 0.5), 0 0 10px rgba(255, 34, 68, 0.3);
          }
          50% {
            box-shadow: 0 0 15px rgba(255, 34, 68, 0.8), 0 0 30px rgba(255, 34, 68, 0.5), 0 0 45px rgba(255, 34, 68, 0.2);
          }
        }
        .animate-pulse-recording {
          animation: pulseRecording 1s ease-in-out infinite;
        }
      `}</style>
    </div>
  );
}
