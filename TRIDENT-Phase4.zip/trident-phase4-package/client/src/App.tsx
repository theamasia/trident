import { Switch, Route, Router, Redirect } from "wouter";
import { useHashLocation } from "wouter/use-hash-location";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useAuth } from "@/hooks/use-auth";
import { useEffect } from "react";

// Pages
import LoginPage from "@/pages/login";
import RegisterPage from "@/pages/register";
import DashboardChat from "@/pages/dashboard-chat";
import DashboardModels from "@/pages/dashboard-models";
import DashboardSettings from "@/pages/dashboard-settings";
import DashboardStub from "@/pages/dashboard-stub";
import DashboardVoice from "@/pages/dashboard-voice";
import DashboardImageGen from "@/pages/dashboard-imagegen";
import AdminUsersPage from "@/pages/admin-users";
import NotFound from "@/pages/not-found";

// Layout
import { DashboardLayout } from "@/components/DashboardLayout";

// Protected route wrapper
function ProtectedRoute({ component: Component, adminOnly = false, ...props }: any) {
  const { isAuthenticated, isLoading, user } = useAuth();

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center grid-bg" style={{ backgroundColor: "#050a0e" }}>
        <div className="flex items-center gap-2">
          {[0, 1, 2].map((i) => (
            <span
              key={i}
              className="inline-block w-2 h-2 rounded-full bg-trident-cyan pulse-dot"
              style={{ animationDelay: `${i * 0.3}s` }}
            />
          ))}
          <span className="text-xs font-mono uppercase tracking-widest text-trident-text/40 ml-2">
            VERIFYING CLEARANCE...
          </span>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Redirect to="/login" />;
  }

  if (adminOnly && user?.role !== "admin") {
    return <Redirect to="/dashboard" />;
  }

  return (
    <DashboardLayout>
      <Component {...props} />
    </DashboardLayout>
  );
}

function AppRouter() {
  const { checkAuth } = useAuth();

  useEffect(() => {
    checkAuth();
  }, []);

  return (
    <Switch>
      <Route path="/login" component={LoginPage} />
      <Route path="/register" component={RegisterPage} />
      
      {/* Dashboard routes */}
      <Route path="/dashboard">
        {() => <ProtectedRoute component={DashboardChat} />}
      </Route>
      <Route path="/dashboard/models">
        {() => <ProtectedRoute component={DashboardModels} />}
      </Route>
      <Route path="/dashboard/imagegen">
        {() => <ProtectedRoute component={DashboardImageGen} />}
      </Route>
      <Route path="/dashboard/voice">
        {() => <ProtectedRoute component={DashboardVoice} />}
      </Route>
      <Route path="/dashboard/gallery">
        {() => (
          <ProtectedRoute
            component={DashboardStub}
            title="MEDIA GALLERY"
            icon="gallery"
            systemName="ASSET DATABASE"
          />
        )}
      </Route>
      <Route path="/dashboard/settings">
        {() => <ProtectedRoute component={DashboardSettings} />}
      </Route>
      
      {/* Admin routes */}
      <Route path="/admin/users">
        {() => <ProtectedRoute component={AdminUsersPage} adminOnly={true} />}
      </Route>

      {/* Root redirect */}
      <Route path="/">
        {() => <Redirect to="/login" />}
      </Route>
      
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  // Force dark class on document
  useEffect(() => {
    document.documentElement.classList.add("dark");
  }, []);

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router hook={useHashLocation}>
          <AppRouter />
        </Router>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
