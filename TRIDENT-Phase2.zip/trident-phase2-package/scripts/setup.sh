#!/bin/bash
set -euo pipefail

# ═══════════════════════════════════════════════════════════
# TRIDENT — Production Server Setup Script
# Run as the 'trident' system user from /opt/trident
# Requires: Node.js 20+, PostgreSQL (via DATABASE_URL)
# ═══════════════════════════════════════════════════════════

# ANSI color codes
CYAN='\033[0;36m'
GREEN='\033[0;32m'
RED='\033[0;31m'
AMBER='\033[0;33m'
NC='\033[0m' # No Color

# ASCII header
echo -e "${CYAN}"
cat << 'EOF'
  _____ ____  ___ ____  _____ _   _ _____
 |_   _|  _ \|_ _|  _ \| ____| \ | |_   _|
   | | | |_) || || | | |  _| |  \| | | |
   | | |  _ < | || |_| | |___| |\  | | |
   |_| |_| \_\___|____/|_____|_| \_| |_|

   TACTICAL NEURAL INTERFACE SYSTEM
   Production Setup v1.0
EOF
echo -e "${NC}"

# ───────────────────────────────────────────
# 1. Check Node.js version (require 20+)
# ───────────────────────────────────────────
echo -e "${CYAN}[TRIDENT]${NC} Checking Node.js version..."
if ! command -v node &> /dev/null; then
    echo -e "${RED}[ERROR]${NC} Node.js is not installed."
    echo -e "${RED}[ERROR]${NC} Install Node.js 20+ via:"
    echo -e "  curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -"
    echo -e "  sudo apt-get install -y nodejs"
    exit 1
fi

NODE_VERSION=$(node -v | sed 's/v//' | cut -d. -f1)
if [ "$NODE_VERSION" -lt 20 ]; then
    echo -e "${RED}[ERROR]${NC} Node.js 20+ required. Found: $(node -v)"
    echo -e "${RED}[ERROR]${NC} Upgrade with: sudo n install 20 (or use nvm)"
    exit 1
fi
echo -e "${GREEN}[OK]${NC} Node.js $(node -v) detected"

# ───────────────────────────────────────────
# 2. Load config and check PostgreSQL
# ───────────────────────────────────────────
CONFIG_FILE="/etc/trident/config.env"
if [ ! -f "$CONFIG_FILE" ]; then
    echo -e "${RED}[ERROR]${NC} Config file not found: ${CONFIG_FILE}"
    echo -e "${RED}[ERROR]${NC} Create it with:"
    echo -e "  sudo mkdir -p /etc/trident"
    echo -e "  sudo cp /opt/trident/.env.example /etc/trident/config.env"
    echo -e "  sudo nano /etc/trident/config.env"
    exit 1
fi

# Source the config file to get env vars
set -a
source "$CONFIG_FILE"
set +a

echo -e "${CYAN}[TRIDENT]${NC} Checking PostgreSQL connectivity..."
if [ -z "${DATABASE_URL:-}" ]; then
    echo -e "${RED}[ERROR]${NC} DATABASE_URL not set in ${CONFIG_FILE}"
    exit 1
fi

# Extract host and port from DATABASE_URL for connectivity check
# Format: postgresql://user:pass@host:port/dbname
DB_HOST=$(echo "$DATABASE_URL" | sed -n 's|.*@\([^:/]*\).*|\1|p')
DB_PORT=$(echo "$DATABASE_URL" | sed -n 's|.*:\([0-9]*\)/.*|\1|p')
DB_PORT=${DB_PORT:-5432}

if ! pg_isready -h "$DB_HOST" -p "$DB_PORT" -q 2>/dev/null; then
    echo -e "${RED}[ERROR]${NC} Cannot reach PostgreSQL at ${DB_HOST}:${DB_PORT}"
    echo -e "${RED}[ERROR]${NC} Ensure PostgreSQL is running and DATABASE_URL is correct in ${CONFIG_FILE}"
    exit 1
fi
echo -e "${GREEN}[OK]${NC} PostgreSQL reachable at ${DB_HOST}:${DB_PORT}"

# ───────────────────────────────────────────
# 3. Install production dependencies
# ───────────────────────────────────────────
echo -e "${CYAN}[TRIDENT]${NC} Installing production dependencies..."
npm install --production
echo -e "${GREEN}[OK]${NC} Dependencies installed"

# ───────────────────────────────────────────
# 4. Build the application
# ───────────────────────────────────────────
echo -e "${CYAN}[TRIDENT]${NC} Building application..."
npm run build
echo -e "${GREEN}[OK]${NC} Build complete"

# ───────────────────────────────────────────
# 5. Run database migrations
# ───────────────────────────────────────────
echo -e "${CYAN}[TRIDENT]${NC} Running database migrations..."
npx drizzle-kit push
echo -e "${GREEN}[OK]${NC} Database schema up to date"

# ───────────────────────────────────────────
# 6. Seed initial admin user
# Read ADMIN_EMAIL and ADMIN_PASSWORD from config,
# or fall back to defaults
# ───────────────────────────────────────────
ADMIN_EMAIL="${ADMIN_EMAIL:-admin@trident.local}"
ADMIN_PASSWORD="${ADMIN_PASSWORD:-TridentAdmin1!}"

echo -e "${CYAN}[TRIDENT]${NC} Seeding admin user: ${ADMIN_EMAIL}"

# Hash the password using bcrypt via Node.js
# The inline script loads bcryptjs and outputs the hash
ADMIN_HASH=$(node -e "
  const bcrypt = require('bcryptjs');
  const hash = bcrypt.hashSync('${ADMIN_PASSWORD}', 12);
  process.stdout.write(hash);
")

# Use psql to INSERT (or skip if already exists via ON CONFLICT)
# This handles both fresh installs and re-runs
psql "$DATABASE_URL" -c "
  INSERT INTO users (username, email, password_hash, role, created_at, is_active)
  VALUES ('admin', '${ADMIN_EMAIL}', '${ADMIN_HASH}', 'admin', NOW()::text, true)
  ON CONFLICT (email) DO UPDATE SET
    password_hash = EXCLUDED.password_hash,
    role = 'admin',
    is_active = true;
" 2>/dev/null || {
    # If psql fails (e.g., SQLite in dev), try the Node.js approach
    echo -e "${AMBER}[WARN]${NC} psql not available, using Node.js for seeding..."
    node -e "
      const Database = require('better-sqlite3');
      const bcrypt = require('bcryptjs');
      const db = new Database('data.db');
      db.pragma('journal_mode = WAL');
      
      // Create table if not exists (for SQLite dev mode)
      db.exec(\`
        CREATE TABLE IF NOT EXISTS users (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          username TEXT NOT NULL UNIQUE,
          email TEXT NOT NULL UNIQUE,
          password_hash TEXT NOT NULL,
          role TEXT NOT NULL DEFAULT 'user',
          created_at TEXT NOT NULL DEFAULT '',
          last_login TEXT,
          is_active INTEGER NOT NULL DEFAULT 1
        )
      \`);
      
      const hash = bcrypt.hashSync('${ADMIN_PASSWORD}', 12);
      const existing = db.prepare('SELECT id FROM users WHERE email = ?').get('${ADMIN_EMAIL}');
      if (existing) {
        db.prepare('UPDATE users SET password_hash = ?, role = ?, is_active = 1 WHERE email = ?')
          .run(hash, 'admin', '${ADMIN_EMAIL}');
        console.log('Admin user updated');
      } else {
        db.prepare('INSERT INTO users (username, email, password_hash, role, created_at, is_active) VALUES (?, ?, ?, ?, ?, 1)')
          .run('admin', '${ADMIN_EMAIL}', hash, 'admin', new Date().toISOString());
        console.log('Admin user created');
      }
    "
}
echo -e "${GREEN}[OK]${NC} Admin user seeded: ${ADMIN_EMAIL}"

# ───────────────────────────────────────────
# 7. Done
# ───────────────────────────────────────────
echo ""
echo -e "${GREEN}═══════════════════════════════════════════════════════${NC}"
echo -e "${GREEN}[ TRIDENT ] App setup complete.${NC}"
echo -e "${GREEN}[ TRIDENT ] Start with: systemctl start trident${NC}"
echo -e "${GREEN}═══════════════════════════════════════════════════════${NC}"
