#!/bin/bash
set -euo pipefail

# ═══════════════════════════════════════════════════════════
# TRIDENT — Production Update Script
# Updates the app, rebuilds, migrates, and restarts
# Run as root or the trident system user
# ═══════════════════════════════════════════════════════════

CYAN='\033[0;36m'
GREEN='\033[0;32m'
RED='\033[0;31m'
AMBER='\033[0;33m'
NC='\033[0m'

echo -e "${CYAN}"
cat << 'EOF'
  _____ ____  ___ ____  _____ _   _ _____
 |_   _|  _ \|_ _|  _ \| ____| \ | |_   _|
   | | | |_) || || | | |  _| |  \| | | |
   | | |  _ < | || |_| | |___| |\  | | |
   |_| |_| \_\___|____/|_____|_| \_| |_|

   Production Update
EOF
echo -e "${NC}"

# ───────────────────────────────────────────
# 1. Navigate to app directory
# ───────────────────────────────────────────
APP_DIR="/opt/trident"
if [ ! -d "$APP_DIR" ]; then
    echo -e "${RED}[ERROR]${NC} App directory not found: ${APP_DIR}"
    exit 1
fi
cd "$APP_DIR"
echo -e "${CYAN}[TRIDENT]${NC} Working directory: ${APP_DIR}"

# ───────────────────────────────────────────
# 2. Pull latest code (if git-managed)
# Skip gracefully if not a git repo
# ───────────────────────────────────────────
if [ -d ".git" ]; then
    echo -e "${CYAN}[TRIDENT]${NC} Pulling latest changes from git..."
    git pull --ff-only || {
        echo -e "${AMBER}[WARN]${NC} Git pull failed. You may need to resolve conflicts manually."
        echo -e "${AMBER}[WARN]${NC} Continuing with existing files..."
    }
    echo -e "${GREEN}[OK]${NC} Code updated"
else
    echo -e "${AMBER}[TRIDENT]${NC} Not a git repository — skipping pull"
    echo -e "${AMBER}[TRIDENT]${NC} Ensure you've deployed updated files to ${APP_DIR}"
fi

# ───────────────────────────────────────────
# 3. Source config
# ───────────────────────────────────────────
if [ -f "/etc/trident/config.env" ]; then
    set -a
    source "/etc/trident/config.env"
    set +a
    echo -e "${GREEN}[OK]${NC} Config loaded from /etc/trident/config.env"
fi

# ───────────────────────────────────────────
# 4. Install production dependencies
# Only production deps to keep the install lean
# ───────────────────────────────────────────
echo -e "${CYAN}[TRIDENT]${NC} Installing dependencies..."
npm install --production
echo -e "${GREEN}[OK]${NC} Dependencies updated"

# ───────────────────────────────────────────
# 5. Build the application
# Compiles TypeScript and bundles frontend
# ───────────────────────────────────────────
echo -e "${CYAN}[TRIDENT]${NC} Building application..."
npm run build
echo -e "${GREEN}[OK]${NC} Build complete"

# ───────────────────────────────────────────
# 6. Run database migrations
# Syncs schema changes to the live database
# ───────────────────────────────────────────
echo -e "${CYAN}[TRIDENT]${NC} Running migrations..."
npx drizzle-kit push
echo -e "${GREEN}[OK]${NC} Migrations applied"

# ───────────────────────────────────────────
# 7. Restart the TRIDENT systemd service
# ───────────────────────────────────────────
echo -e "${CYAN}[TRIDENT]${NC} Restarting TRIDENT service..."
if systemctl is-active --quiet trident 2>/dev/null; then
    systemctl restart trident
    echo -e "${GREEN}[OK]${NC} Service restarted"
else
    echo -e "${AMBER}[WARN]${NC} TRIDENT service not found or not running"
    echo -e "${AMBER}[WARN]${NC} Start manually: systemctl start trident"
fi

# ───────────────────────────────────────────
# 8. Check service status
# ───────────────────────────────────────────
echo -e "${CYAN}[TRIDENT]${NC} Checking service status..."
sleep 2
if systemctl is-active --quiet trident 2>/dev/null; then
    systemctl status trident --no-pager
    echo ""
    echo -e "${GREEN}═══════════════════════════════════════════════════════${NC}"
    echo -e "${GREEN}[ TRIDENT ] Update complete. System is ONLINE.${NC}"
    echo -e "${GREEN}═══════════════════════════════════════════════════════${NC}"
else
    echo -e "${AMBER}[WARN]${NC} Service status unavailable (systemd may not be running)"
    echo ""
    echo -e "${GREEN}═══════════════════════════════════════════════════════${NC}"
    echo -e "${GREEN}[ TRIDENT ] Update complete. Verify service manually.${NC}"
    echo -e "${GREEN}═══════════════════════════════════════════════════════${NC}"
fi
