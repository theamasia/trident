#!/bin/bash
set -euo pipefail

# ═══════════════════════════════════════════════════════════
# TRIDENT — Database Migration Script
# Applies schema changes via Drizzle Kit push
# Sources config from /etc/trident/config.env or local .env
# ═══════════════════════════════════════════════════════════

CYAN='\033[0;36m'
GREEN='\033[0;32m'
RED='\033[0;31m'
NC='\033[0m'

echo -e "${CYAN}"
cat << 'EOF'
  _____ ____  ___ ____  _____ _   _ _____
 |_   _|  _ \|_ _|  _ \| ____| \ | |_   _|
   | | | |_) || || | | |  _| |  \| | | |
   | | |  _ < | || |_| | |___| |\  | | |
   |_| |_| \_\___|____/|_____|_| \_| |_|

   Database Migration
EOF
echo -e "${NC}"

# ───────────────────────────────────────────
# 1. Source configuration
# Check /etc/trident/config.env first (production),
# then fall back to local .env (development)
# ───────────────────────────────────────────
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"

if [ -f "/etc/trident/config.env" ]; then
    echo -e "${CYAN}[TRIDENT]${NC} Loading config from /etc/trident/config.env"
    set -a
    source "/etc/trident/config.env"
    set +a
elif [ -f "$PROJECT_ROOT/.env" ]; then
    echo -e "${CYAN}[TRIDENT]${NC} Loading config from .env"
    set -a
    source "$PROJECT_ROOT/.env"
    set +a
else
    echo -e "${RED}[ERROR]${NC} No config file found."
    echo -e "${RED}[ERROR]${NC} Expected /etc/trident/config.env or .env"
    exit 1
fi

# ───────────────────────────────────────────
# 2. Run Drizzle Kit push
# This syncs the schema.ts definitions to the database
# without needing explicit migration files
# ───────────────────────────────────────────
echo -e "${CYAN}[TRIDENT]${NC} Running database migration..."
cd "$PROJECT_ROOT"

npx drizzle-kit push

if [ $? -eq 0 ]; then
    echo ""
    echo -e "${GREEN}═══════════════════════════════════════════════════════${NC}"
    echo -e "${GREEN}[ TRIDENT ] Database migration complete.${NC}"
    echo -e "${GREEN}═══════════════════════════════════════════════════════${NC}"
else
    echo ""
    echo -e "${RED}═══════════════════════════════════════════════════════${NC}"
    echo -e "${RED}[ TRIDENT ] Migration FAILED. Check errors above.${NC}"
    echo -e "${RED}═══════════════════════════════════════════════════════${NC}"
    exit 1
fi
