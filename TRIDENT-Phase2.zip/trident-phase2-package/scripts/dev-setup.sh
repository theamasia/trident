#!/bin/bash
set -euo pipefail

# ═══════════════════════════════════════════════════════════
# TRIDENT — Local Development Setup
# Run once after cloning the repo on any dev machine
# ═══════════════════════════════════════════════════════════

CYAN='\033[0;36m'
GREEN='\033[0;32m'
RED='\033[0;31m'
AMBER='\033[0;33m'
NC='\033[0m'

echo -e "${CYAN}"
cat << 'EOF'
  _____ ____  ___ ____  _____ _   _ _____
 |_   _|  _ \|_ _|  _ \| ____| \ | |_   _|
   | | | |_) || || | | |  _| |  \| | | |
   | | |  _ < | || |_| | |___| |\  | | |
   |_| |_| \_\___|____/|_____|_| \_| |_|

   TACTICAL NEURAL INTERFACE SYSTEM
   Development Setup v1.0
EOF
echo -e "${NC}"

# ───────────────────────────────────────────
# 1. Check Node.js version (require 20+)
# ───────────────────────────────────────────
echo -e "${CYAN}[TRIDENT]${NC} Checking Node.js version..."
if ! command -v node &> /dev/null; then
    echo -e "${RED}[ERROR]${NC} Node.js is not installed."
    echo -e "${RED}[ERROR]${NC} Install Node.js 20+ from: https://nodejs.org/"
    echo -e "  macOS: brew install node@20"
    echo -e "  Linux: curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash - && sudo apt-get install -y nodejs"
    echo -e "  nvm:   nvm install 20 && nvm use 20"
    exit 1
fi

NODE_VERSION=$(node -v | sed 's/v//' | cut -d. -f1)
if [ "$NODE_VERSION" -lt 20 ]; then
    echo -e "${RED}[ERROR]${NC} Node.js 20+ required. Found: $(node -v)"
    exit 1
fi
echo -e "${GREEN}[OK]${NC} Node.js $(node -v) detected"

# ───────────────────────────────────────────
# 2. Install all dependencies (including devDependencies)
# ───────────────────────────────────────────
echo -e "${CYAN}[TRIDENT]${NC} Installing dependencies..."
npm install
echo -e "${GREEN}[OK]${NC} Dependencies installed"

# ───────────────────────────────────────────
# 3. Check for .env file — copy .env.example if missing
# ───────────────────────────────────────────
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"

if [ ! -f "$PROJECT_ROOT/.env" ]; then
    if [ -f "$PROJECT_ROOT/.env.example" ]; then
        echo -e "${AMBER}[TRIDENT]${NC} No .env file found. Copying from .env.example..."
        cp "$PROJECT_ROOT/.env.example" "$PROJECT_ROOT/.env"
        echo -e "${AMBER}[ACTION REQUIRED]${NC} Edit .env with your database URL and JWT secret before running npm run dev"
        echo -e "  File: ${PROJECT_ROOT}/.env"
    else
        echo -e "${RED}[ERROR]${NC} No .env.example found. Something is wrong with the repo."
        exit 1
    fi
else
    echo -e "${GREEN}[OK]${NC} .env file exists"
fi

# ───────────────────────────────────────────
# 4. Print instructions
# ───────────────────────────────────────────
echo ""
echo -e "${GREEN}═══════════════════════════════════════════════════════${NC}"
echo -e "${GREEN}[ TRIDENT ] Development setup complete!${NC}"
echo -e "${GREEN}═══════════════════════════════════════════════════════${NC}"
echo ""
echo -e "${CYAN}Next steps:${NC}"
echo -e "  1. Edit ${AMBER}.env${NC} if you haven't already"
echo -e "     (SQLite is used in dev by default — no database setup needed)"
echo -e ""
echo -e "  2. Start the dev server:"
echo -e "     ${GREEN}npm run dev${NC}"
echo -e ""
echo -e "  3. Open in browser:"
echo -e "     ${CYAN}http://localhost:5000${NC}"
echo -e ""
echo -e "  4. Seed an admin user (optional):"
echo -e "     ${GREEN}./scripts/db-seed-admin.sh${NC}"
echo ""
