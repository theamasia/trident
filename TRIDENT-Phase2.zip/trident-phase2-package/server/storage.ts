import {
  type User,
  type InsertUser,
  type SafeUser,
  type Session,
  type InsertSession,
  type Conversation,
  type InsertConversation,
  type Message,
  type InsertMessage,
  type ModelConfig,
  type InsertModelConfig,
  users,
  sessions,
  conversations,
  messages,
  modelConfigs,
} from "@shared/schema";
import { drizzle } from "drizzle-orm/better-sqlite3";
import Database from "better-sqlite3";
import { eq, and, desc } from "drizzle-orm";

const sqlite = new Database("data.db");
sqlite.pragma("journal_mode = WAL");

export const db = drizzle(sqlite);

// Strip password_hash from user for frontend delivery
function toSafeUser(user: User): SafeUser {
  const { password_hash, ...safe } = user;
  return safe;
}

export interface IStorage {
  // User CRUD
  getUser(id: number): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, data: Partial<Pick<User, "username" | "email" | "password_hash" | "role" | "is_active" | "last_login">>): Promise<User | undefined>;
  deleteUser(id: number): Promise<boolean>;
  getAllUsers(): Promise<SafeUser[]>;

  // Session CRUD
  createSession(session: InsertSession): Promise<Session>;
  getSessionByTokenHash(tokenHash: string): Promise<Session | undefined>;
  deleteSession(tokenHash: string): Promise<boolean>;
  deleteUserSessions(userId: number): Promise<boolean>;

  // Conversations
  createConversation(data: InsertConversation): Promise<Conversation>;
  getConversation(id: number, userId: number): Promise<Conversation | undefined>;
  getUserConversations(userId: number): Promise<Conversation[]>;
  updateConversation(id: number, userId: number, data: Partial<Pick<Conversation, "title" | "model" | "system_prompt" | "updated_at">>): Promise<Conversation | undefined>;
  deleteConversation(id: number, userId: number): Promise<boolean>;

  // Messages
  addMessage(data: InsertMessage): Promise<Message>;
  getConversationMessages(conversationId: number): Promise<Message[]>;
  deleteConversationMessages(conversationId: number): Promise<boolean>;

  // Model configs
  getModelConfig(userId: number, modelName: string): Promise<ModelConfig | undefined>;
  upsertModelConfig(userId: number, modelName: string, data: Partial<Pick<ModelConfig, "temperature" | "max_tokens" | "top_p" | "system_prompt">>): Promise<ModelConfig>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    return db.select().from(users).where(eq(users.id, id)).get();
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return db.select().from(users).where(eq(users.email, email)).get();
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return db.select().from(users).where(eq(users.username, username)).get();
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const now = new Date().toISOString();
    return db.insert(users).values({ ...insertUser, created_at: now }).returning().get();
  }

  async updateUser(
    id: number,
    data: Partial<Pick<User, "username" | "email" | "password_hash" | "role" | "is_active" | "last_login">>
  ): Promise<User | undefined> {
    return db.update(users).set(data).where(eq(users.id, id)).returning().get();
  }

  async deleteUser(id: number): Promise<boolean> {
    const result = db.delete(users).where(eq(users.id, id)).run();
    return result.changes > 0;
  }

  async getAllUsers(): Promise<SafeUser[]> {
    const allUsers = db.select().from(users).all();
    return allUsers.map(toSafeUser);
  }

  // Sessions
  async createSession(session: InsertSession): Promise<Session> {
    const now = new Date().toISOString();
    return db.insert(sessions).values({ ...session, created_at: now }).returning().get();
  }

  async getSessionByTokenHash(tokenHash: string): Promise<Session | undefined> {
    return db.select().from(sessions).where(eq(sessions.token_hash, tokenHash)).get();
  }

  async deleteSession(tokenHash: string): Promise<boolean> {
    const result = db.delete(sessions).where(eq(sessions.token_hash, tokenHash)).run();
    return result.changes > 0;
  }

  async deleteUserSessions(userId: number): Promise<boolean> {
    const result = db.delete(sessions).where(eq(sessions.user_id, userId)).run();
    return result.changes >= 0;
  }

  // ═══════════════════════════════════════════════════
  // CONVERSATIONS — Phase 2
  // ═══════════════════════════════════════════════════
  async createConversation(data: InsertConversation): Promise<Conversation> {
    return db.insert(conversations).values(data).returning().get();
  }

  async getConversation(id: number, userId: number): Promise<Conversation | undefined> {
    return db.select().from(conversations).where(and(eq(conversations.id, id), eq(conversations.user_id, userId))).get();
  }

  async getUserConversations(userId: number): Promise<Conversation[]> {
    return db.select().from(conversations).where(eq(conversations.user_id, userId)).orderBy(desc(conversations.updated_at)).all();
  }

  async updateConversation(
    id: number,
    userId: number,
    data: Partial<Pick<Conversation, "title" | "model" | "system_prompt" | "updated_at">>
  ): Promise<Conversation | undefined> {
    return db.update(conversations).set(data).where(and(eq(conversations.id, id), eq(conversations.user_id, userId))).returning().get();
  }

  async deleteConversation(id: number, userId: number): Promise<boolean> {
    // Delete messages first
    db.delete(messages).where(eq(messages.conversation_id, id)).run();
    const result = db.delete(conversations).where(and(eq(conversations.id, id), eq(conversations.user_id, userId))).run();
    return result.changes > 0;
  }

  // ═══════════════════════════════════════════════════
  // MESSAGES — Phase 2
  // ═══════════════════════════════════════════════════
  async addMessage(data: InsertMessage): Promise<Message> {
    return db.insert(messages).values(data).returning().get();
  }

  async getConversationMessages(conversationId: number): Promise<Message[]> {
    return db.select().from(messages).where(eq(messages.conversation_id, conversationId)).all();
  }

  async deleteConversationMessages(conversationId: number): Promise<boolean> {
    const result = db.delete(messages).where(eq(messages.conversation_id, conversationId)).run();
    return result.changes >= 0;
  }

  // ═══════════════════════════════════════════════════
  // MODEL CONFIGS — Phase 2
  // ═══════════════════════════════════════════════════
  async getModelConfig(userId: number, modelName: string): Promise<ModelConfig | undefined> {
    return db.select().from(modelConfigs).where(and(eq(modelConfigs.user_id, userId), eq(modelConfigs.model_name, modelName))).get();
  }

  async upsertModelConfig(
    userId: number,
    modelName: string,
    data: Partial<Pick<ModelConfig, "temperature" | "max_tokens" | "top_p" | "system_prompt">>
  ): Promise<ModelConfig> {
    const now = new Date().toISOString();
    const existing = await this.getModelConfig(userId, modelName);
    if (existing) {
      return db.update(modelConfigs).set({ ...data, updated_at: now }).where(eq(modelConfigs.id, existing.id)).returning().get();
    }
    return db.insert(modelConfigs).values({
      user_id: userId,
      model_name: modelName,
      temperature: data.temperature ?? 0.7,
      max_tokens: data.max_tokens ?? 2048,
      top_p: data.top_p ?? 0.9,
      system_prompt: data.system_prompt ?? "",
      updated_at: now,
    }).returning().get();
  }
}

export const storage = new DatabaseStorage();
