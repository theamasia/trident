import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { requireAuth, requireAdmin, generateToken } from "./middleware/auth";
import bcrypt from "bcryptjs";
import { z } from "zod";

// Validation schemas
const registerSchema = z.object({
  username: z.string().min(3).max(32),
  email: z.string().email(),
  password: z.string().min(8),
});

const loginSchema = z.object({
  email: z.string().email(),
  password: z.string(),
});

const updateUserSchema = z.object({
  role: z.enum(["admin", "power_user", "user"]).optional(),
  is_active: z.boolean().optional(),
});

const updateSettingsSchema = z.object({
  username: z.string().min(3).max(32).optional(),
  email: z.string().email().optional(),
  current_password: z.string().optional(),
  new_password: z.string().min(8).optional(),
});

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {

  // ═══════════════════════════════════════════════════
  // AUTH ROUTES
  // ═══════════════════════════════════════════════════

  // POST /api/auth/register — Create new user
  app.post("/api/auth/register", async (req, res) => {
    try {
      const data = registerSchema.parse(req.body);
      data.email = data.email.toLowerCase().trim();

      // Check uniqueness
      const existingEmail = await storage.getUserByEmail(data.email);
      if (existingEmail) {
        return res.status(409).json({ error: "EMAIL ALREADY REGISTERED" });
      }
      const existingUsername = await storage.getUserByUsername(data.username);
      if (existingUsername) {
        return res.status(409).json({ error: "USERNAME ALREADY TAKEN" });
      }

      const password_hash = await bcrypt.hash(data.password, 12);

      const user = await storage.createUser({
        username: data.username,
        email: data.email,
        password_hash,
        role: "user",
        is_active: true,
      });

      const { password_hash: _, ...safeUser } = user;
      res.status(201).json({ message: "ACCESS GRANTED — AWAIT AUTHENTICATION", user: safeUser });
    } catch (err: any) {
      if (err.name === "ZodError") {
        return res.status(400).json({ error: "INVALID INPUT DATA", details: err.errors });
      }
      console.error("Registration error:", err);
      res.status(500).json({ error: "SYSTEM ERROR — REGISTRATION FAILED" });
    }
  });

  // POST /api/auth/login — Validate credentials, return JWT
  app.post("/api/auth/login", async (req, res) => {
    try {
      const data = loginSchema.parse(req.body);
      data.email = data.email.toLowerCase().trim();

      const user = await storage.getUserByEmail(data.email);
      if (!user) {
        return res.status(401).json({ error: "INVALID CREDENTIALS" });
      }

      if (!user.is_active) {
        return res.status(403).json({ error: "ACCOUNT DEACTIVATED — CONTACT ADMINISTRATOR" });
      }

      const valid = await bcrypt.compare(data.password, user.password_hash);
      if (!valid) {
        return res.status(401).json({ error: "INVALID CREDENTIALS" });
      }

      // Update last login
      await storage.updateUser(user.id, { last_login: new Date().toISOString() });

      const token = generateToken(user.id, user.role);
      const { password_hash: _, ...safeUser } = user;

      res.json({ token, user: safeUser });
    } catch (err: any) {
      if (err.name === "ZodError") {
        return res.status(400).json({ error: "INVALID INPUT DATA" });
      }
      console.error("Login error:", err);
      res.status(500).json({ error: "SYSTEM ERROR — AUTHENTICATION FAILED" });
    }
  });

  // POST /api/auth/logout — Invalidate session
  app.post("/api/auth/logout", requireAuth, async (req, res) => {
    // With JWT, logout is client-side (discard token). 
    // We respond affirmatively.
    res.json({ message: "SESSION TERMINATED" });
  });

  // GET /api/auth/me — Return current user
  app.get("/api/auth/me", requireAuth, async (req, res) => {
    res.json({ user: req.user });
  });

  // ═══════════════════════════════════════════════════
  // USER SETTINGS
  // ═══════════════════════════════════════════════════

  app.patch("/api/auth/settings", requireAuth, async (req, res) => {
    try {
      const data = updateSettingsSchema.parse(req.body);
      const userId = req.user!.id;
      const updateData: any = {};

      if (data.username) updateData.username = data.username;
      if (data.email) updateData.email = data.email;

      if (data.new_password) {
        if (!data.current_password) {
          return res.status(400).json({ error: "CURRENT PASSWORD REQUIRED" });
        }
        const user = await storage.getUser(userId);
        if (!user) return res.status(404).json({ error: "USER NOT FOUND" });
        const valid = await bcrypt.compare(data.current_password, user.password_hash);
        if (!valid) return res.status(401).json({ error: "CURRENT PASSWORD INVALID" });
        updateData.password_hash = await bcrypt.hash(data.new_password, 12);
      }

      const updated = await storage.updateUser(userId, updateData);
      if (!updated) return res.status(404).json({ error: "USER NOT FOUND" });

      const { password_hash: _, ...safeUser } = updated;
      res.json({ user: safeUser });
    } catch (err: any) {
      if (err.name === "ZodError") {
        return res.status(400).json({ error: "INVALID INPUT DATA", details: err.errors });
      }
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  // ═══════════════════════════════════════════════════
  // ADMIN ROUTES
  // ═══════════════════════════════════════════════════

  // GET /api/admin/users — List all users
  app.get("/api/admin/users", requireAdmin, async (req, res) => {
    const allUsers = await storage.getAllUsers();
    res.json({ users: allUsers });
  });

  // PATCH /api/admin/users/:id — Update user role/status
  app.patch("/api/admin/users/:id", requireAdmin, async (req, res) => {
    try {
      const userId = parseInt(String(req.params.id), 10);
      if (isNaN(userId)) return res.status(400).json({ error: "INVALID USER ID" });

      const data = updateUserSchema.parse(req.body);
      const updated = await storage.updateUser(userId, data);
      if (!updated) return res.status(404).json({ error: "USER NOT FOUND" });

      const { password_hash: _, ...safeUser } = updated;
      res.json({ user: safeUser });
    } catch (err: any) {
      if (err.name === "ZodError") {
        return res.status(400).json({ error: "INVALID INPUT DATA" });
      }
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  // DELETE /api/admin/users/:id — Delete user
  app.delete("/api/admin/users/:id", requireAdmin, async (req, res) => {
    const userId = parseInt(String(req.params.id), 10);
    if (isNaN(userId)) return res.status(400).json({ error: "INVALID USER ID" });

    // Prevent self-delete
    if (userId === req.user!.id) {
      return res.status(400).json({ error: "CANNOT DELETE OWN ACCOUNT" });
    }

    const deleted = await storage.deleteUser(userId);
    if (!deleted) return res.status(404).json({ error: "USER NOT FOUND" });

    res.json({ message: "USER ELIMINATED" });
  });

  // ═══════════════════════════════════════════════════
  // PHASE 2 — OLLAMA PROXY ROUTES
  // ═══════════════════════════════════════════════════

  const OLLAMA_BASE = "http://localhost:11434";

  // GET /api/ollama/status — Check if Ollama is reachable
  app.get("/api/ollama/status", requireAuth, async (_req, res) => {
    try {
      const response = await fetch(`${OLLAMA_BASE}/api/version`);
      if (response.ok) {
        const data = await response.json();
        res.json({ online: true, version: data.version || "unknown" });
      } else {
        res.json({ online: false, version: "" });
      }
    } catch {
      res.json({ online: false, version: "" });
    }
  });

  // GET /api/ollama/models — List installed models
  app.get("/api/ollama/models", requireAuth, async (_req, res) => {
    try {
      const response = await fetch(`${OLLAMA_BASE}/api/tags`);
      if (!response.ok) {
        return res.status(502).json({ error: "OLLAMA UNREACHABLE" });
      }
      const data = await response.json();
      const models = (data.models || []).map((m: any) => ({
        name: m.name,
        size: m.size,
        modified_at: m.modified_at,
        details: m.details || {},
      }));
      res.json({ models });
    } catch {
      res.status(502).json({ error: "NEURAL LINK SEVERED — OLLAMA OFFLINE" });
    }
  });

  // POST /api/ollama/pull — Pull a model with SSE progress
  app.post("/api/ollama/pull", requireAuth, async (req, res) => {
    const { model } = req.body;
    if (!model || typeof model !== "string") {
      return res.status(400).json({ error: "MODEL NAME REQUIRED" });
    }

    res.setHeader("Content-Type", "text/event-stream");
    res.setHeader("Cache-Control", "no-cache");
    res.setHeader("Connection", "keep-alive");
    res.flushHeaders();

    try {
      const response = await fetch(`${OLLAMA_BASE}/api/pull`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: model, stream: true }),
      });

      if (!response.ok || !response.body) {
        res.write(`data: {"error":"FAILED TO INITIATE PULL"}\n\n`);
        return res.end();
      }

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split("\n");
        buffer = lines.pop() || "";

        for (const line of lines) {
          if (!line.trim()) continue;
          try {
            const parsed = JSON.parse(line);
            res.write(`data: ${JSON.stringify({
              status: parsed.status || "",
              completed: parsed.completed || 0,
              total: parsed.total || 0,
            })}\n\n`);
          } catch {
            // skip malformed lines
          }
        }
      }

      res.write(`data: {"done":true}\n\n`);
      res.end();
    } catch {
      res.write(`data: {"error":"NEURAL LINK SEVERED — OLLAMA OFFLINE"}\n\n`);
      res.end();
    }
  });

  // DELETE /api/ollama/models/:name — Delete a model
  app.delete("/api/ollama/models/:name", requireAuth, async (req, res) => {
    const modelName = req.params.name;
    try {
      const response = await fetch(`${OLLAMA_BASE}/api/delete`, {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: modelName }),
      });
      if (response.ok) {
        res.json({ message: "MODEL PURGED" });
      } else {
        const err = await response.text();
        res.status(response.status).json({ error: err || "DELETE FAILED" });
      }
    } catch {
      res.status(502).json({ error: "NEURAL LINK SEVERED — OLLAMA OFFLINE" });
    }
  });

  // ═══════════════════════════════════════════════════
  // PHASE 2 — CHAT / STREAMING ROUTE
  // ═══════════════════════════════════════════════════

  const chatStreamSchema = z.object({
    conversationId: z.number(),
    message: z.string().min(1),
    model: z.string().min(1),
    temperature: z.number().min(0).max(2).optional(),
    max_tokens: z.number().min(1).max(65536).optional(),
    top_p: z.number().min(0).max(1).optional(),
  });

  app.post("/api/chat/stream", requireAuth, async (req, res) => {
    try {
      const data = chatStreamSchema.parse(req.body);
      const userId = req.user!.id;

      // Validate ownership
      const conversation = await storage.getConversation(data.conversationId, userId);
      if (!conversation) {
        return res.status(404).json({ error: "CONVERSATION NOT FOUND" });
      }

      // Save user message
      const now = new Date().toISOString();
      await storage.addMessage({
        conversation_id: data.conversationId,
        role: "user",
        content: data.message,
        created_at: now,
      });

      // Update conversation timestamp
      await storage.updateConversation(data.conversationId, userId, { updated_at: now });

      // Build message history
      const dbMessages = await storage.getConversationMessages(data.conversationId);
      const ollamaMessages: { role: string; content: string }[] = [];

      // Add system prompt if exists
      const systemPrompt = conversation.system_prompt;
      if (systemPrompt) {
        ollamaMessages.push({ role: "system", content: systemPrompt });
      }

      for (const msg of dbMessages) {
        if (msg.role === "system") continue; // system prompt handled above
        ollamaMessages.push({ role: msg.role, content: msg.content });
      }

      // Set SSE headers
      res.setHeader("Content-Type", "text/event-stream");
      res.setHeader("Cache-Control", "no-cache");
      res.setHeader("Connection", "keep-alive");
      res.flushHeaders();

      try {
        const ollamaRes = await fetch(`${OLLAMA_BASE}/api/chat`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            model: data.model,
            messages: ollamaMessages,
            stream: true,
            options: {
              temperature: data.temperature ?? 0.7,
              num_predict: data.max_tokens ?? 2048,
              top_p: data.top_p ?? 0.9,
            },
          }),
        });

        if (!ollamaRes.ok || !ollamaRes.body) {
          res.write(`data: {"error":"NEURAL LINK SEVERED — OLLAMA OFFLINE"}\n\n`);
          return res.end();
        }

        const reader = ollamaRes.body.getReader();
        const decoder = new TextDecoder();
        let buffer = "";
        let fullContent = "";

        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          buffer += decoder.decode(value, { stream: true });
          const lines = buffer.split("\n");
          buffer = lines.pop() || "";

          for (const line of lines) {
            if (!line.trim()) continue;
            try {
              const parsed = JSON.parse(line);
              if (parsed.message?.content) {
                const token = parsed.message.content;
                fullContent += token;
                res.write(`data: ${JSON.stringify({ token, done: false })}\n\n`);
              }
              if (parsed.done) {
                // Save assistant message
                const savedMsg = await storage.addMessage({
                  conversation_id: data.conversationId,
                  role: "assistant",
                  content: fullContent,
                  created_at: new Date().toISOString(),
                });
                res.write(`data: ${JSON.stringify({ done: true, messageId: savedMsg.id })}\n\n`);
              }
            } catch {
              // skip malformed
            }
          }
        }

        // If we haven't sent done yet (e.g. buffer remaining)
        if (buffer.trim()) {
          try {
            const parsed = JSON.parse(buffer);
            if (parsed.message?.content) {
              fullContent += parsed.message.content;
              res.write(`data: ${JSON.stringify({ token: parsed.message.content, done: false })}\n\n`);
            }
          } catch {}
        }

        res.end();
      } catch (fetchErr) {
        res.write(`data: {"error":"NEURAL LINK SEVERED — OLLAMA OFFLINE"}\n\n`);
        res.end();
      }
    } catch (err: any) {
      if (err.name === "ZodError") {
        return res.status(400).json({ error: "INVALID INPUT DATA", details: err.errors });
      }
      console.error("Chat stream error:", err);
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  // ═══════════════════════════════════════════════════
  // PHASE 2 — CONVERSATION ROUTES
  // ═══════════════════════════════════════════════════

  const createConversationSchema = z.object({
    title: z.string().optional(),
    model: z.string().min(1),
    system_prompt: z.string().optional(),
  });

  const updateConversationSchema = z.object({
    title: z.string().optional(),
    model: z.string().optional(),
    system_prompt: z.string().optional(),
  });

  // GET /api/conversations — List user's conversations
  app.get("/api/conversations", requireAuth, async (req, res) => {
    const userId = req.user!.id;
    const convs = await storage.getUserConversations(userId);
    res.json({ conversations: convs });
  });

  // POST /api/conversations — Create new conversation
  app.post("/api/conversations", requireAuth, async (req, res) => {
    try {
      const data = createConversationSchema.parse(req.body);
      const now = new Date().toISOString();
      const conv = await storage.createConversation({
        user_id: req.user!.id,
        title: data.title || "NEW CONVERSATION",
        model: data.model,
        system_prompt: data.system_prompt || "",
        created_at: now,
        updated_at: now,
      });
      res.status(201).json(conv);
    } catch (err: any) {
      if (err.name === "ZodError") {
        return res.status(400).json({ error: "INVALID INPUT DATA", details: err.errors });
      }
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  // GET /api/conversations/:id — Get conversation + messages
  app.get("/api/conversations/:id", requireAuth, async (req, res) => {
    const convId = parseInt(String(req.params.id), 10);
    if (isNaN(convId)) return res.status(400).json({ error: "INVALID CONVERSATION ID" });

    const conv = await storage.getConversation(convId, req.user!.id);
    if (!conv) return res.status(404).json({ error: "CONVERSATION NOT FOUND" });

    const msgs = await storage.getConversationMessages(convId);
    res.json({ conversation: conv, messages: msgs });
  });

  // PATCH /api/conversations/:id — Update conversation
  app.patch("/api/conversations/:id", requireAuth, async (req, res) => {
    try {
      const convId = parseInt(String(req.params.id), 10);
      if (isNaN(convId)) return res.status(400).json({ error: "INVALID CONVERSATION ID" });

      const data = updateConversationSchema.parse(req.body);
      const updated = await storage.updateConversation(convId, req.user!.id, {
        ...data,
        updated_at: new Date().toISOString(),
      });
      if (!updated) return res.status(404).json({ error: "CONVERSATION NOT FOUND" });
      res.json(updated);
    } catch (err: any) {
      if (err.name === "ZodError") {
        return res.status(400).json({ error: "INVALID INPUT DATA" });
      }
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  // DELETE /api/conversations/:id — Delete conversation + messages
  app.delete("/api/conversations/:id", requireAuth, async (req, res) => {
    const convId = parseInt(String(req.params.id), 10);
    if (isNaN(convId)) return res.status(400).json({ error: "INVALID CONVERSATION ID" });

    const deleted = await storage.deleteConversation(convId, req.user!.id);
    if (!deleted) return res.status(404).json({ error: "CONVERSATION NOT FOUND" });
    res.json({ message: "CONVERSATION PURGED" });
  });

  // ═══════════════════════════════════════════════════
  // PHASE 2 — MODEL CONFIG ROUTES
  // ═══════════════════════════════════════════════════

  const modelConfigSchema = z.object({
    temperature: z.number().min(0).max(2).optional(),
    max_tokens: z.number().min(256).max(65536).optional(),
    top_p: z.number().min(0).max(1).optional(),
    system_prompt: z.string().optional(),
  });

  // GET /api/model-configs/:modelName
  app.get("/api/model-configs/:modelName", requireAuth, async (req, res) => {
    const config = await storage.getModelConfig(req.user!.id, String(req.params.modelName));
    res.json(config || { temperature: 0.7, max_tokens: 2048, top_p: 0.9, system_prompt: "" });
  });

  // PUT /api/model-configs/:modelName
  app.put("/api/model-configs/:modelName", requireAuth, async (req, res) => {
    try {
      const data = modelConfigSchema.parse(req.body);
      const config = await storage.upsertModelConfig(req.user!.id, String(req.params.modelName), data);
      res.json(config);
    } catch (err: any) {
      if (err.name === "ZodError") {
        return res.status(400).json({ error: "INVALID INPUT DATA", details: err.errors });
      }
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  return httpServer;
}
