import type { Request, Response, NextFunction } from "express";
import jwt from "jsonwebtoken";
import { storage } from "../storage";
import type { SafeUser } from "@shared/schema";

const JWT_SECRET = process.env.JWT_SECRET || "trident-dev-secret-change-in-production";

// Extend Express Request to carry the authenticated user
declare global {
  namespace Express {
    interface Request {
      user?: SafeUser;
    }
  }
}

export function generateToken(userId: number, role: string): string {
  return jwt.sign({ userId, role }, JWT_SECRET, { expiresIn: "24h" });
}

export function verifyToken(token: string): { userId: number; role: string } | null {
  try {
    const decoded = jwt.verify(token, JWT_SECRET) as { userId: number; role: string };
    return decoded;
  } catch {
    return null;
  }
}

// Middleware: require valid JWT
export async function requireAuth(req: Request, res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization;
  const token = authHeader?.startsWith("Bearer ") ? authHeader.slice(7) : null;

  if (!token) {
    return res.status(401).json({ error: "AUTHENTICATION REQUIRED" });
  }

  const decoded = verifyToken(token);
  if (!decoded) {
    return res.status(401).json({ error: "INVALID OR EXPIRED TOKEN" });
  }

  const user = await storage.getUser(decoded.userId);
  if (!user || !user.is_active) {
    return res.status(401).json({ error: "USER NOT FOUND OR DEACTIVATED" });
  }

  // Attach safe user (no password hash) to request
  const { password_hash, ...safeUser } = user;
  req.user = safeUser;
  next();
}

// Middleware: require admin role
export async function requireAdmin(req: Request, res: Response, next: NextFunction) {
  await requireAuth(req, res, () => {
    if (req.user?.role !== "admin") {
      return res.status(403).json({ error: "INSUFFICIENT CLEARANCE — ADMIN ACCESS REQUIRED" });
    }
    next();
  });
}
