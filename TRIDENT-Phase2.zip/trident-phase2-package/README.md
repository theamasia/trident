# TRIDENT — TACTICAL NEURAL INTERFACE SYSTEM

A local-network AI platform for homelab environments. TRIDENT provides a military command-terminal styled web interface for managing AI models, chat, image generation, voice synthesis, and more.

**Phase 1** includes authentication, user management, and the core application shell. AI features arrive in Phase 2.

## Screenshots

The UI fuses aesthetics from **Tron** (1982), **Hackers** (1995), and **Starship Troopers** (1997) — electric cyan accents, terminal green text, amber military HUD elements, scanline overlays, and monospace fonts throughout.

## Tech Stack

- **Frontend:** React 18 + TypeScript + Tailwind CSS + shadcn/ui
- **Backend:** Express.js + better-sqlite3 + Drizzle ORM
- **Auth:** JWT (jsonwebtoken) + bcryptjs
- **Routing:** wouter (hash-based)
- **State:** Zustand + TanStack Query

## Quick Start (Development)

```bash
# 1. Clone the repo
git clone <your-repo-url> trident
cd trident

# 2. Run the dev setup script
./scripts/dev-setup.sh

# 3. Seed an admin user
./scripts/db-seed-admin.sh

# 4. Start the dev server
npm run dev

# 5. Open http://localhost:5000
# Login with: admin@trident.local / TridentAdmin1!
```

Or manually:

```bash
npm install
cp .env.example .env   # Edit .env as needed
npm run dev
```

## Default Credentials

| Field    | Value                |
|----------|----------------------|
| Email    | admin@trident.local  |
| Password | TridentAdmin1!       |

**Change these immediately in production.**

## Project Structure

```
trident/
├── client/                  # React frontend (Vite)
│   ├── src/
│   │   ├── components/      # Shared components (DashboardLayout, TridentLogo, etc.)
│   │   ├── hooks/           # Custom hooks (useAuth, useToast, etc.)
│   │   ├── lib/             # Utilities (queryClient)
│   │   ├── pages/           # Page components
│   │   ├── index.css        # TRIDENT theme + custom CSS
│   │   ├── App.tsx          # Router + auth wrapper
│   │   └── main.tsx         # Entry point
│   └── index.html           # HTML shell with Google Fonts
├── server/                  # Express backend
│   ├── middleware/
│   │   └── auth.ts          # JWT auth + role middleware
│   ├── routes.ts            # API endpoints
│   ├── storage.ts           # Database layer (Drizzle ORM)
│   └── index.ts             # Server entry point
├── shared/
│   └── schema.ts            # Database schema + Zod types
├── scripts/                 # Operations scripts
│   ├── setup.sh             # Production server setup
│   ├── dev-setup.sh         # Local development setup
│   ├── db-migrate.sh        # Run database migrations
│   ├── db-seed-admin.sh     # Seed/update admin user
│   └── update.sh            # Production update + restart
├── .env.example             # Environment variable template
├── README.md                # This file
├── package.json
├── tailwind.config.ts
└── tsconfig.json
```

## Scripts

### `scripts/dev-setup.sh`

One-time local development setup. Checks Node.js 20+, runs `npm install`, creates `.env` from `.env.example` if missing.

```bash
./scripts/dev-setup.sh
```

### `scripts/db-seed-admin.sh`

Creates or updates an admin user in the database. Accepts optional `--email` and `--password` flags.

```bash
# Use defaults (admin@trident.local / TridentAdmin1!)
./scripts/db-seed-admin.sh

# Custom credentials
./scripts/db-seed-admin.sh --email ops@mylab.net --password 'S3cur3P@ss!'
```

### `scripts/db-migrate.sh`

Runs Drizzle Kit push to sync schema changes to the database. Sources config from `/etc/trident/config.env` (production) or `.env` (development).

```bash
./scripts/db-migrate.sh
```

### `scripts/setup.sh` (Production)

Full production setup for Ubuntu 24.04. Run as the `trident` system user from `/opt/trident`. Requires:
- Node.js 20+
- PostgreSQL (via `DATABASE_URL` in `/etc/trident/config.env`)

```bash
# As root, create the config first:
sudo mkdir -p /etc/trident
sudo cp .env.example /etc/trident/config.env
sudo nano /etc/trident/config.env

# Then run setup as the trident user:
sudo -u trident ./scripts/setup.sh
```

This script:
1. Validates Node.js and PostgreSQL
2. Installs production dependencies
3. Builds the application
4. Runs database migrations
5. Seeds the admin user
6. Prints startup instructions

### `scripts/update.sh` (Production)

Updates a running production deployment:

```bash
sudo -u trident ./scripts/update.sh
```

This script:
1. Pulls latest code (if git-managed)
2. Installs dependencies
3. Rebuilds the application
4. Runs migrations
5. Restarts the systemd service
6. Prints service status

## Systemd Service (Production)

Create `/etc/systemd/system/trident.service`:

```ini
[Unit]
Description=TRIDENT Tactical Neural Interface System
After=network.target postgresql.service

[Service]
Type=simple
User=trident
WorkingDirectory=/opt/trident
EnvironmentFile=/etc/trident/config.env
ExecStart=/usr/bin/node dist/index.cjs
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl daemon-reload
sudo systemctl enable trident
sudo systemctl start trident
```

## API Endpoints

### Authentication
| Method | Path                  | Description             | Auth    |
|--------|-----------------------|-------------------------|---------|
| POST   | `/api/auth/register`  | Create new user         | None    |
| POST   | `/api/auth/login`     | Login, get JWT          | None    |
| POST   | `/api/auth/logout`    | Terminate session       | JWT     |
| GET    | `/api/auth/me`        | Get current user        | JWT     |
| PATCH  | `/api/auth/settings`  | Update profile/password | JWT     |

### Admin
| Method | Path                     | Description           | Auth       |
|--------|--------------------------|-----------------------|------------|
| GET    | `/api/admin/users`       | List all users        | Admin JWT  |
| PATCH  | `/api/admin/users/:id`   | Update user role/status | Admin JWT |
| DELETE | `/api/admin/users/:id`   | Delete user           | Admin JWT  |

## Environment Variables

| Variable        | Required | Default              | Description                    |
|-----------------|----------|----------------------|--------------------------------|
| `JWT_SECRET`    | Yes      | dev-only fallback    | JWT signing secret             |
| `PORT`          | No       | 5000                 | Server port                    |
| `NODE_ENV`      | No       | development          | Environment mode               |
| `DATABASE_URL`  | Prod     | —                    | PostgreSQL connection string   |
| `ADMIN_EMAIL`   | No       | admin@trident.local  | Initial admin email            |
| `ADMIN_PASSWORD`| No       | TridentAdmin1!       | Initial admin password         |

## Phase 1 Features

- [x] User authentication (register, login, logout, JWT)
- [x] Role-based access control (admin, power_user, user)
- [x] Admin user management (list, update role, toggle active, delete)
- [x] User settings (change username, email, password)
- [x] Military command-terminal UI aesthetic
- [x] Collapsible sidebar navigation
- [x] Live system clock
- [x] CRT/scanline visual effects
- [x] Responsive layout

## Phase 2 (Planned)

- [ ] Chat interface (Ollama / OpenAI integration)
- [ ] Model registry and management
- [ ] Image generation (Stable Diffusion / DALL-E)
- [ ] Voice synthesis and transcription
- [ ] Media gallery
- [ ] WebSocket real-time updates

## License

Private — All rights reserved.
