import { Image, Mic, GalleryHorizontalEnd } from "lucide-react";

interface StubPageProps {
  title: string;
  icon: "image" | "voice" | "gallery";
  systemName: string;
}

const icons = {
  image: Image,
  voice: Mic,
  gallery: GalleryHorizontalEnd,
};

export default function DashboardStub({ title, icon, systemName }: StubPageProps) {
  const Icon = icons[icon];
  
  return (
    <div className="h-full flex flex-col">
      <div className="trident-panel p-4 mb-4">
        <h1 className="font-display text-sm tracking-[0.15em] text-trident-amber text-glow-amber flex items-center gap-2">
          <Icon className="w-4 h-4" />
          {title}
        </h1>
      </div>

      <div className="trident-panel flex-1 flex items-center justify-center">
        <div className="text-center space-y-4">
          <Icon className="w-12 h-12 mx-auto text-trident-cyan/20" />
          <div className="font-mono text-xs space-y-1">
            <p className="text-trident-cyan/60">
              &gt;&gt; {systemName} — INITIALIZING
            </p>
            <p className="text-trident-amber/60">
              &gt;&gt; MODULE PENDING — PHASE 2 DEPLOYMENT
            </p>
          </div>
          <div className="flex items-center justify-center gap-1.5 mt-4">
            {[0, 1, 2].map((i) => (
              <span
                key={i}
                className="inline-block w-1.5 h-1.5 rounded-full bg-trident-cyan pulse-dot"
                style={{ animationDelay: `${i * 0.3}s` }}
              />
            ))}
            <span className="text-[10px] font-mono uppercase tracking-widest text-trident-text/30 ml-2">
              PROCESSING
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
