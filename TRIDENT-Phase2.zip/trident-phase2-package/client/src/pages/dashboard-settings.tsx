import { useState } from "react";
import { Settings, Save, AlertTriangle } from "lucide-react";
import { useAuth, getAuthHeaders } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

export default function DashboardSettings() {
  const { user, setUser } = useAuth();
  const { toast } = useToast();
  
  const [username, setUsername] = useState(user?.username || "");
  const [email, setEmail] = useState(user?.email || "");
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmNewPassword, setConfirmNewPassword] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      const data: any = {};
      if (username !== user?.username) data.username = username;
      if (email !== user?.email) data.email = email;
      
      if (Object.keys(data).length === 0) {
        toast({
          title: ">> INFO",
          description: "NO CHANGES DETECTED",
          className: "border-trident-border bg-trident-surface text-trident-cyan",
        });
        setIsSubmitting(false);
        return;
      }

      const res = await fetch("/api/auth/settings", {
        method: "PATCH",
        headers: { "Content-Type": "application/json", ...getAuthHeaders() },
        body: JSON.stringify(data),
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || "FAILED");
      }
      const result = await res.json();
      setUser(result.user);
      toast({
        title: ">> PROFILE UPDATED",
        description: "SETTINGS SAVED SUCCESSFULLY",
        className: "terminal-text border-trident-border bg-trident-surface",
      });
    } catch (err: any) {
      toast({
        title: ">> ERROR",
        description: err.message || "UPDATE FAILED",
        variant: "destructive",
        className: "border-[#ff2244] bg-trident-surface text-[#ff2244]",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (newPassword !== confirmNewPassword) {
      toast({
        title: ">> ERROR",
        description: "PASSWORDS DO NOT MATCH",
        variant: "destructive",
        className: "border-[#ff2244] bg-trident-surface text-[#ff2244]",
      });
      return;
    }
    setIsSubmitting(true);
    try {
      const res = await fetch("/api/auth/settings", {
        method: "PATCH",
        headers: { "Content-Type": "application/json", ...getAuthHeaders() },
        body: JSON.stringify({
          current_password: currentPassword,
          new_password: newPassword,
        }),
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || "FAILED");
      }
      setCurrentPassword("");
      setNewPassword("");
      setConfirmNewPassword("");
      toast({
        title: ">> PASSWORD UPDATED",
        description: "SECURITY CREDENTIALS MODIFIED",
        className: "terminal-text border-trident-border bg-trident-surface",
      });
    } catch (err: any) {
      toast({
        title: ">> ERROR",
        description: err.message || "PASSWORD UPDATE FAILED",
        variant: "destructive",
        className: "border-[#ff2244] bg-trident-surface text-[#ff2244]",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="h-full flex flex-col">
      <div className="trident-panel p-4 mb-4">
        <h1 className="font-display text-sm tracking-[0.15em] text-trident-amber text-glow-amber flex items-center gap-2">
          <Settings className="w-4 h-4" />
          USER SETTINGS
        </h1>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Profile Settings */}
        <form onSubmit={handleSaveProfile} className="trident-panel p-5 space-y-4">
          <h2 className="font-display text-xs tracking-[0.12em] text-trident-cyan border-b border-trident-border pb-2">
            PROFILE DATA
          </h2>

          <div className="space-y-1">
            <label className="block text-[10px] font-mono uppercase tracking-widest text-trident-cyan/70">
              USERNAME
            </label>
            <input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="trident-input w-full px-3 py-2 text-sm"
              data-testid="input-settings-username"
            />
          </div>

          <div className="space-y-1">
            <label className="block text-[10px] font-mono uppercase tracking-widest text-trident-cyan/70">
              EMAIL
            </label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="trident-input w-full px-3 py-2 text-sm"
              data-testid="input-settings-email"
            />
          </div>

          <div className="flex items-center gap-2 pt-1 text-[10px] font-mono text-trident-text/40">
            <span>ROLE: <span className="text-trident-amber">{user?.role?.toUpperCase()}</span></span>
            <span className="text-trident-border">|</span>
            <span>ID: <span className="text-trident-cyan">{user?.id}</span></span>
          </div>

          <button
            type="submit"
            disabled={isSubmitting}
            className="trident-btn trident-btn-primary px-6 py-2 text-xs flex items-center gap-2 disabled:opacity-50"
            data-testid="button-save-profile"
          >
            <Save className="w-3.5 h-3.5" />
            SAVE PROFILE
          </button>
        </form>

        {/* Password Change */}
        <form onSubmit={handleChangePassword} className="trident-panel p-5 space-y-4">
          <h2 className="font-display text-xs tracking-[0.12em] text-trident-cyan border-b border-trident-border pb-2 flex items-center gap-2">
            <AlertTriangle className="w-3.5 h-3.5 text-trident-amber" />
            SECURITY CREDENTIALS
          </h2>

          <div className="space-y-1">
            <label className="block text-[10px] font-mono uppercase tracking-widest text-trident-cyan/70">
              CURRENT PASSWORD
            </label>
            <input
              type="password"
              value={currentPassword}
              onChange={(e) => setCurrentPassword(e.target.value)}
              className="trident-input w-full px-3 py-2 text-sm"
              style={{ textTransform: "none" }}
              data-testid="input-current-password"
            />
          </div>

          <div className="space-y-1">
            <label className="block text-[10px] font-mono uppercase tracking-widest text-trident-cyan/70">
              NEW PASSWORD
            </label>
            <input
              type="password"
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
              className="trident-input w-full px-3 py-2 text-sm"
              style={{ textTransform: "none" }}
              data-testid="input-new-password"
            />
          </div>

          <div className="space-y-1">
            <label className="block text-[10px] font-mono uppercase tracking-widest text-trident-cyan/70">
              CONFIRM NEW PASSWORD
            </label>
            <input
              type="password"
              value={confirmNewPassword}
              onChange={(e) => setConfirmNewPassword(e.target.value)}
              className="trident-input w-full px-3 py-2 text-sm"
              style={{ textTransform: "none" }}
              data-testid="input-confirm-new-password"
            />
          </div>

          <button
            type="submit"
            disabled={isSubmitting}
            className="trident-btn trident-btn-secondary px-6 py-2 text-xs flex items-center gap-2 disabled:opacity-50"
            data-testid="button-change-password"
          >
            <Save className="w-3.5 h-3.5" />
            UPDATE PASSWORD
          </button>
        </form>
      </div>
    </div>
  );
}
