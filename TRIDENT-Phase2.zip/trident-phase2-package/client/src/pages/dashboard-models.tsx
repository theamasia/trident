import { useState, useEffect, useCallback, useRef } from "react";
import {
  Box,
  Server,
  HardDrive,
  Trash2,
  Download,
  RefreshCw,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  Search,
  Loader2,
  Cpu,
} from "lucide-react";
import { getAuthHeaders } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";

const API_BASE = "__PORT_5000__".startsWith("__") ? "" : "__PORT_5000__";

// ═══════════════════════════════════════════════════
// TYPES
// ═══════════════════════════════════════════════════
interface OllamaModel {
  name: string;
  size: number;
  modified_at: string;
  details: Record<string, unknown>;
}

interface PullProgress {
  status: string;
  completed: number;
  total: number;
  done?: boolean;
  error?: string;
}

// ═══════════════════════════════════════════════════
// CURATED MODELS
// ═══════════════════════════════════════════════════
const CURATED_MODELS = [
  { name: "llama3.2", params: "3B", description: "META'S LLAMA 3.2 — FAST, EFFICIENT GENERAL PURPOSE" },
  { name: "llama3.2:1b", params: "1B", description: "ULTRA-LIGHTWEIGHT — MINIMAL RESOURCE USAGE" },
  { name: "llama3.1:8b", params: "8B", description: "LLAMA 3.1 8B — BALANCED PERFORMANCE" },
  { name: "mistral", params: "7B", description: "MISTRAL 7B — STRONG REASONING, CODE" },
  { name: "mistral-nemo", params: "12B", description: "MISTRAL NEMO 12B — ADVANCED REASONING" },
  { name: "codellama", params: "7B", description: "CODE LLAMA — SPECIALIZED FOR CODE GENERATION" },
  { name: "codellama:13b", params: "13B", description: "CODE LLAMA 13B — ENHANCED CODE MODEL" },
  { name: "deepseek-coder", params: "6.7B", description: "DEEPSEEK CODER — ELITE CODE ASSISTANT" },
  { name: "phi3", params: "3.8B", description: "MICROSOFT PHI-3 MINI — EFFICIENT SMALL MODEL" },
  { name: "phi3:medium", params: "14B", description: "MICROSOFT PHI-3 MEDIUM — ENHANCED CAPABILITY" },
  { name: "gemma2", params: "9B", description: "GOOGLE GEMMA 2 — STRONG GENERAL MODEL" },
  { name: "gemma2:27b", params: "27B", description: "GOOGLE GEMMA 2 27B — HIGH CAPABILITY" },
  { name: "qwen2.5", params: "7B", description: "ALIBABA QWEN 2.5 — MULTILINGUAL" },
  { name: "llava", params: "7B", description: "LLAVA — VISION + LANGUAGE MODEL" },
  { name: "nomic-embed-text", params: "137M", description: "NOMIC EMBED — TEXT EMBEDDINGS" },
];

// ═══════════════════════════════════════════════════
// HELPERS
// ═══════════════════════════════════════════════════
function formatSize(bytes: number): string {
  if (!bytes) return "—";
  const gb = bytes / (1024 * 1024 * 1024);
  if (gb >= 1) return `${gb.toFixed(1)} GB`;
  const mb = bytes / (1024 * 1024);
  return `${mb.toFixed(0)} MB`;
}

function formatDate(iso: string): string {
  try {
    return new Date(iso).toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
    });
  } catch {
    return "—";
  }
}

function formatBytes(bytes: number): string {
  if (!bytes) return "";
  const mb = bytes / (1024 * 1024);
  if (mb >= 1024) return `${(mb / 1024).toFixed(1)} GB`;
  return `${mb.toFixed(0)} MB`;
}

// ═══════════════════════════════════════════════════
// PROGRESS BAR COMPONENT
// ═══════════════════════════════════════════════════
function TerminalProgress({ progress }: { progress: PullProgress }) {
  const pct = progress.total > 0 ? Math.round((progress.completed / progress.total) * 100) : 0;
  const filled = Math.round(pct / 5);
  const empty = 20 - filled;
  const bar = "█".repeat(filled) + "░".repeat(empty);
  const downloaded = formatBytes(progress.completed);
  const total = formatBytes(progress.total);

  return (
    <div className="font-mono text-[10px] space-y-1">
      <div className="flex items-center gap-2">
        <span className="text-trident-cyan">[{bar}]</span>
        <span className="text-trident-cyan tabular-nums">{pct}%</span>
      </div>
      <div className="flex items-center gap-3 text-trident-text/40">
        <span>{progress.status?.toUpperCase() || "DOWNLOADING..."}</span>
        {progress.total > 0 && <span>{downloaded} / {total}</span>}
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════
// MAIN COMPONENT
// ═══════════════════════════════════════════════════
export default function DashboardModels() {
  const { toast } = useToast();
  const authHeaders = getAuthHeaders();

  const [models, setModels] = useState<OllamaModel[]>([]);
  const [ollamaOnline, setOllamaOnline] = useState<boolean | null>(null);
  const [ollamaVersion, setOllamaVersion] = useState("");
  const [loadingModels, setLoadingModels] = useState(true);
  const [search, setSearch] = useState("");
  const [customModel, setCustomModel] = useState("");
  const [pullingModels, setPullingModels] = useState<Record<string, PullProgress>>({});
  const [deletingModel, setDeletingModel] = useState<string | null>(null);
  const [confirmDelete, setConfirmDelete] = useState<string | null>(null);

  // Check status
  const checkStatus = useCallback(async () => {
    try {
      const res = await fetch(`${API_BASE}/api/ollama/status`, { headers: authHeaders });
      if (res.ok) {
        const data = await res.json();
        setOllamaOnline(data.online);
        setOllamaVersion(data.version || "");
      } else {
        setOllamaOnline(false);
      }
    } catch {
      setOllamaOnline(false);
    }
  }, []);

  // Load models
  const loadModels = useCallback(async () => {
    setLoadingModels(true);
    try {
      const res = await fetch(`${API_BASE}/api/ollama/models`, { headers: authHeaders });
      if (res.ok) {
        const data = await res.json();
        setModels(data.models || []);
      }
    } catch {
      // silent
    } finally {
      setLoadingModels(false);
    }
  }, []);

  useEffect(() => {
    checkStatus();
    loadModels();
  }, []);

  // Delete model
  const handleDelete = async (name: string) => {
    setDeletingModel(name);
    setConfirmDelete(null);
    try {
      const res = await fetch(`${API_BASE}/api/ollama/models/${encodeURIComponent(name)}`, {
        method: "DELETE",
        headers: authHeaders,
      });
      if (res.ok) {
        toast({ title: "PURGED", description: `MODEL ${name.toUpperCase()} ELIMINATED` });
        loadModels();
      } else {
        toast({ title: "ERROR", description: "FAILED TO DELETE MODEL", variant: "destructive" });
      }
    } catch {
      toast({ title: "ERROR", description: "NEURAL LINK SEVERED", variant: "destructive" });
    } finally {
      setDeletingModel(null);
    }
  };

  // Pull model via SSE
  const pullModel = async (name: string) => {
    if (pullingModels[name]) return;

    setPullingModels((prev) => ({
      ...prev,
      [name]: { status: "INITIATING...", completed: 0, total: 0 },
    }));

    try {
      const res = await fetch(`${API_BASE}/api/ollama/pull`, {
        method: "POST",
        headers: { ...authHeaders, "Content-Type": "application/json" },
        body: JSON.stringify({ model: name }),
      });

      if (!res.ok || !res.body) {
        setPullingModels((prev) => {
          const next = { ...prev };
          delete next[name];
          return next;
        });
        toast({ title: "ERROR", description: "FAILED TO INITIATE PULL", variant: "destructive" });
        return;
      }

      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split("\n");
        buffer = lines.pop() || "";

        for (const line of lines) {
          if (!line.startsWith("data: ")) continue;
          try {
            const parsed = JSON.parse(line.slice(6));
            if (parsed.error) {
              toast({ title: "ERROR", description: parsed.error, variant: "destructive" });
              break;
            }
            if (parsed.done) {
              toast({ title: "COMPLETE", description: `MODEL ${name.toUpperCase()} DOWNLOADED` });
              loadModels();
            } else {
              setPullingModels((prev) => ({
                ...prev,
                [name]: {
                  status: parsed.status || "",
                  completed: parsed.completed || 0,
                  total: parsed.total || 0,
                },
              }));
            }
          } catch {}
        }
      }
    } catch {
      toast({ title: "ERROR", description: "PULL FAILED — NEURAL LINK SEVERED", variant: "destructive" });
    } finally {
      setPullingModels((prev) => {
        const next = { ...prev };
        delete next[name];
        return next;
      });
    }
  };

  const installedNames = new Set(models.map((m) => m.name));
  const filteredCurated = CURATED_MODELS.filter(
    (m) =>
      m.name.toLowerCase().includes(search.toLowerCase()) ||
      m.description.toLowerCase().includes(search.toLowerCase())
  );

  // ═══════════════════════════════════════════════════
  // RENDER
  // ═══════════════════════════════════════════════════
  return (
    <div className="h-full flex flex-col" data-testid="models-layout">
      {/* Header */}
      <div className="trident-panel p-4 mb-4 flex items-center justify-between">
        <h1 className="font-display text-sm tracking-[0.15em] text-trident-amber text-glow-amber flex items-center gap-2">
          <Box className="w-4 h-4" />
          MODEL REGISTRY
        </h1>
        <div className="flex items-center gap-4">
          {/* Status indicator */}
          <div className="flex items-center gap-2 font-mono text-[10px] uppercase tracking-widest">
            <span className="text-trident-text/40">OLLAMA:</span>
            {ollamaOnline === null ? (
              <span className="text-trident-text/30 flex items-center gap-1">
                <Loader2 className="w-3 h-3 animate-spin" /> CHECKING...
              </span>
            ) : ollamaOnline ? (
              <span className="text-trident-green text-glow-green flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3" />
                ONLINE {ollamaVersion && `v${ollamaVersion}`}
              </span>
            ) : (
              <span className="text-trident-red flex items-center gap-1">
                <XCircle className="w-3 h-3" />
                OFFLINE
              </span>
            )}
          </div>
          <button
            onClick={() => {
              checkStatus();
              loadModels();
            }}
            className="p-1.5 text-trident-cyan/50 hover:text-trident-cyan border border-trident-border hover:border-trident-cyan/50 transition-all"
            data-testid="button-refresh-models"
          >
            <RefreshCw className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto space-y-4">
        {/* ═══════════ INSTALLED MODELS ═══════════ */}
        <div className="trident-panel p-4">
          <h2 className="font-display text-[10px] tracking-[0.15em] text-trident-cyan text-glow-cyan uppercase mb-4 flex items-center gap-2">
            <Server className="w-3.5 h-3.5" />
            INSTALLED MODELS
          </h2>

          {loadingModels ? (
            <div className="flex items-center gap-2 py-6 justify-center">
              <Loader2 className="w-4 h-4 animate-spin text-trident-cyan" />
              <span className="font-mono text-[10px] uppercase tracking-widest text-trident-text/40">
                SCANNING NEURAL REGISTRY...
              </span>
            </div>
          ) : models.length === 0 ? (
            <div className="py-6 text-center">
              <AlertTriangle className="w-5 h-5 text-trident-amber/40 mx-auto mb-2" />
              <p className="font-mono text-[10px] uppercase tracking-widest text-trident-amber/50">
                NO MODELS LOADED — PULL FROM REGISTRY BELOW
              </p>
            </div>
          ) : (
            <div className="space-y-2">
              {models.map((model) => (
                <div
                  key={model.name}
                  className="flex items-center justify-between px-4 py-3 border border-trident-border/50 hover:border-trident-cyan/20 transition-all"
                  style={{ backgroundColor: "#050a0e80" }}
                  data-testid={`installed-model-${model.name}`}
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <Cpu className="w-4 h-4 text-trident-cyan flex-shrink-0" />
                    <div className="min-w-0">
                      <p className="font-mono text-xs uppercase tracking-wider text-trident-text truncate">
                        {model.name}
                      </p>
                      <p className="font-mono text-[9px] text-trident-text/30 uppercase tracking-widest">
                        {(model.details as any)?.parameter_size || ""} {(model.details as any)?.quantization_level || ""}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4 flex-shrink-0">
                    <span className="font-mono text-[10px] text-trident-text/40 flex items-center gap-1">
                      <HardDrive className="w-3 h-3" />
                      {formatSize(model.size)}
                    </span>
                    <span className="font-mono text-[10px] text-trident-text/30">
                      {formatDate(model.modified_at)}
                    </span>
                    {confirmDelete === model.name ? (
                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => handleDelete(model.name)}
                          className="px-2 py-1 text-[9px] font-mono uppercase tracking-widest bg-trident-red text-white hover:bg-trident-red/80 transition-all"
                          data-testid={`button-confirm-delete-${model.name}`}
                        >
                          CONFIRM
                        </button>
                        <button
                          onClick={() => setConfirmDelete(null)}
                          className="px-2 py-1 text-[9px] font-mono uppercase tracking-widest border border-trident-border text-trident-text/50 hover:text-trident-text transition-all"
                        >
                          CANCEL
                        </button>
                      </div>
                    ) : (
                      <button
                        onClick={() => setConfirmDelete(model.name)}
                        disabled={deletingModel === model.name}
                        className="px-2 py-1 text-[9px] font-mono uppercase tracking-widest border border-trident-red/30 text-trident-red/60 hover:text-trident-red hover:border-trident-red transition-all disabled:opacity-30"
                        data-testid={`button-delete-model-${model.name}`}
                      >
                        {deletingModel === model.name ? (
                          <Loader2 className="w-3 h-3 animate-spin" />
                        ) : (
                          <span className="flex items-center gap-1">
                            <Trash2 className="w-3 h-3" /> DELETE
                          </span>
                        )}
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* ═══════════ PULL FROM REGISTRY ═══════════ */}
        <div className="trident-panel p-4">
          <h2 className="font-display text-[10px] tracking-[0.15em] text-trident-cyan text-glow-cyan uppercase mb-4 flex items-center gap-2">
            <Download className="w-3.5 h-3.5" />
            PULL FROM REGISTRY
          </h2>

          {/* Search */}
          <div className="relative mb-4">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-trident-text/30" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="SEARCH MODEL DESIGNATION..."
              className="w-full font-mono text-xs bg-[#050a0e] border border-trident-border text-trident-text uppercase px-3 py-2.5 pl-9 placeholder:text-trident-text/20 focus:border-trident-cyan focus:outline-none transition-all"
              data-testid="input-search-models"
            />
          </div>

          {/* Curated list */}
          <div className="space-y-2 mb-4">
            {filteredCurated.map((model) => {
              const isInstalled = installedNames.has(model.name);
              const isPulling = !!pullingModels[model.name];
              const progress = pullingModels[model.name];

              return (
                <div
                  key={model.name}
                  className="px-4 py-3 border border-trident-border/50 hover:border-trident-cyan/20 transition-all"
                  style={{ backgroundColor: "#050a0e80" }}
                  data-testid={`registry-model-${model.name}`}
                >
                  <div className="flex items-center justify-between">
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2">
                        <p className="font-mono text-xs uppercase tracking-wider text-trident-text">
                          {model.name}
                        </p>
                        <span className="px-1.5 py-0.5 text-[8px] font-mono uppercase tracking-widest border border-trident-text/20 text-trident-text/40">
                          {model.params}
                        </span>
                        {isInstalled && (
                          <span className="px-1.5 py-0.5 text-[8px] font-mono uppercase tracking-widest border border-trident-green/30 text-trident-green/60">
                            INSTALLED
                          </span>
                        )}
                      </div>
                      <p className="font-mono text-[10px] text-trident-text/40 mt-1">{model.description}</p>
                    </div>
                    <div className="flex-shrink-0 ml-4">
                      {isPulling ? (
                        <span className="px-3 py-1.5 text-[9px] font-mono uppercase tracking-widest border border-trident-cyan/30 text-trident-cyan/50 inline-flex items-center gap-1">
                          <Loader2 className="w-3 h-3 animate-spin" />
                          PULLING...
                        </span>
                      ) : isInstalled ? (
                        <span className="px-3 py-1.5 text-[9px] font-mono uppercase tracking-widest text-trident-green/40">
                          ✓ LOADED
                        </span>
                      ) : (
                        <button
                          onClick={() => pullModel(model.name)}
                          className="px-3 py-1.5 text-[9px] font-mono uppercase tracking-widest border border-trident-cyan text-trident-cyan hover:bg-trident-cyan/10 transition-all glow-cyan-hover"
                          data-testid={`button-pull-${model.name}`}
                        >
                          PULL
                        </button>
                      )}
                    </div>
                  </div>
                  {isPulling && progress && (
                    <div className="mt-3 pl-0">
                      <TerminalProgress progress={progress} />
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {/* Custom model */}
          <div className="border-t border-trident-border pt-4">
            <label className="block font-mono text-[9px] uppercase tracking-widest text-trident-text/40 mb-2">
              CUSTOM MODEL DESIGNATION
            </label>
            <div className="flex items-center gap-2">
              <input
                type="text"
                value={customModel}
                onChange={(e) => setCustomModel(e.target.value)}
                placeholder="e.g. codellama:34b"
                className="flex-1 font-mono text-xs bg-[#050a0e] border border-trident-border text-trident-text px-3 py-2.5 placeholder:text-trident-text/20 focus:border-trident-cyan focus:outline-none transition-all"
                data-testid="input-custom-model"
              />
              <button
                onClick={() => {
                  if (customModel.trim()) {
                    pullModel(customModel.trim());
                    setCustomModel("");
                  }
                }}
                disabled={!customModel.trim() || !!pullingModels[customModel.trim()]}
                className="px-4 py-2.5 text-[10px] font-display uppercase tracking-widest bg-trident-amber text-black hover:bg-[#ff8533] disabled:opacity-30 disabled:cursor-not-allowed transition-all glow-amber-hover"
                data-testid="button-pull-custom"
              >
                PULL
              </button>
            </div>
            {pullingModels[customModel] && (
              <div className="mt-3">
                <TerminalProgress progress={pullingModels[customModel]} />
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

