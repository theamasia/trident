import { useState, useEffect } from "react";
import { Users, Shield, Trash2, ToggleLeft, ToggleRight, ChevronDown } from "lucide-react";
import { useAuth, getAuthHeaders } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import type { SafeUser } from "@shared/schema";

export default function AdminUsersPage() {
  const { user: currentUser } = useAuth();
  const { toast } = useToast();
  const [users, setUsers] = useState<SafeUser[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [deleteConfirm, setDeleteConfirm] = useState<number | null>(null);

  const fetchUsers = async () => {
    try {
      const res = await fetch("/api/admin/users", {
        headers: getAuthHeaders(),
      });
      if (!res.ok) throw new Error("FAILED TO LOAD");
      const data = await res.json();
      setUsers(data.users);
    } catch (err) {
      toast({
        title: ">> ERROR",
        description: "FAILED TO LOAD PERSONNEL DATABASE",
        variant: "destructive",
        className: "border-[#ff2244] bg-trident-surface text-[#ff2244]",
      });
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  const handleRoleChange = async (userId: number, newRole: string) => {
    try {
      const res = await fetch(`/api/admin/users/${userId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json", ...getAuthHeaders() },
        body: JSON.stringify({ role: newRole }),
      });
      if (!res.ok) throw new Error("FAILED");
      await fetchUsers();
      toast({
        title: ">> ROLE UPDATED",
        description: `CLEARANCE LEVEL MODIFIED`,
        className: "terminal-text border-trident-border bg-trident-surface",
      });
    } catch {
      toast({
        title: ">> ERROR",
        description: "ROLE UPDATE FAILED",
        variant: "destructive",
        className: "border-[#ff2244] bg-trident-surface text-[#ff2244]",
      });
    }
  };

  const handleToggleActive = async (userId: number, currentlyActive: boolean) => {
    try {
      const res = await fetch(`/api/admin/users/${userId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json", ...getAuthHeaders() },
        body: JSON.stringify({ is_active: !currentlyActive }),
      });
      if (!res.ok) throw new Error("FAILED");
      await fetchUsers();
      toast({
        title: currentlyActive ? ">> USER DEACTIVATED" : ">> USER ACTIVATED",
        description: `STATUS UPDATED`,
        className: "terminal-text border-trident-border bg-trident-surface",
      });
    } catch {
      toast({
        title: ">> ERROR",
        description: "STATUS UPDATE FAILED",
        variant: "destructive",
        className: "border-[#ff2244] bg-trident-surface text-[#ff2244]",
      });
    }
  };

  const handleDelete = async (userId: number) => {
    try {
      const res = await fetch(`/api/admin/users/${userId}`, {
        method: "DELETE",
        headers: getAuthHeaders(),
      });
      if (!res.ok) throw new Error("FAILED");
      setDeleteConfirm(null);
      await fetchUsers();
      toast({
        title: ">> USER ELIMINATED",
        description: "RECORD PURGED FROM DATABASE",
        className: "terminal-text border-trident-border bg-trident-surface",
      });
    } catch {
      toast({
        title: ">> ERROR",
        description: "DELETION FAILED",
        variant: "destructive",
        className: "border-[#ff2244] bg-trident-surface text-[#ff2244]",
      });
    }
  };

  const roleBadgeStyle: Record<string, string> = {
    admin: "text-trident-amber border-trident-amber/40 bg-trident-amber/10",
    power_user: "text-trident-cyan border-trident-cyan/40 bg-trident-cyan/10",
    user: "text-[#00ff41] border-[#00ff41]/40 bg-[#00ff41]/10",
  };

  return (
    <div className="h-full flex flex-col">
      <div className="trident-panel p-4 mb-4">
        <h1 className="font-display text-sm tracking-[0.15em] text-trident-amber text-glow-amber flex items-center gap-2">
          <Users className="w-4 h-4" />
          PERSONNEL DATABASE
        </h1>
      </div>

      <div className="trident-panel flex-1 overflow-auto">
        {isLoading ? (
          <div className="flex items-center justify-center h-full">
            <div className="flex items-center gap-2">
              {[0, 1, 2].map((i) => (
                <span
                  key={i}
                  className="inline-block w-2 h-2 rounded-full bg-trident-cyan pulse-dot"
                  style={{ animationDelay: `${i * 0.3}s` }}
                />
              ))}
              <span className="text-xs font-mono uppercase tracking-widest text-trident-text/40 ml-2">
                LOADING PERSONNEL RECORDS...
              </span>
            </div>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full" data-testid="table-users">
              <thead>
                <tr className="border-b border-trident-border">
                  {["ID", "USERNAME", "EMAIL", "ROLE", "STATUS", "LAST LOGIN", "ACTIONS"].map(
                    (header) => (
                      <th
                        key={header}
                        className="px-4 py-3 text-left text-[10px] font-mono uppercase tracking-widest text-trident-cyan/70"
                      >
                        {header}
                      </th>
                    )
                  )}
                </tr>
              </thead>
              <tbody>
                {users.map((u) => (
                  <tr
                    key={u.id}
                    className="border-b border-trident-border/30 hover:bg-trident-cyan/5 transition-colors"
                    data-testid={`row-user-${u.id}`}
                  >
                    <td className="px-4 py-3 font-mono text-xs text-trident-text/40">
                      {String(u.id).padStart(3, "0")}
                    </td>
                    <td className="px-4 py-3 font-mono text-xs uppercase text-trident-cyan">
                      {u.username}
                      {u.id === currentUser?.id && (
                        <span className="ml-2 text-[9px] text-trident-amber">[YOU]</span>
                      )}
                    </td>
                    <td className="px-4 py-3 font-mono text-xs text-trident-text/60" style={{ textTransform: "none" }}>
                      {u.email}
                    </td>
                    <td className="px-4 py-3">
                      <div className="relative inline-block">
                        <select
                          value={u.role}
                          onChange={(e) => handleRoleChange(u.id, e.target.value)}
                          disabled={u.id === currentUser?.id}
                          className={`appearance-none cursor-pointer px-2 py-0.5 text-[10px] font-mono uppercase tracking-widest border pr-6 bg-transparent ${
                            roleBadgeStyle[u.role] || roleBadgeStyle.user
                          } ${u.id === currentUser?.id ? "opacity-50 cursor-not-allowed" : ""}`}
                          data-testid={`select-role-${u.id}`}
                        >
                          <option value="admin" className="bg-trident-surface text-trident-text">ADMIN</option>
                          <option value="power_user" className="bg-trident-surface text-trident-text">POWER USER</option>
                          <option value="user" className="bg-trident-surface text-trident-text">USER</option>
                        </select>
                        <ChevronDown className="w-3 h-3 absolute right-1 top-1/2 -translate-y-1/2 pointer-events-none text-current opacity-50" />
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <button
                        onClick={() => handleToggleActive(u.id, u.is_active)}
                        disabled={u.id === currentUser?.id}
                        className={`flex items-center gap-1.5 text-[10px] font-mono uppercase tracking-widest transition-colors ${
                          u.id === currentUser?.id ? "opacity-50 cursor-not-allowed" : "cursor-pointer hover:opacity-80"
                        }`}
                        data-testid={`toggle-active-${u.id}`}
                      >
                        {u.is_active ? (
                          <>
                            <ToggleRight className="w-4 h-4 text-[#00ff41]" />
                            <span className="text-[#00ff41]">ACTIVE</span>
                          </>
                        ) : (
                          <>
                            <ToggleLeft className="w-4 h-4 text-trident-red" />
                            <span className="text-trident-red">INACTIVE</span>
                          </>
                        )}
                      </button>
                    </td>
                    <td className="px-4 py-3 font-mono text-[10px] text-trident-text/30">
                      {u.last_login
                        ? new Date(u.last_login).toLocaleString("en-US", {
                            month: "short",
                            day: "2-digit",
                            hour: "2-digit",
                            minute: "2-digit",
                          })
                        : "NEVER"}
                    </td>
                    <td className="px-4 py-3">
                      {u.id !== currentUser?.id && (
                        <>
                          {deleteConfirm === u.id ? (
                            <div className="flex items-center gap-2">
                              <span className="text-[10px] font-mono text-trident-red">CONFIRM?</span>
                              <button
                                onClick={() => handleDelete(u.id)}
                                className="text-[10px] font-mono uppercase text-trident-red hover:text-white bg-trident-red/20 px-2 py-0.5 border border-trident-red/40"
                                data-testid={`confirm-delete-${u.id}`}
                              >
                                YES
                              </button>
                              <button
                                onClick={() => setDeleteConfirm(null)}
                                className="text-[10px] font-mono uppercase text-trident-text/40 hover:text-trident-text px-2 py-0.5 border border-trident-border"
                              >
                                NO
                              </button>
                            </div>
                          ) : (
                            <button
                              onClick={() => setDeleteConfirm(u.id)}
                              className="text-trident-red/40 hover:text-trident-red transition-colors"
                              data-testid={`button-delete-${u.id}`}
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {users.length === 0 && (
              <div className="text-center py-12 font-mono text-xs text-trident-text/30 uppercase">
                NO PERSONNEL RECORDS FOUND
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
