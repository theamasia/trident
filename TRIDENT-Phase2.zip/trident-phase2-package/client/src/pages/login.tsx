import { useState } from "react";
import { useLocation } from "wouter";
import { TridentLogo } from "@/components/TridentLogo";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";

export default function LoginPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [, setLocation] = useLocation();
  const { login } = useAuth();
  const { toast } = useToast();

  // Check for registration success message in URL
  const params = new URLSearchParams(window.location.hash.split("?")[1] || "");
  const registered = params.get("registered");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      await login(email.toLowerCase().trim(), password);
      toast({
        title: ">> USER AUTHENTICATED",
        description: "WELCOME TO TRIDENT NEURAL INTERFACE",
        className: "terminal-text border-trident-border bg-trident-surface",
      });
      setLocation("/dashboard");
    } catch (err: any) {
      const msg = err.message?.includes("401")
        ? "INVALID CREDENTIALS"
        : err.message?.includes("403")
        ? "ACCOUNT DEACTIVATED"
        : "AUTHENTICATION FAILED";
      toast({
        title: ">> ERROR",
        description: msg,
        variant: "destructive",
        className: "border-[#ff2244] bg-trident-surface text-[#ff2244]",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center grid-bg crt-on" style={{ backgroundColor: "#050a0e" }}>
      {/* CRT scanline overlay */}
      <div className="fixed inset-0 scanlines pointer-events-none" />
      
      <div className="w-full max-w-md px-6 crt-flicker relative z-10">
        {/* Logo */}
        <div className="flex flex-col items-center mb-8">
          <TridentLogo size="lg" />
          <p className="mt-3 font-mono text-xs tracking-[0.15em] text-trident-cyan/60 uppercase">
            TACTICAL NEURAL INTERFACE SYSTEM
          </p>
        </div>

        {/* Registration success alert */}
        {registered && (
          <div className="mb-6 p-3 border border-[#00ff41]/30 bg-[#00ff41]/5 text-center">
            <p className="terminal-text text-xs">
              &gt;&gt; ACCESS GRANTED — AWAIT AUTHENTICATION
            </p>
          </div>
        )}

        {/* Login Form */}
        <form onSubmit={handleSubmit} className="trident-panel p-6 space-y-5" data-testid="login-form">
          <div className="text-center mb-4">
            <h2 className="font-display text-sm tracking-[0.15em] text-trident-amber text-glow-amber">
              SYSTEM LOGIN
            </h2>
          </div>

          <div className="space-y-1">
            <label className="block text-[10px] font-mono uppercase tracking-widest text-trident-cyan/70">
              EMAIL ADDRESS
            </label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="trident-input trident-input-lower w-full px-3 py-2.5 text-sm"
              placeholder="ENTER EMAIL"
              required
              data-testid="input-email"
              autoComplete="email"
            />
          </div>

          <div className="space-y-1">
            <label className="block text-[10px] font-mono uppercase tracking-widest text-trident-cyan/70">
              PASSWORD
            </label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="trident-input w-full px-3 py-2.5 text-sm"
              placeholder="ENTER PASSWORD"
              required
              data-testid="input-password"
              autoComplete="current-password"
              style={{ textTransform: "none" }}
            />
          </div>

          <button
            type="submit"
            disabled={isSubmitting}
            className="trident-btn trident-btn-primary w-full py-3 text-sm disabled:opacity-50"
            data-testid="button-login"
          >
            {isSubmitting ? (
              <span className="flex items-center justify-center gap-2">
                <span className="pulse-dot inline-block w-2 h-2 rounded-full bg-black" />
                PROCESSING...
              </span>
            ) : (
              "AUTHENTICATE"
            )}
          </button>

          <div className="text-center pt-2">
            <button
              type="button"
              onClick={() => setLocation("/register")}
              className="text-xs font-mono uppercase tracking-widest text-trident-cyan/50 hover:text-trident-cyan transition-colors"
              data-testid="link-register"
            >
              [ REQUEST ACCESS ]
            </button>
          </div>
        </form>

        {/* Footer */}
        <div className="mt-8 text-center">
          <p className="text-[10px] font-mono text-trident-border tracking-widest">
            v1.0.0 // PHASE 1
          </p>
        </div>
      </div>
    </div>
  );
}
