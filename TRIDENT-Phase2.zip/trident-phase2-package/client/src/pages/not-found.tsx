import { useLocation } from "wouter";
import { AlertTriangle } from "lucide-react";

export default function NotFound() {
  const [, setLocation] = useLocation();
  
  return (
    <div className="min-h-screen flex items-center justify-center grid-bg" style={{ backgroundColor: "#050a0e" }}>
      <div className="trident-panel p-8 max-w-md text-center space-y-4">
        <AlertTriangle className="w-12 h-12 mx-auto text-trident-amber" />
        <h1 className="font-display text-lg tracking-[0.15em] text-trident-red">
          ERROR 404
        </h1>
        <div className="font-mono text-xs text-trident-text/60 space-y-1">
          <p>&gt;&gt; SECTOR NOT FOUND</p>
          <p>&gt;&gt; REQUESTED COORDINATES DO NOT EXIST</p>
        </div>
        <button
          onClick={() => setLocation("/login")}
          className="trident-btn trident-btn-secondary px-6 py-2 text-xs mt-4"
          data-testid="button-go-home"
        >
          RETURN TO BASE
        </button>
      </div>
    </div>
  );
}
