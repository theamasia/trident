interface TridentLogoProps {
  size?: "sm" | "md" | "lg";
  className?: string;
  showText?: boolean;
}

export function TridentLogo({ size = "md", className = "", showText = true }: TridentLogoProps) {
  const dimensions = {
    sm: { width: 32, height: 32, textClass: "text-xs" },
    md: { width: 64, height: 64, textClass: "text-sm" },
    lg: { width: 120, height: 120, textClass: "text-lg" },
  };

  const { width, height, textClass } = dimensions[size];

  return (
    <div className={`flex flex-col items-center gap-2 ${className}`}>
      <svg
        width={width}
        height={height}
        viewBox="0 0 100 120"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        aria-label="TRIDENT Logo"
      >
        {/* Outer glow filter */}
        <defs>
          <filter id="tridentGlow" x="-50%" y="-50%" width="200%" height="200%">
            <feGaussianBlur stdDeviation="3" result="blur" />
            <feMerge>
              <feMergeNode in="blur" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
          <linearGradient id="tridentGrad" x1="50%" y1="0%" x2="50%" y2="100%">
            <stop offset="0%" stopColor="#00f0ff" />
            <stop offset="100%" stopColor="#0080a0" />
          </linearGradient>
        </defs>
        
        <g filter="url(#tridentGlow)">
          {/* Central shaft */}
          <rect x="47" y="30" width="6" height="80" fill="url(#tridentGrad)" />
          
          {/* Center prong — tallest */}
          <polygon points="50,2 42,30 58,30" fill="url(#tridentGrad)" />
          
          {/* Left prong */}
          <polygon points="22,18 18,30 32,30" fill="url(#tridentGrad)" />
          <rect x="22" y="30" width="6" height="16" fill="url(#tridentGrad)" />
          
          {/* Right prong */}
          <polygon points="78,18 68,30 82,30" fill="url(#tridentGrad)" />
          <rect x="72" y="30" width="6" height="16" fill="url(#tridentGrad)" />
          
          {/* Crossbar connecting prongs */}
          <rect x="18" y="40" width="64" height="5" rx="1" fill="url(#tridentGrad)" />
          
          {/* Bottom spike */}
          <polygon points="50,118 44,104 56,104" fill="url(#tridentGrad)" />
          <rect x="47" y="104" width="6" height="8" fill="url(#tridentGrad)" />
          
          {/* Decorative side brackets */}
          <path d="M14,32 L14,48 L20,48" stroke="#00f0ff" strokeWidth="1.5" fill="none" opacity="0.6" />
          <path d="M86,32 L86,48 L80,48" stroke="#00f0ff" strokeWidth="1.5" fill="none" opacity="0.6" />
          
          {/* Center diamond accent */}
          <polygon points="50,55 45,60 50,65 55,60" fill="#00f0ff" opacity="0.8" />
        </g>
      </svg>
      
      {showText && (
        <div className="flex flex-col items-center">
          <span
            className={`font-display font-bold tracking-[0.2em] text-trident-cyan text-glow-cyan ${textClass}`}
          >
            TRIDENT
          </span>
        </div>
      )}
    </div>
  );
}
