import { create } from "zustand";
import { apiRequest } from "@/lib/queryClient";
import type { SafeUser } from "@shared/schema";

interface AuthState {
  user: SafeUser | null;
  token: string | null;
  isLoading: boolean;
  isAuthenticated: boolean;
  login: (email: string, password: string) => Promise<void>;
  register: (username: string, email: string, password: string) => Promise<string>;
  logout: () => void;
  checkAuth: () => Promise<void>;
  setUser: (user: SafeUser) => void;
}

// Store token in memory (not localStorage — sandboxed iframe blocks it)
let memoryToken: string | null = null;

export const useAuth = create<AuthState>((set, get) => ({
  user: null,
  token: null,
  isLoading: true,
  isAuthenticated: false,

  login: async (email: string, password: string) => {
    const res = await apiRequest("POST", "/api/auth/login", { email, password });
    const data = await res.json();
    memoryToken = data.token;
    set({
      user: data.user,
      token: data.token,
      isAuthenticated: true,
      isLoading: false,
    });
  },

  register: async (username: string, email: string, password: string) => {
    const res = await apiRequest("POST", "/api/auth/register", { username, email, password });
    const data = await res.json();
    return data.message;
  },

  logout: () => {
    // Fire-and-forget logout call
    if (memoryToken) {
      fetch("/api/auth/logout", {
        method: "POST",
        headers: { Authorization: `Bearer ${memoryToken}` },
      }).catch(() => {});
    }
    memoryToken = null;
    set({
      user: null,
      token: null,
      isAuthenticated: false,
      isLoading: false,
    });
  },

  checkAuth: async () => {
    if (!memoryToken) {
      set({ isLoading: false });
      return;
    }
    try {
      const res = await fetch("/api/auth/me", {
        headers: { Authorization: `Bearer ${memoryToken}` },
      });
      if (res.ok) {
        const data = await res.json();
        set({
          user: data.user,
          token: memoryToken,
          isAuthenticated: true,
          isLoading: false,
        });
      } else {
        memoryToken = null;
        set({ user: null, token: null, isAuthenticated: false, isLoading: false });
      }
    } catch {
      set({ isLoading: false });
    }
  },

  setUser: (user: SafeUser) => {
    set({ user });
  },
}));

// Helper to get auth headers for API calls
export function getAuthHeaders(): Record<string, string> {
  return memoryToken ? { Authorization: `Bearer ${memoryToken}` } : {};
}
