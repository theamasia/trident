#!/usr/bin/env python3
"""
TRIDENT Reolink Direct Camera Service
Connects directly to individual Reolink cameras (not via NVR) for AI/motion detection events.
Runs on port 5012
"""
import os, time, json, threading, datetime
import requests
import urllib3
from flask import Flask, jsonify

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

app = Flask(__name__)
from flask_cors import CORS
CORS(app)

# Camera list is loaded from a JSON config file so cameras can be added/removed
# without redeploying code. Default location: /etc/trident/reolink-cameras.json
# Format:
# [
#   {"name": "Front Door", "host": "192.168.8.150", "scheme": "http", "port": 80, "username": "admin", "password": "..."},
#   {"name": "Driveway", "host": "192.168.8.151", "scheme": "https", "port": 443, "username": "admin", "password": "..."}
# ]
# Credentials can also be supplied via env vars per camera as a fallback:
# REOLINK_CAM1_HOST, REOLINK_CAM1_USER, REOLINK_CAM1_PASS, REOLINK_CAM1_SCHEME, REOLINK_CAM1_NAME (and CAM2, CAM3, etc.)
CAMERA_CONFIG_PATH = os.environ.get("REOLINK_CAMERA_CONFIG", "/etc/trident/reolink-cameras.json")

def load_camera_config():
    cameras = []
    # Try JSON config file first
    if os.path.exists(CAMERA_CONFIG_PATH):
        try:
            with open(CAMERA_CONFIG_PATH) as f:
                cameras = json.load(f)
        except Exception as e:
            print(f"[ TRIDENT REOLINK ] Failed to parse {CAMERA_CONFIG_PATH}: {e}", flush=True)
    # Fallback: numbered env vars REOLINK_CAM1_HOST, REOLINK_CAM2_HOST, etc (up to 10)
    if not cameras:
        for i in range(1, 11):
            host = os.environ.get(f"REOLINK_CAM{i}_HOST")
            if not host:
                continue
            cameras.append({
                "name": os.environ.get(f"REOLINK_CAM{i}_NAME", f"Camera {i}"),
                "host": host,
                "scheme": os.environ.get(f"REOLINK_CAM{i}_SCHEME", "http"),
                "port": int(os.environ.get(f"REOLINK_CAM{i}_PORT", "443" if os.environ.get(f"REOLINK_CAM{i}_SCHEME") == "https" else "80")),
                "username": os.environ.get(f"REOLINK_CAM{i}_USER", ""),
                "password": os.environ.get(f"REOLINK_CAM{i}_PASS", ""),
            })
    return cameras

CAMERAS = load_camera_config()

STATE = {}  # keyed by camera name -> {status, last_error, last_success, online, ai_state, events}
TOKENS = {}  # keyed by camera name -> {"value": token, "expires_at": ts}
LOCK = threading.Lock()
MAX_EVENTS_CACHE = 100

def cam_base_url(cam):
    return f"{cam['scheme']}://{cam['host']}:{cam['port']}/cgi-bin/api.cgi"

def cam_login(cam):
    name = cam["name"]
    if not cam.get("username") or not cam.get("password"):
        raise Exception(f"{name}: username/password not configured")
    body = [{"cmd": "Login", "action": 0, "param": {"User": {"userName": cam["username"], "password": cam["password"]}}}]
    res = requests.post(cam_base_url(cam), json=body, timeout=8, verify=(False if cam["scheme"] == "https" else True))
    res.raise_for_status()
    data = res.json()
    if not data or data[0].get("code") != 0:
        raise Exception(f"{name}: login failed — {data}")
    token_info = data[0]["value"]["Token"]
    with LOCK:
        TOKENS[name] = {"value": token_info["name"], "expires_at": time.time() + token_info.get("leaseTime", 3600) - 60}
    return TOKENS[name]["value"]

def cam_get_token(cam):
    name = cam["name"]
    tok = TOKENS.get(name)
    if not tok or time.time() > tok["expires_at"]:
        return cam_login(cam)
    return tok["value"]

def cam_call(cam, cmd, param=None, retry=True):
    name = cam["name"]
    token = cam_get_token(cam)
    body = [{"cmd": cmd, "action": 0, "param": param or {}}]
    verify_ssl = False if cam["scheme"] == "https" else True
    res = requests.post(f"{cam_base_url(cam)}?token={token}", json=body, timeout=10, verify=verify_ssl)
    res.raise_for_status()
    data = res.json()
    if data and data[0].get("code") != 0 and retry:
        with LOCK:
            TOKENS.pop(name, None)
        return cam_call(cam, cmd, param, retry=False)
    return data[0] if data else {}

def poll_camera_ai_state(cam):
    result = cam_call(cam, "GetAiState", {"channel": 0})
    val = result.get("value", {}).get("State", {})
    state = {}
    for key in ("people", "vehicle", "dog_cat", "face"):
        if key in val:
            state[key] = {
                "supported": val[key].get("support", 0) == 1,
                "alarm_state": val[key].get("alarm_state", 0) == 1,
            }
    return state

def poll_camera_events(cam, hours_back=24):
    now = datetime.datetime.utcnow()
    start = now - datetime.timedelta(hours=hours_back)
    param = {
        "Search": {
            "channel": 0,
            "onlyStatus": 0,
            "streamType": "sub",
            "StartTime": {"year": start.year, "mon": start.month, "day": start.day, "hour": start.hour, "min": start.minute, "sec": start.second},
            "EndTime": {"year": now.year, "mon": now.month, "day": now.day, "hour": now.hour, "min": now.minute, "sec": now.second},
        }
    }
    result = cam_call(cam, "Search", param)
    files = result.get("value", {}).get("SearchResult", {}).get("File", []) or []
    events = []
    for f in files:
        st = f.get("StartTime", {})
        et = f.get("EndTime", {})
        try:
            start_dt = datetime.datetime(st.get("year",1970), st.get("mon",1), st.get("day",1), st.get("hour",0), st.get("min",0), st.get("sec",0))
            end_dt = datetime.datetime(et.get("year",1970), et.get("mon",1), et.get("day",1), et.get("hour",0), et.get("min",0), et.get("sec",0))
        except Exception:
            continue
        events.append({
            "camera": cam["name"],
            "type": f.get("type", "unknown"),
            "start": start_dt.isoformat() + "Z",
            "end": end_dt.isoformat() + "Z",
            "duration_sec": max(0, int((end_dt - start_dt).total_seconds())),
            "size_bytes": f.get("size"),
            "name": f.get("name"),
        })
    return events

def poll_loop():
    while True:
        for cam in CAMERAS:
            name = cam["name"]
            try:
                ai_state = poll_camera_ai_state(cam)
                events = poll_camera_events(cam, hours_back=24)
                with LOCK:
                    STATE[name] = {
                        "online": True,
                        "status": "live",
                        "last_error": None,
                        "last_success": time.time(),
                        "ai_state": ai_state,
                        "events": events,
                        "host": cam["host"],
                    }
            except Exception as e:
                with LOCK:
                    prev = STATE.get(name, {})
                    STATE[name] = {
                        "online": False,
                        "status": "offline",
                        "last_error": str(e),
                        "last_success": prev.get("last_success"),
                        "ai_state": prev.get("ai_state", {}),
                        "events": prev.get("events", []),
                        "host": cam["host"],
                    }
                print(f"[ TRIDENT REOLINK ] {name} poll error: {e}", flush=True)
        time.sleep(30)

@app.route("/health")
def health():
    with LOCK:
        cams_status = {name: {"online": s["online"], "status": s["status"], "last_error": s["last_error"]} for name, s in STATE.items()}
    return jsonify({
        "service": "TRIDENT Reolink Direct Camera Service",
        "cameras_configured": len(CAMERAS),
        "cameras": cams_status,
    })

@app.route("/cameras")
def cameras():
    with LOCK:
        result = []
        for cam in CAMERAS:
            s = STATE.get(cam["name"], {"online": False, "status": "starting", "ai_state": {}, "last_error": None})
            result.append({
                "name": cam["name"],
                "host": cam["host"],
                "online": s.get("online", False),
                "status": s.get("status", "starting"),
                "ai_state": s.get("ai_state", {}),
                "last_error": s.get("last_error"),
            })
    return jsonify({"cameras": result, "count": len(result)})

@app.route("/events")
def events():
    from flask import request as flask_request
    camera_filter = flask_request.args.get("camera")
    event_type = flask_request.args.get("type")
    limit = flask_request.args.get("limit", default=100, type=int)
    with LOCK:
        all_events = []
        for name, s in STATE.items():
            all_events.extend(s.get("events", []))
        all_events.sort(key=lambda e: e["start"], reverse=True)
        if camera_filter:
            all_events = [e for e in all_events if e["camera"] == camera_filter]
        if event_type:
            all_events = [e for e in all_events if event_type.lower() in (e.get("type") or "").lower()]
        return jsonify({"events": all_events[:limit], "count": len(all_events)})

@app.route("/summary")
def summary():
    with LOCK:
        online_cams = [name for name, s in STATE.items() if s.get("online")]
        total_events_24h = sum(len(s.get("events", [])) for s in STATE.values())
        active_alarms = []
        for name, s in STATE.items():
            for kind, info in s.get("ai_state", {}).items():
                if info.get("alarm_state"):
                    active_alarms.append(f"{name}: {kind} detected")
        return jsonify({
            "status": "live" if CAMERAS and online_cams else ("no_cameras_configured" if not CAMERAS else "offline"),
            "cameras_online": len(online_cams),
            "cameras_total": len(CAMERAS),
            "events_24h": total_events_24h,
            "active_alarms": active_alarms,
        })

if __name__ == "__main__":
    print(f"[ TRIDENT ] Reolink Direct Camera Service starting on port 5012")
    print(f"[ TRIDENT ] Configured cameras: {len(CAMERAS)}")
    for c in CAMERAS:
        print(f"[ TRIDENT ]   - {c['name']} @ {c['scheme']}://{c['host']}:{c['port']}")
    if CAMERAS:
        threading.Thread(target=poll_loop, daemon=True).start()
    app.run(host="127.0.0.1", port=5012, debug=False)
