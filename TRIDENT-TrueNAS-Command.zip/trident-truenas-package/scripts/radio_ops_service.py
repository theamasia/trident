#!/usr/bin/env python3
"""
TRIDENT Radio Ops Aggregator Service
Polls Trunk Recorder (VIPER/P25), dump1090 (ADS-B), and rtl_433 (MQTT) from the SDR node
Runs on port 5010
"""
import os, time, json, threading, datetime
import requests
from flask import Flask, jsonify, request
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

# Config — override via env vars set in systemd unit / /etc/trident/config.env
SDR_NODE_HOST = os.environ.get("SDR_NODE_HOST", "192.168.0.172")
VIPER_PORT = int(os.environ.get("VIPER_PORT", "9001"))
VIPER_PATH = os.environ.get("VIPER_PATH", "/api/radio/viper/calls")
ADSB_PORT = int(os.environ.get("ADSB_PORT", "8080"))
ADSB_PATH = os.environ.get("ADSB_PATH", "/data/aircraft.json")
MQTT_HOST = os.environ.get("MQTT_HOST", SDR_NODE_HOST)
MQTT_PORT = int(os.environ.get("MQTT_PORT", "1883"))
MQTT_TOPIC_PREFIX = os.environ.get("MQTT_TOPIC_PREFIX", "rtl_433")

VIPER_URL = f"http://{SDR_NODE_HOST}:{VIPER_PORT}{VIPER_PATH}"
ADSB_URL = f"http://{SDR_NODE_HOST}:{ADSB_PORT}{ADSB_PATH}"

STATE = {
    "viper": {"status": "offline", "last_success": None, "last_error": None, "data": []},
    "adsb": {"status": "offline", "last_success": None, "last_error": None, "data": []},
    "sensors": {"status": "offline", "last_success": None, "last_error": None, "data": [], "mqtt_connected": False},
}
LOCK = threading.Lock()
MAX_SENSOR_EVENTS = 200
MAX_CALLS_CACHE = 200

# ─── Signal Activity History — rolling buffers for activity meters (RADIO OPS) ───
ACTIVITY_HISTORY_LEN = 60  # keep last 60 samples per feed (60 samples at current poll intervals ~= a few minutes of history)
STATE["activity"] = {
    "viper": [],   # list of {"t": timestamp, "active_calls": int}
    "adsb": [],    # list of {"t": timestamp, "message_count": int, "aircraft_count": int}
    "sensors": [], # list of {"t": timestamp, "event_count": int}  -- count of events received in this sampling window
}

def classify_status(last_success, stale_after_sec, has_reached_endpoint):
    if not has_reached_endpoint:
        return "offline"
    if last_success is None:
        return "starting"
    age = time.time() - last_success
    if age > stale_after_sec:
        return "stale"
    return "live"

def poll_viper():
    while True:
        try:
            res = requests.get(VIPER_URL, timeout=8)
            if res.ok:
                data = res.json()
                calls = data if isinstance(data, list) else data.get("calls", [])
                with LOCK:
                    STATE["viper"]["data"] = calls[:MAX_CALLS_CACHE]
                    STATE["viper"]["last_success"] = time.time()
                    STATE["viper"]["last_error"] = None
                    STATE["viper"]["status"] = "live"
                active_count = sum(1 for c in calls if str(c.get("state", "")).lower() in ("recording", "monitoring"))
                with LOCK:
                    STATE["activity"]["viper"].append({"t": time.time(), "active_calls": active_count})
                    STATE["activity"]["viper"] = STATE["activity"]["viper"][-ACTIVITY_HISTORY_LEN:]
            else:
                with LOCK:
                    STATE["viper"]["last_error"] = f"HTTP {res.status_code}"
                    STATE["viper"]["status"] = classify_status(STATE["viper"]["last_success"], 300, True)
        except requests.exceptions.ConnectionError:
            with LOCK:
                STATE["viper"]["status"] = "offline"
                STATE["viper"]["last_error"] = "Connection refused — Trunk Recorder adapter not reachable"
        except Exception as e:
            with LOCK:
                STATE["viper"]["last_error"] = str(e)
                STATE["viper"]["status"] = classify_status(STATE["viper"]["last_success"], 300, True)
        time.sleep(3)  # poll every 2-5s per spec

def poll_adsb():
    while True:
        try:
            res = requests.get(ADSB_URL, timeout=8)
            if res.ok:
                data = res.json()
                aircraft = data.get("aircraft", data) if isinstance(data, dict) else data
                with LOCK:
                    STATE["adsb"]["data"] = aircraft
                    STATE["adsb"]["last_success"] = time.time()
                    STATE["adsb"]["last_error"] = None
                    STATE["adsb"]["status"] = "live"
                total_messages = sum(a.get("messages", 0) for a in aircraft) if aircraft else 0
                with LOCK:
                    STATE["activity"]["adsb"].append({"t": time.time(), "message_count": total_messages, "aircraft_count": len(aircraft)})
                    STATE["activity"]["adsb"] = STATE["activity"]["adsb"][-ACTIVITY_HISTORY_LEN:]
            else:
                with LOCK:
                    STATE["adsb"]["last_error"] = f"HTTP {res.status_code}"
                    STATE["adsb"]["status"] = classify_status(STATE["adsb"]["last_success"], 60, True)
        except requests.exceptions.ConnectionError:
            with LOCK:
                STATE["adsb"]["status"] = "offline"
                STATE["adsb"]["last_error"] = "Connection refused — dump1090 not reachable"
        except Exception as e:
            with LOCK:
                STATE["adsb"]["last_error"] = str(e)
                STATE["adsb"]["status"] = classify_status(STATE["adsb"]["last_success"], 60, True)
        time.sleep(7)  # poll every 5-10s per spec

def start_mqtt_listener():
    """Subscribe to rtl_433 MQTT events; gracefully disable if paho-mqtt missing or broker unreachable"""
    try:
        import paho.mqtt.client as mqtt
    except ImportError:
        print("[ TRIDENT RADIO ] paho-mqtt not installed — sensors disabled", flush=True)
        with LOCK:
            STATE["sensors"]["status"] = "offline"
            STATE["sensors"]["last_error"] = "paho-mqtt library not installed"
        return

    def on_connect(client, userdata, flags, rc, properties=None):
        if rc == 0:
            print("[ TRIDENT RADIO ] MQTT connected", flush=True)
            client.subscribe(f"{MQTT_TOPIC_PREFIX}/#")
            with LOCK:
                STATE["sensors"]["mqtt_connected"] = True
                STATE["sensors"]["status"] = "starting"
        else:
            with LOCK:
                STATE["sensors"]["mqtt_connected"] = False
                STATE["sensors"]["status"] = "offline"

    def on_disconnect(client, userdata, rc, properties=None):
        with LOCK:
            STATE["sensors"]["mqtt_connected"] = False
            STATE["sensors"]["status"] = "offline"

    def on_message(client, userdata, msg):
        try:
            payload = json.loads(msg.payload.decode("utf-8"))
            event = {
                "id": f"{payload.get('id', payload.get('model',''))}-{int(time.time()*1000)}",
                "timestamp": payload.get("time", datetime.datetime.utcnow().isoformat()),
                "model": payload.get("model"),
                "deviceId": payload.get("id"),
                "channel": payload.get("channel"),
                "topic": msg.topic,
                "raw": payload,
            }
            with LOCK:
                STATE["sensors"]["data"].insert(0, event)
                STATE["sensors"]["data"] = STATE["sensors"]["data"][:MAX_SENSOR_EVENTS]
                STATE["sensors"]["last_success"] = time.time()
                STATE["sensors"]["status"] = "live"
            with LOCK:
                STATE["activity"]["sensors"].append({"t": time.time(), "event_count": 1})
                STATE["activity"]["sensors"] = STATE["activity"]["sensors"][-ACTIVITY_HISTORY_LEN:]
        except Exception as e:
            print(f"[ TRIDENT RADIO ] MQTT message parse error: {e}", flush=True)

    while True:
        try:
            client = mqtt.Client(callback_api_version=mqtt.CallbackAPIVersion.VERSION2)
            client.on_connect = on_connect
            client.on_disconnect = on_disconnect
            client.on_message = on_message
            client.connect(MQTT_HOST, MQTT_PORT, keepalive=30)
            client.loop_forever()
        except Exception as e:
            with LOCK:
                STATE["sensors"]["status"] = "offline"
                STATE["sensors"]["last_error"] = str(e)
            time.sleep(10)  # retry connection

def get_status_with_staleness():
    """Recompute stale status based on time elapsed since last success"""
    with LOCK:
        now = time.time()
        result = {}
        for feed, cfg in [("viper", 300), ("adsb", 60), ("sensors", 600)]:
            s = dict(STATE[feed])
            if s["status"] == "live" and s["last_success"] and (now - s["last_success"]) > cfg:
                s["status"] = "stale"
            result[feed] = {k: v for k, v in s.items() if k != "data"}
        return result

@app.route("/health")
def health():
    return jsonify({
        "service": "TRIDENT Radio Ops Aggregator",
        "sdr_node": SDR_NODE_HOST,
        "feeds": get_status_with_staleness(),
    })

@app.route("/viper/calls")
def viper_calls():
    with LOCK:
        return jsonify({"calls": STATE["viper"]["data"], "status": STATE["viper"]["status"], "last_error": STATE["viper"]["last_error"]})

@app.route("/viper/calls/<call_id>")
def viper_call_detail(call_id):
    with LOCK:
        for c in STATE["viper"]["data"]:
            if str(c.get("id")) == str(call_id):
                return jsonify(c)
    # fall through to live upstream fetch for detail (may have audioUrl not in list view)
    try:
        res = requests.get(f"http://{SDR_NODE_HOST}:{VIPER_PORT}{VIPER_PATH}/{call_id}", timeout=8)
        if res.ok:
            return jsonify(res.json())
    except Exception:
        pass
    return jsonify({"error": "Call not found"}), 404

@app.route("/adsb/aircraft")
def adsb_aircraft():
    with LOCK:
        return jsonify({"aircraft": STATE["adsb"]["data"], "status": STATE["adsb"]["status"], "last_error": STATE["adsb"]["last_error"], "count": len(STATE["adsb"]["data"])})

@app.route("/sensors/events")
def sensor_events():
    with LOCK:
        return jsonify({"events": STATE["sensors"]["data"], "status": STATE["sensors"]["status"], "mqtt_connected": STATE["sensors"]["mqtt_connected"], "last_error": STATE["sensors"]["last_error"]})

@app.route("/activity")
def activity():
    with LOCK:
        return jsonify({
            "viper": STATE["activity"]["viper"],
            "adsb": STATE["activity"]["adsb"],
            "sensors": STATE["activity"]["sensors"],
        })

if __name__ == "__main__":
    threading.Thread(target=poll_viper, daemon=True).start()
    threading.Thread(target=poll_adsb, daemon=True).start()
    threading.Thread(target=start_mqtt_listener, daemon=True).start()
    print(f"[ TRIDENT ] Radio Ops Aggregator starting on port 5010, SDR node: {SDR_NODE_HOST}")
    app.run(host="127.0.0.1", port=5010, debug=False)
