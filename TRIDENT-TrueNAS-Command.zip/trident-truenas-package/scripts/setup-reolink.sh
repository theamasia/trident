#!/usr/bin/env bash
#
# TRIDENT Reolink Direct Camera Service — installer
# Installs the Python Reolink direct-camera detection service (AI/motion detection
# events polled straight from each Reolink camera's own local CGI API — no NVR
# passthrough, no channel indexing) as a systemd unit on port 5012.
#
# Each camera exposes the same Reolink CGI API (/cgi-bin/api.cgi) directly on its
# own LAN IP. Supports both plain HTTP and HTTPS-with-self-signed-cert per camera.
#
set -euo pipefail

echo "[ SETUP ] Configure your cameras BEFORE starting, using ONE of these methods:"
echo ""
echo "  METHOD 1 (recommended) — JSON config file at /etc/trident/reolink-cameras.json:"
echo '  [{"name":"Front Door","host":"192.168.8.150","scheme":"http","port":80,"username":"admin","password":"yourpass"}]'
echo ""
echo "  METHOD 2 — numbered env vars in /etc/trident/config.env:"
echo "  REOLINK_CAM1_NAME=Front Door"
echo "  REOLINK_CAM1_HOST=192.168.8.150"
echo "  REOLINK_CAM1_SCHEME=http"
echo "  REOLINK_CAM1_USER=admin"
echo "  REOLINK_CAM1_PASS=yourpass"
echo "  (repeat with CAM2, CAM3, etc for additional cameras)"
echo ""
echo "[ SETUP ] With zero cameras configured, the service starts cleanly and reports"
echo "[ SETUP ] a 'no cameras configured yet' state until you add entries."

SERVICE_NAME="trident-reolink"
INSTALL_DIR="/opt/trident-reolink"
VENV_DIR="${INSTALL_DIR}/venv"
CONFIG_ENV="/etc/trident/config.env"
CAMERA_CONFIG="/etc/trident/reolink-cameras.json"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PORT=5012

echo "[ TRIDENT ] ═══ Reolink Direct Camera Service Setup ═══"

# ── 1. Directories ──
echo "[ TRIDENT ] Creating ${INSTALL_DIR} ..."
sudo mkdir -p "${INSTALL_DIR}"
sudo mkdir -p "$(dirname "${CONFIG_ENV}")"

# ── 2. Python venv + dependencies ──
echo "[ TRIDENT ] Building virtualenv at ${VENV_DIR} ..."
sudo python3 -m venv "${VENV_DIR}"
sudo "${VENV_DIR}/bin/pip" install --upgrade pip
sudo "${VENV_DIR}/bin/pip" install flask flask-cors requests urllib3

# ── 3. Deploy service code ──
echo "[ TRIDENT ] Copying reolink_service.py ..."
sudo cp "${SCRIPT_DIR}/reolink_service.py" "${INSTALL_DIR}/reolink_service.py"

# ── 4. Ensure config env exists ──
if [ ! -f "${CONFIG_ENV}" ]; then
  echo "[ TRIDENT ] Creating ${CONFIG_ENV} ..."
  sudo tee "${CONFIG_ENV}" > /dev/null <<'ENVEOF'
# TRIDENT Reolink Direct Camera config
# Fallback method (METHOD 2) for camera credentials if /etc/trident/reolink-cameras.json
# does not exist. Add numbered blocks (CAM1, CAM2, ... CAM10) below, one per camera.
# Credentials must be a dedicated VIEW-ONLY local camera account — this service only
# performs read/search operations, never configuration changes.
#
# REOLINK_CAM1_NAME=Front Door
# REOLINK_CAM1_HOST=192.168.8.150
# REOLINK_CAM1_SCHEME=http
# REOLINK_CAM1_USER=
# REOLINK_CAM1_PASS=
ENVEOF
  echo "[ TRIDENT ] >>> EDIT ${CONFIG_ENV} NOW to add camera entries (or use ${CAMERA_CONFIG} instead). <<<"
else
  echo "[ TRIDENT ] ${CONFIG_ENV} already exists — leaving untouched."
  echo "[ TRIDENT ] Ensure it contains REOLINK_CAM1_HOST / _USER / _PASS / _SCHEME / _NAME (see reminder above) if using METHOD 2."
fi

# ── 5. Camera JSON config note ──
if [ -f "${CAMERA_CONFIG}" ]; then
  echo "[ TRIDENT ] Found existing ${CAMERA_CONFIG} — the service will read it automatically."
else
  echo "[ TRIDENT ] No ${CAMERA_CONFIG} found. Create it (METHOD 1) to configure cameras, or rely on"
  echo "[ TRIDENT ] the numbered env vars in ${CONFIG_ENV} (METHOD 2). No special permissions setup is"
  echo "[ TRIDENT ] needed beyond making the file readable by root — systemd runs this service as root."
fi

# ── 6. systemd unit ──
echo "[ TRIDENT ] Installing systemd unit ${SERVICE_NAME} ..."
sudo tee "/etc/systemd/system/${SERVICE_NAME}.service" > /dev/null <<EOF
[Unit]
Description=TRIDENT Reolink Direct Camera Service (port ${PORT})
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
WorkingDirectory=${INSTALL_DIR}
EnvironmentFile=${CONFIG_ENV}
ExecStart=${VENV_DIR}/bin/python ${INSTALL_DIR}/reolink_service.py
Restart=always
RestartSec=5
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
EOF

# ── 7. Enable + start ──
echo "[ TRIDENT ] Reloading systemd and starting service ..."
sudo systemctl daemon-reload
sudo systemctl enable "${SERVICE_NAME}"
sudo systemctl restart "${SERVICE_NAME}"

# ── 8. Health check ──
echo "[ TRIDENT ] Waiting for service to come online ..."
sleep 3
echo "[ TRIDENT ] Health check:"
curl -fsS "http://127.0.0.1:${PORT}/health" && echo "" || {
  echo "[ TRIDENT ] Health check FAILED — inspect: sudo journalctl -u ${SERVICE_NAME} -n 50"
  exit 1
}

echo "[ TRIDENT ] ═══ Reolink Direct Camera Service installed on port ${PORT} ═══"
echo "[ TRIDENT ] NOTE: With zero cameras configured, /summary reports 'no_cameras_configured'."
echo "[ TRIDENT ] Add cameras via ${CAMERA_CONFIG} (METHOD 1) or REOLINK_CAM1_* env vars in"
echo "[ TRIDENT ] ${CONFIG_ENV} (METHOD 2), then run: sudo systemctl restart ${SERVICE_NAME}"
