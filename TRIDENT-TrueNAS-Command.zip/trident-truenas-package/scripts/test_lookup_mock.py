#!/usr/bin/env python3
"""
Manual mock test for the new /clients and /lookup endpoints in network_service.py.
Stubs STATE with fake client/device data (no live UniFi needed) and exercises
the lookup() and clients() view functions directly through Flask's test client.
"""
import sys
sys.path.insert(0, "/home/user/workspace/trident/scripts")

import network_service as ns

# --- Stub STATE with fake data, bypassing poll_unifi()/UniFi entirely ---
with ns.LOCK:
    ns.STATE["status"] = "live"
    ns.STATE["clients"] = [
        {
            "mac": "AA:BB:CC:DD:EE:FF",
            "name": "Johns-iPhone",
            "ip": "192.168.0.42",
            "is_wired": False,
            "connected_to": "11:22:33:44:55:66",
            "uptime_sec": 3600,
            "last_seen": 1234567890,
            "signal": -55,
            "network": "Main",
            "essid": "HomeWiFi",
            "sw_port": None,
        },
        {
            "mac": "11:22:33:AA:BB:CC",
            "name": "Living-Room-TV",
            "ip": "192.168.0.55",
            "is_wired": True,
            "connected_to": "22:33:44:55:66:77",
            "uptime_sec": 90000,
            "last_seen": 1234567890,
            "signal": None,
            "network": "Main",
            "essid": None,
            "sw_port": 4,
        },
    ]
    ns.STATE["devices"] = [
        {
            "name": "Living Room Switch",
            "model": "USW-24-PoE",
            "mac": "22:33:44:55:66:77",
            "type": "usw",
            "state": 1,
            "state_label": "ONLINE",
            "ip": "192.168.0.2",
            "uptime_sec": 500000,
            "version": "6.5.0",
            "num_ports": 24,
            "ports_up": 10,
            "cpu_pct": 5,
            "mem_pct": 30,
            "satisfaction": 100,
        }
    ]

client = ns.app.test_client()

def run_case(label, url):
    resp = client.get(url)
    print(f"\n=== {label} ===")
    print(f"GET {url} -> HTTP {resp.status_code}")
    print(resp.get_json())

# 1. /clients endpoint returns full list, count matches
run_case("GET /clients (full list)", "/clients")

# 2. /lookup by exact MAC match (client)
run_case("GET /lookup?q=AA:BB:CC:DD:EE:FF (exact MAC, client)", "/lookup?q=AA:BB:CC:DD:EE:FF")

# 3. /lookup by partial MAC (no colons)
run_case("GET /lookup?q=aabbccddeeff (partial/no-colon MAC)", "/lookup?q=aabbccddeeff")

# 4. /lookup by partial name (case-insensitive)
run_case("GET /lookup?q=iphone (partial name match)", "/lookup?q=iphone")

# 5. /lookup by infrastructure device name ("living room switch")
run_case("GET /lookup?q=living room switch (infrastructure match)", "/lookup?q=living%20room%20switch")

# 6. /lookup with no match at all
run_case("GET /lookup?q=nonexistentdevice999 (no match)", "/lookup?q=nonexistentdevice999")

# 7. /lookup with missing query param -> 400
run_case("GET /lookup (missing q param, expect 400)", "/lookup")

# 8. Verify clients_count field/behavior still intact (existing shape preserved)
with ns.LOCK:
    ns.STATE["clients_count"] = len(ns.STATE["clients"])
run_case("GET /status (existing endpoint, shape preserved)", "/status")

print("\n--- ALL MOCK TESTS COMPLETED ---")
