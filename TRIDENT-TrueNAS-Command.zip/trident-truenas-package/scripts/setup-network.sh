#!/usr/bin/env bash
#
# TRIDENT Network Monitoring Service — installer
# Installs the Python UniFi monitoring service (WAN status + switch/AP/gateway
# health via the local UniFi OS API on a UDM/UDM-Pro/UDR) as a systemd unit on
# port 5011. Polls the UDM at 192.168.0.1 by default.
#
set -euo pipefail

echo "[ SETUP ] Before starting, ensure /etc/trident/config.env contains:"
echo "  UNIFI_HOST=192.168.0.1"
echo "  UNIFI_USER=<view-only account username>"
echo "  UNIFI_PASS=<view-only account password>"
echo "  UNIFI_SITE=default"

SERVICE_NAME="trident-network"
INSTALL_DIR="/opt/trident-network"
VENV_DIR="${INSTALL_DIR}/venv"
CONFIG_ENV="/etc/trident/config.env"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PORT=5011

echo "[ TRIDENT ] ═══ Network Monitoring Service Setup ═══"

# ── 1. Directories ──
echo "[ TRIDENT ] Creating ${INSTALL_DIR} ..."
sudo mkdir -p "${INSTALL_DIR}"
sudo mkdir -p "$(dirname "${CONFIG_ENV}")"

# ── 2. Python venv + dependencies ──
echo "[ TRIDENT ] Building virtualenv at ${VENV_DIR} ..."
sudo python3 -m venv "${VENV_DIR}"
sudo "${VENV_DIR}/bin/pip" install --upgrade pip
sudo "${VENV_DIR}/bin/pip" install flask flask-cors requests urllib3

# ── 3. Deploy service code ──
echo "[ TRIDENT ] Copying network_service.py ..."
sudo cp "${SCRIPT_DIR}/network_service.py" "${INSTALL_DIR}/network_service.py"

# ── 4. Ensure config env exists ──
if [ ! -f "${CONFIG_ENV}" ]; then
  echo "[ TRIDENT ] Creating ${CONFIG_ENV} ..."
  sudo tee "${CONFIG_ENV}" > /dev/null <<'ENVEOF'
# TRIDENT Network Monitoring config
# UniFi Dream Machine (UDM/UDM-Pro/UDR) running UniFi OS.
# UNIFI_USER / UNIFI_PASS must be a dedicated VIEW-ONLY local UniFi account —
# this service only performs GET/read operations, never configuration changes.
UNIFI_HOST=192.168.0.1
UNIFI_USER=
UNIFI_PASS=
UNIFI_SITE=default
ENVEOF
  echo "[ TRIDENT ] >>> EDIT ${CONFIG_ENV} NOW to set UNIFI_USER and UNIFI_PASS before starting the service. <<<"
else
  echo "[ TRIDENT ] ${CONFIG_ENV} already exists — leaving untouched."
  echo "[ TRIDENT ] Ensure it contains UNIFI_HOST, UNIFI_USER, UNIFI_PASS, UNIFI_SITE (see reminder above)."
fi

# ── 5. systemd unit ──
echo "[ TRIDENT ] Installing systemd unit ${SERVICE_NAME} ..."
sudo tee "/etc/systemd/system/${SERVICE_NAME}.service" > /dev/null <<EOF
[Unit]
Description=TRIDENT Network Monitoring Service (port ${PORT})
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
WorkingDirectory=${INSTALL_DIR}
EnvironmentFile=${CONFIG_ENV}
ExecStart=${VENV_DIR}/bin/python ${INSTALL_DIR}/network_service.py
Restart=always
RestartSec=5
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
EOF

# ── 6. Enable + start ──
echo "[ TRIDENT ] Reloading systemd and starting service ..."
sudo systemctl daemon-reload
sudo systemctl enable "${SERVICE_NAME}"
sudo systemctl restart "${SERVICE_NAME}"

# ── 7. Health check ──
echo "[ TRIDENT ] Waiting for service to come online ..."
sleep 3
echo "[ TRIDENT ] Health check:"
curl -fsS "http://127.0.0.1:${PORT}/health" && echo "" || {
  echo "[ TRIDENT ] Health check FAILED — inspect: sudo journalctl -u ${SERVICE_NAME} -n 50"
  exit 1
}

echo "[ TRIDENT ] ═══ Network Monitoring Service installed on port ${PORT} ═══"
echo "[ TRIDENT ] NOTE: Status will report 'offline' until UNIFI_USER/UNIFI_PASS are set in ${CONFIG_ENV}"
echo "[ TRIDENT ] and the UDM at \$UNIFI_HOST is reachable on the local network."
echo "[ TRIDENT ] Edit ${CONFIG_ENV} to point at a different UDM without touching code."
