#!/usr/bin/env python3
"""
TRIDENT Network Monitoring Service
Polls a UniFi Dream Machine (UDM/UDM-Pro) for WAN status, switch/port health, and connected clients
Runs on port 5011
"""
import os, time, threading, datetime
import requests
import urllib3
from flask import Flask, jsonify
from flask_cors import CORS

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

app = Flask(__name__)
CORS(app)

UNIFI_HOST = os.environ.get("UNIFI_HOST", "192.168.0.1")
UNIFI_USER = os.environ.get("UNIFI_USER", "")
UNIFI_PASS = os.environ.get("UNIFI_PASS", "")
UNIFI_SITE = os.environ.get("UNIFI_SITE", "default")
BASE_URL = f"https://{UNIFI_HOST}"

STATE = {
    "status": "offline",
    "last_success": None,
    "last_error": None,
    "wan": [],
    "devices": [],
    "clients_count": 0,
    "health": [],
}
LOCK = threading.Lock()

class UnifiSession:
    """Cookie-based UniFi OS session with CSRF header support and auto re-login on 401."""
    def __init__(self):
        self.session = requests.Session()
        self.session.verify = False
        self.logged_in = False
        self.csrf_token = None

    def login(self):
        if not UNIFI_USER or not UNIFI_PASS:
            raise Exception("UNIFI_USER / UNIFI_PASS not configured in /etc/trident/config.env")
        res = self.session.post(
            f"{BASE_URL}/api/auth/login",
            json={"username": UNIFI_USER, "password": UNIFI_PASS},
            timeout=10,
        )
        if res.status_code != 200:
            raise Exception(f"UniFi login failed: HTTP {res.status_code}")
        # UniFi OS returns an X-CSRF-Token header on login; must be echoed back
        # on subsequent state-changing (non-GET) requests.
        csrf = res.headers.get("X-CSRF-Token") or res.headers.get("x-csrf-token")
        if csrf:
            self.csrf_token = csrf
            self.session.headers.update({"X-CSRF-Token": csrf})
        self.logged_in = True

    def get(self, path):
        if not self.logged_in:
            self.login()
        url = f"{BASE_URL}{path}"
        res = self.session.get(url, timeout=10)
        if res.status_code == 401:
            # session expired — re-login once and retry
            self.logged_in = False
            self.login()
            res = self.session.get(url, timeout=10)
        res.raise_for_status()
        return res.json()

unifi = UnifiSession()

def poll_unifi():
    while True:
        try:
            # Site health (WAN status is included here for UDM)
            health_res = unifi.get(f"/proxy/network/api/s/{UNIFI_SITE}/stat/health")
            health_data = health_res.get("data", [])

            wan_subsystems = [h for h in health_data if h.get("subsystem") == "wan"]

            # Devices (switches, APs, gateway itself)
            devices_res = unifi.get(f"/proxy/network/api/s/{UNIFI_SITE}/stat/device")
            devices_data = devices_res.get("data", [])

            devices = []
            for d in devices_data:
                devices.append({
                    "name": d.get("name", d.get("model", "Unknown")),
                    "model": d.get("model"),
                    "mac": d.get("mac"),
                    "type": d.get("type"),  # 'usw' switch, 'uap' AP, 'ugw'/'udm' gateway
                    "state": d.get("state"),  # 1 = connected typically
                    "state_label": "ONLINE" if d.get("state") == 1 else "OFFLINE",
                    "ip": d.get("ip"),
                    "uptime_sec": d.get("uptime"),
                    "version": d.get("version"),
                    "num_ports": len(d.get("port_table", [])) if d.get("port_table") else None,
                    "ports_up": sum(1 for p in d.get("port_table", []) if p.get("up")) if d.get("port_table") else None,
                    "cpu_pct": d.get("system-stats", {}).get("cpu"),
                    "mem_pct": d.get("system-stats", {}).get("mem"),
                    "satisfaction": d.get("satisfaction"),
                })

            # Clients count
            clients_res = unifi.get(f"/proxy/network/api/s/{UNIFI_SITE}/stat/sta")
            clients_count = len(clients_res.get("data", []))

            with LOCK:
                STATE["wan"] = wan_subsystems
                STATE["devices"] = devices
                STATE["clients_count"] = clients_count
                STATE["health"] = health_data
                STATE["last_success"] = time.time()
                STATE["last_error"] = None
                STATE["status"] = "live"

        except Exception as e:
            with LOCK:
                STATE["last_error"] = str(e)
                STATE["status"] = "offline" if "login failed" in str(e).lower() or "not configured" in str(e).lower() else "stale"
            print(f"[ TRIDENT NETWORK ] Poll error: {e}", flush=True)

        time.sleep(15)  # network health doesn't need sub-10s polling

@app.route("/health")
def health():
    with LOCK:
        age = time.time() - STATE["last_success"] if STATE["last_success"] else None
        status = STATE["status"]
        if status == "live" and age and age > 60:
            status = "stale"
        return jsonify({
            "service": "TRIDENT Network Monitoring",
            "unifi_host": UNIFI_HOST,
            "status": status,
            "last_error": STATE["last_error"],
            "last_success_age_sec": age,
        })

@app.route("/status")
def status():
    with LOCK:
        return jsonify({
            "status": STATE["status"],
            "wan": STATE["wan"],
            "devices": STATE["devices"],
            "clients_count": STATE["clients_count"],
            "last_error": STATE["last_error"],
        })

@app.route("/devices")
def devices():
    with LOCK:
        return jsonify({"devices": STATE["devices"], "count": len(STATE["devices"])})

@app.route("/wan")
def wan():
    with LOCK:
        return jsonify({"wan": STATE["wan"]})

@app.route("/summary")
def summary():
    """Compact summary for COMMAND system status / full sitrep queries"""
    with LOCK:
        online_devices = [d for d in STATE["devices"] if d["state_label"] == "ONLINE"]
        offline_devices = [d for d in STATE["devices"] if d["state_label"] != "ONLINE"]
        wan_status = "UP" if STATE["wan"] and all(w.get("status") == "ok" or w.get("wan_ip") for w in STATE["wan"]) else ("UNKNOWN" if not STATE["wan"] else "DEGRADED")
        return jsonify({
            "status": STATE["status"],
            "wan_status": wan_status,
            "devices_online": len(online_devices),
            "devices_total": len(STATE["devices"]),
            "devices_offline_names": [d["name"] for d in offline_devices],
            "clients_connected": STATE["clients_count"],
            "last_error": STATE["last_error"],
        })

if __name__ == "__main__":
    threading.Thread(target=poll_unifi, daemon=True).start()
    print(f"[ TRIDENT ] Network Monitoring Service starting on port 5011, UniFi host: {UNIFI_HOST}")
    app.run(host="127.0.0.1", port=5011, debug=False)
