#!/usr/bin/env python3
"""
TRIDENT Geo-Intelligence Service
Aggregates ACLED, GDELT, and open RSS feeds
Runs on port 5003
"""
import os, json, time, datetime, hashlib
import requests
from flask import Flask, jsonify, request
from flask_cors import CORS
import xml.etree.ElementTree as ET

app = Flask(__name__)
CORS(app)

ACLED_EMAIL = os.environ.get("ACLED_EMAIL", "")
ACLED_PASSWORD = os.environ.get("ACLED_PASSWORD", "")
ACLED_TOKEN = None
ACLED_TOKEN_TS = 0

CACHE = {}
CACHE_TTL = 900  # 15 min cache for geo data

def get_cached(key):
    if key in CACHE and time.time() - CACHE[key]["ts"] < CACHE_TTL:
        return CACHE[key]["data"]
    return None

def set_cached(key, data):
    CACHE[key] = {"data": data, "ts": time.time()}

def get_acled_token():
    global ACLED_TOKEN, ACLED_TOKEN_TS
    if ACLED_TOKEN and time.time() - ACLED_TOKEN_TS < 82800:  # 23hr refresh
        return ACLED_TOKEN
    if not ACLED_EMAIL or not ACLED_PASSWORD:
        return None
    try:
        res = requests.post(
            "https://api.acleddata.com/authenticate/",
            json={"email": ACLED_EMAIL, "password": ACLED_PASSWORD},
            timeout=10
        )
        data = res.json()
        if data.get("success"):
            ACLED_TOKEN = data["data"]["access_token"]
            ACLED_TOKEN_TS = time.time()
            return ACLED_TOKEN
    except:
        pass
    return None

@app.route("/health")
def health():
    return jsonify({"status": "ok", "service": "TRIDENT Geo-Intelligence"})

@app.route("/acled/events")
def acled_events():
    """Recent conflict events from ACLED"""
    cached = get_cached("acled_events")
    if cached:
        return jsonify(cached)
    
    token = get_acled_token()
    if not token:
        return jsonify({"error": "ACLED not configured", "events": [], "count": 0}), 200
    
    try:
        params = {
            "key": token,
            "email": ACLED_EMAIL,
            "limit": 100,
            "fields": "event_id_cnty|event_date|event_type|sub_event_type|actor1|actor2|country|admin1|location|latitude|longitude|fatalities|notes|source",
            "date_range_start": (datetime.datetime.utcnow() - datetime.timedelta(days=30)).strftime("%Y-%m-%d"),
            "date_range_end": datetime.datetime.utcnow().strftime("%Y-%m-%d"),
        }
        res = requests.get("https://api.acleddata.com/acled/read.php", params=params, timeout=15)
        data = res.json()
        events = data.get("data", [])
        result = {"events": events, "count": len(events), "source": "ACLED"}
        set_cached("acled_events", result)
        return jsonify(result)
    except Exception as e:
        return jsonify({"error": str(e), "events": [], "count": 0}), 200

@app.route("/acled/summary")
def acled_summary():
    """Aggregate conflict stats by country"""
    cached = get_cached("acled_summary")
    if cached:
        return jsonify(cached)
    
    token = get_acled_token()
    if not token:
        return jsonify({"error": "ACLED not configured", "summary": []}), 200
    
    try:
        params = {
            "key": token,
            "email": ACLED_EMAIL,
            "limit": 500,
            "fields": "event_type|country|fatalities",
            "date_range_start": (datetime.datetime.utcnow() - datetime.timedelta(days=7)).strftime("%Y-%m-%d"),
            "date_range_end": datetime.datetime.utcnow().strftime("%Y-%m-%d"),
        }
        res = requests.get("https://api.acleddata.com/acled/read.php", params=params, timeout=15)
        data = res.json()
        events = data.get("data", [])
        
        # Aggregate by country
        by_country = {}
        for e in events:
            c = e.get("country", "Unknown")
            if c not in by_country:
                by_country[c] = {"country": c, "events": 0, "fatalities": 0, "types": {}}
            by_country[c]["events"] += 1
            by_country[c]["fatalities"] += int(e.get("fatalities", 0) or 0)
            etype = e.get("event_type", "Unknown")
            by_country[c]["types"][etype] = by_country[c]["types"].get(etype, 0) + 1
        
        summary = sorted(by_country.values(), key=lambda x: x["events"], reverse=True)[:30]
        result = {"summary": summary, "total_events": len(events), "source": "ACLED", "period_days": 7}
        set_cached("acled_summary", result)
        return jsonify(result)
    except Exception as e:
        return jsonify({"error": str(e), "summary": []}), 200

@app.route("/gdelt/events")
def gdelt_events():
    """Recent events from GDELT (no auth required)"""
    cached = get_cached("gdelt_events")
    if cached:
        return jsonify(cached)
    
    try:
        # GDELT GKG RSS — top global events
        url = "http://data.gdeltproject.org/gdeltv2/lastupdate.txt"
        res = requests.get(url, timeout=10)
        lines = res.text.strip().split("\n")
        
        events = []
        for line in lines[:5]:
            parts = line.split(" ")
            if len(parts) >= 3:
                events.append({"file": parts[2], "size": parts[0], "hash": parts[1]})
        
        result = {"events": events, "source": "GDELT", "note": "GDELT GDELTv2 latest update files"}
        set_cached("gdelt_events", result)
        return jsonify(result)
    except Exception as e:
        return jsonify({"error": str(e), "events": []}), 200

@app.route("/news/military")
def military_news():
    """Aggregate military/defense news from open RSS feeds"""
    cached = get_cached("military_news")
    if cached:
        return jsonify(cached)
    
    feeds = [
        ("Defense News", "https://www.defensenews.com/arc/outboundfeeds/rss/?outputType=xml"),
        ("Breaking Defense", "https://breakingdefense.com/feed/"),
        ("War on the Rocks", "https://warontherocks.com/feed/"),
        ("Janes", "https://www.janes.com/feeds/news"),
        ("Military Times", "https://www.militarytimes.com/rss/"),
        ("Reuters World", "https://feeds.reuters.com/Reuters/worldNews"),
    ]
    
    articles = []
    for source_name, feed_url in feeds:
        try:
            res = requests.get(feed_url, timeout=8, headers={"User-Agent": "TRIDENT/1.0"})
            root = ET.fromstring(res.content)
            
            # Handle both RSS and Atom
            items = root.findall(".//item") or root.findall(".//{http://www.w3.org/2005/Atom}entry")
            
            for item in items[:5]:
                title = item.findtext("title") or item.findtext("{http://www.w3.org/2005/Atom}title") or ""
                link = item.findtext("link") or item.findtext("{http://www.w3.org/2005/Atom}link") or ""
                pub = item.findtext("pubDate") or item.findtext("{http://www.w3.org/2005/Atom}published") or ""
                desc = item.findtext("description") or item.findtext("{http://www.w3.org/2005/Atom}summary") or ""
                
                if title:
                    articles.append({
                        "title": title.strip(),
                        "link": link.strip() if isinstance(link, str) else "",
                        "published": pub.strip(),
                        "description": desc.strip()[:300] if desc else "",
                        "source": source_name
                    })
        except:
            pass
    
    # Sort by freshness (roughly) — just return all collected
    result = {"articles": articles[:50], "source_count": len(feeds), "sources": [f[0] for f in feeds]}
    set_cached("military_news", result)
    return jsonify(result)

@app.route("/news/geopolitical")
def geopolitical_news():
    """Geopolitical news from open RSS feeds"""
    cached = get_cached("geo_news")
    if cached:
        return jsonify(cached)
    
    feeds = [
        ("Foreign Affairs", "https://www.foreignaffairs.com/rss.xml"),
        ("Foreign Policy", "https://foreignpolicy.com/feed/"),
        ("BBC World", "http://feeds.bbci.co.uk/news/world/rss.xml"),
        ("Al Jazeera", "https://www.aljazeera.com/xml/rss/all.xml"),
        ("AP World", "https://feeds.apnews.com/apf-worldnews"),
        ("Reuters Politics", "https://feeds.reuters.com/Reuters/PoliticsNews"),
    ]
    
    articles = []
    for source_name, feed_url in feeds:
        try:
            res = requests.get(feed_url, timeout=8, headers={"User-Agent": "TRIDENT/1.0"})
            root = ET.fromstring(res.content)
            items = root.findall(".//item") or root.findall(".//{http://www.w3.org/2005/Atom}entry")
            
            for item in items[:5]:
                title = item.findtext("title") or item.findtext("{http://www.w3.org/2005/Atom}title") or ""
                link = item.findtext("link") or ""
                pub = item.findtext("pubDate") or item.findtext("{http://www.w3.org/2005/Atom}published") or ""
                desc = item.findtext("description") or item.findtext("{http://www.w3.org/2005/Atom}summary") or ""
                
                if title:
                    articles.append({
                        "title": title.strip(),
                        "link": link.strip(),
                        "published": pub.strip(),
                        "description": desc.strip()[:300] if desc else "",
                        "source": source_name
                    })
        except:
            pass
    
    result = {"articles": articles[:50], "sources": [f[0] for f in feeds]}
    set_cached("geo_news", result)
    return jsonify(result)

@app.route("/threat-summary")
def threat_summary():
    """Aggregated threat data for dashboard"""
    acled_data = {}
    try:
        token = get_acled_token()
        if token:
            params = {
                "key": token, "email": ACLED_EMAIL, "limit": 200,
                "fields": "event_type|country|fatalities|latitude|longitude|event_date",
                "date_range_start": (datetime.datetime.utcnow() - datetime.timedelta(days=7)).strftime("%Y-%m-%d"),
                "date_range_end": datetime.datetime.utcnow().strftime("%Y-%m-%d"),
            }
            res = requests.get("https://api.acleddata.com/acled/read.php", params=params, timeout=15)
            events = res.json().get("data", [])
            
            total_fatalities = sum(int(e.get("fatalities", 0) or 0) for e in events)
            hotspots = {}
            for e in events:
                c = e.get("country", "Unknown")
                hotspots[c] = hotspots.get(c, 0) + 1
            
            top_hotspots = sorted(hotspots.items(), key=lambda x: x[1], reverse=True)[:5]
            
            acled_data = {
                "total_events_7d": len(events),
                "total_fatalities_7d": total_fatalities,
                "top_hotspots": [{"country": c, "events": n} for c, n in top_hotspots],
                "event_points": [{"lat": float(e.get("latitude", 0)), "lon": float(e.get("longitude", 0)), "type": e.get("event_type", ""), "country": e.get("country", ""), "fatalities": int(e.get("fatalities", 0) or 0)} for e in events if e.get("latitude") and e.get("longitude")]
            }
    except:
        acled_data = {"error": "ACLED unavailable"}
    
    return jsonify({
        "acled": acled_data,
        "timestamp": datetime.datetime.utcnow().isoformat(),
        "source": "ACLED + Open RSS"
    })

if __name__ == "__main__":
    print("[ TRIDENT ] Geo-Intelligence Service starting on port 5003")
    app.run(host="127.0.0.1", port=5003, debug=False)
