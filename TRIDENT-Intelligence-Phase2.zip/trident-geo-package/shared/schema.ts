import { sqliteTable, text, integer, real } from "drizzle-orm/sqlite-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// ═══════════════════════════════════════════════════
// USERS — Core identity table
// ═══════════════════════════════════════════════════
export const users = sqliteTable("users", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  username: text("username").notNull().unique(),
  email: text("email").notNull().unique(),
  password_hash: text("password_hash").notNull(),
  role: text("role", { enum: ["admin", "power_user", "user"] }).notNull().default("user"),
  created_at: text("created_at").notNull().default(""),
  last_login: text("last_login"),
  is_active: integer("is_active", { mode: "boolean" }).notNull().default(true),
});

// ═══════════════════════════════════════════════════
// SESSIONS — Token management
// ═══════════════════════════════════════════════════
export const sessions = sqliteTable("sessions", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  user_id: integer("user_id").notNull(),
  token_hash: text("token_hash").notNull(),
  expires_at: text("expires_at").notNull(),
  created_at: text("created_at").notNull().default(""),
});

// ═══════════════════════════════════════════════════
// Insert schemas (drizzle-zod)
// ═══════════════════════════════════════════════════
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  created_at: true,
  last_login: true,
});

export const insertSessionSchema = createInsertSchema(sessions).omit({
  id: true,
  created_at: true,
});

// ═══════════════════════════════════════════════════
// Types
// ═══════════════════════════════════════════════════
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertSession = z.infer<typeof insertSessionSchema>;
export type Session = typeof sessions.$inferSelect;

// ═══════════════════════════════════════════════════
// Frontend-safe user type (no password hash)
// ═══════════════════════════════════════════════════
export type SafeUser = Omit<User, "password_hash">;

// ═══════════════════════════════════════════════════
// CONVERSATIONS — One per chat session per user
// ═══════════════════════════════════════════════════
export const conversations = sqliteTable("conversations", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  user_id: integer("user_id").notNull(),
  title: text("title").notNull().default("NEW CONVERSATION"),
  model: text("model").notNull(),
  system_prompt: text("system_prompt").default(""),
  created_at: text("created_at").notNull(),
  updated_at: text("updated_at").notNull(),
});

// ═══════════════════════════════════════════════════
// MESSAGES — Individual chat messages
// ═══════════════════════════════════════════════════
export const messages = sqliteTable("messages", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  conversation_id: integer("conversation_id").notNull(),
  role: text("role", { enum: ["user", "assistant", "system"] }).notNull(),
  content: text("content").notNull(),
  created_at: text("created_at").notNull(),
});

// ═══════════════════════════════════════════════════
// MODEL_CONFIGS — Per-user model parameter preferences
// ═══════════════════════════════════════════════════
export const modelConfigs = sqliteTable("model_configs", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  user_id: integer("user_id").notNull(),
  model_name: text("model_name").notNull(),
  temperature: real("temperature").default(0.7),
  max_tokens: integer("max_tokens").default(2048),
  top_p: real("top_p").default(0.9),
  system_prompt: text("system_prompt").default(""),
  updated_at: text("updated_at").notNull(),
});

// ═══════════════════════════════════════════════════
// Insert schemas — Phase 2
// ═══════════════════════════════════════════════════
export const insertConversationSchema = createInsertSchema(conversations).omit({
  id: true,
});

export const insertMessageSchema = createInsertSchema(messages).omit({
  id: true,
});

export const insertModelConfigSchema = createInsertSchema(modelConfigs).omit({
  id: true,
});

// ═══════════════════════════════════════════════════
// Types — Phase 2
// ═══════════════════════════════════════════════════
export type InsertConversation = z.infer<typeof insertConversationSchema>;
export type Conversation = typeof conversations.$inferSelect;
export type InsertMessage = z.infer<typeof insertMessageSchema>;
export type Message = typeof messages.$inferSelect;
export type InsertModelConfig = z.infer<typeof insertModelConfigSchema>;
export type ModelConfig = typeof modelConfigs.$inferSelect;

// ═══════════════════════════════════════════════════
// VOICE_SESSIONS — Phase 3: Voice conversation sessions
// ═══════════════════════════════════════════════════
export const voiceSessions = sqliteTable("voice_sessions", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  user_id: integer("user_id").notNull(),
  conversation_id: integer("conversation_id"),
  created_at: text("created_at").notNull(),
  duration_seconds: integer("duration_seconds").default(0),
  message_count: integer("message_count").default(0),
});

// ═══════════════════════════════════════════════════
// Insert schemas — Phase 3
// ═══════════════════════════════════════════════════
export const insertVoiceSessionSchema = createInsertSchema(voiceSessions).omit({
  id: true,
});

// ═══════════════════════════════════════════════════
// Types — Phase 3
// ═══════════════════════════════════════════════════
export type InsertVoiceSession = z.infer<typeof insertVoiceSessionSchema>;
export type VoiceSession = typeof voiceSessions.$inferSelect;

// ═══════════════════════════════════════════════════
// GENERATED_IMAGES — Phase 4: Image generation history
// ═══════════════════════════════════════════════════
export const generatedImages = sqliteTable("generated_images", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  user_id: integer("user_id").notNull(),
  prompt: text("prompt").notNull(),
  negative_prompt: text("negative_prompt").default(""),
  model: text("model").notNull().default("stable-diffusion"),
  width: integer("width").default(512),
  height: integer("height").default(512),
  steps: integer("steps").default(20),
  cfg_scale: real("cfg_scale").default(7.0),
  seed: integer("seed").default(-1),
  actual_seed: integer("actual_seed"),
  image_path: text("image_path").notNull(),
  thumbnail_path: text("thumbnail_path"),
  created_at: text("created_at").notNull(),
  is_favorite: integer("is_favorite").default(0),
});

// ═══════════════════════════════════════════════════
// Insert schemas — Phase 4
// ═══════════════════════════════════════════════════
export const insertGeneratedImageSchema = createInsertSchema(generatedImages).omit({
  id: true,
});

// ═══════════════════════════════════════════════════
// Types — Phase 4
// ═══════════════════════════════════════════════════
export type InsertGeneratedImage = z.infer<typeof insertGeneratedImageSchema>;
export type GeneratedImage = typeof generatedImages.$inferSelect;

// ═══════════════════════════════════════════════════
// CONVERSATION_FILES — Phase 5: Files attached to conversations for LLM context
// ═══════════════════════════════════════════════════
export const conversationFiles = sqliteTable("conversation_files", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  conversation_id: integer("conversation_id").notNull(),
  user_id: integer("user_id").notNull(),
  filename: text("filename").notNull(),
  stored_filename: text("stored_filename").notNull(),
  file_path: text("file_path").notNull(),
  mime_type: text("mime_type").notNull(),
  file_size: integer("file_size").notNull(),
  extracted_text: text("extracted_text"),
  extraction_status: text("extraction_status").notNull().default("pending"),
  created_at: text("created_at").notNull(),
});

// ═══════════════════════════════════════════════════
// Insert schemas — Phase 5
// ═══════════════════════════════════════════════════
export const insertConversationFileSchema = createInsertSchema(conversationFiles).omit({
  id: true,
});

// ═══════════════════════════════════════════════════
// Types — Phase 5
// ═══════════════════════════════════════════════════
export type InsertConversationFile = z.infer<typeof insertConversationFileSchema>;
export type ConversationFile = typeof conversationFiles.$inferSelect;

// ═══════════════════════════════════════════════════
// API_KEYS — Phase 6: API key management
// ═══════════════════════════════════════════════════
export const apiKeys = sqliteTable("api_keys", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  user_id: integer("user_id").notNull(),
  key_hash: text("key_hash").notNull().unique(),
  key_prefix: text("key_prefix").notNull(),
  name: text("name").notNull(),
  created_at: text("created_at").notNull(),
  last_used: text("last_used"),
  is_active: integer("is_active").default(1),
});

// ═══════════════════════════════════════════════════
// Insert schemas — Phase 6
// ═══════════════════════════════════════════════════
export const insertApiKeySchema = createInsertSchema(apiKeys).omit({
  id: true,
});

// ═══════════════════════════════════════════════════
// Types — Phase 6
// ═══════════════════════════════════════════════════
export type InsertApiKey = z.infer<typeof insertApiKeySchema>;
export type ApiKey = typeof apiKeys.$inferSelect;

// ═══════════════════════════════════════════════════
// TOOL_CONFIGS — Phase 8: User-configured tool endpoints and credentials
// ═══════════════════════════════════════════════════
export const toolConfigs = sqliteTable("tool_configs", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  user_id: integer("user_id").notNull(),
  tool_name: text("tool_name").notNull(),
  config: text("config").notNull(),
  is_enabled: integer("is_enabled").default(1),
  created_at: text("created_at").notNull(),
  updated_at: text("updated_at").notNull(),
});

// ═══════════════════════════════════════════════════
// SCHEDULED_TASKS — Phase 8: LLM-defined monitoring jobs
// ═══════════════════════════════════════════════════
export const scheduledTasks = sqliteTable("scheduled_tasks", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  user_id: integer("user_id").notNull(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  tool_name: text("tool_name").notNull(),
  tool_action: text("tool_action").notNull(),
  tool_params: text("tool_params").notNull(),
  schedule_cron: text("schedule_cron").notNull(),
  is_active: integer("is_active").default(1),
  last_run: text("last_run"),
  last_result: text("last_result"),
  alert_condition: text("alert_condition"),
  created_at: text("created_at").notNull(),
});

// ═══════════════════════════════════════════════════
// TASK_RUNS — Phase 8: History of scheduled task executions
// ═══════════════════════════════════════════════════
export const taskRuns = sqliteTable("task_runs", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  task_id: integer("task_id").notNull(),
  user_id: integer("user_id").notNull(),
  started_at: text("started_at").notNull(),
  completed_at: text("completed_at"),
  status: text("status").notNull().default("running"),
  result: text("result"),
  alert_triggered: integer("alert_triggered").default(0),
  error: text("error"),
});

// ═══════════════════════════════════════════════════
// Insert schemas — Phase 8
// ═══════════════════════════════════════════════════
export const insertToolConfigSchema = createInsertSchema(toolConfigs).omit({
  id: true,
});

export const insertScheduledTaskSchema = createInsertSchema(scheduledTasks).omit({
  id: true,
});

export const insertTaskRunSchema = createInsertSchema(taskRuns).omit({
  id: true,
});

// ═══════════════════════════════════════════════════
// Types — Phase 8
// ═══════════════════════════════════════════════════
export type InsertToolConfig = z.infer<typeof insertToolConfigSchema>;
export type ToolConfig = typeof toolConfigs.$inferSelect;
export type InsertScheduledTask = z.infer<typeof insertScheduledTaskSchema>;
export type ScheduledTask = typeof scheduledTasks.$inferSelect;
export type InsertTaskRun = z.infer<typeof insertTaskRunSchema>;
export type TaskRun = typeof taskRuns.$inferSelect;

// ═══════════════════════════════════════════════════
// System Config — Hardware acceleration settings
// ═══════════════════════════════════════════════════
export const systemConfig = sqliteTable("system_config", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  key: text("key").notNull().unique(),
  value: text("value").notNull(),
  updated_at: text("updated_at").notNull(),
});

export const insertSystemConfigSchema = createInsertSchema(systemConfig).omit({ id: true });
export type InsertSystemConfig = z.infer<typeof insertSystemConfigSchema>;
export type SystemConfig = typeof systemConfig.$inferSelect;

// ═══════════════════════════════════════════════════
// INTELLIGENCE — Markets & Daily Brief (Phase 1)
// ═══════════════════════════════════════════════════

// market_watchlist — user's tracked symbols
export const marketWatchlist = sqliteTable("market_watchlist", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  user_id: integer("user_id").notNull(),
  symbol: text("symbol").notNull(),
  name: text("name").notNull().default(""),
  category: text("category").notNull().default("stock"), // stock|crypto|commodity|index|fx
  display_order: integer("display_order").default(0),
  created_at: text("created_at").notNull(),
});

// daily_briefs — AI-generated market briefs
export const dailyBriefs = sqliteTable("daily_briefs", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  user_id: integer("user_id").notNull(),
  date: text("date").notNull(), // YYYY-MM-DD
  content: text("content").notNull(), // markdown brief
  model_used: text("model_used").notNull(),
  created_at: text("created_at").notNull(),
});

// news_cache — cached financial news articles
export const newsCache = sqliteTable("news_cache", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  symbol: text("symbol").notNull().default("MARKET"),
  title: text("title").notNull(),
  publisher: text("publisher").notNull().default(""),
  link: text("link").notNull(),
  published_at: integer("published_at").notNull(), // unix timestamp
  summary: text("summary").default(""),
  cached_at: text("cached_at").notNull(),
});

export const insertMarketWatchlistSchema = createInsertSchema(marketWatchlist).omit({ id: true });
export const insertDailyBriefSchema = createInsertSchema(dailyBriefs).omit({ id: true });
export const insertNewsCacheSchema = createInsertSchema(newsCache).omit({ id: true });

export type InsertMarketWatchlist = z.infer<typeof insertMarketWatchlistSchema>;
export type MarketWatchlist = typeof marketWatchlist.$inferSelect;
export type InsertDailyBrief = z.infer<typeof insertDailyBriefSchema>;
export type DailyBrief = typeof dailyBriefs.$inferSelect;
export type InsertNewsCache = z.infer<typeof insertNewsCacheSchema>;
export type NewsCache = typeof newsCache.$inferSelect;

// ═══════════════════════════════════════════════════
// GEO-INTELLIGENCE (Phase 2)
// ═══════════════════════════════════════════════════

// geo_events_cache — cached conflict events (ACLED / GDELT)
export const geoEventsCache = sqliteTable("geo_events_cache", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  source: text("source").notNull(), // "acled" | "gdelt"
  event_id: text("event_id").notNull().unique(),
  event_date: text("event_date").notNull(),
  event_type: text("event_type").notNull(),
  country: text("country").notNull(),
  location: text("location").notNull().default(""),
  latitude: real("latitude").notNull().default(0),
  longitude: real("longitude").notNull().default(0),
  fatalities: integer("fatalities").default(0),
  description: text("description").default(""),
  cached_at: text("cached_at").notNull(),
});

// geo_briefs — AI-generated geo-intelligence briefs
export const geoBriefs = sqliteTable("geo_briefs", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  user_id: integer("user_id").notNull(),
  date: text("date").notNull(), // YYYY-MM-DD
  content: text("content").notNull(),
  model_used: text("model_used").notNull(),
  region_focus: text("region_focus").default("GLOBAL"),
  created_at: text("created_at").notNull(),
});

export const insertGeoEventsCacheSchema = createInsertSchema(geoEventsCache).omit({ id: true });
export const insertGeoBriefSchema = createInsertSchema(geoBriefs).omit({ id: true });

export type InsertGeoEventsCache = z.infer<typeof insertGeoEventsCacheSchema>;
export type GeoEventsCache = typeof geoEventsCache.$inferSelect;
export type InsertGeoBrief = z.infer<typeof insertGeoBriefSchema>;
export type GeoBrief = typeof geoBriefs.$inferSelect;
