import { useState, useMemo } from "react";
import {
  TrendingUp,
  TrendingDown,
  Plus,
  X,
  Radio,
  FileText,
  BarChart3,
  Newspaper,
  Loader2,
  RefreshCw,
  Activity,
  Trash2,
  ArrowUpRight,
  ExternalLink,
  Globe,
  Skull,
  Crosshair,
  Database,
} from "lucide-react";
import { getAuthHeaders } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useQueryClient, useMutation } from "@tanstack/react-query";
import type { MarketWatchlist, DailyBrief, GeoBrief } from "@shared/schema";

const API_BASE = "__PORT_5000__".startsWith("__") ? "" : "__PORT_5000__";

// ═══════════════════════════════════════════════════
// Types
// ═══════════════════════════════════════════════════
interface QuotePoint { t: string; o: number; h: number; l: number; c: number; v: number; }
interface Quote {
  symbol: string;
  price: number;
  change: number;
  change_pct: number;
  prev_close?: number;
  high?: number;
  low?: number;
  volume?: number;
  market_cap?: number;
  intraday?: QuotePoint[];
}
interface OverviewItem { symbol: string; price: number; change_pct: number; change: number; }
interface MacroIndicator {
  id: string; label: string; value: string; date: string;
  prev_value: string; prev_date: string;
}
interface NewsItem {
  title: string; publisher: string; link: string;
  published: number; summary: string; type: string;
}

type TabKey = "markets" | "brief" | "macro" | "news" | "geo";

// ── Geo-Intelligence types ──
interface GeoHotspot { country: string; events: number; }
interface GeoThreatSummary {
  acled: {
    total_events_7d?: number;
    total_fatalities_7d?: number;
    top_hotspots?: GeoHotspot[];
    error?: string;
  };
  timestamp?: string;
  source?: string;
}
interface GeoArticle {
  title: string;
  link: string;
  published: string;
  description: string;
  source: string;
}

// ═══════════════════════════════════════════════════
// Helpers
// ═══════════════════════════════════════════════════
async function apiGet<T>(path: string): Promise<T> {
  const res = await fetch(`${API_BASE}${path}`, { headers: getAuthHeaders() });
  if (!res.ok) throw new Error(`Request failed: ${res.status}`);
  return res.json();
}

function fmtNum(n: number | undefined, digits = 2): string {
  if (n === undefined || n === null || isNaN(n)) return "—";
  return n.toLocaleString("en-US", { minimumFractionDigits: digits, maximumFractionDigits: digits });
}
function fmtCompact(n: number | undefined): string {
  if (!n || isNaN(n)) return "—";
  if (n >= 1e12) return `${(n / 1e12).toFixed(2)}T`;
  if (n >= 1e9) return `${(n / 1e9).toFixed(2)}B`;
  if (n >= 1e6) return `${(n / 1e6).toFixed(2)}M`;
  if (n >= 1e3) return `${(n / 1e3).toFixed(2)}K`;
  return `${n}`;
}
function timeAgo(unixSeconds: number): string {
  if (!unixSeconds) return "";
  const diff = Date.now() / 1000 - unixSeconds;
  if (diff < 60) return "JUST NOW";
  if (diff < 3600) return `${Math.floor(diff / 60)}M AGO`;
  if (diff < 86400) return `${Math.floor(diff / 3600)}H AGO`;
  return `${Math.floor(diff / 86400)}D AGO`;
}

// ═══════════════════════════════════════════════════
// SVG Line Chart
// ���══════════════════════════════════════════════════
function LineChart({
  data,
  height = 240,
  color = "#00f0ff",
}: {
  data: { t: string; c: number }[];
  height?: number;
  color?: string;
}) {
  const W = 800;
  const H = height;
  const padX = 8;
  const padY = 16;

  const geometry = useMemo(() => {
    if (!data || data.length < 2) return null;
    const vals = data.map((d) => d.c);
    const min = Math.min(...vals);
    const max = Math.max(...vals);
    const range = max - min || 1;
    const n = data.length;
    const points = data.map((d, i) => {
      const x = padX + (i / (n - 1)) * (W - padX * 2);
      const y = padY + (1 - (d.c - min) / range) * (H - padY * 2);
      return { x, y, c: d.c, t: d.t };
    });
    const line = points.map((p, i) => `${i === 0 ? "M" : "L"} ${p.x.toFixed(1)} ${p.y.toFixed(1)}`).join(" ");
    const area = `${line} L ${points[points.length - 1].x.toFixed(1)} ${H - padY} L ${points[0].x.toFixed(1)} ${H - padY} Z`;
    const last = points[points.length - 1];
    return { points, line, area, min, max, last };
  }, [data, H]);

  if (!geometry) {
    return (
      <div
        className="flex items-center justify-center border border-trident-border/50 bg-black/40 font-mono text-[10px] uppercase tracking-widest text-trident-text/40"
        style={{ height }}
        data-testid="chart-empty"
      >
        NO SIGNAL DATA
      </div>
    );
  }

  const gridLines = 4;
  return (
    <div className="relative w-full border border-trident-border/50 bg-black/40" style={{ height }}>
      <svg viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none" width="100%" height={height} data-testid="chart-svg">
        <defs>
          <linearGradient id="chartFill" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={color} stopOpacity="0.28" />
            <stop offset="100%" stopColor={color} stopOpacity="0" />
          </linearGradient>
        </defs>
        {/* grid */}
        {Array.from({ length: gridLines + 1 }).map((_, i) => {
          const y = padY + (i / gridLines) * (H - padY * 2);
          return (
            <line key={i} x1={padX} y1={y} x2={W - padX} y2={y}
              stroke="#1a3a4a" strokeWidth="0.5" strokeDasharray="2 4" />
          );
        })}
        {/* current price dashed line */}
        <line x1={padX} y1={geometry.last.y} x2={W - padX} y2={geometry.last.y}
          stroke={color} strokeWidth="0.6" strokeDasharray="4 4" opacity="0.5" />
        {/* area + line */}
        <path d={geometry.area} fill="url(#chartFill)" />
        <path d={geometry.line} fill="none" stroke={color} strokeWidth="1.6"
          style={{ filter: `drop-shadow(0 0 4px ${color}90)` }} />
        {/* current price marker */}
        <circle cx={geometry.last.x} cy={geometry.last.y} r="3" fill={color}
          style={{ filter: `drop-shadow(0 0 6px ${color})` }} />
      </svg>
      {/* Y-axis labels */}
      <div className="pointer-events-none absolute inset-0 flex flex-col justify-between p-1 font-mono text-[9px] tabular-nums text-trident-text/40">
        <span>{fmtNum(geometry.max)}</span>
        <span>{fmtNum(geometry.min)}</span>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════
// Small colored change display
// ═══════════════════════════════════════════════════
function Change({ pct, abs, size = "sm" }: { pct: number; abs?: number; size?: "sm" | "lg" }) {
  const up = pct >= 0;
  const cls = up ? "text-trident-green" : "text-trident-red";
  const Arrow = up ? TrendingUp : TrendingDown;
  return (
    <span className={`inline-flex items-center gap-1 font-mono tabular-nums ${cls} ${size === "lg" ? "text-lg" : "text-xs"}`}>
      <Arrow className={size === "lg" ? "w-4 h-4" : "w-3 h-3"} />
      {abs !== undefined && <span>{up ? "+" : ""}{fmtNum(abs)}</span>}
      <span>({up ? "+" : ""}{fmtNum(pct)}%)</span>
    </span>
  );
}

// ═══════════════════════════════════════════════════
// Minimal markdown renderer (TRIDENT styled)
// ═══════════════════════════════════════════════════
function BriefMarkdown({ content }: { content: string }) {
  const lines = content.split("\n");
  return (
    <div className="space-y-2 font-mono text-sm leading-relaxed text-trident-text/90" data-testid="brief-content">
      {lines.map((raw, i) => {
        const line = raw.trimEnd();
        if (!line.trim()) return <div key={i} className="h-2" />;
        // headings: markdown ## or numbered section headers
        const headingMatch = line.match(/^#{1,6}\s+(.*)$/);
        const numberedSection = line.match(/^\s*(\d+)\.\s+([A-Z][A-Z\s/&-]{3,})$/);
        if (headingMatch || numberedSection) {
          const text = (headingMatch ? headingMatch[1] : `${numberedSection![1]}. ${numberedSection![2]}`).replace(/\*\*/g, "");
          return (
            <h3 key={i} className="pt-3 font-display text-xs uppercase tracking-[0.2em] text-trident-cyan text-glow-cyan">
              {text}
            </h3>
          );
        }
        // bullet
        const bulletMatch = line.match(/^\s*[-*]\s+(.*)$/);
        if (bulletMatch) {
          return (
            <div key={i} className="flex gap-2 pl-2">
              <span className="text-trident-amber">▸</span>
              <span>{bulletMatch[1].replace(/\*\*(.*?)\*\*/g, "$1")}</span>
            </div>
          );
        }
        return <p key={i}>{line.replace(/\*\*(.*?)\*\*/g, "$1")}</p>;
      })}
    </div>
  );
}

// ═══════════════════════════════════════════════════
// Category badge helper
// ═══════════════════════════════════════════════════
function detectCategory(symbol: string): string {
  const s = symbol.toUpperCase();
  if (s.includes("-USD") || s.includes("USDT")) return "crypto";
  if (s.endsWith("=F")) return "commodity";
  if (s.startsWith("^")) return "index";
  if (s.endsWith("=X") || s.includes("USD")) return "fx";
  return "stock";
}

// ═══════════════════════════════════════════════════
// MAIN PAGE
// ═══════════════════════════════════════════════════
export default function DashboardIntelligence() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [tab, setTab] = useState<TabKey>("markets");
  const [selectedSymbol, setSelectedSymbol] = useState<string | null>(null);
  const [histPeriod, setHistPeriod] = useState<string>("intraday");
  const [addOpen, setAddOpen] = useState(false);
  const [newSymbol, setNewSymbol] = useState("");
  const [newsFilter, setNewsFilter] = useState<"MARKET" | "SYMBOL">("MARKET");
  const [selectedBriefId, setSelectedBriefId] = useState<number | null>(null);

  // ── Market service status ──
  const { data: statusData } = useQuery<{ online: boolean }>({
    queryKey: ["/api/markets/status"],
    staleTime: 0,
    refetchInterval: 30000,
    queryFn: () => apiGet("/api/markets/status"),
  });
  const serviceOnline = statusData?.online ?? false;

  // ── Watchlist ──
  const { data: wlData } = useQuery<{ watchlist: MarketWatchlist[] }>({
    queryKey: ["/api/markets/watchlist"],
    staleTime: 0,
    queryFn: () => apiGet("/api/markets/watchlist"),
  });
  const watchlist = wlData?.watchlist ?? [];
  const wlSymbols = watchlist.map((w) => w.symbol).join(",");

  // ── Live quotes for watchlist (auto-refresh 60s) ──
  const { data: quotesData } = useQuery<{ quotes: OverviewItem[] }>({
    queryKey: ["/api/markets/quotes", wlSymbols],
    enabled: wlSymbols.length > 0,
    staleTime: 0,
    refetchInterval: 60000,
    queryFn: () => apiGet(`/api/markets/quotes?symbols=${encodeURIComponent(wlSymbols)}`),
  });
  const quoteMap = useMemo(() => {
    const m: Record<string, OverviewItem> = {};
    (quotesData?.quotes || []).forEach((q) => { m[q.symbol.toUpperCase()] = q; });
    return m;
  }, [quotesData]);

  // ── Add / remove watchlist ──
  const addMut = useMutation({
    mutationFn: async (symbol: string) => {
      const res = await fetch(`${API_BASE}/api/markets/watchlist`, {
        method: "POST",
        headers: { "Content-Type": "application/json", ...getAuthHeaders() },
        body: JSON.stringify({ symbol, category: detectCategory(symbol) }),
      });
      if (!res.ok) {
        const j = await res.json().catch(() => ({}));
        throw new Error(j.error || "FAILED TO ADD");
      }
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/markets/watchlist"] });
      setNewSymbol("");
      setAddOpen(false);
      toast({ title: "SYMBOL ADDED" });
    },
    onError: (e: any) => toast({ title: e.message || "ERROR", variant: "destructive" }),
  });
  const removeMut = useMutation({
    mutationFn: async (id: number) => {
      const res = await fetch(`${API_BASE}/api/markets/watchlist/${id}`, {
        method: "DELETE",
        headers: getAuthHeaders(),
      });
      if (!res.ok) throw new Error("FAILED TO REMOVE");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/markets/watchlist"] });
      toast({ title: "SYMBOL REMOVED" });
    },
  });

  return (
    <div className="flex h-full flex-col" data-testid="page-intelligence">
      {/* ═══════════ HEADER + TABS ═══════════ */}
      <div className="mb-3 flex flex-wrap items-center justify-between gap-3 border-b border-trident-border pb-3">
        <div className="flex items-center gap-2">
          <Activity className="h-5 w-5 text-trident-amber" style={{ filter: "drop-shadow(0 0 6px #ff6b00)" }} />
          <h1 className="font-display text-sm uppercase tracking-[0.25em] text-trident-cyan text-glow-cyan">
            INTELLIGENCE COMMAND
          </h1>
        </div>
        <nav className="flex gap-1">
          {([
            { k: "markets", label: "MARKETS", icon: BarChart3 },
            { k: "brief", label: "BRIEF", icon: FileText },
            { k: "macro", label: "MACRO", icon: TrendingUp },
            { k: "news", label: "NEWS", icon: Newspaper },
            { k: "geo", label: "GEO-INTEL", icon: Globe },
          ] as { k: TabKey; label: string; icon: any }[]).map(({ k, label, icon: Icon }) => (
            <button
              key={k}
              onClick={() => setTab(k)}
              data-testid={`tab-${k}`}
              className={`flex items-center gap-1.5 border px-3 py-1.5 font-mono text-[10px] uppercase tracking-widest transition-all ${
                tab === k
                  ? "border-trident-cyan/60 bg-trident-cyan/10 text-trident-cyan text-glow-cyan"
                  : "border-trident-border text-trident-text/50 hover:border-trident-cyan/30 hover:text-trident-cyan"
              }`}
            >
              <Icon className="h-3 w-3" />
              {label}
            </button>
          ))}
        </nav>
      </div>

      {/* ═══════════ BODY ═══════════ */}
      {tab === "geo" ? (
        <div className="min-h-0 flex-1 overflow-y-auto">
          <GeoIntelTab />
        </div>
      ) : (
      <div className="flex min-h-0 flex-1 gap-3">
        {/* ── WATCHLIST PANEL ── */}
        <aside className="flex w-[220px] flex-shrink-0 flex-col border border-trident-border bg-trident-surface/40" data-testid="watchlist-panel">
          <div className="flex items-center justify-between border-b border-trident-border px-3 py-2">
            <span className="font-mono text-[10px] uppercase tracking-widest text-trident-text/60">WATCHLIST</span>
            <span className="flex items-center gap-1.5" title={serviceOnline ? "Market service online" : "Market service offline"}>
              <span
                className={`inline-block h-1.5 w-1.5 rounded-full ${serviceOnline ? "bg-trident-green animate-pulse" : "bg-trident-red"}`}
                style={serviceOnline ? { boxShadow: "0 0 6px #00ff41" } : { boxShadow: "0 0 6px #ff2244" }}
                data-testid="status-market-service"
              />
              <span className={`font-mono text-[8px] uppercase tracking-widest ${serviceOnline ? "text-trident-green" : "text-trident-red"}`}>
                {serviceOnline ? "LIVE" : "OFF"}
              </span>
            </span>
          </div>

          <div className="min-h-0 flex-1 overflow-y-auto">
            {watchlist.length === 0 && (
              <div className="p-3 font-mono text-[10px] uppercase tracking-widest text-trident-text/40">
                NO SYMBOLS TRACKED
              </div>
            )}
            {watchlist.map((w) => {
              const q = quoteMap[w.symbol.toUpperCase()];
              const pct = q?.change_pct ?? 0;
              const up = pct >= 0;
              const active = selectedSymbol === w.symbol;
              return (
                <div
                  key={w.id}
                  onClick={() => { setSelectedSymbol(w.symbol); setHistPeriod("intraday"); setTab("markets"); }}
                  data-testid={`row-watchlist-${w.symbol}`}
                  className={`group flex cursor-pointer items-center justify-between border-l-2 px-3 py-2 transition-all ${
                    active
                      ? "border-trident-amber bg-trident-cyan/8"
                      : "border-transparent hover:bg-trident-cyan/5"
                  }`}
                >
                  <div className="min-w-0">
                    <div className="flex items-center gap-1">
                      <span className="font-mono text-xs font-bold text-trident-text">{w.symbol}</span>
                    </div>
                    <div className="truncate font-mono text-[9px] uppercase tracking-wide text-trident-text/40">
                      {w.name || w.category}
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="text-right">
                      <div className="font-mono text-[11px] tabular-nums text-trident-text/80">
                        {q ? fmtNum(q.price) : "—"}
                      </div>
                      <div className={`flex items-center justify-end gap-0.5 font-mono text-[9px] tabular-nums ${up ? "text-trident-green" : "text-trident-red"}`}>
                        {up ? <TrendingUp className="h-2.5 w-2.5" /> : <TrendingDown className="h-2.5 w-2.5" />}
                        {up ? "+" : ""}{fmtNum(pct)}%
                      </div>
                    </div>
                    <button
                      onClick={(e) => { e.stopPropagation(); removeMut.mutate(w.id); }}
                      className="opacity-0 transition-opacity group-hover:opacity-100"
                      data-testid={`button-remove-${w.symbol}`}
                    >
                      <X className="h-3 w-3 text-trident-red/60 hover:text-trident-red" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Add symbol */}
          <div className="border-t border-trident-border p-2">
            {addOpen ? (
              <div className="space-y-2">
                <input
                  autoFocus
                  value={newSymbol}
                  onChange={(e) => setNewSymbol(e.target.value.toUpperCase())}
                  onKeyDown={(e) => { if (e.key === "Enter" && newSymbol.trim()) addMut.mutate(newSymbol.trim()); }}
                  placeholder="TICKER e.g. AAPL"
                  data-testid="input-add-symbol"
                  className="w-full border border-trident-border bg-black/40 px-2 py-1.5 font-mono text-[11px] uppercase tracking-widest text-trident-cyan placeholder:text-trident-text/30 focus:border-trident-cyan focus:outline-none"
                />
                <div className="flex gap-1">
                  <button
                    onClick={() => newSymbol.trim() && addMut.mutate(newSymbol.trim())}
                    disabled={addMut.isPending}
                    data-testid="button-confirm-add"
                    className="flex-1 border border-trident-green/40 bg-trident-green/10 py-1 font-mono text-[9px] uppercase tracking-widest text-trident-green hover:bg-trident-green/20"
                  >
                    {addMut.isPending ? <Loader2 className="mx-auto h-3 w-3 animate-spin" /> : "CONFIRM"}
                  </button>
                  <button
                    onClick={() => { setAddOpen(false); setNewSymbol(""); }}
                    className="border border-trident-border px-2 py-1 font-mono text-[9px] uppercase tracking-widest text-trident-text/50 hover:text-trident-red"
                  >
                    <X className="h-3 w-3" />
                  </button>
                </div>
              </div>
            ) : (
              <button
                onClick={() => setAddOpen(true)}
                data-testid="button-add-symbol"
                className="flex w-full items-center justify-center gap-1.5 border border-trident-cyan/30 py-1.5 font-mono text-[10px] uppercase tracking-widest text-trident-cyan/70 transition-all hover:border-trident-cyan hover:text-trident-cyan hover:bg-trident-cyan/5"
              >
                <Plus className="h-3 w-3" /> ADD SYMBOL
              </button>
            )}
          </div>
        </aside>

        {/* ── MAIN CONTENT AREA ── */}
        <section className="min-h-0 min-w-0 flex-1 overflow-y-auto border border-trident-border bg-trident-surface/20 p-4">
          {tab === "markets" && (
            <MarketsTab
              symbol={selectedSymbol}
              histPeriod={histPeriod}
              setHistPeriod={setHistPeriod}
              serviceOnline={serviceOnline}
            />
          )}
          {tab === "brief" && (
            <BriefTab
              selectedBriefId={selectedBriefId}
              setSelectedBriefId={setSelectedBriefId}
            />
          )}
          {tab === "macro" && <MacroTab />}
          {tab === "news" && (
            <NewsTab
              filter={newsFilter}
              setFilter={setNewsFilter}
              symbol={selectedSymbol}
            />
          )}
        </section>
      </div>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════
// MARKETS TAB
// ═══════════════════════════════════════════════════
function MarketsTab({
  symbol,
  histPeriod,
  setHistPeriod,
  serviceOnline,
}: {
  symbol: string | null;
  histPeriod: string;
  setHistPeriod: (p: string) => void;
  serviceOnline: boolean;
}) {
  // Quote for selected symbol
  const { data: quote, isLoading: quoteLoading } = useQuery<Quote>({
    queryKey: ["/api/markets/quote", symbol],
    enabled: !!symbol,
    staleTime: 0,
    refetchInterval: 60000,
    queryFn: () => apiGet(`/api/markets/quote/${encodeURIComponent(symbol!)}`),
  });

  // Historical data (when a non-intraday period selected)
  const periodMap: Record<string, string> = { "1W": "5d", "1M": "1mo", "3M": "3mo", "6M": "6mo", "1Y": "1y" };
  const { data: hist } = useQuery<{ data: QuotePoint[] }>({
    queryKey: ["/api/markets/history", symbol, histPeriod],
    enabled: !!symbol && histPeriod !== "intraday",
    staleTime: 0,
    queryFn: () => apiGet(`/api/markets/history/${encodeURIComponent(symbol!)}?period=${periodMap[histPeriod] || "1mo"}&interval=1d`),
  });

  // Market overview (no symbol selected)
  const { data: overview, isLoading: ovLoading } = useQuery<Record<string, OverviewItem[]>>({
    queryKey: ["/api/markets/overview"],
    enabled: !symbol,
    staleTime: 0,
    refetchInterval: 60000,
    queryFn: () => apiGet("/api/markets/overview"),
  });

  if (!serviceOnline) {
    return <OfflineBanner />;
  }

  // ── Symbol detail view ──
  if (symbol) {
    const chartData =
      histPeriod === "intraday"
        ? (quote?.intraday || []).map((p) => ({ t: p.t, c: p.c }))
        : (hist?.data || []).map((p) => ({ t: p.t, c: p.c }));
    const up = (quote?.change_pct ?? 0) >= 0;
    return (
      <div className="space-y-4">
        {/* Price header */}
        <div className="flex flex-wrap items-end justify-between gap-3 border-b border-trident-border pb-3">
          <div>
            <div className="font-display text-lg uppercase tracking-[0.2em] text-trident-cyan text-glow-cyan" data-testid="text-symbol">
              {symbol}
            </div>
            {quoteLoading ? (
              <Loader2 className="mt-2 h-6 w-6 animate-spin text-trident-cyan/50" />
            ) : (
              <div className="mt-1 flex items-baseline gap-3">
                <span className="font-mono text-3xl font-bold tabular-nums text-trident-text" data-testid="text-price">
                  {fmtNum(quote?.price)}
                </span>
                <Change pct={quote?.change_pct ?? 0} abs={quote?.change} size="lg" />
              </div>
            )}
          </div>
          {/* period toggles */}
          <div className="flex gap-1">
            {["intraday", "1W", "1M", "3M", "6M", "1Y"].map((p) => (
              <button
                key={p}
                onClick={() => setHistPeriod(p)}
                data-testid={`button-period-${p}`}
                className={`border px-2 py-1 font-mono text-[9px] uppercase tracking-widest transition-all ${
                  histPeriod === p
                    ? "border-trident-cyan/60 bg-trident-cyan/10 text-trident-cyan"
                    : "border-trident-border text-trident-text/50 hover:text-trident-cyan"
                }`}
              >
                {p === "intraday" ? "1D" : p}
              </button>
            ))}
          </div>
        </div>

        {/* Chart */}
        <LineChart data={chartData} color={up ? "#00ff41" : "#ff2244"} height={260} />

        {/* Stats grid */}
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
          {[
            { label: "HIGH", value: fmtNum(quote?.high) },
            { label: "LOW", value: fmtNum(quote?.low) },
            { label: "VOLUME", value: fmtCompact(quote?.volume) },
            { label: "MKT CAP", value: fmtCompact(quote?.market_cap) },
          ].map((s) => (
            <div key={s.label} className="border border-trident-border bg-black/30 p-3" data-testid={`stat-${s.label}`}>
              <div className="font-mono text-[9px] uppercase tracking-widest text-trident-text/40">{s.label}</div>
              <div className="mt-1 font-mono text-sm tabular-nums text-trident-cyan">{s.value}</div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  // ── Market overview grid ──
  if (ovLoading) {
    return (
      <div className="flex h-40 items-center justify-center">
        <Loader2 className="h-6 w-6 animate-spin text-trident-cyan/50" />
      </div>
    );
  }

  const catLabels: Record<string, string> = {
    indices: "INDICES", commodities: "COMMODITIES", crypto: "CRYPTO",
    bonds: "BONDS / YIELDS", fx: "FOREX",
  };
  return (
    <div className="space-y-5">
      <div className="font-mono text-[10px] uppercase tracking-widest text-trident-text/50">
        SELECT A SYMBOL FROM WATCHLIST FOR DETAILED ANALYSIS — OR REVIEW GLOBAL MARKET STATUS BELOW
      </div>
      {Object.entries(overview || {}).map(([cat, items]) => (
        <div key={cat}>
          <div className="mb-2 font-display text-xs uppercase tracking-[0.2em] text-trident-amber">
            {catLabels[cat] || cat.toUpperCase()}
          </div>
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-5">
            {(items as OverviewItem[]).map((item) => {
              const up = item.change_pct >= 0;
              return (
                <div key={item.symbol} className="border border-trident-border bg-black/30 p-2.5" data-testid={`overview-${item.symbol}`}>
                  <div className="font-mono text-[10px] uppercase tracking-wide text-trident-text/60">{item.symbol}</div>
                  <div className="mt-1 font-mono text-sm tabular-nums text-trident-text">{fmtNum(item.price)}</div>
                  <div className={`mt-0.5 flex items-center gap-0.5 font-mono text-[10px] tabular-nums ${up ? "text-trident-green" : "text-trident-red"}`}>
                    {up ? <TrendingUp className="h-2.5 w-2.5" /> : <TrendingDown className="h-2.5 w-2.5" />}
                    {up ? "+" : ""}{fmtNum(item.change_pct)}%
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      ))}
    </div>
  );
}

// ═══════════════════════════════════════════════════
// BRIEF TAB
// ═══════════════════════════════════════════════════
function BriefTab({
  selectedBriefId,
  setSelectedBriefId,
}: {
  selectedBriefId: number | null;
  setSelectedBriefId: (id: number | null) => void;
}) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: briefData, isLoading } = useQuery<{ brief: DailyBrief | null; today: string }>({
    queryKey: ["/api/markets/brief"],
    staleTime: 0,
    queryFn: () => apiGet("/api/markets/brief"),
  });
  const { data: briefsData } = useQuery<{ briefs: DailyBrief[] }>({
    queryKey: ["/api/markets/briefs"],
    staleTime: 0,
    queryFn: () => apiGet("/api/markets/briefs"),
  });

  const genMut = useMutation({
    mutationFn: async () => {
      const res = await fetch(`${API_BASE}/api/markets/brief/generate`, {
        method: "POST",
        headers: { "Content-Type": "application/json", ...getAuthHeaders() },
      });
      if (!res.ok) {
        const j = await res.json().catch(() => ({}));
        throw new Error(j.error || "GENERATION FAILED");
      }
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/markets/brief"] });
      queryClient.invalidateQueries({ queryKey: ["/api/markets/briefs"] });
      setSelectedBriefId(null);
      toast({ title: "INTELLIGENCE COMPILED" });
    },
    onError: (e: any) => toast({ title: e.message || "ERROR", variant: "destructive" }),
  });

  const briefs = briefsData?.briefs || [];
  const activeBrief =
    selectedBriefId != null
      ? briefs.find((b) => b.id === selectedBriefId) || briefData?.brief || null
      : briefData?.brief || null;

  if (isLoading) {
    return <div className="flex h-40 items-center justify-center"><Loader2 className="h-6 w-6 animate-spin text-trident-cyan/50" /></div>;
  }

  return (
    <div className="grid gap-4 lg:grid-cols-[1fr_240px]">
      {/* Brief content */}
      <div className="min-w-0">
        {genMut.isPending ? (
          <div className="flex flex-col items-center justify-center gap-3 border border-trident-cyan/30 bg-black/40 py-16">
            <Loader2 className="h-8 w-8 animate-spin text-trident-cyan" style={{ filter: "drop-shadow(0 0 8px #00f0ff)" }} />
            <span className="font-mono text-xs uppercase tracking-[0.25em] text-trident-cyan text-glow-cyan animate-pulse" data-testid="text-compiling">
              &gt;&gt; COMPILING INTELLIGENCE...
            </span>
          </div>
        ) : activeBrief ? (
          <div className="border border-trident-border bg-black/30 p-5">
            <div className="mb-4 flex items-center justify-between border-b border-trident-border pb-3">
              <h2 className="font-display text-sm uppercase tracking-[0.2em] text-trident-amber" style={{ textShadow: "0 0 8px #ff6b0080" }}>
                MARKET INTELLIGENCE BRIEF — {activeBrief.date}
              </h2>
              <button
                onClick={() => genMut.mutate()}
                data-testid="button-regenerate-brief"
                className="flex items-center gap-1.5 border border-trident-cyan/30 px-2 py-1 font-mono text-[9px] uppercase tracking-widest text-trident-cyan/70 hover:border-trident-cyan hover:text-trident-cyan"
              >
                <RefreshCw className="h-3 w-3" /> REGEN
              </button>
            </div>
            <BriefMarkdown content={activeBrief.content} />
            <div className="mt-4 border-t border-trident-border pt-2 font-mono text-[9px] uppercase tracking-widest text-trident-text/40">
              GENERATED BY {activeBrief.model_used}
            </div>
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center gap-4 border border-trident-border bg-black/30 py-16">
            <FileText className="h-10 w-10 text-trident-text/30" />
            <span className="font-mono text-xs uppercase tracking-[0.2em] text-trident-text/50" data-testid="text-no-brief">
              NO BRIEF GENERATED TODAY
            </span>
            <button
              onClick={() => genMut.mutate()}
              data-testid="button-generate-brief"
              className="flex items-center gap-2 border border-trident-cyan/50 bg-trident-cyan/10 px-4 py-2 font-mono text-[11px] uppercase tracking-widest text-trident-cyan text-glow-cyan transition-all hover:bg-trident-cyan/20"
            >
              <Radio className="h-4 w-4" /> GENERATE BRIEF
            </button>
          </div>
        )}
      </div>

      {/* Brief history */}
      <div>
        <div className="mb-2 font-mono text-[10px] uppercase tracking-widest text-trident-text/60">BRIEF ARCHIVE</div>
        <div className="space-y-1">
          {briefs.length === 0 && (
            <div className="font-mono text-[10px] uppercase tracking-widest text-trident-text/30">NO PRIOR BRIEFS</div>
          )}
          {briefs.map((b) => (
            <button
              key={b.id}
              onClick={() => setSelectedBriefId(b.id)}
              data-testid={`brief-history-${b.id}`}
              className={`w-full border-l-2 p-2 text-left transition-all ${
                (selectedBriefId ?? briefData?.brief?.id) === b.id
                  ? "border-trident-amber bg-trident-cyan/8"
                  : "border-transparent hover:bg-trident-cyan/5"
              }`}
            >
              <div className="font-mono text-[11px] uppercase tracking-widest text-trident-cyan">{b.date}</div>
              <div className="mt-0.5 truncate font-mono text-[9px] text-trident-text/40">
                {b.content.replace(/[#*\n]/g, " ").slice(0, 100)}
              </div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════
// MACRO TAB
// ═══════════════════════════════════════════════════
function MacroTab() {
  const { data, isLoading } = useQuery<{ indicators: MacroIndicator[]; error?: string }>({
    queryKey: ["/api/markets/macro"],
    staleTime: 0,
    queryFn: () => apiGet("/api/markets/macro"),
  });

  if (isLoading) {
    return <div className="flex h-40 items-center justify-center"><Loader2 className="h-6 w-6 animate-spin text-trident-cyan/50" /></div>;
  }

  const indicators = data?.indicators || [];

  return (
    <div className="space-y-4">
      <div className="font-display text-xs uppercase tracking-[0.2em] text-trident-amber">MACRO INTELLIGENCE</div>
      {indicators.length === 0 ? (
        <div className="border border-trident-border bg-black/30 p-6 font-mono text-[11px] uppercase tracking-widest text-trident-text/50">
          NO MACRO DATA — FRED_API_KEY MAY NOT BE CONFIGURED ON THE MARKET SERVICE
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {indicators.map((m) => {
            const cur = parseFloat(m.value);
            const prev = parseFloat(m.prev_value);
            const delta = cur - prev;
            const up = delta >= 0;
            const hasDelta = !isNaN(delta) && prev !== 0;
            return (
              <div key={m.id} className="border border-trident-border bg-black/30 p-4" data-testid={`macro-${m.id}`}>
                <div className="font-mono text-[10px] uppercase tracking-widest text-trident-text/50">{m.label}</div>
                <div className="mt-2 flex items-end justify-between">
                  <span className="font-mono text-2xl font-bold tabular-nums text-trident-cyan text-glow-cyan">{m.value}</span>
                  {hasDelta && (
                    <span className={`flex items-center gap-0.5 font-mono text-[11px] tabular-nums ${up ? "text-trident-green" : "text-trident-red"}`}>
                      {up ? <TrendingUp className="h-3 w-3" /> : <TrendingDown className="h-3 w-3" />}
                      {up ? "+" : ""}{fmtNum(delta)}
                    </span>
                  )}
                </div>
                <div className="mt-2 flex items-center justify-between font-mono text-[9px] uppercase tracking-wide text-trident-text/40">
                  <span>AS OF {m.date}</span>
                  <span>PREV {m.prev_value}</span>
                </div>
              </div>
            );
          })}
        </div>
      )}
      <div className="border-t border-trident-border pt-3 text-center font-mono text-[9px] uppercase tracking-widest text-trident-text/30">
        POWERED BY FEDERAL RESERVE ECONOMIC DATA
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════
// NEWS TAB
// ═══════════════════════════════════════════════════
function NewsTab({
  filter,
  setFilter,
  symbol,
}: {
  filter: "MARKET" | "SYMBOL";
  setFilter: (f: "MARKET" | "SYMBOL") => void;
  symbol: string | null;
}) {
  const effectiveSymbol = filter === "SYMBOL" && symbol ? symbol : "";
  const { data, isLoading } = useQuery<{ news: NewsItem[]; symbol: string }>({
    queryKey: ["/api/markets/news", effectiveSymbol],
    staleTime: 0,
    refetchInterval: 300000,
    queryFn: () => apiGet(`/api/markets/news${effectiveSymbol ? `?symbol=${encodeURIComponent(effectiveSymbol)}` : ""}`),
  });

  const news = data?.news || [];

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between border-b border-trident-border pb-3">
        <div className="font-display text-xs uppercase tracking-[0.2em] text-trident-amber">INTELLIGENCE FEED</div>
        <div className="flex gap-1">
          {(["MARKET", "SYMBOL"] as const).map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              disabled={f === "SYMBOL" && !symbol}
              data-testid={`news-filter-${f}`}
              className={`border px-3 py-1 font-mono text-[9px] uppercase tracking-widest transition-all disabled:opacity-30 ${
                filter === f
                  ? "border-trident-cyan/60 bg-trident-cyan/10 text-trident-cyan"
                  : "border-trident-border text-trident-text/50 hover:text-trident-cyan"
              }`}
            >
              {f === "SYMBOL" && symbol ? symbol : f}
            </button>
          ))}
        </div>
      </div>

      {isLoading ? (
        <div className="flex h-40 items-center justify-center"><Loader2 className="h-6 w-6 animate-spin text-trident-cyan/50" /></div>
      ) : news.length === 0 ? (
        <div className="border border-trident-border bg-black/30 p-6 font-mono text-[11px] uppercase tracking-widest text-trident-text/50">
          NO INTELLIGENCE FEED AVAILABLE
        </div>
      ) : (
        <div className="space-y-2">
          {news.map((n, i) => (
            <a
              key={i}
              href={n.link}
              target="_blank"
              rel="noopener noreferrer"
              data-testid={`news-item-${i}`}
              className="group block border border-trident-border bg-black/30 p-3 transition-all hover:border-trident-cyan/40 hover:bg-trident-cyan/5"
            >
              <div className="flex items-start justify-between gap-2">
                <span className="font-mono text-sm text-trident-text group-hover:text-trident-cyan">{n.title}</span>
                <ExternalLink className="h-3 w-3 flex-shrink-0 text-trident-text/30 group-hover:text-trident-cyan" />
              </div>
              <div className="mt-1 flex items-center gap-2 font-mono text-[9px] uppercase tracking-widest text-trident-text/40">
                <span className="text-trident-amber">{n.publisher}</span>
                {n.published ? <span>• {timeAgo(n.published)}</span> : null}
              </div>
              {n.summary && (
                <div className="mt-1.5 font-mono text-[11px] leading-relaxed text-trident-text/60 line-clamp-2">
                  {n.summary}
                </div>
              )}
            </a>
          ))}
        </div>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════
// Offline banner
// ═══════════════════════════════════════════════════
function OfflineBanner() {
  return (
    <div className="flex flex-col items-center justify-center gap-3 border border-trident-red/40 bg-trident-red/5 py-16" data-testid="banner-offline">
      <Radio className="h-10 w-10 text-trident-red/60" />
      <span className="font-mono text-xs uppercase tracking-[0.2em] text-trident-red">MARKET SERVICE OFFLINE</span>
      <span className="max-w-md text-center font-mono text-[10px] uppercase tracking-widest text-trident-text/40">
        THE PYTHON MARKET INTELLIGENCE SERVICE (PORT 5002) IS NOT RESPONDING.
        RUN scripts/setup-markets.sh TO DEPLOY IT.
      </span>
    </div>
  );
}

// ═══════════════════════════════════════════════════
// GEO-INTEL TAB (Phase 2)
// ═══════════════════════════════════════════════════
function rssTimeAgo(pub: string): string {
  if (!pub) return "";
  const t = Date.parse(pub);
  if (isNaN(t)) return "";
  const diff = (Date.now() - t) / 1000;
  if (diff < 60) return "JUST NOW";
  if (diff < 3600) return `${Math.floor(diff / 60)}M AGO`;
  if (diff < 86400) return `${Math.floor(diff / 3600)}H AGO`;
  return `${Math.floor(diff / 86400)}D AGO`;
}

function GeoStatCard({
  label,
  value,
  icon: Icon,
  accent = "cyan",
}: {
  label: string;
  value: string;
  icon: any;
  accent?: "cyan" | "red" | "amber" | "green";
}) {
  const color =
    accent === "red" ? "text-trident-red"
    : accent === "amber" ? "text-trident-amber"
    : accent === "green" ? "text-trident-green"
    : "text-trident-cyan";
  return (
    <div className="border border-trident-border bg-black/30 p-4" data-testid={`geo-stat-${label.toLowerCase().replace(/[^a-z0-9]+/g, "-")}`}>
      <div className="flex items-center justify-between">
        <div className="font-mono text-[10px] uppercase tracking-widest text-trident-amber">{label}</div>
        <Icon className={`h-3.5 w-3.5 ${color}`} />
      </div>
      <div className={`mt-2 font-mono text-2xl font-bold tabular-nums ${color} ${accent === "cyan" ? "text-glow-cyan" : ""}`}>
        {value}
      </div>
    </div>
  );
}

function GeoIntelTab() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [feedTab, setFeedTab] = useState<"MILITARY" | "GEOPOLITICAL">("MILITARY");
  const [selectedGeoBriefId, setSelectedGeoBriefId] = useState<number | null>(null);

  // ── Geo service status ──
  const { data: statusData } = useQuery<{ online: boolean }>({
    queryKey: ["/api/geo/status"],
    staleTime: 0,
    refetchInterval: 30000,
    queryFn: () => apiGet("/api/geo/status"),
  });
  const geoOnline = statusData?.online ?? false;

  // ── Threat summary ──
  const { data: threatData, isLoading: threatLoading } = useQuery<GeoThreatSummary>({
    queryKey: ["/api/geo/threat-summary"],
    staleTime: 0,
    refetchInterval: 300000,
    queryFn: () => apiGet("/api/geo/threat-summary"),
  });
  const acled = threatData?.acled || {};
  const hotspots = acled.top_hotspots || [];
  const acledConfigured = !acled.error && (acled.total_events_7d !== undefined || hotspots.length > 0);
  const maxHotspot = Math.max(1, ...hotspots.map((h) => h.events));

  // ── Intel feed (military / geopolitical) ──
  const { data: milData } = useQuery<{ articles: GeoArticle[] }>({
    queryKey: ["/api/geo/news/military"],
    staleTime: 0,
    refetchInterval: 300000,
    queryFn: () => apiGet("/api/geo/news/military"),
  });
  const { data: geoNewsData } = useQuery<{ articles: GeoArticle[] }>({
    queryKey: ["/api/geo/news/geopolitical"],
    staleTime: 0,
    refetchInterval: 300000,
    queryFn: () => apiGet("/api/geo/news/geopolitical"),
  });
  const feedArticles = (feedTab === "MILITARY" ? milData?.articles : geoNewsData?.articles) || [];

  // ── Geo briefs ──
  const { data: geoBriefData } = useQuery<{ brief: GeoBrief | null; today: string }>({
    queryKey: ["/api/geo/brief"],
    staleTime: 0,
    queryFn: () => apiGet("/api/geo/brief"),
  });
  const { data: geoBriefsData } = useQuery<{ briefs: GeoBrief[] }>({
    queryKey: ["/api/geo/briefs"],
    staleTime: 0,
    queryFn: () => apiGet("/api/geo/briefs"),
  });
  const geoBriefs = geoBriefsData?.briefs || [];
  const activeGeoBrief =
    selectedGeoBriefId != null
      ? geoBriefs.find((b) => b.id === selectedGeoBriefId) || geoBriefData?.brief || null
      : geoBriefData?.brief || null;

  const genMut = useMutation({
    mutationFn: async () => {
      const res = await fetch(`${API_BASE}/api/geo/brief/generate`, {
        method: "POST",
        headers: { "Content-Type": "application/json", ...getAuthHeaders() },
      });
      if (!res.ok) {
        const j = await res.json().catch(() => ({}));
        throw new Error(j.error || "GENERATION FAILED");
      }
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/geo/brief"] });
      queryClient.invalidateQueries({ queryKey: ["/api/geo/briefs"] });
      setSelectedGeoBriefId(null);
      toast({ title: "TACTICAL INTELLIGENCE COMPILED" });
    },
    onError: (e: any) => toast({ title: e.message || "ERROR", variant: "destructive" }),
  });

  const fmtInt = (n: number | undefined) =>
    n === undefined || n === null || isNaN(n) ? "—" : n.toLocaleString("en-US");

  return (
    <div className="space-y-4" data-testid="geo-intel-tab">
      {/* ── Service status indicator ── */}
      <div className="flex items-center justify-between border-b border-trident-border pb-3">
        <div className="flex items-center gap-2">
          <Globe className="h-4 w-4 text-trident-amber" style={{ filter: "drop-shadow(0 0 6px #ff6b00)" }} />
          <span className="font-display text-xs uppercase tracking-[0.2em] text-trident-cyan text-glow-cyan">
            GEO-INTELLIGENCE
          </span>
        </div>
        <span className="flex items-center gap-1.5" data-testid="status-geo-service">
          <span
            className={`inline-block h-2 w-2 rounded-full ${geoOnline ? "bg-trident-green animate-pulse" : "bg-trident-red"}`}
            style={geoOnline ? { boxShadow: "0 0 6px #00ff41" } : { boxShadow: "0 0 6px #ff2244" }}
          />
          <span className={`font-mono text-[9px] uppercase tracking-widest ${geoOnline ? "text-trident-green" : "text-trident-red"}`}>
            {geoOnline ? "GEO SERVICE ONLINE" : "GEO SERVICE OFFLINE — RUN scripts/setup-geo.sh"}
          </span>
        </span>
      </div>

      {/* ── Top stats row ── */}
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <GeoStatCard
          label="CONFLICT EVENTS (7D)"
          value={threatLoading ? "…" : fmtInt(acled.total_events_7d)}
          icon={Crosshair}
          accent="cyan"
        />
        <GeoStatCard
          label="FATALITIES (7D)"
          value={threatLoading ? "…" : fmtInt(acled.total_fatalities_7d)}
          icon={Skull}
          accent="red"
        />
        <GeoStatCard
          label="ACTIVE HOTSPOTS"
          value={threatLoading ? "…" : fmtInt(hotspots.length)}
          icon={Activity}
          accent="amber"
        />
        <GeoStatCard
          label="DATA SOURCES"
          value="ACLED · GDELT · 6 RSS"
          icon={Database}
          accent="green"
        />
      </div>

      {/* ── Middle row: hotspots + feed ── */}
      <div className="grid gap-3 lg:grid-cols-2">
        {/* Top conflict zones */}
        <div className="border border-trident-border bg-black/30 p-4">
          <div className="mb-3 font-display text-[11px] uppercase tracking-[0.2em] text-trident-amber">
            TOP CONFLICT ZONES
          </div>
          {!acledConfigured ? (
            <div className="border border-trident-red/30 bg-trident-red/5 p-4 font-mono text-[10px] uppercase leading-relaxed tracking-widest text-trident-red/80" data-testid="geo-acled-offline">
              ACLED NOT CONFIGURED — ADD ACLED_EMAIL + ACLED_PASSWORD TO SERVER CONFIG
            </div>
          ) : hotspots.length === 0 ? (
            <div className="font-mono text-[10px] uppercase tracking-widest text-trident-text/40">
              NO CONFLICT ZONES DETECTED
            </div>
          ) : (
            <div className="space-y-2.5">
              {hotspots.map((h) => (
                <div key={h.country} className="flex items-center gap-3" data-testid={`geo-hotspot-${h.country}`}>
                  <div className="w-28 flex-shrink-0 truncate font-mono text-[11px] uppercase tracking-wide text-trident-text/80">
                    {h.country}
                  </div>
                  <div className="h-2.5 flex-1 overflow-hidden border border-trident-border bg-black/40">
                    <div
                      className="h-full bg-trident-amber"
                      style={{
                        width: `${Math.max(6, (h.events / maxHotspot) * 100)}%`,
                        boxShadow: "0 0 6px #ff6b00",
                      }}
                    />
                  </div>
                  <div className="w-20 flex-shrink-0 text-right font-mono text-[11px] tabular-nums text-trident-cyan">
                    {h.events} events
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Intel feed */}
        <div className="border border-trident-border bg-black/30 p-4">
          <div className="mb-3 flex items-center justify-between">
            <div className="font-display text-[11px] uppercase tracking-[0.2em] text-trident-amber">INTEL FEED</div>
            <div className="flex gap-1">
              {(["MILITARY", "GEOPOLITICAL"] as const).map((f) => (
                <button
                  key={f}
                  onClick={() => setFeedTab(f)}
                  data-testid={`geo-feed-${f}`}
                  className={`border px-2.5 py-1 font-mono text-[9px] uppercase tracking-widest transition-all ${
                    feedTab === f
                      ? "border-trident-cyan/60 bg-trident-cyan/10 text-trident-cyan"
                      : "border-trident-border text-trident-text/50 hover:text-trident-cyan"
                  }`}
                >
                  {f}
                </button>
              ))}
            </div>
          </div>
          <div className="max-h-[350px] space-y-2 overflow-y-auto pr-1">
            {feedArticles.length === 0 ? (
              <div className="font-mono text-[10px] uppercase tracking-widest text-trident-text/40">
                NO INTEL FEED AVAILABLE
              </div>
            ) : (
              feedArticles.map((a, i) => (
                <a
                  key={i}
                  href={a.link}
                  target="_blank"
                  rel="noopener noreferrer"
                  data-testid={`geo-article-${i}`}
                  className="group block border border-trident-border bg-black/20 p-2.5 transition-all hover:border-trident-cyan/40 hover:bg-trident-cyan/5"
                >
                  <div className="flex items-center gap-2 font-mono text-[8px] uppercase tracking-widest text-trident-text/40">
                    <span className="text-trident-amber">{a.source}</span>
                    {a.published ? <span>• {rssTimeAgo(a.published)}</span> : null}
                  </div>
                  <div className="mt-1 font-mono text-[12px] leading-snug text-trident-text group-hover:text-trident-cyan">
                    {a.title}
                  </div>
                  {a.description && (
                    <div className="mt-1 font-mono text-[10px] leading-relaxed text-trident-text/50 line-clamp-2">
                      {a.description.replace(/<[^>]*>/g, "")}
                    </div>
                  )}
                </a>
              ))
            )}
          </div>
        </div>
      </div>

      {/* ── Geo-intel brief ── */}
      <div className="grid gap-4 lg:grid-cols-[1fr_240px]">
        <div className="min-w-0">
          {genMut.isPending ? (
            <div className="flex flex-col items-center justify-center gap-3 border border-trident-cyan/30 bg-black/40 py-16">
              <Loader2 className="h-8 w-8 animate-spin text-trident-cyan" style={{ filter: "drop-shadow(0 0 8px #00f0ff)" }} />
              <span className="font-mono text-xs uppercase tracking-[0.25em] text-trident-cyan text-glow-cyan animate-pulse" data-testid="geo-text-compiling">
                &gt;&gt; COMPILING TACTICAL INTELLIGENCE...
              </span>
            </div>
          ) : activeGeoBrief ? (
            <div className="border border-trident-border bg-black/30 p-5">
              <div className="mb-4 flex items-center justify-between border-b border-trident-border pb-3">
                <h2 className="font-display text-sm uppercase tracking-[0.2em] text-trident-amber" style={{ textShadow: "0 0 8px #ff6b0080" }}>
                  GEO-INTEL BRIEF — {activeGeoBrief.date}
                </h2>
                <button
                  onClick={() => genMut.mutate()}
                  data-testid="geo-button-regenerate"
                  className="flex items-center gap-1.5 border border-trident-cyan/30 px-2 py-1 font-mono text-[9px] uppercase tracking-widest text-trident-cyan/70 hover:border-trident-cyan hover:text-trident-cyan"
                >
                  <RefreshCw className="h-3 w-3" /> REGEN
                </button>
              </div>
              <BriefMarkdown content={activeGeoBrief.content} />
              <div className="mt-4 border-t border-trident-border pt-2 font-mono text-[9px] uppercase tracking-widest text-trident-text/40">
                GENERATED BY {activeGeoBrief.model_used} · {activeGeoBrief.region_focus || "GLOBAL"}
              </div>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center gap-4 border border-trident-border bg-black/30 py-16">
              <Globe className="h-10 w-10 text-trident-text/30" />
              <span className="font-mono text-xs uppercase tracking-[0.2em] text-trident-text/50" data-testid="geo-text-no-brief">
                NO GEO-INTEL BRIEF GENERATED TODAY
              </span>
              <button
                onClick={() => genMut.mutate()}
                data-testid="geo-button-generate"
                className="flex items-center gap-2 border border-trident-cyan/50 bg-trident-cyan/10 px-4 py-2 font-mono text-[11px] uppercase tracking-widest text-trident-cyan text-glow-cyan transition-all hover:bg-trident-cyan/20"
              >
                <Radio className="h-4 w-4" /> GENERATE GEO-INTEL BRIEF
              </button>
            </div>
          )}
        </div>

        {/* Brief archive */}
        <div>
          <div className="mb-2 font-mono text-[10px] uppercase tracking-widest text-trident-text/60">GEO-INTEL ARCHIVE</div>
          <div className="space-y-1">
            {geoBriefs.length === 0 && (
              <div className="font-mono text-[10px] uppercase tracking-widest text-trident-text/30">NO PRIOR BRIEFS</div>
            )}
            {geoBriefs.slice(0, 5).map((b) => (
              <button
                key={b.id}
                onClick={() => setSelectedGeoBriefId(b.id)}
                data-testid={`geo-brief-history-${b.id}`}
                className={`w-full border-l-2 p-2 text-left transition-all ${
                  (selectedGeoBriefId ?? geoBriefData?.brief?.id) === b.id
                    ? "border-trident-amber bg-trident-cyan/8"
                    : "border-transparent hover:bg-trident-cyan/5"
                }`}
              >
                <div className="font-mono text-[11px] uppercase tracking-widest text-trident-cyan">{b.date}</div>
                <div className="mt-0.5 truncate font-mono text-[9px] text-trident-text/40">
                  {b.content.replace(/[#*\n]/g, " ").slice(0, 100)}
                </div>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
