import { sqliteTable, text, integer } from "drizzle-orm/sqlite-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// ═══════════════════════════════════════════════════
// USERS — Core identity table
// ═══════════════════════════════════════════════════
export const users = sqliteTable("users", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  username: text("username").notNull().unique(),
  email: text("email").notNull().unique(),
  password_hash: text("password_hash").notNull(),
  role: text("role", { enum: ["admin", "power_user", "user"] }).notNull().default("user"),
  created_at: text("created_at").notNull().default(""),
  last_login: text("last_login"),
  is_active: integer("is_active", { mode: "boolean" }).notNull().default(true),
});

// ═══════════════════════════════════════════════════
// SESSIONS — Token management
// ═══════════════════════════════════════════════════
export const sessions = sqliteTable("sessions", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  user_id: integer("user_id").notNull(),
  token_hash: text("token_hash").notNull(),
  expires_at: text("expires_at").notNull(),
  created_at: text("created_at").notNull().default(""),
});

// ═══════════════════════════════════════════════════
// Insert schemas (drizzle-zod)
// ═══════════════════════════════════════════════════
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  created_at: true,
  last_login: true,
});

export const insertSessionSchema = createInsertSchema(sessions).omit({
  id: true,
  created_at: true,
});

// ═══════════════════════════════════════════════════
// Types
// ═══════════════════════════════════════════════════
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertSession = z.infer<typeof insertSessionSchema>;
export type Session = typeof sessions.$inferSelect;

// ═══════════════════════════════════════════════════
// Frontend-safe user type (no password hash)
// ═══════════════════════════════════════════════════
export type SafeUser = Omit<User, "password_hash">;
