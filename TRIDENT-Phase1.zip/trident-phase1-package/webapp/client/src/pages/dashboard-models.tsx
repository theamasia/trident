import { useState, useEffect } from "react";
import { Box, Server, HardDrive } from "lucide-react";

export default function DashboardModels() {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setProgress((p) => {
        if (p >= 100) return 0;
        return p + Math.random() * 8;
      });
    }, 200);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="h-full flex flex-col">
      <div className="trident-panel p-4 mb-4">
        <h1 className="font-display text-sm tracking-[0.15em] text-trident-amber text-glow-amber flex items-center gap-2">
          <Box className="w-4 h-4" />
          MODEL REGISTRY
        </h1>
      </div>

      <div className="trident-panel flex-1 p-6">
        <div className="max-w-2xl mx-auto space-y-6">
          {/* Scanning animation */}
          <div className="border border-trident-border p-4" style={{ backgroundColor: "#050a0e" }}>
            <div className="font-mono text-xs space-y-3">
              <p className="text-trident-cyan">
                &gt;&gt; MODEL REGISTRY — INITIALIZING
              </p>
              <div className="flex items-center gap-3">
                <span className="text-trident-text/40 w-24">SCANNING:</span>
                <div className="flex-1 h-1.5 bg-trident-border/30 overflow-hidden">
                  <div
                    className="h-full bg-trident-cyan transition-all duration-200"
                    style={{ width: `${Math.min(progress, 100)}%`, boxShadow: "0 0 8px #00f0ff" }}
                  />
                </div>
                <span className="text-trident-cyan text-[10px] w-8 tabular-nums">
                  {Math.min(Math.round(progress), 100)}%
                </span>
              </div>
              <p className="text-trident-amber text-[10px]">
                &gt;&gt; NO LOCAL MODELS DETECTED
              </p>
            </div>
          </div>

          {/* Stub model list */}
          <div className="space-y-3">
            {[
              { name: "OLLAMA / LLAMA 3.1", size: "—", status: "NOT LOADED" },
              { name: "OLLAMA / MISTRAL 7B", size: "—", status: "NOT LOADED" },
              { name: "OLLAMA / CODELLAMA", size: "—", status: "NOT LOADED" },
              { name: "OPENAI / GPT-4", size: "API", status: "NOT CONFIGURED" },
            ].map((model) => (
              <div
                key={model.name}
                className="flex items-center justify-between border border-trident-border/50 px-4 py-3"
                style={{ backgroundColor: "#0a162880" }}
              >
                <div className="flex items-center gap-3">
                  <Server className="w-3.5 h-3.5 text-trident-text/30" />
                  <span className="font-mono text-xs uppercase tracking-wider text-trident-text/50">
                    {model.name}
                  </span>
                </div>
                <div className="flex items-center gap-4">
                  <span className="font-mono text-[10px] text-trident-text/30 flex items-center gap-1">
                    <HardDrive className="w-3 h-3" />
                    {model.size}
                  </span>
                  <span className="font-mono text-[10px] uppercase tracking-widest text-trident-red/60 px-2 py-0.5 border border-trident-red/20">
                    {model.status}
                  </span>
                </div>
              </div>
            ))}
          </div>

          <p className="text-center font-mono text-[10px] uppercase tracking-widest text-trident-text/20">
            MODEL MANAGEMENT AVAILABLE IN PHASE 2
          </p>
        </div>
      </div>
    </div>
  );
}
