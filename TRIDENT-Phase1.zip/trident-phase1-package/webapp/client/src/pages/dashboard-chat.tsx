import { useState, useEffect } from "react";
import { MessageSquare, Cpu } from "lucide-react";

export default function DashboardChat() {
  const [dots, setDots] = useState("");
  const [showMessage, setShowMessage] = useState(false);

  // Terminal typing animation
  useEffect(() => {
    const dotInterval = setInterval(() => {
      setDots((d) => (d.length >= 3 ? "" : d + "."));
    }, 500);

    const msgTimeout = setTimeout(() => setShowMessage(true), 2000);

    return () => {
      clearInterval(dotInterval);
      clearTimeout(msgTimeout);
    };
  }, []);

  return (
    <div className="h-full flex flex-col">
      <div className="trident-panel p-4 mb-4">
        <h1 className="font-display text-sm tracking-[0.15em] text-trident-amber text-glow-amber flex items-center gap-2">
          <MessageSquare className="w-4 h-4" />
          NEURAL CHAT INTERFACE
        </h1>
      </div>

      <div className="trident-panel flex-1 p-6 flex flex-col items-center justify-center">
        {/* Terminal animation */}
        <div className="w-full max-w-lg space-y-4">
          <div className="border border-trident-border p-4" style={{ backgroundColor: "#050a0e" }}>
            <div className="font-mono text-xs space-y-2">
              <p className="text-trident-cyan/60">
                <span className="text-trident-amber">root@trident</span>
                <span className="text-trident-text/40">:</span>
                <span className="text-trident-cyan/80">~/neural</span>
                <span className="text-trident-text/40">$</span>
                <span className="text-trident-green ml-2">initialize --chat-module</span>
              </p>
              <p className="text-trident-text/60">
                &gt;&gt; LOADING NEURAL LINK MODULE{dots}
              </p>
              {showMessage && (
                <>
                  <p className="text-trident-amber">
                    &gt;&gt; WARNING: NO MODELS LOADED
                  </p>
                  <p className="text-trident-red/80">
                    &gt;&gt; STATUS: NEURAL LINK PENDING — PHASE 2 ONLINE SOON
                  </p>
                  <p className="text-trident-cyan/40 mt-4">
                    &gt;&gt; AVAILABLE MODELS: <span className="text-trident-text/30">[NONE]</span>
                  </p>
                  <p className="text-trident-cyan/40">
                    &gt;&gt; OLLAMA ENDPOINT: <span className="text-trident-text/30">NOT CONFIGURED</span>
                  </p>
                  <p className="text-trident-cyan/40">
                    &gt;&gt; OPENAI API: <span className="text-trident-text/30">NOT CONFIGURED</span>
                  </p>
                </>
              )}
              <p className="text-trident-cyan cursor-blink mt-2">&gt; _</p>
            </div>
          </div>

          <div className="flex items-center gap-3 justify-center text-xs font-mono uppercase tracking-widest text-trident-text/30">
            <Cpu className="w-4 h-4" />
            <span>CHAT SYSTEM WILL BE AVAILABLE IN PHASE 2</span>
          </div>
        </div>
      </div>
    </div>
  );
}
