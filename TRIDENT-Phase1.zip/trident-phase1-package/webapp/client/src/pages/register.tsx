import { useState } from "react";
import { useLocation } from "wouter";
import { TridentLogo } from "@/components/TridentLogo";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";

export default function RegisterPage() {
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [, setLocation] = useLocation();
  const { register } = useAuth();
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (password !== confirmPassword) {
      toast({
        title: ">> ERROR",
        description: "PASSWORDS DO NOT MATCH",
        variant: "destructive",
        className: "border-[#ff2244] bg-trident-surface text-[#ff2244]",
      });
      return;
    }

    if (password.length < 8) {
      toast({
        title: ">> ERROR",
        description: "PASSWORD MUST BE 8+ CHARACTERS",
        variant: "destructive",
        className: "border-[#ff2244] bg-trident-surface text-[#ff2244]",
      });
      return;
    }

    setIsSubmitting(true);
    try {
      await register(username, email, password);
      toast({
        title: ">> ACCESS GRANTED",
        description: "REGISTRATION COMPLETE — REDIRECTING TO LOGIN",
        className: "terminal-text border-trident-border bg-trident-surface",
      });
      setLocation("/login?registered=true");
    } catch (err: any) {
      const msg = err.message?.includes("409")
        ? "EMAIL OR USERNAME ALREADY EXISTS"
        : "REGISTRATION FAILED";
      toast({
        title: ">> ERROR",
        description: msg,
        variant: "destructive",
        className: "border-[#ff2244] bg-trident-surface text-[#ff2244]",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center grid-bg crt-on" style={{ backgroundColor: "#050a0e" }}>
      <div className="fixed inset-0 scanlines pointer-events-none" />
      
      <div className="w-full max-w-md px-6 crt-flicker relative z-10">
        {/* Logo */}
        <div className="flex flex-col items-center mb-8">
          <TridentLogo size="lg" />
          <p className="mt-3 font-mono text-xs tracking-[0.15em] text-trident-cyan/60 uppercase">
            TACTICAL NEURAL INTERFACE SYSTEM
          </p>
        </div>

        {/* Register Form */}
        <form onSubmit={handleSubmit} className="trident-panel p-6 space-y-4" data-testid="register-form">
          <div className="text-center mb-4">
            <h2 className="font-display text-sm tracking-[0.15em] text-trident-amber text-glow-amber">
              REQUEST ACCESS
            </h2>
          </div>

          <div className="space-y-1">
            <label className="block text-[10px] font-mono uppercase tracking-widest text-trident-cyan/70">
              USERNAME
            </label>
            <input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="trident-input w-full px-3 py-2.5 text-sm"
              placeholder="ENTER CALLSIGN"
              required
              minLength={3}
              data-testid="input-username"
              autoComplete="username"
            />
          </div>

          <div className="space-y-1">
            <label className="block text-[10px] font-mono uppercase tracking-widest text-trident-cyan/70">
              EMAIL ADDRESS
            </label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="trident-input w-full px-3 py-2.5 text-sm"
              placeholder="ENTER EMAIL"
              required
              data-testid="input-email"
              autoComplete="email"
            />
          </div>

          <div className="space-y-1">
            <label className="block text-[10px] font-mono uppercase tracking-widest text-trident-cyan/70">
              PASSWORD
            </label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="trident-input w-full px-3 py-2.5 text-sm"
              placeholder="MIN 8 CHARACTERS"
              required
              minLength={8}
              data-testid="input-password"
              autoComplete="new-password"
              style={{ textTransform: "none" }}
            />
          </div>

          <div className="space-y-1">
            <label className="block text-[10px] font-mono uppercase tracking-widest text-trident-cyan/70">
              CONFIRM PASSWORD
            </label>
            <input
              type="password"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              className="trident-input w-full px-3 py-2.5 text-sm"
              placeholder="RE-ENTER PASSWORD"
              required
              data-testid="input-confirm-password"
              autoComplete="new-password"
              style={{ textTransform: "none" }}
            />
          </div>

          <button
            type="submit"
            disabled={isSubmitting}
            className="trident-btn trident-btn-primary w-full py-3 text-sm disabled:opacity-50"
            data-testid="button-register"
          >
            {isSubmitting ? (
              <span className="flex items-center justify-center gap-2">
                <span className="pulse-dot inline-block w-2 h-2 rounded-full bg-black" />
                PROCESSING...
              </span>
            ) : (
              "REQUEST ACCESS"
            )}
          </button>

          <div className="text-center pt-2">
            <button
              type="button"
              onClick={() => setLocation("/login")}
              className="text-xs font-mono uppercase tracking-widest text-trident-cyan/50 hover:text-trident-cyan transition-colors"
              data-testid="link-login"
            >
              [ RETURN TO LOGIN ]
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
