import {
  type User,
  type InsertUser,
  type SafeUser,
  type Session,
  type InsertSession,
  users,
  sessions,
} from "@shared/schema";
import { drizzle } from "drizzle-orm/better-sqlite3";
import Database from "better-sqlite3";
import { eq, and } from "drizzle-orm";

const sqlite = new Database("data.db");
sqlite.pragma("journal_mode = WAL");

export const db = drizzle(sqlite);

// Strip password_hash from user for frontend delivery
function toSafeUser(user: User): SafeUser {
  const { password_hash, ...safe } = user;
  return safe;
}

export interface IStorage {
  // User CRUD
  getUser(id: number): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, data: Partial<Pick<User, "username" | "email" | "password_hash" | "role" | "is_active" | "last_login">>): Promise<User | undefined>;
  deleteUser(id: number): Promise<boolean>;
  getAllUsers(): Promise<SafeUser[]>;

  // Session CRUD
  createSession(session: InsertSession): Promise<Session>;
  getSessionByTokenHash(tokenHash: string): Promise<Session | undefined>;
  deleteSession(tokenHash: string): Promise<boolean>;
  deleteUserSessions(userId: number): Promise<boolean>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    return db.select().from(users).where(eq(users.id, id)).get();
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return db.select().from(users).where(eq(users.email, email)).get();
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return db.select().from(users).where(eq(users.username, username)).get();
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const now = new Date().toISOString();
    return db.insert(users).values({ ...insertUser, created_at: now }).returning().get();
  }

  async updateUser(
    id: number,
    data: Partial<Pick<User, "username" | "email" | "password_hash" | "role" | "is_active" | "last_login">>
  ): Promise<User | undefined> {
    return db.update(users).set(data).where(eq(users.id, id)).returning().get();
  }

  async deleteUser(id: number): Promise<boolean> {
    const result = db.delete(users).where(eq(users.id, id)).run();
    return result.changes > 0;
  }

  async getAllUsers(): Promise<SafeUser[]> {
    const allUsers = db.select().from(users).all();
    return allUsers.map(toSafeUser);
  }

  // Sessions
  async createSession(session: InsertSession): Promise<Session> {
    const now = new Date().toISOString();
    return db.insert(sessions).values({ ...session, created_at: now }).returning().get();
  }

  async getSessionByTokenHash(tokenHash: string): Promise<Session | undefined> {
    return db.select().from(sessions).where(eq(sessions.token_hash, tokenHash)).get();
  }

  async deleteSession(tokenHash: string): Promise<boolean> {
    const result = db.delete(sessions).where(eq(sessions.token_hash, tokenHash)).run();
    return result.changes > 0;
  }

  async deleteUserSessions(userId: number): Promise<boolean> {
    const result = db.delete(sessions).where(eq(sessions.user_id, userId)).run();
    return result.changes >= 0;
  }
}

export const storage = new DatabaseStorage();
