import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { requireAuth, requireAdmin, generateToken } from "./middleware/auth";
import bcrypt from "bcryptjs";
import { z } from "zod";

// Validation schemas
const registerSchema = z.object({
  username: z.string().min(3).max(32),
  email: z.string().email(),
  password: z.string().min(8),
});

const loginSchema = z.object({
  email: z.string().email(),
  password: z.string(),
});

const updateUserSchema = z.object({
  role: z.enum(["admin", "power_user", "user"]).optional(),
  is_active: z.boolean().optional(),
});

const updateSettingsSchema = z.object({
  username: z.string().min(3).max(32).optional(),
  email: z.string().email().optional(),
  current_password: z.string().optional(),
  new_password: z.string().min(8).optional(),
});

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {

  // ═══════════════════════════════════════════════════
  // AUTH ROUTES
  // ═══════════════════════════════════════════════════

  // POST /api/auth/register — Create new user
  app.post("/api/auth/register", async (req, res) => {
    try {
      const data = registerSchema.parse(req.body);

      // Check uniqueness
      const existingEmail = await storage.getUserByEmail(data.email);
      if (existingEmail) {
        return res.status(409).json({ error: "EMAIL ALREADY REGISTERED" });
      }
      const existingUsername = await storage.getUserByUsername(data.username);
      if (existingUsername) {
        return res.status(409).json({ error: "USERNAME ALREADY TAKEN" });
      }

      const password_hash = await bcrypt.hash(data.password, 12);

      const user = await storage.createUser({
        username: data.username,
        email: data.email,
        password_hash,
        role: "user",
        is_active: true,
      });

      const { password_hash: _, ...safeUser } = user;
      res.status(201).json({ message: "ACCESS GRANTED — AWAIT AUTHENTICATION", user: safeUser });
    } catch (err: any) {
      if (err.name === "ZodError") {
        return res.status(400).json({ error: "INVALID INPUT DATA", details: err.errors });
      }
      console.error("Registration error:", err);
      res.status(500).json({ error: "SYSTEM ERROR — REGISTRATION FAILED" });
    }
  });

  // POST /api/auth/login — Validate credentials, return JWT
  app.post("/api/auth/login", async (req, res) => {
    try {
      const data = loginSchema.parse(req.body);

      const user = await storage.getUserByEmail(data.email);
      if (!user) {
        return res.status(401).json({ error: "INVALID CREDENTIALS" });
      }

      if (!user.is_active) {
        return res.status(403).json({ error: "ACCOUNT DEACTIVATED — CONTACT ADMINISTRATOR" });
      }

      const valid = await bcrypt.compare(data.password, user.password_hash);
      if (!valid) {
        return res.status(401).json({ error: "INVALID CREDENTIALS" });
      }

      // Update last login
      await storage.updateUser(user.id, { last_login: new Date().toISOString() });

      const token = generateToken(user.id, user.role);
      const { password_hash: _, ...safeUser } = user;

      res.json({ token, user: safeUser });
    } catch (err: any) {
      if (err.name === "ZodError") {
        return res.status(400).json({ error: "INVALID INPUT DATA" });
      }
      console.error("Login error:", err);
      res.status(500).json({ error: "SYSTEM ERROR — AUTHENTICATION FAILED" });
    }
  });

  // POST /api/auth/logout — Invalidate session
  app.post("/api/auth/logout", requireAuth, async (req, res) => {
    // With JWT, logout is client-side (discard token). 
    // We respond affirmatively.
    res.json({ message: "SESSION TERMINATED" });
  });

  // GET /api/auth/me — Return current user
  app.get("/api/auth/me", requireAuth, async (req, res) => {
    res.json({ user: req.user });
  });

  // ═══════════════════════════════════════════════════
  // USER SETTINGS
  // ═══════════════════════════════════════════════════

  app.patch("/api/auth/settings", requireAuth, async (req, res) => {
    try {
      const data = updateSettingsSchema.parse(req.body);
      const userId = req.user!.id;
      const updateData: any = {};

      if (data.username) updateData.username = data.username;
      if (data.email) updateData.email = data.email;

      if (data.new_password) {
        if (!data.current_password) {
          return res.status(400).json({ error: "CURRENT PASSWORD REQUIRED" });
        }
        const user = await storage.getUser(userId);
        if (!user) return res.status(404).json({ error: "USER NOT FOUND" });
        const valid = await bcrypt.compare(data.current_password, user.password_hash);
        if (!valid) return res.status(401).json({ error: "CURRENT PASSWORD INVALID" });
        updateData.password_hash = await bcrypt.hash(data.new_password, 12);
      }

      const updated = await storage.updateUser(userId, updateData);
      if (!updated) return res.status(404).json({ error: "USER NOT FOUND" });

      const { password_hash: _, ...safeUser } = updated;
      res.json({ user: safeUser });
    } catch (err: any) {
      if (err.name === "ZodError") {
        return res.status(400).json({ error: "INVALID INPUT DATA", details: err.errors });
      }
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  // ═══════════════════════════════════════════════════
  // ADMIN ROUTES
  // ═══════════════════════════════════════════════════

  // GET /api/admin/users — List all users
  app.get("/api/admin/users", requireAdmin, async (req, res) => {
    const allUsers = await storage.getAllUsers();
    res.json({ users: allUsers });
  });

  // PATCH /api/admin/users/:id — Update user role/status
  app.patch("/api/admin/users/:id", requireAdmin, async (req, res) => {
    try {
      const userId = parseInt(String(req.params.id), 10);
      if (isNaN(userId)) return res.status(400).json({ error: "INVALID USER ID" });

      const data = updateUserSchema.parse(req.body);
      const updated = await storage.updateUser(userId, data);
      if (!updated) return res.status(404).json({ error: "USER NOT FOUND" });

      const { password_hash: _, ...safeUser } = updated;
      res.json({ user: safeUser });
    } catch (err: any) {
      if (err.name === "ZodError") {
        return res.status(400).json({ error: "INVALID INPUT DATA" });
      }
      res.status(500).json({ error: "SYSTEM ERROR" });
    }
  });

  // DELETE /api/admin/users/:id — Delete user
  app.delete("/api/admin/users/:id", requireAdmin, async (req, res) => {
    const userId = parseInt(String(req.params.id), 10);
    if (isNaN(userId)) return res.status(400).json({ error: "INVALID USER ID" });

    // Prevent self-delete
    if (userId === req.user!.id) {
      return res.status(400).json({ error: "CANNOT DELETE OWN ACCOUNT" });
    }

    const deleted = await storage.deleteUser(userId);
    if (!deleted) return res.status(404).json({ error: "USER NOT FOUND" });

    res.json({ message: "USER ELIMINATED" });
  });

  return httpServer;
}
