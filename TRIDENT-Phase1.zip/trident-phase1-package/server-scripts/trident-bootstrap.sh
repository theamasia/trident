#!/usr/bin/env bash
# =============================================================================
# TRIDENT AI Platform — Automated Server Bootstrap (Phase 1)
# Target: Ubuntu 24.04 LTS (Noble Numbat) on Proxmox VM
# Usage:  sudo ./trident-bootstrap.sh
# =============================================================================

set -euo pipefail

# ---------------------------------------------------------------------------
# ANSI color codes
# ---------------------------------------------------------------------------
CYAN='\033[0;36m'
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
BOLD='\033[1m'
NC='\033[0m' # No Color

# ---------------------------------------------------------------------------
# Global state
# ---------------------------------------------------------------------------
CURRENT_STEP=""
STEPS_COMPLETED=()
STEPS_FAILED=()
DB_PASSWORD=""
JWT_SECRET_VALUE=""
LAN_IP=""

# ---------------------------------------------------------------------------
# ASCII art header
# ---------------------------------------------------------------------------
print_header() {
    echo -e "${CYAN}"
    cat << 'ASCIIART'

  ████████╗██████╗ ██╗██████╗ ███████╗███╗   ██╗████████╗
  ╚══██╔══╝██╔══██╗██║██╔══██╗██╔════╝████╗  ██║╚══██╔══╝
     ██║   ██████╔╝██║██║  ██║█████╗  ██╔██╗ ██║   ██║
     ██║   ██╔══██╗██║██║  ██║██╔══╝  ██║╚██╗██║   ██║
     ██║   ██║  ██║██║██████╔╝███████╗██║ ╚████║   ██║
     ╚═╝   ╚═╝  ╚═╝╚═╝╚═════╝ ╚══════╝╚═╝  ╚═══╝   ╚═╝

     AI Platform — Phase 1 Server Bootstrap
     Ubuntu 24.04 LTS | Proxmox VM

ASCIIART
    echo -e "${NC}"
}

# ---------------------------------------------------------------------------
# Logging helpers
# ---------------------------------------------------------------------------
log_step() {
    CURRENT_STEP="$1"
    echo -e "\n${CYAN}${BOLD}[ TRIDENT ]${NC} ${CYAN}$1${NC}"
}

log_info() {
    echo -e "  ${BOLD}→${NC} $1"
}

log_ok() {
    echo -e "  ${GREEN}✓${NC} $1"
}

log_warn() {
    echo -e "  ${YELLOW}⚠${NC} $1"
}

log_fail() {
    echo -e "\n${RED}${BOLD}[ TRIDENT ] SETUP FAILED at step: ${CURRENT_STEP}${NC}"
    echo -e "${RED}  Review the output above for details.${NC}\n"
    STEPS_FAILED+=("${CURRENT_STEP}")
    print_summary
    exit 1
}

# Trap any unhandled error and report which step failed
trap 'log_fail' ERR

# ---------------------------------------------------------------------------
# Root check
# ---------------------------------------------------------------------------
check_root() {
    if [[ $EUID -ne 0 ]]; then
        echo -e "${RED}[ TRIDENT ] This script must be run as root (sudo).${NC}"
        exit 1
    fi
}

# ---------------------------------------------------------------------------
# Detect LAN IP
# ---------------------------------------------------------------------------
detect_ip() {
    LAN_IP=$(hostname -I | awk '{print $1}')
    if [[ -z "${LAN_IP}" ]]; then
        echo -e "${RED}[ TRIDENT ] Could not detect LAN IP address.${NC}"
        exit 1
    fi
    log_info "Detected LAN IP: ${LAN_IP}"
}

# ===========================================================================
# STEP 1: System Update
# ===========================================================================
step_system_update() {
    log_step "Step 1/13: System update (apt update && apt upgrade)"

    if [[ -f /var/lib/trident/.step_system_update_done ]]; then
        log_warn "Already completed — skipping."
        STEPS_COMPLETED+=("System Update")
        return
    fi

    # Prevent interactive prompts during upgrade
    export DEBIAN_FRONTEND=noninteractive

    apt-get update -y
    apt-get upgrade -y -o Dpkg::Options::="--force-confdef" -o Dpkg::Options::="--force-confold"

    mkdir -p /var/lib/trident
    touch /var/lib/trident/.step_system_update_done
    STEPS_COMPLETED+=("System Update")
    log_ok "System packages updated."
}

# ===========================================================================
# STEP 2: Base Packages
# ===========================================================================
step_base_packages() {
    log_step "Step 2/13: Installing base packages"

    if command -v git &>/dev/null && command -v curl &>/dev/null && command -v htop &>/dev/null; then
        log_warn "Base packages already installed — skipping."
        STEPS_COMPLETED+=("Base Packages")
        return
    fi

    export DEBIAN_FRONTEND=noninteractive

    apt-get install -y \
        curl \
        wget \
        git \
        build-essential \
        unzip \
        net-tools \
        ufw \
        htop \
        gnupg \
        ca-certificates \
        lsb-release

    STEPS_COMPLETED+=("Base Packages")
    log_ok "Base packages installed."
}

# ===========================================================================
# STEP 3: Node.js 20 LTS via NodeSource
# ===========================================================================
step_nodejs() {
    log_step "Step 3/13: Installing Node.js 20 LTS (NodeSource)"

    if command -v node &>/dev/null; then
        local node_ver
        node_ver=$(node --version 2>/dev/null || true)
        if [[ "${node_ver}" == v20.* ]]; then
            log_warn "Node.js ${node_ver} already installed — skipping."
            STEPS_COMPLETED+=("Node.js 20 LTS")
            return
        fi
    fi

    export DEBIAN_FRONTEND=noninteractive

    # Add NodeSource repository for Node.js 20.x
    curl -fsSL https://deb.nodesource.com/setup_20.x | bash -

    # Install Node.js (includes npm)
    apt-get install -y nodejs

    log_info "Node.js $(node --version) installed"
    log_info "npm $(npm --version) installed"

    STEPS_COMPLETED+=("Node.js 20 LTS")
    log_ok "Node.js 20 LTS installed via NodeSource."
}

# ===========================================================================
# STEP 4: Python 3 + pip + venv
# ===========================================================================
step_python() {
    log_step "Step 4/13: Installing Python 3 + pip + venv"

    if command -v python3 &>/dev/null && dpkg -l python3-pip &>/dev/null 2>&1; then
        log_warn "Python 3 + pip already installed — skipping."
        STEPS_COMPLETED+=("Python 3")
        return
    fi

    export DEBIAN_FRONTEND=noninteractive

    apt-get install -y python3 python3-pip python3-venv

    log_info "Python $(python3 --version 2>&1)"

    STEPS_COMPLETED+=("Python 3")
    log_ok "Python 3 + pip + venv installed."
}

# ===========================================================================
# STEP 5: PostgreSQL 16
# ===========================================================================
step_postgresql() {
    log_step "Step 5/13: Installing PostgreSQL 16 and creating trident database"

    export DEBIAN_FRONTEND=noninteractive

    # Install PostgreSQL if not present
    if ! command -v psql &>/dev/null; then
        # Add official PostgreSQL apt repo for guaranteed v16 on Ubuntu 24.04
        apt-get install -y curl ca-certificates
        install -d /usr/share/postgresql-common/pgdg
        curl -o /usr/share/postgresql-common/pgdg/apt.postgresql.org.asc \
            --fail https://www.postgresql.org/media/keys/ACCC4CF8.asc

        . /etc/os-release
        echo "deb [signed-by=/usr/share/postgresql-common/pgdg/apt.postgresql.org.asc] https://apt.postgresql.org/pub/repos/apt ${VERSION_CODENAME}-pgdg main" \
            > /etc/apt/sources.list.d/pgdg.list

        apt-get update -y
        apt-get install -y postgresql-16 postgresql-contrib-16

        systemctl enable postgresql
        systemctl start postgresql
        log_ok "PostgreSQL 16 installed and running."
    else
        log_warn "PostgreSQL already installed — skipping binary install."
    fi

    # Create system user 'trident' if it doesn't exist (needed for app later too)
    if ! id -u trident &>/dev/null; then
        useradd --system --shell /usr/sbin/nologin --home-dir /opt/trident --create-home trident
        log_ok "System user 'trident' created."
    else
        log_warn "System user 'trident' already exists."
    fi

    # Generate a random password for the PostgreSQL trident user
    DB_PASSWORD=$(openssl rand -base64 24 | tr -d '/+=' | head -c 32)

    # Create PostgreSQL user and database (idempotent)
    local user_exists
    user_exists=$(sudo -u postgres psql -tAc "SELECT 1 FROM pg_roles WHERE rolname='trident'" 2>/dev/null || true)

    if [[ "${user_exists}" != "1" ]]; then
        sudo -u postgres psql -c "CREATE USER trident WITH PASSWORD '${DB_PASSWORD}';"
        log_ok "PostgreSQL user 'trident' created."
    else
        # Reset password to the newly generated one
        sudo -u postgres psql -c "ALTER USER trident PASSWORD '${DB_PASSWORD}';"
        log_warn "PostgreSQL user 'trident' already exists — password reset."
    fi

    local db_exists
    db_exists=$(sudo -u postgres psql -tAc "SELECT 1 FROM pg_database WHERE datname='trident'" 2>/dev/null || true)

    if [[ "${db_exists}" != "1" ]]; then
        sudo -u postgres psql -c "CREATE DATABASE trident OWNER trident;"
        log_ok "Database 'trident' created."
    else
        log_warn "Database 'trident' already exists."
    fi

    sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE trident TO trident;"

    # Configure pg_hba.conf for password auth on the trident database
    local PG_HBA="/etc/postgresql/16/main/pg_hba.conf"
    if ! grep -q "trident.*trident.*scram-sha-256" "${PG_HBA}" 2>/dev/null; then
        # Insert trident-specific rules before the first uncommented local/host line
        sed -i '/^local\s\+all\s\+all/i \
# TRIDENT application user\
local   trident         trident                                 scram-sha-256\
host    trident         trident         127.0.0.1/32            scram-sha-256' "${PG_HBA}"
        systemctl reload postgresql
        log_ok "pg_hba.conf updated for trident user."
    else
        log_warn "pg_hba.conf already configured for trident."
    fi

    # Save DATABASE_URL to config directory
    mkdir -p /etc/trident
    echo "DATABASE_URL=postgresql://trident:${DB_PASSWORD}@127.0.0.1:5432/trident" > /etc/trident/config.env
    chmod 600 /etc/trident/config.env
    chown root:root /etc/trident/config.env

    STEPS_COMPLETED+=("PostgreSQL 16")
    log_ok "PostgreSQL 16 configured. Connection string saved to /etc/trident/config.env"
}

# ===========================================================================
# STEP 6: Nginx
# ===========================================================================
step_nginx() {
    log_step "Step 6/13: Installing Nginx"

    export DEBIAN_FRONTEND=noninteractive

    if command -v nginx &>/dev/null; then
        log_warn "Nginx already installed — skipping."
    else
        apt-get install -y nginx
        log_ok "Nginx installed."
    fi

    systemctl enable nginx
    systemctl start nginx

    STEPS_COMPLETED+=("Nginx")
    log_ok "Nginx enabled and running."
}

# ===========================================================================
# STEP 7: Self-Signed SSL Certificate
# ===========================================================================
step_ssl_cert() {
    log_step "Step 7/13: Generating self-signed SSL certificate for ${LAN_IP}"

    if [[ -f /etc/ssl/trident/trident.crt && -f /etc/ssl/trident/trident.key ]]; then
        log_warn "SSL certificate already exists at /etc/ssl/trident/ — skipping."
        STEPS_COMPLETED+=("SSL Certificate")
        return
    fi

    mkdir -p /etc/ssl/trident

    # Generate a self-signed certificate valid for 10 years
    # SAN includes both DNS name and the detected LAN IP
    openssl req -x509 -nodes -days 3650 \
        -newkey rsa:2048 \
        -keyout /etc/ssl/trident/trident.key \
        -out /etc/ssl/trident/trident.crt \
        -subj "/C=US/ST=Local/L=Homelab/O=TRIDENT/CN=trident.local" \
        -addext "subjectAltName=DNS:trident.local,IP:${LAN_IP}"

    chmod 600 /etc/ssl/trident/trident.key
    chmod 644 /etc/ssl/trident/trident.crt

    STEPS_COMPLETED+=("SSL Certificate")
    log_ok "Self-signed certificate generated for IP ${LAN_IP}."
}

# ===========================================================================
# STEP 8: Nginx Configuration
# ===========================================================================
step_nginx_config() {
    log_step "Step 8/13: Writing Nginx reverse proxy configuration"

    cat > /etc/nginx/sites-available/trident <<'NGINX'
# TRIDENT AI Platform — Nginx reverse proxy configuration
# Auto-generated by trident-bootstrap.sh

upstream trident_backend {
    server 127.0.0.1:5000;
    keepalive 64;
}

# HTTP → HTTPS redirect
server {
    listen 80 default_server;
    listen [::]:80 default_server;
    server_name _;
    return 301 https://$host$request_uri;
}

# HTTPS — reverse proxy to Node.js app on port 5000
server {
    listen 443 ssl http2 default_server;
    listen [::]:443 ssl http2 default_server;
    server_name _;

    ssl_certificate     /etc/ssl/trident/trident.crt;
    ssl_certificate_key /etc/ssl/trident/trident.key;

    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers HIGH:!aNULL:!MD5:!RC4;
    ssl_prefer_server_ciphers on;
    ssl_session_cache shared:SSL:10m;
    ssl_session_timeout 10m;

    add_header X-Frame-Options SAMEORIGIN always;
    add_header X-Content-Type-Options nosniff always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;

    client_max_body_size 50M;

    location / {
        proxy_pass http://trident_backend;
        proxy_set_header Host              $host;
        proxy_set_header X-Real-IP         $remote_addr;
        proxy_set_header X-Forwarded-For   $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;

        proxy_http_version 1.1;
        proxy_set_header Upgrade    $http_upgrade;
        proxy_set_header Connection "upgrade";

        proxy_connect_timeout 60s;
        proxy_send_timeout    120s;
        proxy_read_timeout    120s;
    }

    location /assets/ {
        alias /opt/trident/dist/assets/;
        expires 30d;
        add_header Cache-Control "public, immutable";
        access_log off;
    }
}
NGINX

    # Enable site, remove default
    rm -f /etc/nginx/sites-enabled/default
    ln -sf /etc/nginx/sites-available/trident /etc/nginx/sites-enabled/trident

    # Test and reload
    nginx -t
    systemctl reload nginx

    STEPS_COMPLETED+=("Nginx Config")
    log_ok "Nginx configured as reverse proxy to localhost:5000 with SSL."
}

# ===========================================================================
# STEP 9: UFW Firewall
# ===========================================================================
step_ufw() {
    log_step "Step 9/13: Configuring UFW firewall"

    # Allow required ports
    ufw allow 22/tcp comment 'SSH'
    ufw allow 80/tcp comment 'HTTP redirect'
    ufw allow 443/tcp comment 'HTTPS'

    # Enable non-interactively (--force skips the confirmation prompt)
    ufw --force enable

    STEPS_COMPLETED+=("UFW Firewall")
    log_ok "UFW enabled — ports 22, 80, 443 open."
}

# ===========================================================================
# STEP 10: Ollama
# ===========================================================================
step_ollama() {
    log_step "Step 10/13: Installing Ollama"

    if command -v ollama &>/dev/null; then
        log_warn "Ollama already installed — skipping."
    else
        curl -fsSL https://ollama.com/install.sh | sh
        log_ok "Ollama installed."
    fi

    # Ensure the systemd service is enabled and started
    if systemctl list-unit-files | grep -q ollama.service; then
        systemctl enable ollama
        systemctl start ollama
        log_ok "Ollama systemd service enabled and started."
    else
        log_warn "Ollama systemd service not found — creating manually."

        # Create ollama user if needed
        if ! id -u ollama &>/dev/null; then
            useradd -r -s /bin/false -m -d /usr/share/ollama ollama
        fi

        cat > /etc/systemd/system/ollama.service <<'EOF'
[Unit]
Description=Ollama Server
After=network-online.target

[Service]
ExecStart=/usr/local/bin/ollama serve
User=ollama
Group=ollama
Restart=always
RestartSec=3
Environment="PATH=/usr/local/bin:/usr/bin:/bin"

[Install]
WantedBy=multi-user.target
EOF
        systemctl daemon-reload
        systemctl enable ollama
        systemctl start ollama
        log_ok "Ollama systemd service created and started."
    fi

    STEPS_COMPLETED+=("Ollama")
}

# ===========================================================================
# STEP 11: App Directories
# ===========================================================================
step_directories() {
    log_step "Step 11/13: Creating application directories"

    # /opt/trident — application code
    mkdir -p /opt/trident
    chown trident:trident /opt/trident

    # /etc/trident — configuration (already created in PostgreSQL step)
    mkdir -p /etc/trident
    chmod 750 /etc/trident

    # /var/log/trident — application logs (optional, journald is primary)
    mkdir -p /var/log/trident
    chown trident:trident /var/log/trident

    STEPS_COMPLETED+=("Directories")
    log_ok "Directories created: /opt/trident, /etc/trident, /var/log/trident"
}

# ===========================================================================
# STEP 12: Generate JWT_SECRET and finalize config.env
# ===========================================================================
step_config_env() {
    log_step "Step 12/13: Generating JWT_SECRET and finalizing config.env"

    JWT_SECRET_VALUE=$(openssl rand -hex 32)

    # Read existing DATABASE_URL from config.env (set during PostgreSQL step)
    local db_url=""
    if [[ -f /etc/trident/config.env ]]; then
        db_url=$(grep '^DATABASE_URL=' /etc/trident/config.env | head -1 || true)
    fi

    # If DATABASE_URL is empty, construct it (shouldn't happen if steps ran in order)
    if [[ -z "${db_url}" ]]; then
        db_url="DATABASE_URL=postgresql://trident:CHANGE_ME@127.0.0.1:5432/trident"
        log_warn "DATABASE_URL not found — using placeholder. Update /etc/trident/config.env manually."
    fi

    cat > /etc/trident/config.env <<EOF
# TRIDENT AI Platform — Environment Configuration
# Auto-generated by trident-bootstrap.sh on $(date -Iseconds)

# PostgreSQL connection string
${db_url}

# JWT secret for session token signing
JWT_SECRET=${JWT_SECRET_VALUE}

# Application port (Nginx reverse-proxies to this port)
PORT=5000

# Runtime environment
NODE_ENV=production
EOF

    chmod 600 /etc/trident/config.env
    chown root:root /etc/trident/config.env

    STEPS_COMPLETED+=("Config Env")
    log_ok "JWT_SECRET generated. /etc/trident/config.env finalized."
}

# ===========================================================================
# STEP 13: Systemd Service for TRIDENT
# ===========================================================================
step_systemd_service() {
    log_step "Step 13/13: Writing trident.service systemd unit"

    # Determine the Node.js binary path (NodeSource installs to /usr/bin/node)
    local node_path="/usr/bin/node"
    if [[ ! -x "${node_path}" ]]; then
        node_path=$(command -v node || echo "/usr/bin/node")
    fi

    cat > /etc/systemd/system/trident.service <<EOF
[Unit]
Description=TRIDENT AI Platform
After=network.target postgresql.service
Requires=postgresql.service

[Service]
Type=simple
User=trident
Group=trident
WorkingDirectory=/opt/trident

# Load environment variables from the config file
EnvironmentFile=/etc/trident/config.env

# Start the TRIDENT application
ExecStart=${node_path} dist/index.cjs

# Restart policy — always restart on failure with a 10-second delay
Restart=always
RestartSec=10

# Security hardening
NoNewPrivileges=true
ProtectSystem=strict
ProtectHome=true
ReadWritePaths=/opt/trident /var/log/trident

# Logging
StandardOutput=journal
StandardError=journal
SyslogIdentifier=trident

[Install]
WantedBy=multi-user.target
EOF

    # Reload and enable (but do NOT start — app code not deployed yet)
    systemctl daemon-reload
    systemctl enable trident

    STEPS_COMPLETED+=("Systemd Service")
    log_ok "trident.service written and enabled (not started — deploy app first)."
}

# ===========================================================================
# Completion Summary
# ===========================================================================
print_summary() {
    echo ""
    echo -e "${CYAN}${BOLD}╔══════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${CYAN}${BOLD}║          TRIDENT Phase 1 Bootstrap — Summary                ║${NC}"
    echo -e "${CYAN}${BOLD}╠══════════════════════════════════════════════════════════════╣${NC}"

    # Collect version info
    local node_ver="N/A"
    local npm_ver="N/A"
    local python_ver="N/A"
    local pg_ver="N/A"
    local nginx_ver="N/A"
    local ollama_ver="N/A"

    command -v node    &>/dev/null && node_ver=$(node --version 2>/dev/null || echo "N/A")
    command -v npm     &>/dev/null && npm_ver=$(npm --version 2>/dev/null || echo "N/A")
    command -v python3 &>/dev/null && python_ver=$(python3 --version 2>&1 | awk '{print $2}')
    command -v psql    &>/dev/null && pg_ver=$(psql --version 2>/dev/null | awk '{print $3}' || echo "N/A")
    command -v nginx   &>/dev/null && nginx_ver=$(nginx -v 2>&1 | awk -F/ '{print $2}' || echo "N/A")
    command -v ollama  &>/dev/null && ollama_ver=$(ollama --version 2>/dev/null | awk '{print $NF}' || echo "N/A")

    local components=(
        "System Update"
        "Base Packages"
        "Node.js 20 LTS"
        "Python 3"
        "PostgreSQL 16"
        "Nginx"
        "SSL Certificate"
        "Nginx Config"
        "UFW Firewall"
        "Ollama"
        "Directories"
        "Config Env"
        "Systemd Service"
    )

    for comp in "${components[@]}"; do
        local status="${RED}✗${NC}"
        for done in "${STEPS_COMPLETED[@]}"; do
            if [[ "${done}" == "${comp}" ]]; then
                status="${GREEN}✓${NC}"
                break
            fi
        done
        printf "  ${CYAN}║${NC}  %b  %-50s ${CYAN}║${NC}\n" "${status}" "${comp}"
    done

    echo -e "${CYAN}${BOLD}╠══════════════════════════════════════════════════════════════╣${NC}"
    printf "  ${CYAN}║${NC}  %-56s  ${CYAN}║${NC}\n" "Versions:"
    printf "  ${CYAN}║${NC}    Node.js:    %-43s  ${CYAN}║${NC}\n" "${node_ver}"
    printf "  ${CYAN}║${NC}    npm:        %-43s  ${CYAN}║${NC}\n" "${npm_ver}"
    printf "  ${CYAN}║${NC}    Python:     %-43s  ${CYAN}║${NC}\n" "${python_ver}"
    printf "  ${CYAN}║${NC}    PostgreSQL: %-43s  ${CYAN}║${NC}\n" "${pg_ver}"
    printf "  ${CYAN}║${NC}    Nginx:      %-43s  ${CYAN}║${NC}\n" "${nginx_ver}"
    printf "  ${CYAN}║${NC}    Ollama:     %-43s  ${CYAN}║${NC}\n" "${ollama_ver}"
    echo -e "${CYAN}${BOLD}╠══════════════════════════════════════════════════════════════╣${NC}"
    printf "  ${CYAN}║${NC}  %-56s  ${CYAN}║${NC}\n" "Server LAN IP:  ${LAN_IP}"
    printf "  ${CYAN}║${NC}  %-56s  ${CYAN}║${NC}\n" "Config file:    /etc/trident/config.env"
    printf "  ${CYAN}║${NC}  %-56s  ${CYAN}║${NC}\n" "SSL cert:       /etc/ssl/trident/trident.crt"
    printf "  ${CYAN}║${NC}  %-56s  ${CYAN}║${NC}\n" "App directory:  /opt/trident"
    echo -e "${CYAN}${BOLD}╠══════════════════════════════════════════════════════════════╣${NC}"
    printf "  ${CYAN}║${NC}  ${BOLD}%-56s${NC}  ${CYAN}║${NC}\n" "Next Steps:"
    printf "  ${CYAN}║${NC}  %-56s  ${CYAN}║${NC}\n" "  1. Deploy app to /opt/trident (git clone or scp)"
    printf "  ${CYAN}║${NC}  %-56s  ${CYAN}║${NC}\n" "  2. cd /opt/trident && npm install --production"
    printf "  ${CYAN}║${NC}  %-56s  ${CYAN}║${NC}\n" "  3. npm run build"
    printf "  ${CYAN}║${NC}  %-56s  ${CYAN}║${NC}\n" "  4. sudo systemctl start trident"
    printf "  ${CYAN}║${NC}  %-56s  ${CYAN}║${NC}\n" "  5. Browse to https://${LAN_IP}"
    printf "  ${CYAN}║${NC}  %-56s  ${CYAN}║${NC}\n" "  6. Run trident-verify.sh to confirm everything"
    echo -e "${CYAN}${BOLD}╚══════════════════════════════════════════════════════════════╝${NC}"
    echo ""
}

# ===========================================================================
# Main
# ===========================================================================
main() {
    print_header
    check_root
    detect_ip

    step_system_update      # Step  1
    step_base_packages      # Step  2
    step_nodejs             # Step  3
    step_python             # Step  4
    step_postgresql         # Step  5
    step_nginx              # Step  6
    step_ssl_cert           # Step  7
    step_nginx_config       # Step  8
    step_ufw                # Step  9
    step_ollama             # Step 10
    step_directories        # Step 11
    step_config_env         # Step 12
    step_systemd_service    # Step 13

    print_summary

    echo -e "${GREEN}${BOLD}[ TRIDENT ] Bootstrap complete. Server is ready for app deployment.${NC}\n"
}

main "$@"
