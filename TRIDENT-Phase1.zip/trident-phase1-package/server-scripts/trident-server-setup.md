# TRIDENT AI Platform — Ubuntu 24.04 LTS Server Setup Guide (Phase 1)

**Version:** 1.1  
**Target OS:** Ubuntu 24.04 LTS (Noble Numbat) — minimal server install  
**Deployment:** Proxmox VM, local network access via HTTPS  
**Scope:** Phase 1 — Core platform infrastructure (GPU-agnostic)  
**Last updated:** March 2026

---

## Table of Contents

0. [Automated Bootstrap Script](#0-automated-bootstrap-script)
1. [VM Baseline](#1-vm-baseline)
2. [System Prep](#2-system-prep)
3. [PostgreSQL Setup](#3-postgresql-setup)
4. [Nginx Installation & Config](#4-nginx-installation--config)
5. [Self-Signed SSL Certificate](#5-self-signed-ssl-certificate)
6. [UFW Firewall](#6-ufw-firewall)
7. [TRIDENT App Deployment](#7-trident-app-deployment)
8. [Systemd Service](#8-systemd-service)
9. [Ollama Pre-Install (Phase 2 Readiness)](#9-ollama-pre-install-phase-2-readiness)
10. [Phase 1 Verification Checklist](#10-phase-1-verification-checklist)
11. [Troubleshooting](#11-troubleshooting)
12. [Appendix: Script Source](#12-appendix-script-source)

---

## 0. Automated Bootstrap Script

Before walking through each section manually, you can execute the entire server provisioning in one shot using `trident-bootstrap.sh`. This script is fully non-interactive and handles Sections 2–9 of this guide automatically.

**What the script does (in order):**

| Step | Action |
|------|--------|
| 1 | Full `apt update && apt upgrade` |
| 2 | Install base packages (curl, wget, git, build-essential, etc.) |
| 3 | Install Node.js 20 LTS via NodeSource binary repo |
| 4 | Install Python 3.12 + pip + venv |
| 5 | Install PostgreSQL 16, create `trident` database and user, save `DATABASE_URL` |
| 6 | Install and start Nginx |
| 7 | Generate self-signed SSL cert for the server's detected LAN IP |
| 8 | Write Nginx reverse proxy config (HTTPS → localhost:5000) |
| 9 | Configure UFW (ports 22, 80, 443) |
| 10 | Install Ollama via official script, enable systemd service |
| 11 | Create `/opt/trident`, `/etc/trident`, `/var/log/trident` directories |
| 12 | Generate `JWT_SECRET`, write complete `/etc/trident/config.env` |
| 13 | Write and enable `trident.service` systemd unit (does not start — app not yet deployed) |
| 14 | Print completion summary with all installed versions |

**Usage:**

```bash
# Transfer the script to the server
scp trident-bootstrap.sh admin@<SERVER_IP>:/tmp/

# SSH into the server
ssh admin@<SERVER_IP>

# Make executable and run as root
chmod +x /tmp/trident-bootstrap.sh
sudo /tmp/trident-bootstrap.sh
```

> **Idempotent:** The script checks for existing installations before each step. Safe to re-run on partial failures.

After the bootstrap completes, deploy your application to `/opt/trident` (see [Section 7](#7-trident-app-deployment)) and start the service with `sudo systemctl start trident`.

**Post-deployment verification:**

```bash
# Transfer and run the verification script
scp trident-verify.sh admin@<SERVER_IP>:/tmp/
ssh admin@<SERVER_IP>
chmod +x /tmp/trident-verify.sh
sudo /tmp/trident-verify.sh
```

Both scripts are included as full, copy-pasteable code blocks in [Section 12: Appendix](#12-appendix-script-source) and are also provided as separate downloadable files alongside this guide.

---

## 1. VM Baseline

### Recommended Proxmox VM Specifications (Phase 1)

| Resource | Minimum | Recommended | Notes |
|----------|---------|-------------|-------|
| CPU | 4 vCPU | 8 vCPU | `host` CPU type for best performance; adjust upward if Ollama CPU inference is planned |
| RAM | 8 GB | 16 GB | PostgreSQL + Node.js + Nginx baseline is ~2 GB; headroom for Ollama in Phase 2 |
| Disk | 40 GB | 100 GB | SSD/NVMe-backed storage strongly preferred; LLM model files in Phase 2 will consume 10–40 GB each |
| Network | 1x virtio NIC | 1x virtio NIC | Bridged to LAN; assign a static IP via DHCP reservation or Netplan |

### Ubuntu 24.04 LTS Minimal Server Install Notes

- Download the **Ubuntu Server 24.04 LTS** ISO from [releases.ubuntu.com](https://releases.ubuntu.com/24.04/).
- During Proxmox VM creation, set **BIOS** to OVMF (UEFI) or SeaBIOS depending on your environment. SCSI controller: `VirtIO SCSI single`.
- Choose **Ubuntu Server (minimized)** during installation. Do not install a desktop environment.
- Enable **OpenSSH server** during the install wizard.
- Set the hostname to `trident` (or your preferred FQDN-compatible name).
- Create a non-root admin user (e.g., `admin`). All commands below assume `sudo` access via this user.
- After first boot, confirm static IP assignment:

```bash
# Verify IP address
ip addr show
```

> **Note:** GPU passthrough (PCI-e) configuration is deferred to Phase 2. The VM definition here is intentionally GPU-agnostic.

---

## 2. System Prep

### 2.1 Full System Upgrade

```bash
# Update package lists and upgrade all installed packages to latest versions
sudo apt update && sudo apt upgrade -y

# Reboot if a new kernel was installed
sudo reboot
```

### 2.2 Essential Tools

```bash
# Install core utilities for building software, networking diagnostics, and system monitoring
sudo apt install -y \
  curl \
  wget \
  git \
  build-essential \
  unzip \
  net-tools \
  ufw \
  htop \
  gnupg \
  ca-certificates \
  lsb-release
```

### 2.3 Node.js 20 LTS via nvm

```bash
# Download and run the nvm installer script (v0.39.7)
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.7/install.sh | bash

# Reload shell configuration so nvm is available in the current session
source ~/.bashrc

# Install Node.js 20 LTS (the active LTS release)
nvm install 20

# Set Node.js 20 as the active version for this session
nvm use 20

# Pin Node.js 20 as the default for all future shell sessions
nvm alias default 20

# Verify installation
node --version   # Expected: v20.x.x
npm --version    # Expected: 10.x.x
```

> **Important:** `nvm` installs Node.js per-user. The systemd service in [Section 8](#8-systemd-service) references an absolute path to the node binary. After installing via nvm, note the path with `which node` — you will need it later. Alternatively, the [bootstrap script](#0-automated-bootstrap-script) uses NodeSource to install Node.js system-wide, which avoids this issue entirely.

### 2.4 Python 3.12 + pip

Ubuntu 24.04 ships with Python 3.12 by default. Install pip and venv for future ML/AI workloads:

```bash
# Install Python 3 package manager and virtual environment support
sudo apt install -y python3 python3-pip python3-venv

# Verify installation
python3 --version   # Expected: Python 3.12.x
pip3 --version
```

> **Note:** Python is not used in Phase 1 but is pre-installed here for Phase 2 readiness (model pipelines, data processing).

---

## 3. PostgreSQL Setup

### 3.1 Install PostgreSQL 16

Ubuntu 24.04 includes PostgreSQL 16 in the default repositories:

```bash
# Install PostgreSQL 16 server and client tools
sudo apt install -y postgresql postgresql-contrib

# Verify the service is running
sudo systemctl status postgresql

# Confirm the version
sudo -u postgres psql -c "SELECT version();"
# Expected: PostgreSQL 16.x
```

### 3.2 Create TRIDENT Database and User

```bash
# Switch to the postgres system user and open the psql shell
sudo -u postgres psql
```

Execute the following SQL inside the `psql` prompt:

```sql
-- Create a dedicated database user for TRIDENT
CREATE USER trident WITH PASSWORD 'CHANGE_ME_USE_A_STRONG_PASSWORD';

-- Create the application database owned by the trident user
CREATE DATABASE trident OWNER trident;

-- Grant all privileges on the trident database to the trident user
GRANT ALL PRIVILEGES ON DATABASE trident TO trident;

-- Exit psql
\q
```

> **Security:** Replace `CHANGE_ME_USE_A_STRONG_PASSWORD` with a cryptographically random password. Generate one with: `openssl rand -base64 24`

### 3.3 Configure pg_hba.conf for Local Auth

Ensure the trident user can authenticate via password over localhost:

```bash
# Edit the PostgreSQL client authentication file
sudo nano /etc/postgresql/16/main/pg_hba.conf
```

Locate the `local` and `IPv4` sections. Ensure these lines exist (or modify existing entries):

```
# TYPE  DATABASE        USER            ADDRESS                 METHOD
local   trident         trident                                 scram-sha-256
host    trident         trident         127.0.0.1/32            scram-sha-256
```

```bash
# Reload PostgreSQL to apply authentication changes
sudo systemctl reload postgresql
```

### 3.4 Test Connectivity

```bash
# Test the connection as the trident user
psql -U trident -d trident -h 127.0.0.1 -c "SELECT current_database(), current_user;"
# Expected output: trident | trident
```

### 3.5 Save Connection String

```bash
# Create the TRIDENT configuration directory
sudo mkdir -p /etc/trident

# Write the database connection string to the config file
# Replace the password with the one you set above
sudo tee /etc/trident/config.env > /dev/null <<'EOF'
DATABASE_URL=postgresql://trident:CHANGE_ME_USE_A_STRONG_PASSWORD@127.0.0.1:5432/trident
EOF

# Restrict file permissions — only root can read this file
sudo chmod 600 /etc/trident/config.env
sudo chown root:root /etc/trident/config.env
```

---

## 4. Nginx Installation & Config

### 4.1 Install Nginx

```bash
# Install the Nginx web server
sudo apt install -y nginx

# Verify installation and service status
sudo systemctl status nginx
nginx -v
```

### 4.2 Create TRIDENT Site Configuration

```bash
# Create the Nginx configuration for the TRIDENT reverse proxy
sudo tee /etc/nginx/sites-available/trident > /dev/null <<'NGINX'
# Upstream definition for the TRIDENT Node.js application
upstream trident_backend {
    server 127.0.0.1:5000;

    # Keep-alive connections to reduce TCP overhead
    keepalive 64;
}

# HTTP → HTTPS redirect (all HTTP traffic redirects to HTTPS)
server {
    listen 80 default_server;
    listen [::]:80 default_server;
    server_name _;

    # Redirect all HTTP requests to HTTPS
    return 301 https://$host$request_uri;
}

# HTTPS server block — reverse proxy to TRIDENT app
server {
    listen 443 ssl http2 default_server;
    listen [::]:443 ssl http2 default_server;
    server_name _;

    # SSL certificate paths (configured in Section 5)
    ssl_certificate     /etc/ssl/trident/trident.crt;
    ssl_certificate_key /etc/ssl/trident/trident.key;

    # SSL hardening
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers HIGH:!aNULL:!MD5:!RC4;
    ssl_prefer_server_ciphers on;
    ssl_session_cache shared:SSL:10m;
    ssl_session_timeout 10m;

    # Security headers
    add_header X-Frame-Options SAMEORIGIN always;
    add_header X-Content-Type-Options nosniff always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;

    # Request size limit (increase if handling file uploads)
    client_max_body_size 50M;

    # Proxy all requests to the TRIDENT Node.js backend
    location / {
        proxy_pass http://trident_backend;

        # Pass original client information to the backend
        proxy_set_header Host              $host;
        proxy_set_header X-Real-IP         $remote_addr;
        proxy_set_header X-Forwarded-For   $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;

        # WebSocket support (for future real-time features)
        proxy_http_version 1.1;
        proxy_set_header Upgrade    $http_upgrade;
        proxy_set_header Connection "upgrade";

        # Timeouts — increase for long-running AI inference requests
        proxy_connect_timeout 60s;
        proxy_send_timeout    120s;
        proxy_read_timeout    120s;
    }

    # Serve static assets directly via Nginx if placed in /opt/trident/public
    location /assets/ {
        alias /opt/trident/dist/assets/;
        expires 30d;
        add_header Cache-Control "public, immutable";
        access_log off;
    }
}
NGINX
```

### 4.3 Enable the Site and Test

```bash
# Remove the default Nginx site
sudo rm -f /etc/nginx/sites-enabled/default

# Enable the TRIDENT site via symlink
sudo ln -sf /etc/nginx/sites-available/trident /etc/nginx/sites-enabled/trident

# Test the Nginx configuration for syntax errors
sudo nginx -t
# Expected: syntax is ok / test is successful

# Note: Do NOT reload Nginx yet — the SSL certificates must be created first (Section 5).
```

---

## 5. Self-Signed SSL Certificate

### 5.1 Generate the Certificate

Replace `192.168.1.100` below with your server's actual static LAN IP address.

```bash
# Create directory for TRIDENT SSL certificates
sudo mkdir -p /etc/ssl/trident

# Generate a self-signed certificate valid for 3650 days (10 years)
# The SAN (Subject Alternative Name) includes the local IP for browser compatibility
sudo openssl req -x509 -nodes -days 3650 \
  -newkey rsa:2048 \
  -keyout /etc/ssl/trident/trident.key \
  -out /etc/ssl/trident/trident.crt \
  -subj "/C=US/ST=Local/L=Homelab/O=TRIDENT/CN=trident.local" \
  -addext "subjectAltName=DNS:trident.local,IP:192.168.1.100"

# Restrict permissions on the private key
sudo chmod 600 /etc/ssl/trident/trident.key
sudo chmod 644 /etc/ssl/trident/trident.crt
```

### 5.2 Reload Nginx with SSL

```bash
# Verify configuration is still valid
sudo nginx -t

# Reload Nginx to apply the SSL configuration
sudo systemctl reload nginx
```

### 5.3 Trusting the Certificate on Client Browsers

Since this is a self-signed certificate, browsers will display a security warning on first access.

**Option A — Accept the warning per browser:**  
Navigate to `https://192.168.1.100` and click through the browser's "Advanced" → "Accept the risk" prompt. This is the quickest method for a homelab.

**Option B — Import the CA certificate into client trust stores (recommended for multiple users):**

1. Copy the certificate to a client machine:
   ```bash
   scp admin@192.168.1.100:/etc/ssl/trident/trident.crt ~/trident.crt
   ```
2. **Windows:** Double-click the `.crt` file → Install Certificate → Local Machine → Trusted Root Certification Authorities.
3. **macOS:** Double-click the `.crt` → add to Keychain → set trust to "Always Trust."
4. **Linux (Chrome/Chromium):** Import via `Settings` → `Privacy and security` → `Manage certificates` → `Authorities` → Import.
5. **Firefox (all platforms):** `Settings` → `Privacy & Security` → `View Certificates` → `Authorities` → Import.

---

## 6. UFW Firewall

### 6.1 Configure Rules

```bash
# Allow SSH access (required for remote administration)
sudo ufw allow 22/tcp comment 'SSH'

# Allow HTTP (used only for the HTTPS redirect)
sudo ufw allow 80/tcp comment 'HTTP redirect'

# Allow HTTPS (primary application access)
sudo ufw allow 443/tcp comment 'HTTPS'
```

### 6.2 Enable UFW

```bash
# Enable the firewall (will prompt for confirmation)
sudo ufw enable

# Verify the active rules
sudo ufw status verbose
```

Expected output:

```
Status: active
Logging: on (low)
Default: deny (incoming), allow (outgoing), disabled (routed)
New profiles: skip

To                         Action      From
--                         ------      ----
22/tcp                     ALLOW IN    Anywhere                   # SSH
80/tcp                     ALLOW IN    Anywhere                   # HTTP redirect
443/tcp                    ALLOW IN    Anywhere                   # HTTPS
22/tcp (v6)                ALLOW IN    Anywhere (v6)              # SSH
80/tcp (v6)                ALLOW IN    Anywhere (v6)              # HTTP redirect
443/tcp (v6)               ALLOW IN    Anywhere (v6)              # HTTPS
```

> **Warning:** Ensure SSH (port 22) is allowed before enabling UFW. If you lock yourself out, access the VM via the Proxmox console.

---

## 7. TRIDENT App Deployment

### 7.1 Create Application Directory and User

```bash
# Create a dedicated system user for the TRIDENT service (no login shell)
sudo useradd --system --shell /usr/sbin/nologin --home-dir /opt/trident --create-home trident

# Create the application directory structure
sudo mkdir -p /opt/trident
sudo chown trident:trident /opt/trident
```

### 7.2 Deploy Application Files

```bash
# Option A: Clone from Git repository (replace with your actual repo URL)
sudo -u trident git clone https://your-git-server/trident/trident-app.git /opt/trident

# Option B: Copy files from local build machine via scp
# scp -r ./trident-app/* admin@192.168.1.100:/tmp/trident-deploy/
# sudo cp -r /tmp/trident-deploy/* /opt/trident/
# sudo chown -R trident:trident /opt/trident
```

### 7.3 Install Dependencies and Build

```bash
# Switch to the application directory
cd /opt/trident

# Install production dependencies only (skip devDependencies)
sudo -u trident npm install --production

# Build the application (compiles TypeScript, bundles frontend assets, etc.)
sudo -u trident npm run build
```

> **Note:** If you used the bootstrap script, Node.js is installed system-wide via NodeSource and is available to all users including `trident`. If you installed via `nvm` instead, see [Section 8.1](#81-determine-the-nodejs-binary-path) for path considerations.

### 7.4 Configure Environment Variables

```bash
# Generate a cryptographically secure JWT signing secret
JWT_SECRET=$(openssl rand -hex 32)

# Write the full application configuration
sudo tee /etc/trident/config.env > /dev/null <<EOF
# TRIDENT AI Platform — Environment Configuration
# Phase 1

# PostgreSQL connection string
DATABASE_URL=postgresql://trident:CHANGE_ME_USE_A_STRONG_PASSWORD@127.0.0.1:5432/trident

# JWT secret for session token signing (auto-generated)
JWT_SECRET=${JWT_SECRET}

# Application port (Nginx proxies to this port)
PORT=5000

# Runtime environment
NODE_ENV=production
EOF

# Lock down permissions
sudo chmod 600 /etc/trident/config.env
sudo chown root:root /etc/trident/config.env
```

---

## 8. Systemd Service

### 8.1 Determine the Node.js Binary Path

```bash
# If installed via NodeSource (bootstrap script), node is at:
which node
# Expected: /usr/bin/node

# If installed via nvm, find the absolute path:
# Example: /home/admin/.nvm/versions/node/v20.18.0/bin/node
# For systemd, copy it system-wide:
# sudo cp $(which node) /usr/local/bin/node
```

### 8.2 Create the Service Unit File

```bash
# Create the TRIDENT systemd service file
sudo tee /etc/systemd/system/trident.service > /dev/null <<'EOF'
[Unit]
Description=TRIDENT AI Platform
Documentation=https://github.com/your-org/trident
After=network.target postgresql.service
Requires=postgresql.service

[Service]
Type=simple
User=trident
Group=trident
WorkingDirectory=/opt/trident

# Load environment variables from the config file
EnvironmentFile=/etc/trident/config.env

# Start the TRIDENT application
ExecStart=/usr/bin/node dist/index.cjs

# Restart policy — always restart on failure with a 10-second delay
Restart=always
RestartSec=10

# Security hardening
NoNewPrivileges=true
ProtectSystem=strict
ProtectHome=true
ReadWritePaths=/opt/trident

# Logging — output goes to journald
StandardOutput=journal
StandardError=journal
SyslogIdentifier=trident

[Install]
WantedBy=multi-user.target
EOF
```

### 8.3 Enable and Start the Service

```bash
# Reload systemd to pick up the new unit file
sudo systemctl daemon-reload

# Enable TRIDENT to start on boot
sudo systemctl enable trident

# Start the service
sudo systemctl start trident

# Verify the service is running
sudo systemctl status trident
```

Expected output:

```
● trident.service - TRIDENT AI Platform
     Loaded: loaded (/etc/systemd/system/trident.service; enabled; preset: enabled)
     Active: active (running) since ...
```

### 8.4 View Logs

```bash
# Stream live application logs
sudo journalctl -u trident -f

# View the last 100 lines of logs
sudo journalctl -u trident -n 100 --no-pager
```

---

## 9. Ollama Pre-Install (Phase 2 Readiness)

Ollama provides a local LLM inference server. This section installs it for Phase 2 readiness. No GPU drivers are configured — CPU-only inference is available for validation.

### 9.1 Install Ollama

```bash
# Download and run the official Ollama install script
curl -fsSL https://ollama.com/install.sh | sh
```

The install script automatically:
- Downloads the Ollama binary to `/usr/local/bin/ollama`
- Creates an `ollama` system user and group
- Installs and enables a systemd service

### 9.2 Verify the Systemd Service

```bash
# Check that the Ollama service is running
sudo systemctl status ollama
```

If the service was not created by the install script (e.g., systemd was unavailable), create it manually:

```bash
# Create the ollama system user (if not already created by the installer)
sudo useradd -r -s /bin/false -m -d /usr/share/ollama ollama

# Create the systemd service file
sudo tee /etc/systemd/system/ollama.service > /dev/null <<'EOF'
[Unit]
Description=Ollama Server
After=network-online.target

[Service]
ExecStart=/usr/local/bin/ollama serve
User=ollama
Group=ollama
Restart=always
RestartSec=3
Environment="PATH=/usr/local/bin:/usr/bin:/bin"

[Install]
WantedBy=multi-user.target
EOF

# Reload, enable, and start
sudo systemctl daemon-reload
sudo systemctl enable ollama
sudo systemctl start ollama
```

### 9.3 Pull a Test Model

```bash
# Download the Llama 3.2 model (~2 GB) for validation
ollama pull llama3.2

# Test inference with a simple prompt
ollama run llama3.2 "Respond with exactly: TRIDENT Phase 2 ready."
```

### 9.4 Verify Ollama API

```bash
# The Ollama API listens on port 11434 by default
curl http://localhost:11434/api/tags
# Expected: JSON response listing the llama3.2 model
```

> **Phase 2 Note:** GPU drivers (NVIDIA CUDA or AMD ROCm) and Ollama GPU configuration will be addressed in a future guide. CPU inference works out of the box but is significantly slower than GPU-accelerated inference.

---

## 10. Phase 1 Verification Checklist

Run each check sequentially after completing all setup steps. Every item must pass before Phase 1 is considered complete. You can also run `trident-verify.sh` (see [Section 12](#122-trident-verifysh)) for automated validation.

```bash
# === TRIDENT Phase 1 Verification ===

# 1. SSH connectivity
echo "1. SSH access"
ssh admin@192.168.1.100 "echo 'SSH OK'"

# 2. Node.js version
echo "2. Node.js"
node --version | grep -q "v20" && echo "PASS: Node.js 20" || echo "FAIL"

# 3. PostgreSQL service and database
echo "3. PostgreSQL"
sudo systemctl is-active postgresql && \
psql -U trident -d trident -h 127.0.0.1 -c "SELECT 1;" > /dev/null 2>&1 && \
echo "PASS: PostgreSQL + trident DB" || echo "FAIL"

# 4. Nginx HTTPS
echo "4. Nginx HTTPS"
curl -sk https://localhost | grep -qi "trident" && \
echo "PASS: Nginx HTTPS serving TRIDENT" || echo "FAIL"

# 5. TRIDENT app accessible in browser
echo "5. App login page"
curl -sk https://192.168.1.100 -o /dev/null -w "%{http_code}" | grep -q "200" && \
echo "PASS: Login page reachable" || echo "FAIL"

# 6. User registration creates DB record
echo "6. DB record check (after registering a test user)"
psql -U trident -d trident -h 127.0.0.1 -c "SELECT id, email FROM users LIMIT 5;"

# 7. Admin user exists
echo "7. Admin user"
psql -U trident -d trident -h 127.0.0.1 -c "SELECT id, email, role FROM users WHERE role = 'admin';"

# 8. TRIDENT systemd service
echo "8. TRIDENT service"
sudo systemctl is-active trident && echo "PASS: trident active" || echo "FAIL"

# 9. UFW status
echo "9. UFW"
sudo ufw status | grep -q "Status: active" && echo "PASS: UFW active" || echo "FAIL"
sudo ufw status numbered

# 10. Ollama
echo "10. Ollama"
ollama --version && \
curl -s http://localhost:11434/api/tags | grep -q "llama3.2" && \
echo "PASS: Ollama + llama3.2 model" || echo "FAIL"
```

### Summary Checklist

| # | Check | Command | Expected |
|---|-------|---------|----------|
| 1 | SSH reachable | `ssh admin@<IP>` | Login succeeds |
| 2 | Node.js 20 installed | `node --version` | `v20.x.x` |
| 3 | PostgreSQL running, DB accessible | `psql -U trident -d trident -h 127.0.0.1` | Connected |
| 4 | Nginx serving HTTPS | `curl -sk https://localhost` | HTML response |
| 5 | TRIDENT login page loads | Browser → `https://<IP>` | Login page renders |
| 6 | User registration → DB record | `SELECT * FROM users;` | Row exists |
| 7 | Admin user exists | `SELECT * FROM users WHERE role='admin';` | Row exists |
| 8 | systemd service active | `systemctl status trident` | `active (running)` |
| 9 | UFW active with correct rules | `sudo ufw status` | Ports 22, 80, 443 |
| 10 | Ollama installed, test model responds | `ollama run llama3.2 "hello"` | Text response |

---

## 11. Troubleshooting

### Nginx 502 Bad Gateway

**Symptom:** Accessing `https://<IP>` returns a `502 Bad Gateway` error.

**Root causes and fixes:**

```bash
# 1. Check if the TRIDENT Node.js app is actually running
sudo systemctl status trident
# If inactive/failed, check logs:
sudo journalctl -u trident -n 50 --no-pager

# 2. Verify the app is listening on port 5000
sudo ss -tlnp | grep 5000
# If nothing is listening, the app failed to start. Check EnvironmentFile path and NODE_ENV.

# 3. Confirm the upstream port in Nginx matches the app's PORT
grep proxy_pass /etc/nginx/sites-available/trident
# Must point to 127.0.0.1:5000

# 4. Check Nginx error logs for details
sudo tail -20 /var/log/nginx/error.log

# 5. Test direct backend connectivity (bypassing Nginx)
curl -s http://127.0.0.1:5000/
# If this works but Nginx doesn't, the issue is in the Nginx config.
```

### SSL Certificate Trust Issues

**Symptom:** Browser shows "Your connection is not private" / `NET::ERR_CERT_AUTHORITY_INVALID`.

```bash
# 1. Verify the certificate contains the correct SAN (Subject Alternative Name)
openssl x509 -in /etc/ssl/trident/trident.crt -text -noout | grep -A2 "Subject Alternative Name"
# Must include your server's IP address: IP:192.168.1.100

# 2. If the IP doesn't match, regenerate the certificate (Section 5.1) with the correct IP

# 3. Check certificate expiry
openssl x509 -in /etc/ssl/trident/trident.crt -noout -enddate

# 4. Verify Nginx is loading the correct certificate
sudo nginx -T 2>/dev/null | grep ssl_certificate
```

**Fix for Chrome `NET::ERR_CERT_COMMON_NAME_INVALID`:**  
Modern Chrome requires a Subject Alternative Name (SAN), not just a Common Name (CN). The `openssl` command in Section 5.1 includes `-addext "subjectAltName=..."` to address this. If you generated the cert without the SAN, regenerate it.

### PostgreSQL Authentication Failures

**Symptom:** `psql: error: connection to server failed: FATAL: password authentication failed for user "trident"`

```bash
# 1. Verify the pg_hba.conf entry for the trident user
sudo grep trident /etc/postgresql/16/main/pg_hba.conf
# Must show: host trident trident 127.0.0.1/32 scram-sha-256

# 2. Verify you're connecting to the right host
# Common mistake: using "localhost" resolves to a Unix socket, not TCP
# Always use -h 127.0.0.1 to force TCP connection
psql -U trident -d trident -h 127.0.0.1

# 3. Reset the password if needed
sudo -u postgres psql -c "ALTER USER trident PASSWORD 'new_strong_password_here';"

# 4. Update the connection string in /etc/trident/config.env to match
sudo nano /etc/trident/config.env

# 5. Restart the TRIDENT service to pick up the new password
sudo systemctl restart trident

# 6. If using 'local' connections (Unix socket), verify the auth method:
sudo grep "local.*trident" /etc/postgresql/16/main/pg_hba.conf
# Must show: local trident trident scram-sha-256
# Then reload: sudo systemctl reload postgresql
```

### TRIDENT Service Fails to Start

```bash
# Check detailed service failure information
sudo systemctl status trident
sudo journalctl -u trident --since "5 min ago"

# Common issues:
# - ExecStart path wrong: verify /usr/bin/node exists (NodeSource) or /usr/local/bin/node (nvm copy)
#   ls -la /usr/bin/node
#
# - dist/index.cjs missing: ensure npm run build completed successfully
#   ls -la /opt/trident/dist/index.cjs
#
# - Permission denied: ensure /opt/trident is owned by trident user
#   sudo chown -R trident:trident /opt/trident
#
# - EnvironmentFile not found: verify /etc/trident/config.env exists
#   ls -la /etc/trident/config.env
#
# - Port 5000 already in use:
#   sudo ss -tlnp | grep 5000
```

### Ollama Not Responding

```bash
# 1. Check service status
sudo systemctl status ollama

# 2. Check if Ollama is listening
curl http://localhost:11434

# 3. If running but model fails, check disk space (models are large)
df -h /usr/share/ollama

# 4. View Ollama logs
sudo journalctl -u ollama -n 50 --no-pager

# 5. If using CPU-only and inference is slow, this is expected
# GPU passthrough will be configured in Phase 2
```

---

## 12. Appendix: Script Source

Both scripts below are complete and copy-pasteable. They are also provided as separate downloadable files: `trident-bootstrap.sh` and `trident-verify.sh`.

### 12.1 trident-bootstrap.sh

```bash
#!/usr/bin/env bash
# =============================================================================
# TRIDENT AI Platform — Automated Server Bootstrap (Phase 1)
# Target: Ubuntu 24.04 LTS (Noble Numbat) on Proxmox VM
# Usage:  sudo ./trident-bootstrap.sh
# =============================================================================

set -euo pipefail

# ---------------------------------------------------------------------------
# ANSI color codes
# ---------------------------------------------------------------------------
CYAN='\033[0;36m'
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
BOLD='\033[1m'
NC='\033[0m' # No Color

# ---------------------------------------------------------------------------
# Global state
# ---------------------------------------------------------------------------
CURRENT_STEP=""
STEPS_COMPLETED=()
STEPS_FAILED=()
DB_PASSWORD=""
JWT_SECRET_VALUE=""
LAN_IP=""

# ---------------------------------------------------------------------------
# ASCII art header
# ---------------------------------------------------------------------------
print_header() {
    echo -e "${CYAN}"
    cat << 'ASCIIART'

  ████████╗██████╗ ██╗██████╗ ███████╗███╗   ██╗████████╗
  ╚══██╔══╝██╔══██╗██║██╔══██╗██╔════╝████╗  ██║╚══██╔══╝
     ██║   ██████╔╝██║██║  ██║█████╗  ██╔██╗ ██║   ██║
     ██║   ██╔══██╗██║██║  ██║██╔══╝  ██║╚██╗██║   ██║
     ██║   ██║  ██║██║██████╔╝███████╗██║ ╚████║   ██║
     ╚═╝   ╚═╝  ╚═╝╚═╝╚═════╝ ╚══════╝╚═╝  ╚═══╝   ╚═╝

     AI Platform — Phase 1 Server Bootstrap
     Ubuntu 24.04 LTS | Proxmox VM

ASCIIART
    echo -e "${NC}"
}

# ---------------------------------------------------------------------------
# Logging helpers
# ---------------------------------------------------------------------------
log_step() {
    CURRENT_STEP="$1"
    echo -e "\n${CYAN}${BOLD}[ TRIDENT ]${NC} ${CYAN}$1${NC}"
}

log_info() {
    echo -e "  ${BOLD}→${NC} $1"
}

log_ok() {
    echo -e "  ${GREEN}✓${NC} $1"
}

log_warn() {
    echo -e "  ${YELLOW}⚠${NC} $1"
}

log_fail() {
    echo -e "\n${RED}${BOLD}[ TRIDENT ] SETUP FAILED at step: ${CURRENT_STEP}${NC}"
    echo -e "${RED}  Review the output above for details.${NC}\n"
    STEPS_FAILED+=("${CURRENT_STEP}")
    print_summary
    exit 1
}

# Trap any unhandled error and report which step failed
trap 'log_fail' ERR

# ---------------------------------------------------------------------------
# Root check
# ---------------------------------------------------------------------------
check_root() {
    if [[ $EUID -ne 0 ]]; then
        echo -e "${RED}[ TRIDENT ] This script must be run as root (sudo).${NC}"
        exit 1
    fi
}

# ---------------------------------------------------------------------------
# Detect LAN IP
# ---------------------------------------------------------------------------
detect_ip() {
    LAN_IP=$(hostname -I | awk '{print $1}')
    if [[ -z "${LAN_IP}" ]]; then
        echo -e "${RED}[ TRIDENT ] Could not detect LAN IP address.${NC}"
        exit 1
    fi
    log_info "Detected LAN IP: ${LAN_IP}"
}

# ===========================================================================
# STEP 1: System Update
# ===========================================================================
step_system_update() {
    log_step "Step 1/13: System update (apt update && apt upgrade)"

    if [[ -f /var/lib/trident/.step_system_update_done ]]; then
        log_warn "Already completed — skipping."
        STEPS_COMPLETED+=("System Update")
        return
    fi

    # Prevent interactive prompts during upgrade
    export DEBIAN_FRONTEND=noninteractive

    apt-get update -y
    apt-get upgrade -y -o Dpkg::Options::="--force-confdef" -o Dpkg::Options::="--force-confold"

    mkdir -p /var/lib/trident
    touch /var/lib/trident/.step_system_update_done
    STEPS_COMPLETED+=("System Update")
    log_ok "System packages updated."
}

# ===========================================================================
# STEP 2: Base Packages
# ===========================================================================
step_base_packages() {
    log_step "Step 2/13: Installing base packages"

    if command -v git &>/dev/null && command -v curl &>/dev/null && command -v htop &>/dev/null; then
        log_warn "Base packages already installed — skipping."
        STEPS_COMPLETED+=("Base Packages")
        return
    fi

    export DEBIAN_FRONTEND=noninteractive

    apt-get install -y \
        curl \
        wget \
        git \
        build-essential \
        unzip \
        net-tools \
        ufw \
        htop \
        gnupg \
        ca-certificates \
        lsb-release

    STEPS_COMPLETED+=("Base Packages")
    log_ok "Base packages installed."
}

# ===========================================================================
# STEP 3: Node.js 20 LTS via NodeSource
# ===========================================================================
step_nodejs() {
    log_step "Step 3/13: Installing Node.js 20 LTS (NodeSource)"

    if command -v node &>/dev/null; then
        local node_ver
        node_ver=$(node --version 2>/dev/null || true)
        if [[ "${node_ver}" == v20.* ]]; then
            log_warn "Node.js ${node_ver} already installed — skipping."
            STEPS_COMPLETED+=("Node.js 20 LTS")
            return
        fi
    fi

    export DEBIAN_FRONTEND=noninteractive

    # Add NodeSource repository for Node.js 20.x
    curl -fsSL https://deb.nodesource.com/setup_20.x | bash -

    # Install Node.js (includes npm)
    apt-get install -y nodejs

    log_info "Node.js $(node --version) installed"
    log_info "npm $(npm --version) installed"

    STEPS_COMPLETED+=("Node.js 20 LTS")
    log_ok "Node.js 20 LTS installed via NodeSource."
}

# ===========================================================================
# STEP 4: Python 3 + pip + venv
# ===========================================================================
step_python() {
    log_step "Step 4/13: Installing Python 3 + pip + venv"

    if command -v python3 &>/dev/null && dpkg -l python3-pip &>/dev/null 2>&1; then
        log_warn "Python 3 + pip already installed — skipping."
        STEPS_COMPLETED+=("Python 3")
        return
    fi

    export DEBIAN_FRONTEND=noninteractive

    apt-get install -y python3 python3-pip python3-venv

    log_info "Python $(python3 --version 2>&1)"

    STEPS_COMPLETED+=("Python 3")
    log_ok "Python 3 + pip + venv installed."
}

# ===========================================================================
# STEP 5: PostgreSQL 16
# ===========================================================================
step_postgresql() {
    log_step "Step 5/13: Installing PostgreSQL 16 and creating trident database"

    export DEBIAN_FRONTEND=noninteractive

    # Install PostgreSQL if not present
    if ! command -v psql &>/dev/null; then
        # Add official PostgreSQL apt repo for guaranteed v16 on Ubuntu 24.04
        apt-get install -y curl ca-certificates
        install -d /usr/share/postgresql-common/pgdg
        curl -o /usr/share/postgresql-common/pgdg/apt.postgresql.org.asc \
            --fail https://www.postgresql.org/media/keys/ACCC4CF8.asc

        . /etc/os-release
        echo "deb [signed-by=/usr/share/postgresql-common/pgdg/apt.postgresql.org.asc] https://apt.postgresql.org/pub/repos/apt ${VERSION_CODENAME}-pgdg main" \
            > /etc/apt/sources.list.d/pgdg.list

        apt-get update -y
        apt-get install -y postgresql-16 postgresql-contrib-16

        systemctl enable postgresql
        systemctl start postgresql
        log_ok "PostgreSQL 16 installed and running."
    else
        log_warn "PostgreSQL already installed — skipping binary install."
    fi

    # Create system user 'trident' if it doesn't exist (needed for app later too)
    if ! id -u trident &>/dev/null; then
        useradd --system --shell /usr/sbin/nologin --home-dir /opt/trident --create-home trident
        log_ok "System user 'trident' created."
    else
        log_warn "System user 'trident' already exists."
    fi

    # Generate a random password for the PostgreSQL trident user
    DB_PASSWORD=$(openssl rand -base64 24 | tr -d '/+=' | head -c 32)

    # Create PostgreSQL user and database (idempotent)
    local user_exists
    user_exists=$(sudo -u postgres psql -tAc "SELECT 1 FROM pg_roles WHERE rolname='trident'" 2>/dev/null || true)

    if [[ "${user_exists}" != "1" ]]; then
        sudo -u postgres psql -c "CREATE USER trident WITH PASSWORD '${DB_PASSWORD}';"
        log_ok "PostgreSQL user 'trident' created."
    else
        # Reset password to the newly generated one
        sudo -u postgres psql -c "ALTER USER trident PASSWORD '${DB_PASSWORD}';"
        log_warn "PostgreSQL user 'trident' already exists — password reset."
    fi

    local db_exists
    db_exists=$(sudo -u postgres psql -tAc "SELECT 1 FROM pg_database WHERE datname='trident'" 2>/dev/null || true)

    if [[ "${db_exists}" != "1" ]]; then
        sudo -u postgres psql -c "CREATE DATABASE trident OWNER trident;"
        log_ok "Database 'trident' created."
    else
        log_warn "Database 'trident' already exists."
    fi

    sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE trident TO trident;"

    # Configure pg_hba.conf for password auth on the trident database
    local PG_HBA="/etc/postgresql/16/main/pg_hba.conf"
    if ! grep -q "trident.*trident.*scram-sha-256" "${PG_HBA}" 2>/dev/null; then
        # Insert trident-specific rules before the first uncommented local/host line
        sed -i '/^local\s\+all\s\+all/i \
# TRIDENT application user\
local   trident         trident                                 scram-sha-256\
host    trident         trident         127.0.0.1/32            scram-sha-256' "${PG_HBA}"
        systemctl reload postgresql
        log_ok "pg_hba.conf updated for trident user."
    else
        log_warn "pg_hba.conf already configured for trident."
    fi

    # Save DATABASE_URL to config directory
    mkdir -p /etc/trident
    echo "DATABASE_URL=postgresql://trident:${DB_PASSWORD}@127.0.0.1:5432/trident" > /etc/trident/config.env
    chmod 600 /etc/trident/config.env
    chown root:root /etc/trident/config.env

    STEPS_COMPLETED+=("PostgreSQL 16")
    log_ok "PostgreSQL 16 configured. Connection string saved to /etc/trident/config.env"
}

# ===========================================================================
# STEP 6: Nginx
# ===========================================================================
step_nginx() {
    log_step "Step 6/13: Installing Nginx"

    export DEBIAN_FRONTEND=noninteractive

    if command -v nginx &>/dev/null; then
        log_warn "Nginx already installed — skipping."
    else
        apt-get install -y nginx
        log_ok "Nginx installed."
    fi

    systemctl enable nginx
    systemctl start nginx

    STEPS_COMPLETED+=("Nginx")
    log_ok "Nginx enabled and running."
}

# ===========================================================================
# STEP 7: Self-Signed SSL Certificate
# ===========================================================================
step_ssl_cert() {
    log_step "Step 7/13: Generating self-signed SSL certificate for ${LAN_IP}"

    if [[ -f /etc/ssl/trident/trident.crt && -f /etc/ssl/trident/trident.key ]]; then
        log_warn "SSL certificate already exists at /etc/ssl/trident/ — skipping."
        STEPS_COMPLETED+=("SSL Certificate")
        return
    fi

    mkdir -p /etc/ssl/trident

    # Generate a self-signed certificate valid for 10 years
    # SAN includes both DNS name and the detected LAN IP
    openssl req -x509 -nodes -days 3650 \
        -newkey rsa:2048 \
        -keyout /etc/ssl/trident/trident.key \
        -out /etc/ssl/trident/trident.crt \
        -subj "/C=US/ST=Local/L=Homelab/O=TRIDENT/CN=trident.local" \
        -addext "subjectAltName=DNS:trident.local,IP:${LAN_IP}"

    chmod 600 /etc/ssl/trident/trident.key
    chmod 644 /etc/ssl/trident/trident.crt

    STEPS_COMPLETED+=("SSL Certificate")
    log_ok "Self-signed certificate generated for IP ${LAN_IP}."
}

# ===========================================================================
# STEP 8: Nginx Configuration
# ===========================================================================
step_nginx_config() {
    log_step "Step 8/13: Writing Nginx reverse proxy configuration"

    cat > /etc/nginx/sites-available/trident <<'NGINX'
# TRIDENT AI Platform — Nginx reverse proxy configuration
# Auto-generated by trident-bootstrap.sh

upstream trident_backend {
    server 127.0.0.1:5000;
    keepalive 64;
}

# HTTP → HTTPS redirect
server {
    listen 80 default_server;
    listen [::]:80 default_server;
    server_name _;
    return 301 https://$host$request_uri;
}

# HTTPS — reverse proxy to Node.js app on port 5000
server {
    listen 443 ssl http2 default_server;
    listen [::]:443 ssl http2 default_server;
    server_name _;

    ssl_certificate     /etc/ssl/trident/trident.crt;
    ssl_certificate_key /etc/ssl/trident/trident.key;

    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers HIGH:!aNULL:!MD5:!RC4;
    ssl_prefer_server_ciphers on;
    ssl_session_cache shared:SSL:10m;
    ssl_session_timeout 10m;

    add_header X-Frame-Options SAMEORIGIN always;
    add_header X-Content-Type-Options nosniff always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;

    client_max_body_size 50M;

    location / {
        proxy_pass http://trident_backend;
        proxy_set_header Host              $host;
        proxy_set_header X-Real-IP         $remote_addr;
        proxy_set_header X-Forwarded-For   $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;

        proxy_http_version 1.1;
        proxy_set_header Upgrade    $http_upgrade;
        proxy_set_header Connection "upgrade";

        proxy_connect_timeout 60s;
        proxy_send_timeout    120s;
        proxy_read_timeout    120s;
    }

    location /assets/ {
        alias /opt/trident/dist/assets/;
        expires 30d;
        add_header Cache-Control "public, immutable";
        access_log off;
    }
}
NGINX

    # Enable site, remove default
    rm -f /etc/nginx/sites-enabled/default
    ln -sf /etc/nginx/sites-available/trident /etc/nginx/sites-enabled/trident

    # Test and reload
    nginx -t
    systemctl reload nginx

    STEPS_COMPLETED+=("Nginx Config")
    log_ok "Nginx configured as reverse proxy to localhost:5000 with SSL."
}

# ===========================================================================
# STEP 9: UFW Firewall
# ===========================================================================
step_ufw() {
    log_step "Step 9/13: Configuring UFW firewall"

    # Allow required ports
    ufw allow 22/tcp comment 'SSH'
    ufw allow 80/tcp comment 'HTTP redirect'
    ufw allow 443/tcp comment 'HTTPS'

    # Enable non-interactively (--force skips the confirmation prompt)
    ufw --force enable

    STEPS_COMPLETED+=("UFW Firewall")
    log_ok "UFW enabled — ports 22, 80, 443 open."
}

# ===========================================================================
# STEP 10: Ollama
# ===========================================================================
step_ollama() {
    log_step "Step 10/13: Installing Ollama"

    if command -v ollama &>/dev/null; then
        log_warn "Ollama already installed — skipping."
    else
        curl -fsSL https://ollama.com/install.sh | sh
        log_ok "Ollama installed."
    fi

    # Ensure the systemd service is enabled and started
    if systemctl list-unit-files | grep -q ollama.service; then
        systemctl enable ollama
        systemctl start ollama
        log_ok "Ollama systemd service enabled and started."
    else
        log_warn "Ollama systemd service not found — creating manually."

        # Create ollama user if needed
        if ! id -u ollama &>/dev/null; then
            useradd -r -s /bin/false -m -d /usr/share/ollama ollama
        fi

        cat > /etc/systemd/system/ollama.service <<'EOF'
[Unit]
Description=Ollama Server
After=network-online.target

[Service]
ExecStart=/usr/local/bin/ollama serve
User=ollama
Group=ollama
Restart=always
RestartSec=3
Environment="PATH=/usr/local/bin:/usr/bin:/bin"

[Install]
WantedBy=multi-user.target
EOF
        systemctl daemon-reload
        systemctl enable ollama
        systemctl start ollama
        log_ok "Ollama systemd service created and started."
    fi

    STEPS_COMPLETED+=("Ollama")
}

# ===========================================================================
# STEP 11: App Directories
# ===========================================================================
step_directories() {
    log_step "Step 11/13: Creating application directories"

    # /opt/trident — application code
    mkdir -p /opt/trident
    chown trident:trident /opt/trident

    # /etc/trident — configuration (already created in PostgreSQL step)
    mkdir -p /etc/trident
    chmod 750 /etc/trident

    # /var/log/trident — application logs (optional, journald is primary)
    mkdir -p /var/log/trident
    chown trident:trident /var/log/trident

    STEPS_COMPLETED+=("Directories")
    log_ok "Directories created: /opt/trident, /etc/trident, /var/log/trident"
}

# ===========================================================================
# STEP 12: Generate JWT_SECRET and finalize config.env
# ===========================================================================
step_config_env() {
    log_step "Step 12/13: Generating JWT_SECRET and finalizing config.env"

    JWT_SECRET_VALUE=$(openssl rand -hex 32)

    # Read existing DATABASE_URL from config.env (set during PostgreSQL step)
    local db_url=""
    if [[ -f /etc/trident/config.env ]]; then
        db_url=$(grep '^DATABASE_URL=' /etc/trident/config.env | head -1 || true)
    fi

    # If DATABASE_URL is empty, construct it (shouldn't happen if steps ran in order)
    if [[ -z "${db_url}" ]]; then
        db_url="DATABASE_URL=postgresql://trident:CHANGE_ME@127.0.0.1:5432/trident"
        log_warn "DATABASE_URL not found — using placeholder. Update /etc/trident/config.env manually."
    fi

    cat > /etc/trident/config.env <<EOF
# TRIDENT AI Platform — Environment Configuration
# Auto-generated by trident-bootstrap.sh on $(date -Iseconds)

# PostgreSQL connection string
${db_url}

# JWT secret for session token signing
JWT_SECRET=${JWT_SECRET_VALUE}

# Application port (Nginx reverse-proxies to this port)
PORT=5000

# Runtime environment
NODE_ENV=production
EOF

    chmod 600 /etc/trident/config.env
    chown root:root /etc/trident/config.env

    STEPS_COMPLETED+=("Config Env")
    log_ok "JWT_SECRET generated. /etc/trident/config.env finalized."
}

# ===========================================================================
# STEP 13: Systemd Service for TRIDENT
# ===========================================================================
step_systemd_service() {
    log_step "Step 13/13: Writing trident.service systemd unit"

    # Determine the Node.js binary path (NodeSource installs to /usr/bin/node)
    local node_path="/usr/bin/node"
    if [[ ! -x "${node_path}" ]]; then
        node_path=$(command -v node || echo "/usr/bin/node")
    fi

    cat > /etc/systemd/system/trident.service <<EOF
[Unit]
Description=TRIDENT AI Platform
After=network.target postgresql.service
Requires=postgresql.service

[Service]
Type=simple
User=trident
Group=trident
WorkingDirectory=/opt/trident

# Load environment variables from the config file
EnvironmentFile=/etc/trident/config.env

# Start the TRIDENT application
ExecStart=${node_path} dist/index.cjs

# Restart policy — always restart on failure with a 10-second delay
Restart=always
RestartSec=10

# Security hardening
NoNewPrivileges=true
ProtectSystem=strict
ProtectHome=true
ReadWritePaths=/opt/trident /var/log/trident

# Logging
StandardOutput=journal
StandardError=journal
SyslogIdentifier=trident

[Install]
WantedBy=multi-user.target
EOF

    # Reload and enable (but do NOT start — app code not deployed yet)
    systemctl daemon-reload
    systemctl enable trident

    STEPS_COMPLETED+=("Systemd Service")
    log_ok "trident.service written and enabled (not started — deploy app first)."
}

# ===========================================================================
# Completion Summary
# ===========================================================================
print_summary() {
    echo ""
    echo -e "${CYAN}${BOLD}╔══════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${CYAN}${BOLD}║          TRIDENT Phase 1 Bootstrap — Summary                ║${NC}"
    echo -e "${CYAN}${BOLD}╠══════════════════════════════════════════════════════════════╣${NC}"

    # Collect version info
    local node_ver="N/A"
    local npm_ver="N/A"
    local python_ver="N/A"
    local pg_ver="N/A"
    local nginx_ver="N/A"
    local ollama_ver="N/A"

    command -v node    &>/dev/null && node_ver=$(node --version 2>/dev/null || echo "N/A")
    command -v npm     &>/dev/null && npm_ver=$(npm --version 2>/dev/null || echo "N/A")
    command -v python3 &>/dev/null && python_ver=$(python3 --version 2>&1 | awk '{print $2}')
    command -v psql    &>/dev/null && pg_ver=$(psql --version 2>/dev/null | awk '{print $3}' || echo "N/A")
    command -v nginx   &>/dev/null && nginx_ver=$(nginx -v 2>&1 | awk -F/ '{print $2}' || echo "N/A")
    command -v ollama  &>/dev/null && ollama_ver=$(ollama --version 2>/dev/null | awk '{print $NF}' || echo "N/A")

    local components=(
        "System Update"
        "Base Packages"
        "Node.js 20 LTS"
        "Python 3"
        "PostgreSQL 16"
        "Nginx"
        "SSL Certificate"
        "Nginx Config"
        "UFW Firewall"
        "Ollama"
        "Directories"
        "Config Env"
        "Systemd Service"
    )

    for comp in "${components[@]}"; do
        local status="${RED}✗${NC}"
        for done in "${STEPS_COMPLETED[@]}"; do
            if [[ "${done}" == "${comp}" ]]; then
                status="${GREEN}✓${NC}"
                break
            fi
        done
        printf "  ${CYAN}║${NC}  %b  %-50s ${CYAN}║${NC}\n" "${status}" "${comp}"
    done

    echo -e "${CYAN}${BOLD}╠══════════════════════════════════════════════════════════════╣${NC}"
    printf "  ${CYAN}║${NC}  %-56s  ${CYAN}║${NC}\n" "Versions:"
    printf "  ${CYAN}║${NC}    Node.js:    %-43s  ${CYAN}║${NC}\n" "${node_ver}"
    printf "  ${CYAN}║${NC}    npm:        %-43s  ${CYAN}║${NC}\n" "${npm_ver}"
    printf "  ${CYAN}║${NC}    Python:     %-43s  ${CYAN}║${NC}\n" "${python_ver}"
    printf "  ${CYAN}║${NC}    PostgreSQL: %-43s  ${CYAN}║${NC}\n" "${pg_ver}"
    printf "  ${CYAN}║${NC}    Nginx:      %-43s  ${CYAN}║${NC}\n" "${nginx_ver}"
    printf "  ${CYAN}║${NC}    Ollama:     %-43s  ${CYAN}║${NC}\n" "${ollama_ver}"
    echo -e "${CYAN}${BOLD}╠══════════════════════════════════════════════════════════════╣${NC}"
    printf "  ${CYAN}║${NC}  %-56s  ${CYAN}║${NC}\n" "Server LAN IP:  ${LAN_IP}"
    printf "  ${CYAN}║${NC}  %-56s  ${CYAN}║${NC}\n" "Config file:    /etc/trident/config.env"
    printf "  ${CYAN}║${NC}  %-56s  ${CYAN}║${NC}\n" "SSL cert:       /etc/ssl/trident/trident.crt"
    printf "  ${CYAN}║${NC}  %-56s  ${CYAN}║${NC}\n" "App directory:  /opt/trident"
    echo -e "${CYAN}${BOLD}╠══════════════════════════════════════════════════════════════╣${NC}"
    printf "  ${CYAN}║${NC}  ${BOLD}%-56s${NC}  ${CYAN}║${NC}\n" "Next Steps:"
    printf "  ${CYAN}║${NC}  %-56s  ${CYAN}║${NC}\n" "  1. Deploy app to /opt/trident (git clone or scp)"
    printf "  ${CYAN}║${NC}  %-56s  ${CYAN}║${NC}\n" "  2. cd /opt/trident && npm install --production"
    printf "  ${CYAN}║${NC}  %-56s  ${CYAN}║${NC}\n" "  3. npm run build"
    printf "  ${CYAN}║${NC}  %-56s  ${CYAN}║${NC}\n" "  4. sudo systemctl start trident"
    printf "  ${CYAN}║${NC}  %-56s  ${CYAN}║${NC}\n" "  5. Browse to https://${LAN_IP}"
    printf "  ${CYAN}║${NC}  %-56s  ${CYAN}║${NC}\n" "  6. Run trident-verify.sh to confirm everything"
    echo -e "${CYAN}${BOLD}╚══════════════════════════════════════════════════════════════╝${NC}"
    echo ""
}

# ===========================================================================
# Main
# ===========================================================================
main() {
    print_header
    check_root
    detect_ip

    step_system_update      # Step  1
    step_base_packages      # Step  2
    step_nodejs             # Step  3
    step_python             # Step  4
    step_postgresql         # Step  5
    step_nginx              # Step  6
    step_ssl_cert           # Step  7
    step_nginx_config       # Step  8
    step_ufw                # Step  9
    step_ollama             # Step 10
    step_directories        # Step 11
    step_config_env         # Step 12
    step_systemd_service    # Step 13

    print_summary

    echo -e "${GREEN}${BOLD}[ TRIDENT ] Bootstrap complete. Server is ready for app deployment.${NC}\n"
}

main "$@"
```

### 12.2 trident-verify.sh

```bash
#!/usr/bin/env bash
# =============================================================================
# TRIDENT AI Platform — Post-Deployment Verification Script
# Run AFTER deploying the app and starting the trident service.
# Usage:  sudo ./trident-verify.sh
# =============================================================================

set -uo pipefail

# ---------------------------------------------------------------------------
# ANSI color codes
# ---------------------------------------------------------------------------
GREEN='\033[0;32m'
RED='\033[0;31m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m'

# ---------------------------------------------------------------------------
# Counters
# ---------------------------------------------------------------------------
PASS_COUNT=0
FAIL_COUNT=0
TOTAL_CHECKS=10

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
print_header() {
    echo ""
    echo -e "${CYAN}${BOLD}╔══════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${CYAN}${BOLD}║        TRIDENT Phase 1 — Verification Suite                 ║${NC}"
    echo -e "${CYAN}${BOLD}╚══════════════════════════════════════════════════════════════╝${NC}"
    echo ""
}

check_pass() {
    local label="$1"
    local detail="${2:-}"
    PASS_COUNT=$((PASS_COUNT + 1))
    printf "  ${GREEN}PASS${NC}  %-40s %s\n" "${label}" "${detail}"
}

check_fail() {
    local label="$1"
    local detail="${2:-}"
    FAIL_COUNT=$((FAIL_COUNT + 1))
    printf "  ${RED}FAIL${NC}  %-40s %s\n" "${label}" "${detail}"
}

# ---------------------------------------------------------------------------
# Check 1: Node.js version
# ---------------------------------------------------------------------------
check_nodejs() {
    local label="Node.js 20 LTS"
    if command -v node &>/dev/null; then
        local ver
        ver=$(node --version 2>/dev/null || echo "unknown")
        if [[ "${ver}" == v20.* ]]; then
            check_pass "${label}" "${ver}"
        else
            check_fail "${label}" "Found ${ver}, expected v20.x"
        fi
    else
        check_fail "${label}" "node binary not found"
    fi
}

# ---------------------------------------------------------------------------
# Check 2: npm available
# ---------------------------------------------------------------------------
check_npm() {
    local label="npm"
    if command -v npm &>/dev/null; then
        local ver
        ver=$(npm --version 2>/dev/null || echo "unknown")
        check_pass "${label}" "v${ver}"
    else
        check_fail "${label}" "npm binary not found"
    fi
}

# ---------------------------------------------------------------------------
# Check 3: PostgreSQL service running
# ---------------------------------------------------------------------------
check_postgresql_service() {
    local label="PostgreSQL service"
    if systemctl is-active --quiet postgresql 2>/dev/null; then
        local ver
        ver=$(psql --version 2>/dev/null | awk '{print $3}' || echo "unknown")
        check_pass "${label}" "active (v${ver})"
    else
        check_fail "${label}" "service not running"
    fi
}

# ---------------------------------------------------------------------------
# Check 4: trident database accessible
# ---------------------------------------------------------------------------
check_postgresql_db() {
    local label="trident database"
    # Read password from config.env if available
    if [[ -f /etc/trident/config.env ]]; then
        local db_url
        db_url=$(grep '^DATABASE_URL=' /etc/trident/config.env | head -1 | cut -d= -f2-)
        if [[ -n "${db_url}" ]]; then
            if psql "${db_url}" -c "SELECT 1;" &>/dev/null; then
                check_pass "${label}" "connection successful"
            else
                check_fail "${label}" "connection failed (check DATABASE_URL in config.env)"
            fi
            return
        fi
    fi
    # Fallback: try without explicit password
    if sudo -u postgres psql -d trident -c "SELECT 1;" &>/dev/null; then
        check_pass "${label}" "accessible via postgres user"
    else
        check_fail "${label}" "database not accessible"
    fi
}

# ---------------------------------------------------------------------------
# Check 5: Nginx service running
# ---------------------------------------------------------------------------
check_nginx() {
    local label="Nginx service"
    if systemctl is-active --quiet nginx 2>/dev/null; then
        local ver
        ver=$(nginx -v 2>&1 | awk -F/ '{print $2}' || echo "unknown")
        check_pass "${label}" "active (v${ver})"
    else
        check_fail "${label}" "service not running"
    fi
}

# ---------------------------------------------------------------------------
# Check 6: HTTPS responding
# ---------------------------------------------------------------------------
check_https() {
    local label="HTTPS endpoint"
    local http_code
    http_code=$(curl -sk -o /dev/null -w "%{http_code}" https://localhost/ 2>/dev/null || echo "000")
    if [[ "${http_code}" =~ ^(200|301|302|502)$ ]]; then
        if [[ "${http_code}" == "502" ]]; then
            check_pass "${label}" "Nginx responding (502 — app may not be running yet)"
        else
            check_pass "${label}" "HTTP ${http_code}"
        fi
    else
        check_fail "${label}" "HTTP ${http_code} (expected 200 or 502)"
    fi
}

# ---------------------------------------------------------------------------
# Check 7: TRIDENT systemd service
# ---------------------------------------------------------------------------
check_trident_service() {
    local label="trident.service"
    if systemctl is-active --quiet trident 2>/dev/null; then
        check_pass "${label}" "active (running)"
    elif systemctl is-enabled --quiet trident 2>/dev/null; then
        check_fail "${label}" "enabled but not running — start with: systemctl start trident"
    else
        check_fail "${label}" "not found or not enabled"
    fi
}

# ---------------------------------------------------------------------------
# Check 8: UFW active with correct rules
# ---------------------------------------------------------------------------
check_ufw() {
    local label="UFW firewall"
    local ufw_status
    ufw_status=$(ufw status 2>/dev/null || echo "")
    if echo "${ufw_status}" | grep -q "Status: active"; then
        local ports_ok=true
        for port in 22 80 443; do
            if ! echo "${ufw_status}" | grep -q "${port}/tcp"; then
                ports_ok=false
            fi
        done
        if ${ports_ok}; then
            check_pass "${label}" "active — ports 22, 80, 443 open"
        else
            check_fail "${label}" "active but missing required port rules"
        fi
    else
        check_fail "${label}" "UFW is not active"
    fi
}

# ---------------------------------------------------------------------------
# Check 9: Ollama installed
# ---------------------------------------------------------------------------
check_ollama() {
    local label="Ollama"
    if command -v ollama &>/dev/null; then
        local ver
        ver=$(ollama --version 2>/dev/null | awk '{print $NF}' || echo "unknown")
        if systemctl is-active --quiet ollama 2>/dev/null; then
            check_pass "${label}" "v${ver} — service running"
        else
            check_pass "${label}" "v${ver} — installed (service not running)"
        fi
    else
        check_fail "${label}" "ollama binary not found"
    fi
}

# ---------------------------------------------------------------------------
# Check 10: config.env exists and contains required keys
# ---------------------------------------------------------------------------
check_config() {
    local label="config.env"
    if [[ -f /etc/trident/config.env ]]; then
        local missing=""
        for key in DATABASE_URL JWT_SECRET PORT NODE_ENV; do
            if ! grep -q "^${key}=" /etc/trident/config.env; then
                missing="${missing} ${key}"
            fi
        done
        if [[ -z "${missing}" ]]; then
            check_pass "${label}" "all required keys present"
        else
            check_fail "${label}" "missing keys:${missing}"
        fi
    else
        check_fail "${label}" "/etc/trident/config.env not found"
    fi
}

# ---------------------------------------------------------------------------
# Summary
# ---------------------------------------------------------------------------
print_summary() {
    echo ""
    echo -e "${CYAN}${BOLD}──────────────────────────────────────────────────────────────${NC}"
    printf "  Results: ${GREEN}%d passed${NC} / ${RED}%d failed${NC} / %d total\n" \
        "${PASS_COUNT}" "${FAIL_COUNT}" "${TOTAL_CHECKS}"
    echo -e "${CYAN}${BOLD}──────────────────────────────────────────────────────────────${NC}"

    if [[ ${FAIL_COUNT} -eq 0 ]]; then
        echo -e "\n  ${GREEN}${BOLD}All checks passed. TRIDENT Phase 1 is fully operational.${NC}\n"
    else
        echo -e "\n  ${RED}${BOLD}${FAIL_COUNT} check(s) failed. Review output above and fix before proceeding.${NC}\n"
    fi
}

# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
main() {
    print_header

    check_nodejs                # 1
    check_npm                   # 2
    check_postgresql_service    # 3
    check_postgresql_db         # 4
    check_nginx                 # 5
    check_https                 # 6
    check_trident_service       # 7
    check_ufw                   # 8
    check_ollama                # 9
    check_config                # 10

    print_summary

    # Exit 0 only if all checks passed
    if [[ ${FAIL_COUNT} -eq 0 ]]; then
        exit 0
    else
        exit 1
    fi
}

main "$@"
```

---

*TRIDENT AI Platform — Phase 1 Setup Guide*  
*Last updated: March 2026*
