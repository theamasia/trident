#!/usr/bin/env bash
# =============================================================================
# TRIDENT AI Platform — Post-Deployment Verification Script
# Run AFTER deploying the app and starting the trident service.
# Usage:  sudo ./trident-verify.sh
# =============================================================================

set -uo pipefail

# ---------------------------------------------------------------------------
# ANSI color codes
# ---------------------------------------------------------------------------
GREEN='\033[0;32m'
RED='\033[0;31m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m'

# ---------------------------------------------------------------------------
# Counters
# ---------------------------------------------------------------------------
PASS_COUNT=0
FAIL_COUNT=0
TOTAL_CHECKS=10

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
print_header() {
    echo ""
    echo -e "${CYAN}${BOLD}╔══════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${CYAN}${BOLD}║        TRIDENT Phase 1 — Verification Suite                 ║${NC}"
    echo -e "${CYAN}${BOLD}╚══════════════════════════════════════════════════════════════╝${NC}"
    echo ""
}

check_pass() {
    local label="$1"
    local detail="${2:-}"
    PASS_COUNT=$((PASS_COUNT + 1))
    printf "  ${GREEN}PASS${NC}  %-40s %s\n" "${label}" "${detail}"
}

check_fail() {
    local label="$1"
    local detail="${2:-}"
    FAIL_COUNT=$((FAIL_COUNT + 1))
    printf "  ${RED}FAIL${NC}  %-40s %s\n" "${label}" "${detail}"
}

# ---------------------------------------------------------------------------
# Check 1: Node.js version
# ---------------------------------------------------------------------------
check_nodejs() {
    local label="Node.js 20 LTS"
    if command -v node &>/dev/null; then
        local ver
        ver=$(node --version 2>/dev/null || echo "unknown")
        if [[ "${ver}" == v20.* ]]; then
            check_pass "${label}" "${ver}"
        else
            check_fail "${label}" "Found ${ver}, expected v20.x"
        fi
    else
        check_fail "${label}" "node binary not found"
    fi
}

# ---------------------------------------------------------------------------
# Check 2: npm available
# ---------------------------------------------------------------------------
check_npm() {
    local label="npm"
    if command -v npm &>/dev/null; then
        local ver
        ver=$(npm --version 2>/dev/null || echo "unknown")
        check_pass "${label}" "v${ver}"
    else
        check_fail "${label}" "npm binary not found"
    fi
}

# ---------------------------------------------------------------------------
# Check 3: PostgreSQL service running
# ---------------------------------------------------------------------------
check_postgresql_service() {
    local label="PostgreSQL service"
    if systemctl is-active --quiet postgresql 2>/dev/null; then
        local ver
        ver=$(psql --version 2>/dev/null | awk '{print $3}' || echo "unknown")
        check_pass "${label}" "active (v${ver})"
    else
        check_fail "${label}" "service not running"
    fi
}

# ---------------------------------------------------------------------------
# Check 4: trident database accessible
# ---------------------------------------------------------------------------
check_postgresql_db() {
    local label="trident database"
    # Read password from config.env if available
    if [[ -f /etc/trident/config.env ]]; then
        local db_url
        db_url=$(grep '^DATABASE_URL=' /etc/trident/config.env | head -1 | cut -d= -f2-)
        if [[ -n "${db_url}" ]]; then
            if psql "${db_url}" -c "SELECT 1;" &>/dev/null; then
                check_pass "${label}" "connection successful"
            else
                check_fail "${label}" "connection failed (check DATABASE_URL in config.env)"
            fi
            return
        fi
    fi
    # Fallback: try without explicit password
    if sudo -u postgres psql -d trident -c "SELECT 1;" &>/dev/null; then
        check_pass "${label}" "accessible via postgres user"
    else
        check_fail "${label}" "database not accessible"
    fi
}

# ---------------------------------------------------------------------------
# Check 5: Nginx service running
# ---------------------------------------------------------------------------
check_nginx() {
    local label="Nginx service"
    if systemctl is-active --quiet nginx 2>/dev/null; then
        local ver
        ver=$(nginx -v 2>&1 | awk -F/ '{print $2}' || echo "unknown")
        check_pass "${label}" "active (v${ver})"
    else
        check_fail "${label}" "service not running"
    fi
}

# ---------------------------------------------------------------------------
# Check 6: HTTPS responding
# ---------------------------------------------------------------------------
check_https() {
    local label="HTTPS endpoint"
    local http_code
    http_code=$(curl -sk -o /dev/null -w "%{http_code}" https://localhost/ 2>/dev/null || echo "000")
    if [[ "${http_code}" =~ ^(200|301|302|502)$ ]]; then
        if [[ "${http_code}" == "502" ]]; then
            check_pass "${label}" "Nginx responding (502 — app may not be running yet)"
        else
            check_pass "${label}" "HTTP ${http_code}"
        fi
    else
        check_fail "${label}" "HTTP ${http_code} (expected 200 or 502)"
    fi
}

# ---------------------------------------------------------------------------
# Check 7: TRIDENT systemd service
# ---------------------------------------------------------------------------
check_trident_service() {
    local label="trident.service"
    if systemctl is-active --quiet trident 2>/dev/null; then
        check_pass "${label}" "active (running)"
    elif systemctl is-enabled --quiet trident 2>/dev/null; then
        check_fail "${label}" "enabled but not running — start with: systemctl start trident"
    else
        check_fail "${label}" "not found or not enabled"
    fi
}

# ---------------------------------------------------------------------------
# Check 8: UFW active with correct rules
# ---------------------------------------------------------------------------
check_ufw() {
    local label="UFW firewall"
    local ufw_status
    ufw_status=$(ufw status 2>/dev/null || echo "")
    if echo "${ufw_status}" | grep -q "Status: active"; then
        local ports_ok=true
        for port in 22 80 443; do
            if ! echo "${ufw_status}" | grep -q "${port}/tcp"; then
                ports_ok=false
            fi
        done
        if ${ports_ok}; then
            check_pass "${label}" "active — ports 22, 80, 443 open"
        else
            check_fail "${label}" "active but missing required port rules"
        fi
    else
        check_fail "${label}" "UFW is not active"
    fi
}

# ---------------------------------------------------------------------------
# Check 9: Ollama installed
# ---------------------------------------------------------------------------
check_ollama() {
    local label="Ollama"
    if command -v ollama &>/dev/null; then
        local ver
        ver=$(ollama --version 2>/dev/null | awk '{print $NF}' || echo "unknown")
        if systemctl is-active --quiet ollama 2>/dev/null; then
            check_pass "${label}" "v${ver} — service running"
        else
            check_pass "${label}" "v${ver} — installed (service not running)"
        fi
    else
        check_fail "${label}" "ollama binary not found"
    fi
}

# ---------------------------------------------------------------------------
# Check 10: config.env exists and contains required keys
# ---------------------------------------------------------------------------
check_config() {
    local label="config.env"
    if [[ -f /etc/trident/config.env ]]; then
        local missing=""
        for key in DATABASE_URL JWT_SECRET PORT NODE_ENV; do
            if ! grep -q "^${key}=" /etc/trident/config.env; then
                missing="${missing} ${key}"
            fi
        done
        if [[ -z "${missing}" ]]; then
            check_pass "${label}" "all required keys present"
        else
            check_fail "${label}" "missing keys:${missing}"
        fi
    else
        check_fail "${label}" "/etc/trident/config.env not found"
    fi
}

# ---------------------------------------------------------------------------
# Summary
# ---------------------------------------------------------------------------
print_summary() {
    echo ""
    echo -e "${CYAN}${BOLD}──────────────────────────────────────────────────────────────${NC}"
    printf "  Results: ${GREEN}%d passed${NC} / ${RED}%d failed${NC} / %d total\n" \
        "${PASS_COUNT}" "${FAIL_COUNT}" "${TOTAL_CHECKS}"
    echo -e "${CYAN}${BOLD}──────────────────────────────────────────────────────────────${NC}"

    if [[ ${FAIL_COUNT} -eq 0 ]]; then
        echo -e "\n  ${GREEN}${BOLD}All checks passed. TRIDENT Phase 1 is fully operational.${NC}\n"
    else
        echo -e "\n  ${RED}${BOLD}${FAIL_COUNT} check(s) failed. Review output above and fix before proceeding.${NC}\n"
    fi
}

# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
main() {
    print_header

    check_nodejs                # 1
    check_npm                   # 2
    check_postgresql_service    # 3
    check_postgresql_db         # 4
    check_nginx                 # 5
    check_https                 # 6
    check_trident_service       # 7
    check_ufw                   # 8
    check_ollama                # 9
    check_config                # 10

    print_summary

    # Exit 0 only if all checks passed
    if [[ ${FAIL_COUNT} -eq 0 ]]; then
        exit 0
    else
        exit 1
    fi
}

main "$@"
